from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from email.parser import BytesParser
from email.policy import default as email_policy
import mimetypes, re, shutil
from pathlib import Path
from datetime import date, datetime
import json, os, html, uuid, subprocess, sys

CORPORATE_THEME_CSS = r"""
:root{
 --cyber-bg:#05080d;--cyber-bg2:#09111a;--cyber-panel:#0d1721;--cyber-panel2:#111f2b;
 --cyber-line:#1e3b4c;--cyber-line-hot:#00c8ff;--cyber-red:#ec0000;--cyber-red2:#ff3347;
 --cyber-cyan:#00c8ff;--cyber-green:#24e6a1;--cyber-amber:#ffbf3f;--cyber-text:#e8f3f8;
 --cyber-muted:#8ba5b4;--cyber-shadow:0 14px 40px rgba(0,0,0,.38);
 --brand-font:"Segoe UI",Arial,sans-serif;--body-font:"Segoe UI",Arial,sans-serif;
}
*{box-sizing:border-box}html{background:var(--cyber-bg)}html,body{font-family:var(--body-font)!important}
body{background:radial-gradient(circle at 85% -10%,rgba(0,200,255,.10),transparent 34%),radial-gradient(circle at 5% 0%,rgba(236,0,0,.10),transparent 30%),linear-gradient(145deg,var(--cyber-bg),var(--cyber-bg2) 55%,#05090e)!important;color:var(--cyber-text)!important;min-height:100vh}
body:before{content:"";position:fixed;inset:0;pointer-events:none;z-index:-1;background-image:linear-gradient(rgba(255,255,255,.018) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.018) 1px,transparent 1px);background-size:32px 32px;mask-image:linear-gradient(to bottom,black,transparent 88%)}
header{min-height:72px!important;height:auto!important;padding:10px 22px!important;background:linear-gradient(90deg,rgba(8,15,22,.98),rgba(12,25,35,.98))!important;color:var(--cyber-text)!important;border:0!important;border-bottom:1px solid rgba(0,200,255,.35)!important;box-shadow:0 8px 28px rgba(0,0,0,.35)!important;position:sticky!important;top:0!important;z-index:30!important}
header:after{content:"";position:absolute;left:0;right:0;bottom:-1px;height:2px;background:linear-gradient(90deg,var(--cyber-red),transparent 26%,var(--cyber-cyan) 70%,transparent);opacity:.9}
.brand{color:var(--cyber-text)!important;font-size:19px!important;font-weight:700!important;letter-spacing:.4px!important;text-transform:none;display:flex!important;align-items:center!important;gap:12px!important}
.brand img,.brand-logo{width:45px!important;height:45px!important;object-fit:contain!important;filter:drop-shadow(0 0 10px rgba(236,0,0,.45))}
.brand::before{display:none!important}.brand small{color:var(--cyber-cyan)!important}
.shell{min-height:calc(100vh - 72px)!important}.shell aside,aside{background:linear-gradient(180deg,rgba(10,18,27,.97),rgba(7,13,20,.98))!important;border:0!important;border-right:1px solid rgba(0,200,255,.20)!important;box-shadow:8px 0 26px rgba(0,0,0,.2)!important}
aside nav a,nav a{position:relative;color:#a9bfca!important;border:1px solid transparent!important;border-radius:6px!important;letter-spacing:.2px!important;transition:background .16s ease,border-color .16s ease,color .16s ease,transform .16s ease!important}
aside nav a:before,nav a:before{content:"";position:absolute;left:0;top:25%;bottom:25%;width:2px;background:transparent;box-shadow:none}
aside nav a:hover,nav a:hover{background:rgba(0,200,255,.07)!important;color:#fff!important;border-color:rgba(0,200,255,.24)!important;transform:translateX(2px)}
aside nav a.active,nav a.active{background:linear-gradient(90deg,rgba(236,0,0,.20),rgba(0,200,255,.07))!important;color:#fff!important;border-color:rgba(236,0,0,.42)!important;border-left:1px solid rgba(236,0,0,.42)!important;font-weight:700!important;box-shadow:inset 3px 0 0 var(--cyber-red),0 0 18px rgba(236,0,0,.08)!important}
aside nav a.active:before{background:var(--cyber-red);box-shadow:0 0 10px var(--cyber-red)}.aside-note{color:#607d8c!important;border-color:rgba(0,200,255,.12)!important}
main{color:var(--cyber-text)!important}main h1,main h2,.page-title{color:#f2f8fb!important;letter-spacing:.25px!important}main h2:after{content:"";display:block;width:42px;height:2px;margin-top:7px;background:linear-gradient(90deg,var(--cyber-red),var(--cyber-cyan));box-shadow:0 0 8px rgba(0,200,255,.35)}main h3{color:#dcecf3!important}
p,small,.muted,.page-head p,.stats span,.stat span{color:var(--cyber-muted)!important}a{color:var(--cyber-cyan)!important}a:hover{color:#7ee6ff!important}
.card,.panel,.widget,.stat,.tile,.project-card,.task-card,.wiki-card,.bau-card,section,.hero,.info-card,.form-card,.filters,.module-tabs,.health-row,.pending-chip,.import-dialog,.summary-row,.current-assets{background:linear-gradient(145deg,rgba(15,27,38,.96),rgba(9,18,27,.96))!important;border:1px solid rgba(77,133,158,.28)!important;border-radius:8px!important;box-shadow:var(--cyber-shadow)!important;color:var(--cyber-text)!important;backdrop-filter:blur(8px)}
.card:hover,.project-card:hover,.task-card:hover,.pending-chip:hover{border-color:rgba(0,200,255,.42)!important}.stat strong,.stats strong,.health-value{color:#fff!important;text-shadow:0 0 16px rgba(0,200,255,.18)}
.btn,.button,button,input[type=submit],input[type=button]{min-height:36px;font-family:var(--body-font)!important;border-radius:5px!important;border:1px solid rgba(0,200,255,.35)!important;background:linear-gradient(180deg,#142734,#0d1a24)!important;color:#dff7ff!important;box-shadow:inset 0 1px rgba(255,255,255,.04),0 5px 16px rgba(0,0,0,.22)!important;transition:.16s ease!important;text-decoration:none!important}
.btn:hover,.button:hover,button:hover,input[type=submit]:hover,input[type=button]:hover{border-color:var(--cyber-cyan)!important;color:#fff!important;box-shadow:0 0 15px rgba(0,200,255,.18)!important;transform:translateY(-1px)}
.btn.primary,.btn-primary,.button-primary,button.primary,input[type=submit],.word-template-action{background:linear-gradient(180deg,var(--cyber-red2),var(--cyber-red))!important;border-color:#ff4c5c!important;color:#fff!important;box-shadow:0 0 18px rgba(236,0,0,.20)!important}
.btn.primary:hover,.btn-primary:hover,button.primary:hover,input[type=submit]:hover{background:linear-gradient(180deg,#ff4a5b,#c90000)!important;border-color:#ff7280!important}.btn.danger{background:#551520!important;border-color:#a92b3a!important;color:#ffd9dd!important}.secondary,.cancel{background:linear-gradient(180deg,#172a36,#101c25)!important;color:#d9edf5!important}
input,select,textarea{background:#07111a!important;color:var(--cyber-text)!important;border:1px solid #294757!important;border-radius:5px!important;font-family:var(--body-font)!important}input::placeholder,textarea::placeholder{color:#587180!important}input:focus,select:focus,textarea:focus{border-color:var(--cyber-cyan)!important;outline:0!important;box-shadow:0 0 0 2px rgba(0,200,255,.13),0 0 18px rgba(0,200,255,.08)!important}select option{background:#0a151e;color:#e7f4f8}
table{background:transparent!important;border-color:#29414e!important;color:var(--cyber-text)!important}thead th,table th{background:linear-gradient(180deg,#172b38,#10202b)!important;color:#dff7ff!important;border-color:#294958!important;text-transform:uppercase;letter-spacing:.45px}td,th{border-color:rgba(64,105,125,.28)!important}tbody tr:nth-child(even){background:rgba(255,255,255,.018)!important}tbody tr:hover{background:rgba(0,200,255,.045)!important}td a,.project-card h3 a{color:var(--cyber-cyan)!important}
.badge,.chip,.tag,.person-chip,.doc-category,.pending-filter,.search-filters a{border-radius:999px!important;background:#122631!important;color:#aeeeff!important;border:1px solid rgba(0,200,255,.25)!important}.status-finalizado,.status-completada{background:rgba(36,230,161,.10)!important;color:var(--cyber-green)!important;border-color:rgba(36,230,161,.28)!important}.status-en-curso,.badge.en-curso{background:rgba(0,200,255,.10)!important;color:#65ddff!important}.status-bloqueada,.status-cancelado,.priority-critica,.priority-crítica{background:rgba(236,0,0,.13)!important;color:#ff7180!important;border-color:rgba(236,0,0,.3)!important}.priority-alta{background:rgba(255,191,63,.11)!important;color:var(--cyber-amber)!important}
.notice,.alert,.callout,.import-warning{background:rgba(0,200,255,.055)!important;color:#ccecf5!important;border:1px solid rgba(0,200,255,.20)!important;border-left:4px solid var(--cyber-cyan)!important}.bar,.progress{background:#071119!important}.bar span,.progress span{background:linear-gradient(90deg,var(--cyber-red),var(--cyber-cyan))!important;box-shadow:0 0 12px rgba(0,200,255,.35)}
pre,code,.code-block,.summary-details{background:#03090d!important;color:#8fffd1!important;border:1px solid rgba(36,230,161,.22)!important;font-family:Consolas,"Courier New",monospace!important;text-shadow:0 0 7px rgba(36,230,161,.12)}.activity-icon,.linked-doc-dot,.timeline-dot{background:var(--cyber-red)!important;color:#fff!important;box-shadow:0 0 12px rgba(236,0,0,.55)!important}.import-modal{background:rgba(0,4,8,.82)!important}.import-dialog-head,.import-dialog-actions{border-color:#29414e!important;background:#0c1821!important}
::-webkit-scrollbar{width:11px;height:11px}::-webkit-scrollbar-track{background:#071019}::-webkit-scrollbar-thumb{background:#24404f;border:2px solid #071019;border-radius:8px}::-webkit-scrollbar-thumb:hover{background:#356477}
@media(max-width:900px){header{position:relative!important}.shell aside,aside{border-right:0!important;border-bottom:1px solid rgba(0,200,255,.2)!important}}
@media print{body,html{background:#fff!important;color:#111!important}body:before{display:none!important}header,aside,.header-actions,.actions,.toolbar,footer{display:none!important}main{width:100%!important;max-width:none!important;margin:0!important;padding:0!important}.card,.panel,.widget,.stat,.tile,.project-card,.task-card,.wiki-card,.bau-card,section,.hero,.info-card,.form-card{background:#fff!important;color:#111!important;border-color:#ccc!important;box-shadow:none!important;backdrop-filter:none!important}h1,h2,h3,p,small,.muted{color:#111!important;text-shadow:none!important}table{color:#111!important;background:#fff!important}table th,thead th{background:#ec0000!important;color:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}td{color:#111!important}pre,code,.code-block{background:#f2f2f2!important;color:#111!important;text-shadow:none!important}}


/* V4.1 Cyber Command visual refinement */
:root{
 --cc41-surface:#0b1721;--cc41-surface2:#0f202c;--cc41-surface3:#132936;
 --cc41-border:rgba(56,151,190,.34);--cc41-glow:rgba(0,200,255,.16);
}
body{background:
 radial-gradient(ellipse at 85% 0%,rgba(0,184,230,.12),transparent 38%),
 radial-gradient(ellipse at 8% 8%,rgba(236,0,0,.10),transparent 32%),
 linear-gradient(135deg,#05080d 0%,#07131c 55%,#061019 100%)!important}
body:after{content:"";position:fixed;inset:72px 0 0 0;pointer-events:none;z-index:-1;opacity:.24;background:
 linear-gradient(90deg,transparent 49.8%,rgba(0,200,255,.07) 50%,transparent 50.2%),
 linear-gradient(transparent 49.8%,rgba(0,200,255,.055) 50%,transparent 50.2%);background-size:96px 96px}
header{min-height:64px!important;padding:7px 16px!important}
header .brand{font-size:20px!important;text-shadow:0 0 18px rgba(0,200,255,.10)}
header .header-actions,header .actions{display:flex!important;gap:8px!important;align-items:center!important}
header .brand:after{content:"SOC // SECURE";font-size:9px;line-height:1;padding:5px 8px;margin-left:8px;color:#78e8ff;border:1px solid rgba(0,200,255,.33);border-radius:999px;background:rgba(0,200,255,.06);letter-spacing:1.1px;font-weight:700}
main{animation:cc41Fade .22s ease-out}
@keyframes cc41Fade{from{opacity:.25;transform:translateY(3px)}to{opacity:1;transform:none}}
/* Never use bright white application cards */
.stat,.stats>*,.metric,.metric-card,.summary-card,.template-card,.template-item,.template-type,.template-option,.type-card,.quick-card,.category-card,.counter-card,.word-template-card,.document-card,.attachment-card,.upload-card,.link-card,.mail-card,.mail-block,.note-block,.callout-note,.preview-card,.word-preview,.preview-box,.white-card{
 background:linear-gradient(145deg,rgba(17,34,46,.98),rgba(8,18,27,.98))!important;
 color:#eaf7fb!important;border:1px solid var(--cc41-border)!important;
 box-shadow:inset 0 1px rgba(255,255,255,.035),0 13px 28px rgba(0,0,0,.30)!important}
.stat:hover,.template-card:hover,.template-item:hover,.type-card:hover,.word-template-card:hover{transform:translateY(-2px);border-color:rgba(0,200,255,.60)!important;box-shadow:0 0 0 1px rgba(0,200,255,.08),0 16px 34px rgba(0,0,0,.35),0 0 20px var(--cc41-glow)!important}
.stat strong,.metric strong,.summary-card strong,.counter-card strong{font-size:28px!important;color:#70e8ff!important;text-shadow:0 0 18px rgba(0,200,255,.27)!important}
.stat span,.metric span,.summary-card span,.counter-card span{color:#9db5c1!important}
/* Explicitly catch common pale blocks from legacy CSS */
main [style*="background:white"],main [style*="background: white"],main [style*="background:#fff"],main [style*="background: #fff"],main [style*="background:#f"],main [style*="background: #f"]{background:linear-gradient(145deg,#10212d,#0a1720)!important;color:#e8f4f8!important}
section,.panel,.card,.form-card,.filters,.module-tabs,.current-assets{position:relative;overflow:hidden}
section:before,.panel:before,.card:before,.form-card:before{content:"";position:absolute;left:0;top:0;width:85px;height:1px;background:linear-gradient(90deg,#ec0000,#00c8ff,transparent);box-shadow:0 0 10px rgba(0,200,255,.30)}
/* Controls: sharper command-console geometry */
.btn,.button,button,input[type=submit],input[type=button]{border-radius:4px!important;letter-spacing:.1px!important;font-weight:600!important}
.btn:active,.button:active,button:active{transform:translateY(1px)!important}
.btn.primary,.btn-primary,button.primary,input[type=submit]{clip-path:polygon(7px 0,100% 0,100% calc(100% - 7px),calc(100% - 7px) 100%,0 100%,0 7px)}
/* Editor and technical blocks */
textarea,.editor-textarea,.editor-area,[contenteditable="true"]{background:#030d14!important;color:#e9f6fa!important;caret-color:#00d7ff!important}
pre,.code-block,.code-panel,.text-block{position:relative!important;background:linear-gradient(180deg,#02090e,#061117)!important;border-color:rgba(36,230,161,.28)!important;box-shadow:inset 0 0 28px rgba(0,0,0,.52),0 10px 25px rgba(0,0,0,.22)!important}
pre:before,.code-block:before,.code-panel:before{content:"TERMINAL / READ ONLY";display:block;color:#64f6c1;font:700 9px/1.2 Consolas,monospace;letter-spacing:1.1px;margin:0 0 10px;padding-bottom:7px;border-bottom:1px solid rgba(36,230,161,.18)}
/* Tables */
table{border-collapse:separate!important;border-spacing:0!important;overflow:hidden;border:1px solid rgba(49,111,139,.30)!important;border-radius:6px!important}
thead th,table th{height:40px!important;background:linear-gradient(180deg,#173140,#10232f)!important;border-bottom:1px solid rgba(0,200,255,.40)!important}
tbody td{padding-top:11px!important;padding-bottom:11px!important}
tbody tr{transition:background .14s ease,box-shadow .14s ease}
tbody tr:hover{box-shadow:inset 3px 0 0 #00c8ff!important}
/* White content previews stay readable but become intentional document canvases */
.document-preview,.word-document,.page-preview,.preview-paper,.rendered-content,.mail-preview,.note-preview{
 background:#eaf0f3!important;color:#16242d!important;border:1px solid #91a6b0!important;
 box-shadow:inset 0 0 0 1px #fff,0 14px 32px rgba(0,0,0,.28)!important}
.document-preview *,.word-document *,.page-preview *,.preview-paper *,.rendered-content *,.mail-preview *,.note-preview *{color:inherit}
/* Side navigation */
aside nav a{min-height:40px!important;display:flex!important;align-items:center!important}
aside nav a.active:after{content:"";position:absolute;right:9px;width:5px;height:5px;border-radius:50%;background:#00d5ff;box-shadow:0 0 10px #00d5ff}
/* Image presentation */
main img:not(.brand-logo):not(.logo){border-radius:5px;outline:1px solid rgba(0,200,255,.22);box-shadow:0 16px 35px rgba(0,0,0,.36)}
/* Improve readability of labels over dark UI */
label,legend,.field-label{color:#d9e8ee!important;font-weight:650!important}
hr{border:0!important;height:1px!important;background:linear-gradient(90deg,transparent,rgba(0,200,255,.55),rgba(236,0,0,.35),transparent)!important}
@media (prefers-reduced-motion:reduce){main{animation:none}.stat,.template-card,.template-item,.type-card,.word-template-card{transition:none!important}}

/* V4.1.8 · Corrección global de contraste y fondos residuales */
:root{color-scheme:dark}

/* Superficies de aplicación: nunca blancas ni gris muy claro */
main .content,
main .content-card,
main .editor-card,
main .editor-shell,
main .editor-container,
main .editor-preview,
main .preview,
main .preview-content,
main .preview-area,
main .details-card,
main .detail-card,
main .metadata-card,
main .date-card,
main .template-list,
main .template-row,
main .template-box,
main .template-selector,
main .template-choice,
main .attachment-panel,
main .attachments-panel,
main .attachment-box,
main .link-box,
main .upload-box,
main .mail,
main .communication,
main .admonition,
main .note,
main .toolbar,
main .toolbar-menu-panel,
main details,
main summary,
main fieldset{
 background:linear-gradient(145deg,#10212d,#091720)!important;
 color:#e7f4f8!important;
 border-color:rgba(66,139,169,.38)!important;
}

/* Texto sobre superficies oscuras */
main .content,
main .content p,
main .content li,
main .content div,
main .content span,
main .content strong,
main .content em,
main .content label,
main .communication,
main .communication p,
main .communication div,
main .communication span,
main .admonition,
main .admonition p,
main .admonition div,
main .note,
main .note p,
main .note div,
main .toolbar,
main .toolbar label,
main .attachment-panel,
main .attachments-panel,
main .attachment-box,
main .link-box,
main .upload-box,
main .template-row,
main .template-box,
main .template-selector,
main .template-choice{
 color:#e7f4f8!important;
}
main .content small,main .communication small,main .admonition small,
main .attachment-panel small,main .attachments-panel small,
main .template-row small,main .template-box small{color:#91acb9!important}

/* Captura fondos blancos/grises heredados o inline en contenedores */
main :is(div,section,article,form,aside,fieldset)[style*="background:white"],
main :is(div,section,article,form,aside,fieldset)[style*="background: white"],
main :is(div,section,article,form,aside,fieldset)[style*="background:#fff"],
main :is(div,section,article,form,aside,fieldset)[style*="background: #fff"],
main :is(div,section,article,form,aside,fieldset)[style*="background:#FFF"],
main :is(div,section,article,form,aside,fieldset)[style*="background-color:white"],
main :is(div,section,article,form,aside,fieldset)[style*="background-color: white"],
main :is(div,section,article,form,aside,fieldset)[style*="background-color:#fff"],
main :is(div,section,article,form,aside,fieldset)[style*="background-color: #fff"]{
 background:linear-gradient(145deg,#10212d,#091720)!important;
 color:#e7f4f8!important;
 border-color:rgba(66,139,169,.38)!important;
}

/* Barras de herramientas y botones: contraste completo */
main .toolbar button,main .editor-toolbar button,main .toolbar-menu summary,
main .toolbar .btn,main .editor-toolbar .btn{
 background:linear-gradient(180deg,#19303e,#0c1b25)!important;
 color:#e8f7fb!important;
 border-color:#31586b!important;
}
main .toolbar button:hover,main .editor-toolbar button:hover,
main .toolbar-menu summary:hover{background:#173746!important;color:#fff!important;border-color:#00c8ff!important}
main button:disabled,main .btn:disabled{background:#12202a!important;color:#617985!important;border-color:#273d48!important;opacity:.72!important}

/* Campos y selectores, incluidos date/file/múltiples */
main input,main select,main textarea,main [contenteditable="true"]{
 background:#06131c!important;color:#edf9fc!important;border-color:#31586b!important;
}
main input[type="file"]{color:#a9c2ce!important;padding:7px!important}
main input[type="file"]::file-selector-button{
 background:#18303d!important;color:#e8f7fb!important;border:1px solid #3a6477!important;
 border-radius:4px;padding:7px 11px;margin-right:10px;cursor:pointer
}
main select[multiple],main option{background:#071721!important;color:#edf9fc!important}

/* Tablas y filas que todavía traían blanco del tema clásico */
main table,main tbody,main tr,main td{color:#dcecf3!important}
main tbody tr{background:#0b1923!important}
main tbody tr:nth-child(even){background:#0e1e29!important}
main tbody tr:hover{background:#112a38!important}

/* Tarjetas de métricas, plantillas, adjuntos y elementos de selección */
main :is(.stats>div,.group-card,.project-card,.task-card,.template-card,.template-item,
.template-type,.template-option,.word-template-card,.document-card,.attachment-card,
.upload-card,.link-card,.meta-grid>div,.calendar-day,.info-card,.form-card){
 background:linear-gradient(145deg,#10212d,#091720)!important;
 color:#e7f4f8!important;border-color:rgba(66,139,169,.38)!important;
}
main :is(.stats>div,.group-card,.project-card,.task-card,.template-card,.template-item,
.template-type,.template-option,.word-template-card,.document-card,.attachment-card,
.upload-card,.link-card,.meta-grid>div,.calendar-day,.info-card,.form-card) p{color:#9bb4c0!important}

/* Vistas deliberadamente claras (documento/Word/PDF): texto siempre oscuro */
main :is(.document-preview,.word-document,.page-preview,.preview-paper,.rendered-document,
.document-canvas,.paper-preview,.docx-preview){
 background:#f4f7f8!important;color:#17252e!important;border-color:#90a6b1!important;
}
main :is(.document-preview,.word-document,.page-preview,.preview-paper,.rendered-document,
.document-canvas,.paper-preview,.docx-preview) *{color:#17252e!important;text-shadow:none!important}
main :is(.document-preview,.word-document,.page-preview,.preview-paper,.rendered-document,
.document-canvas,.paper-preview,.docx-preview) a{color:#006b91!important}

/* Correos y notas se integran en el tema oscuro, evitando texto claro sobre blanco */
main :is(.mail-preview,.mail-block,.mail-card,.communication,.note-preview,.note-block,.callout-note){
 background:#0c1c27!important;color:#e7f4f8!important;border-color:#315565!important;
}
main :is(.mail-preview,.mail-block,.mail-card,.communication,.note-preview,.note-block,.callout-note) *{
 color:inherit!important;text-shadow:none!important
}
main :is(.mail-preview,.mail-block,.mail-card,.communication,.note-preview,.note-block,.callout-note) a{color:#58d9ff!important}

/* Mantener impresión y exportación en blanco, solo fuera de pantalla */
@media print{
 :root{color-scheme:light}
 main .content,main .communication,main .admonition,main .note,
 main .mail-preview,main .mail-block,main .mail-card,
 main .document-preview,main .word-document,main .page-preview,main .preview-paper{
  background:#fff!important;color:#111!important;border-color:#ccc!important
 }
 main .content *,main .communication *,main .admonition *,main .note *,
 main .mail-preview *,main .mail-block *,main .mail-card *,
 main .document-preview *,main .word-document *,main .page-preview *,main .preview-paper *{color:#111!important}
}


/* === V4.1.8 FORCE DARK UI — sin superficies blancas en pantalla === */
@media screen {
  :root{color-scheme:dark!important}
  html,body,.shell,main,.main,.content-area,.page-content,.workspace,.layout,.app-shell{
    background:#050d14!important;color:#e7f4f8!important
  }
  main{background-image:radial-gradient(circle at 85% 0,rgba(0,200,255,.055),transparent 31%),radial-gradient(circle at 0 30%,rgba(236,0,0,.045),transparent 28%)!important}
  main :is(section,article,div,form,fieldset,details,dialog,table,tbody,tr,td,ul,ol,li){
    border-color:rgba(73,125,148,.30)
  }
  main :is(.card,.panel,.widget,.tile,.stat,.stats>div,.summary-card,.metric,.metric-card,
  .template-card,.template-grid>a,.template-grid a,.template-item,.template-row,.template-box,
  .template-selector,.template-choice,.template-type,.template-option,.type-card,.quick-card,
  .category-card,.counter-card,.project-card,.task-card,.wiki-card,.bau-card,.info-card,.form-card,
  .document-card,.attachment-card,.upload-card,.link-card,.mail-card,.mail-block,.communication,
  .note,.note-block,.admonition,.callout,.callout-note,.preview-card,.word-preview,.preview-box,
  .document-preview,.word-document,.page-preview,.preview-paper,.rendered-document,.document-canvas,
  .paper-preview,.docx-preview,.template-preview-panel,.template-editor-panel,.number-preview,
  .filters,.module-tabs,.calendar-list,.calendar-day,.content,.viewer,.editor-preview,.white-card){
    background:linear-gradient(145deg,#0d1c26,#07131b)!important;
    color:#e7f4f8!important;
    border-color:rgba(69,132,158,.42)!important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.025),0 10px 26px rgba(0,0,0,.23)!important
  }
  main :is(.template-card,.template-grid>a,.template-grid a,.template-item,.template-row,.template-box,
  .template-selector,.template-choice,.word-template-card,.document-card,.attachment-card,.upload-card,.link-card) *{
    background-color:transparent!important;color:#dff3f9!important
  }
  main :is(.template-card,.template-grid>a,.template-grid a,.template-item,.template-row,.template-box,
  .template-selector,.template-choice) a{color:#18d2ff!important}
  main :is(h1,h2,h3,h4,h5,h6,strong,label,legend,dt,th){color:#f1f8fb!important}
  main :is(p,span,small,em,li,dd,.muted,.meta,.help-text,.description){color:#9fb8c4!important}
  main a{color:#22cff8!important}
  main table,main thead,main tbody,main tr,main td,main th{background-color:#091720!important;color:#dcecf3!important}
  main thead th,main table th{background:#122936!important;color:#eaf8fc!important}
  main tbody tr:nth-child(even){background:#0b1b25!important}
  main tbody tr:hover{background:#102936!important}
  main input,main select,main textarea,main option,main [contenteditable=true]{
    background:#06131c!important;color:#edf9fc!important;border-color:#31586b!important
  }
  main input::placeholder,main textarea::placeholder{color:#6f8996!important;opacity:1}
  main input[type=file]{background:#071721!important;color:#a9c2ce!important}
  main input[type=file]::file-selector-button{background:#132b38!important;color:#e8f7fb!important;border:1px solid #386277!important}
  main button,main .btn,main .button,main a.btn,main .page-actions a,main .page-actions button,
  main .manage-templates-button,main summary{
    background:linear-gradient(180deg,#142c39,#0a1922)!important;color:#e7f4f8!important;border-color:#31586b!important
  }
  main button:hover,main .btn:hover,main .button:hover,main a.btn:hover,main summary:hover{
    background:#173746!important;color:#fff!important;border-color:#00c8ff!important
  }
  main .primary,main .btn.primary,main .btn-primary,main input[type=submit],main .danger.primary{
    background:linear-gradient(180deg,#ff293b,#c90000)!important;color:#fff!important;border-color:#ff4c5c!important
  }
  main button:disabled,main .btn:disabled{background:#101e27!important;color:#647b86!important;border-color:#263b46!important;opacity:.75!important}
  main .editor-toolbar,main .toolbar{background:#0b1a24!important;color:#e7f4f8!important;border-color:#31586b!important}
  main pre,main code,main .code-wrap,main .code-head,main .code-box{background:#02090e!important;color:#a8ffd8!important}
  main .wiki-image img,main img.preview,main .image-preview{background:#07131b!important;border-color:#31586b!important}
  footer{background:#07131b!important;color:#8da7b3!important;border-color:#29414e!important}
}


/* === V4.1.8 ABSOLUTE DARK SURFACE LOCK === */
@media screen {
  :root { color-scheme: dark !important; }
  html, body { background:#050d14 !important; color:#e7f4f8 !important; }

  /* Ventanas, modales y paneles fuera de main */
  .modal, .modal-content, .dialog, .dialog-content, dialog,
  .import-modal, .import-dialog, .import-dialog-head, .import-dialog-body,
  .import-dialog-actions, .import-summary, .summary-grid, .summary-row,
  .summary-details, .overlay-panel, .popup, .popover, .dropdown-menu {
    background:#091722 !important;
    color:#e7f4f8 !important;
    border-color:#294b5d !important;
  }
  .import-modal { background:rgba(1,8,13,.82) !important; }
  .import-dialog { box-shadow:0 24px 70px rgba(0,0,0,.72) !important; }
  .import-dialog-head, .import-dialog-actions { background:#0c1c27 !important; }
  .import-dialog-head h2, .import-file-label, .import-mode-title,
  .import-option strong, .summary-row strong { color:#edf9fc !important; }
  .import-option {
    background:#0b1a24 !important;
    color:#bdd2dc !important;
    border-color:#31586b !important;
  }
  .import-option:has(input:checked) {
    background:linear-gradient(90deg,rgba(236,0,0,.15),rgba(0,200,255,.07)) !important;
    border-color:#ec3040 !important;
  }
  .import-option small { color:#91adba !important; }
  .import-warning {
    background:#102632 !important;
    color:#d7edf5 !important;
    border-color:#00c8ff !important;
  }
  .import-close, .import-dialog-actions .cancel {
    background:#122633 !important;
    color:#edf9fc !important;
    border-color:#31586b !important;
  }

  /* Opciones, tarjetas y filas: nunca blancas en pantalla */
  :is(main,.main,.content-area,.page-content,.workspace,.layout,.app-shell)
  :is(.card,.panel,.tile,.widget,.stat,.stats>div,.template-card,.template-item,
  .template-grid>a,.template-grid a,.template-option,.template-type,.project-card,
  .task-card,.info-card,.form-card,.attachment-card,.upload-card,.link-card,
  .mail-card,.mail-block,.communication,.note,.note-block,.admonition,.callout,
  .preview-card,.preview-box,.document-preview,.word-document,.page-preview,
  .preview-paper,.rendered-document,.document-canvas,.paper-preview,.docx-preview,
  .template-preview-panel,.template-editor-panel,.filters,.module-tabs,.calendar-day,
  .content,.viewer,.editor-preview,.white-card,.health-row,.pending-chip,.summary-row) {
    background:linear-gradient(145deg,#0d1c26,#07131b) !important;
    color:#e7f4f8 !important;
    border-color:rgba(63,123,148,.42) !important;
  }

  /* Cualquier estilo inline claro dentro de la aplicación */
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background:white"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background: white"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background:#fff"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background: #fff"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background-color:white"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background-color: white"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background-color:#fff"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background-color: #fff"] {
    background:#0b1a24 !important;
    color:#e7f4f8 !important;
  }

  input, select, textarea, [contenteditable="true"] {
    background:#06131c !important;
    color:#edf9fc !important;
    border-color:#31586b !important;
  }
  input::placeholder, textarea::placeholder { color:#6f8b98 !important; }
  option { background:#071721 !important; color:#edf9fc !important; }
  input[type="file"] { background:#06131c !important; color:#a9c2ce !important; }
  input[type="file"]::file-selector-button {
    background:#18303d !important; color:#edf9fc !important;
    border:1px solid #3a6477 !important;
  }

  table, thead, tbody, tr, th, td { border-color:#294959 !important; }
  tbody tr { background:#0a1822 !important; }
  tbody tr:nth-child(even) { background:#0d1d27 !important; }
  th { background:#112a38 !important; color:#eaf8fc !important; }
  td { color:#dcecf3 !important; }

  /* Botones secundarios claros heredados */
  button:not(.primary):not(.danger), .btn:not(.primary):not(.danger),
  a.button:not(.primary):not(.danger) {
    background:#102531 !important;
    color:#e8f7fb !important;
    border-color:#31586b !important;
  }
  button:disabled, .btn:disabled {
    background:#101c24 !important; color:#607985 !important;
    border-color:#263b46 !important; opacity:.78 !important;
  }
}

/* La salida impresa y los informes deben seguir siendo blancos */
@media print {
  :root { color-scheme: light !important; }
  html, body { background:#fff !important; color:#111 !important; }
}
"""

BASE=Path(__file__).resolve().parent
DATA=BASE/'data'; STATIC=BASE/'static'
PROJECTS=DATA/'projects.json'; TASKS=DATA/'tasks.json'; RESPONSIBLES=DATA/'responsibles.json'; ATTACHMENTS=DATA/'attachments'
DATA.mkdir(parents=True,exist_ok=True); STATIC.mkdir(parents=True,exist_ok=True); ATTACHMENTS.mkdir(parents=True,exist_ok=True)
WIKI_URL=os.environ.get('WIKI_URL','http://127.0.0.1:8080')
PORTAL_URL=os.environ.get('PORTAL_URL','http://127.0.0.1:8079')
BAU_URL=os.environ.get('BAU_URL','http://127.0.0.1:8082')
BITACORA_URL=os.environ.get('BITACORA_URL','http://127.0.0.1:8083')
BIBLIOTECA_URL=os.environ.get('BIBLIOTECA_URL','http://127.0.0.1:8084')
CAMBIOS_URL=os.environ.get('CAMBIOS_URL','http://127.0.0.1:8085')
WIKI_PAGES=BASE.parent/'wiki'/'data'/'pages'
BITACORA_DB=BASE.parent/'bitacora'/'data'/'entries.json'
BIBLIOTECA_DB=BASE.parent/'biblioteca'/'data'/'snippets.json'

def read_json(path, default):
    try: return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default
    except Exception: return default

def write_json(path, value):
    tmp=path.with_suffix('.tmp'); tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(path)

def esc(v): return html.escape(str(v or ''), quote=True)
def now(): return datetime.now().isoformat(timespec='seconds')
def uid(prefix): return prefix+'_'+uuid.uuid4().hex[:10]
def projects(): return read_json(PROJECTS, [])
def tasks(): return read_json(TASKS, [])
def responsibles(): return read_json(RESPONSIBLES, [])

def field_values(form, name):
    value=form.get(name, [])
    if isinstance(value, list): return [str(x) for x in value if str(x).strip()]
    return [str(value)] if str(value or '').strip() else []

def selected_responsibles(item):
    ids=item.get('responsible_ids', [])
    if isinstance(ids, str): ids=[ids] if ids else []
    if not ids and item.get('owner'):
        owner=str(item.get('owner')).strip().lower()
        ids=[r['id'] for r in responsibles() if str(r.get('name','')).strip().lower()==owner]
    return ids

def responsible_sort_key(person):
    name=str(person.get('name','')).strip()
    return (0 if name.casefold() in ('emailsecurity','mailsecurity') else 1, name.casefold())

def responsible_names(item):
    selected=set(selected_responsibles(item))
    people=sorted(responsibles(),key=responsible_sort_key)
    names=[r.get('name','') for r in people if r.get('id') in selected]
    if not names and item.get('owner'): names=[item.get('owner')]
    return [n for n in names if n]

def responsibles_badges(item):
    names=responsible_names(item)
    return ''.join(f'<span class="person-chip">{esc(n)}</span>' for n in names) or '<span class="muted">Sin asignar</span>'

def responsible_options(selected=None):
    chosen=set(selected or [])
    return ''.join(f'<option value="{esc(r.get("id"))}" {"selected" if r.get("id") in chosen else ""}>{esc(r.get("name"))}</option>' for r in sorted(responsibles(),key=responsible_sort_key))

def responsible_checkboxes(selected=None):
    chosen=set(selected or [])
    people=sorted(responsibles(),key=responsible_sort_key)
    if not people:
        return '<div class="responsible-empty">No hay responsables creados.</div>'
    return ''.join(
        f'<label class="responsible-check"><input type="checkbox" name="responsible_ids" value="{esc(r.get("id"))}" {"checked" if r.get("id") in chosen else ""}><span>{esc(r.get("name"))}</span></label>'
        for r in people
    )


def responsible_multiselect(selected=None, prefix='project'):
    chosen={str(x) for x in (selected or [])}
    people=sorted(responsibles(),key=responsible_sort_key)
    names=[str(r.get('name','')) for r in people if str(r.get('id')) in chosen and str(r.get('name',''))]
    summary=' · '.join(names) if names else 'Seleccionar responsables'
    checks=''.join(
        '<label class="responsible-menu-check"><input type="checkbox" class="responsible-menu-checkbox" '
        'name="responsible_ids" value="'+esc(r.get('id'))+'" data-responsible-name="'+esc(r.get('name'))+'" '
        +('checked' if str(r.get('id')) in chosen else '')+'><span>'+esc(r.get('name'))+'</span></label>'
        for r in people
    ) or '<div class="responsible-empty">No hay responsables creados.</div>'
    return (
        '<div class="responsible-dropdown-field"><span class="field-title">Responsables</span>'
        '<details class="responsible-multiselect" data-responsible-menu>'
        '<summary><span data-responsible-summary>'+esc(summary)+'</span><span class="responsible-arrow">▾</span></summary>'
        '<div class="responsible-menu-options">'+checks+'</div></details>'
        '<small>Seleccione uno o varios responsables.</small></div>'
    )


def safe_filename(name):
    name=Path(str(name or 'archivo')).name
    clean=re.sub(r'[^A-Za-z0-9._-]+','_',name).strip('._') or 'archivo'
    return clean[:140]

def open_local_file(path):
    path=Path(path).resolve()
    if not path.is_file():
        raise FileNotFoundError(f'No se encuentra el archivo: {path}')
    if os.name=='nt':
        os.startfile(str(path))
    elif sys.platform=='darwin':
        subprocess.Popen(['open',str(path)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    else:
        opener=shutil.which('xdg-open')
        if not opener:
            raise RuntimeError('No se encontró una aplicación para abrir el archivo.')
        subprocess.Popen([opener,str(path)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)

def attachment_icon(name):
    ext=Path(str(name or '')).suffix.lower()
    if ext in {'.jpg','.jpeg','.png','.gif','.bmp','.webp','.tif','.tiff'}: return '🖼️'
    if ext=='.pdf': return '📕'
    if ext in {'.doc','.docx','.odt','.rtf'}: return '📘'
    if ext in {'.xls','.xlsx','.xlsm','.csv','.ods'}: return '📗'
    if ext in {'.ppt','.pptx','.odp'}: return '📙'
    if ext in {'.zip','.rar','.7z'}: return '🗜️'
    if ext in {'.txt','.log','.json','.xml','.yaml','.yml','.md'}: return '📄'
    return '📎'

def save_upload(filename, content):
    ATTACHMENTS.mkdir(parents=True, exist_ok=True)
    original=safe_filename(filename)
    stored=uuid.uuid4().hex[:12]+'_'+original
    target=ATTACHMENTS/stored
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
    return {'name':original,'file':stored}

def delete_uploads(items):
    for item in items or []:
        stored=item.get('file','') if isinstance(item,dict) else ''
        if stored:
            try: (ATTACHMENTS/stored).unlink(missing_ok=True)
            except Exception: pass


def wiki_pages():
    items=[]
    try:
        WIKI_PAGES.mkdir(parents=True, exist_ok=True)
        for path in sorted(WIKI_PAGES.glob('*.json')):
            try:
                page=json.loads(path.read_text(encoding='utf-8'))
                slug=str(page.get('slug') or path.stem)
                title=str(page.get('title') or slug)
                items.append({'slug':slug,'title':title,'category':str(page.get('category') or '')})
            except Exception:
                continue
    except Exception:
        pass
    return items

def selected_wiki_pages(item):
    values=item.get('wiki_pages',[])
    if isinstance(values,str): values=[values] if values else []
    return [str(x) for x in values if str(x).strip()]

def wiki_page_options(selected=None):
    chosen=set(selected or [])
    pages=wiki_pages()
    if not pages:
        return '<option disabled>No hay páginas Wiki disponibles</option>'
    return ''.join(f'<option value="{esc(p["slug"])}" {"selected" if p["slug"] in chosen else ""}>{esc(p["title"])}{(" · "+esc(p["category"])) if p.get("category") else ""}</option>' for p in pages)

def wiki_links_html(item):
    slugs=selected_wiki_pages(item)
    if not slugs: return ''
    by_slug={p['slug']:p for p in wiki_pages()}
    rows=[]
    for slug in slugs:
        page=by_slug.get(slug,{'title':slug})
        rows.append(f'<li><a href="{esc(WIKI_URL)}/view?slug={esc(slug)}" target="_blank" rel="noopener">📘 {esc(page.get("title") or slug)}</a></li>')
    return '<ul class="attachment-list wiki-links">'+''.join(rows)+'</ul>'



def ensure_note_ids(history):
    changed=False
    for note in history or []:
        if not note.get('id'):
            note['id']=uid('note')
            changed=True
        note.setdefault('created', note.get('date') or now())
    return changed

def note_actions(kind, parent_id, note_id):
    return f'''<div class="note-actions"><a class="btn small" href="/{kind}/note/edit?id={esc(parent_id)}&note_id={esc(note_id)}">Editar</a><form class="inline" method="post" action="/{kind}/note/delete" onsubmit="return confirm('¿Eliminar este seguimiento?')"><input type="hidden" name="id" value="{esc(parent_id)}"><input type="hidden" name="note_id" value="{esc(note_id)}"><button class="btn small danger">Eliminar</button></form></div>'''

def note_form(kind, parent_id, note_id):
    collection=projects() if kind=='project' else tasks()
    parent=next((x for x in collection if x.get('id')==parent_id),None)
    if not parent:
        return layout('No encontrado','<h1>Elemento no encontrado</h1>','projects' if kind=='project' else 'tasks')
    history=parent.setdefault('history',[])
    changed=ensure_note_ids(history)
    if changed:
        write_json(PROJECTS if kind=='project' else TASKS,collection)
    note=next((x for x in history if x.get('id')==note_id),None)
    if not note:
        return layout('No encontrado','<h1>Seguimiento no encontrado</h1>','projects' if kind=='project' else 'tasks')
    links='\n'.join((str(x.get('title') or x.get('url') or '')+' | '+str(x.get('url') or '')).strip(' |') for x in note.get('links',[]))
    assets=attachments_html(note.get('attachments',[]))
    back=f'/{kind}?id={esc(parent_id)}'
    title='Editar seguimiento del proyecto' if kind=='project' else 'Editar seguimiento de la tarea'
    assets_block=f'<div class="wide current-assets"><strong>Adjuntos actuales</strong>{assets}<label class="remove-assets"><input type="checkbox" name="remove_attachments" value="1"> Eliminar los adjuntos actuales</label></div>' if assets else ''
    body=f'''<div class="page-head"><div><h1>{title}</h1><p>Corrige el contenido sin crear un registro duplicado.</p></div></div><form class="form-card" method="post" action="/{kind}/note/save" enctype="multipart/form-data"><input type="hidden" name="id" value="{esc(parent_id)}"><input type="hidden" name="note_id" value="{esc(note_id)}"><label>Fecha y hora<input type="datetime-local" name="date" value="{esc(str(note.get('date','')).replace(' ','T'))}"></label><label class="wide">Seguimiento<textarea required name="text" rows="7">{esc(note.get('text',''))}</textarea></label><label class="wide">Enlaces relacionados <span class="field-help">Uno por línea. Formato opcional: Nombre | URL</span><textarea name="links" rows="4">{esc(links)}</textarea></label><label class="wide">Añadir archivos<input type="file" name="files" multiple></label>{assets_block}<div class="form-actions wide"><button class="btn primary">Guardar cambios</button><a class="btn" href="{back}">Cancelar</a></div></form>'''
    return layout(title,body,'projects' if kind=='project' else 'tasks')

def normalize_url(value):
    value=str(value or '').strip()
    if value and not value.lower().startswith(('http://','https://','file://')):
        value='https://'+value
    return value

def parse_links(text):
    links=[]
    for raw in str(text or '').splitlines():
        raw=raw.strip()
        if not raw: continue
        if '|' in raw:
            title,url=[x.strip() for x in raw.split('|',1)]
        else:
            title,url=raw,raw
        url=normalize_url(url)
        if url: links.append({'title':title or url,'url':url})
    return links

def attachments_html(items):
    if not items: return ''
    rows=[]
    for a in items:
        stored=esc(a.get('file'))
        name=esc(a.get('name'))
        icon=attachment_icon(a.get('name'))
        rows.append(
            f'<li><span class="attachment-name">{icon} {name}</span> '
            f'<a class="btn small primary" href="/attachments/open?file={stored}">Abrir</a> '
            f'<a class="btn small" href="/attachments/{stored}?download=1">Descargar</a></li>'
        )
    return f'<ul class="attachment-list">{"".join(rows)}</ul>'

def links_html(items):
    if not items: return ''
    rows=''.join(f'<li><a href="{esc(a.get("url"))}" target="_blank" rel="noopener">🔗 {esc(a.get("title") or a.get("url"))}</a></li>' for a in items)
    return f'<ul class="attachment-list">{rows}</ul>'

def layout(title, body, active='dashboard'):
    main_links=[('Inicio',PORTAL_URL),('Wiki',WIKI_URL),('Proyectos y tareas','/'),('BAU',BAU_URL),('Bitácora',BITACORA_URL),('Biblioteca',BIBLIOTECA_URL),('Plantillas',CAMBIOS_URL)]
    nav=''.join(f'<a class="{"active" if n=="Proyectos y tareas" else ""}" href="{esc(u)}">{esc(n)}</a>' for n,u in main_links)
    tabs=[('dashboard','Resumen','/'),('projects','Proyectos','/projects'),('tasks','Tareas','/tasks'),('responsibles','Responsables','/responsibles'),('calendar','Calendario','/calendar')]
    module_nav='<div class="module-tabs">'+''.join(f'<a class="{"active" if active==k else ""}" href="{u}">{esc(label)}</a>' for k,label,u in tabs)+'</div>'
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)} · Proyectos</title><link rel="stylesheet" href="/static/style.css"><style>{CORPORATE_THEME_CSS}
/* V4.2.6 · Selector de tipo de tarea oscuro */
.task-type-box,.task-type-options,.task-type-options .inline-choice{{background:#091720!important;color:#e8f3f8!important;border-color:#31586b!important}}
.task-type-box{{border:1px solid #31586b!important;border-radius:7px!important;box-shadow:none!important}}
.task-type-options .inline-choice span,.task-type-box .field-title{{color:#dcecf3!important}}
.task-type-options input[type=radio]{{accent-color:#00c8ff!important;background:#06131c!important}}
</style>
<style>
/* V27.3 · Logotipo adaptable al espacio disponible */
header{{
  min-height:72px!important;
  height:auto!important;
  overflow:visible!important;
}}
.brand{{
  min-height:56px!important;
  max-width:min(70vw,760px)!important;
  display:flex!important;
  align-items:center!important;
  gap:14px!important;
  overflow:visible!important;
}}
.brand::before{{
  display:none!important;
  content:none!important;
  background-image:none!important;
}}
.brand .brand-logo{{
  display:block!important;
  width:auto!important;
  height:auto!important;
  min-width:0!important;
  min-height:0!important;
  max-width:210px!important;
  max-height:56px!important;
  flex:0 1 auto!important;
  object-fit:contain!important;
  object-position:left center!important;
  background:transparent!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
}}
.brand>span{{
  display:block!important;
  min-width:0!important;
  overflow:hidden!important;
  text-overflow:ellipsis!important;
}}
@media(max-width:760px){{
  header{{min-height:64px!important;padding:8px 14px!important}}
  .brand{{min-height:46px!important;gap:10px!important;max-width:76vw!important}}
  .brand .brand-logo{{
    width:auto!important;
    height:auto!important;
    max-width:145px!important;
    max-height:46px!important;
  }}
}}
@media(max-width:480px){{
  .brand .brand-logo{{max-width:105px!important;max-height:42px!important}}
  .brand>span{{font-size:15px!important}}
}}
</style>

<style>
/* V27.7 */
header{{min-height:58px!important;padding:6px 16px!important}}
.brand{{min-height:44px!important;max-width:min(62vw,680px)!important;gap:10px!important}}
.brand .brand-logo{{max-width:150px!important;max-height:40px!important;width:auto!important;height:auto!important;object-fit:contain!important}}
.form-card.project-form{{max-width:1180px;margin:0 auto}}
.project-main{{grid-template-columns:minmax(0,1fr) 340px!important;gap:18px!important}}
.project-description textarea{{min-height:210px!important;max-height:360px}}
.responsible-checklist{{display:grid!important;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:4px 12px;max-height:190px;overflow:auto;padding:8px!important}}
.responsible-check{{display:flex!important;align-items:center!important;gap:7px!important;margin:0!important;padding:5px 7px!important}}
.responsible-check input{{width:16px!important;height:16px!important;flex:0 0 16px!important;margin:0!important}}
.responsible-check span{{display:inline!important;line-height:1.2}}
.compact-task-form{{max-width:1050px;margin:0 auto}}
.inline-choice{{display:inline-flex!important;align-items:center;gap:6px;margin-right:22px!important}}
.inline-choice input{{width:auto!important}}
.task-type-box{{padding:10px 12px;background:#fafafa;border:1px solid #ddd;border-radius:7px}}
.orphan-notice{{margin:0 0 22px!important;padding:12px 14px!important}}
.independent-section{{margin-top:26px!important;margin-bottom:28px!important}}
.person-chip{{display:inline-block;margin:2px 4px 2px 0!important;white-space:nowrap}}
.stats{{grid-template-columns:repeat(auto-fit,minmax(155px,1fr))!important}}
@media(max-width:900px){{.project-main{{grid-template-columns:1fr!important}}.brand .brand-logo{{max-width:120px!important}}
</style>

<style>
/* V27.10 · Actividad por responsable */
.count-link{{display:inline-flex;min-width:32px;justify-content:center;padding:5px 9px;border-radius:999px;background:#fdecec;color:#b30000;font-weight:700;text-decoration:none}}
.activity-count-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:18px}}
.activity-count-card{{display:flex;flex-direction:column;background:#fff;border:1px solid #ddd;border-radius:9px;padding:15px;text-decoration:none}}
.activity-count-card strong{{font-size:26px;color:#111}}.activity-count-card span{{color:#666}}
.responsible-sections{{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:16px}}
.responsible-section{{scroll-margin-top:90px}}
.responsible-activity-list{{list-style:none;padding:0;margin:0}}
.responsible-activity-list li{{display:flex;justify-content:space-between;gap:12px;padding:9px 0;border-bottom:1px solid #eee}}
.responsible-activity-list li span{{color:#666;font-size:12px}}
</style>

<style>
/* V27.11.2 · Responsables desplegables en proyectos */
.project-top-row{{
  display:grid!important;
  grid-template-columns:minmax(420px,2.1fr) minmax(320px,.9fr)!important;
  gap:16px!important;
  align-items:start!important;
  margin-bottom:12px!important;
}}
.project-top-row .project-name{{margin:0!important}}
.responsible-dropdown-field{{min-width:0}}
.responsible-dropdown-field>.field-title{{display:block;font-weight:600;margin-bottom:5px}}
.responsible-multiselect{{position:relative;width:100%}}
.responsible-multiselect summary{{
  min-height:38px;display:flex;align-items:center;justify-content:space-between;
  gap:10px;padding:8px 11px;border:1px solid #8a9097;border-radius:6px;
  background:#fff;cursor:pointer;list-style:none;
}}
.responsible-multiselect summary::-webkit-details-marker{{display:none}}
.responsible-multiselect [data-responsible-summary]{{
  display:block;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
}}
.responsible-arrow{{flex:0 0 auto}}
.responsible-menu-options{{
  position:absolute;z-index:150;top:calc(100% + 4px);left:0;right:0;
  max-height:260px;overflow:auto;padding:7px;background:#fff;
  border:1px solid #b8bec5;border-radius:7px;box-shadow:0 8px 24px rgba(0,0,0,.16);
}}
.responsible-menu-check{{
  display:flex!important;align-items:center!important;gap:8px!important;
  padding:7px 8px!important;margin:0!important;border-radius:5px;cursor:pointer;
}}
.responsible-menu-check:hover{{background:#fdecec}}
.responsible-menu-check input{{
  width:16px!important;height:16px!important;flex:0 0 16px!important;margin:0!important;
}}
.responsible-menu-check span{{display:inline!important;line-height:1.2}}
.responsible-dropdown-field small{{display:block;margin-top:4px;color:#666}}
@media(max-width:900px){{
  .project-top-row{{grid-template-columns:1fr!important}}
  .responsible-menu-options{{position:static;margin-top:5px}}
}}

/* V4.1.8 · Asignación compacta de tareas */
.compact-task-form{{
  max-width:none!important;
  width:100%!important;
}}
.task-assignment-row{{
  display:grid!important;
  grid-template-columns:minmax(255px,.72fr) minmax(300px,.95fr) minmax(380px,1.35fr)!important;
  gap:14px!important;
  align-items:start!important;
}}
.task-assignment-row>.task-type-box,
.task-assignment-row>.task-project-field,
.task-assignment-row>.responsible-dropdown-field{{
  min-width:0!important;
  margin:0!important;
}}
.task-assignment-row .task-type-box{{
  min-height:67px!important;
  padding:8px 11px!important;
  display:flex!important;
  flex-direction:column!important;
  justify-content:flex-start!important;
}}
.task-type-options{{
  display:flex!important;
  align-items:center!important;
  flex-wrap:nowrap!important;
  gap:14px!important;
  min-height:38px!important;
}}
.task-type-options .inline-choice{{
  margin:0!important;
  white-space:nowrap!important;
}}
.task-assignment-row .task-project-field>select{{
  width:100%!important;
}}
.task-assignment-row .responsible-multiselect summary{{
  min-height:38px!important;
}}
.task-assignment-row [data-responsible-summary]{{
  white-space:nowrap!important;
  overflow:hidden!important;
  text-overflow:ellipsis!important;
}}
@media(max-width:1180px){{
  .task-assignment-row{{
    grid-template-columns:minmax(235px,.75fr) minmax(260px,.9fr) minmax(320px,1.2fr)!important;
  }}
  .task-type-options{{gap:9px!important}}
}}
@media(max-width:900px){{
  .task-assignment-row{{grid-template-columns:1fr!important}}
  .task-assignment-row .responsible-menu-options{{position:static!important;margin-top:5px!important}}
}}
</style>

<style>
/* V4.1.8 · Corrección definitiva de la fila de asignación de tareas */
.compact-task-form .task-assignment-row{{
  display:grid!important;
  grid-template-columns:minmax(250px,.72fr) minmax(300px,.95fr) minmax(390px,1.35fr)!important;
  gap:14px!important;
  align-items:start!important;
  width:100%!important;
}}
.compact-task-form .task-assignment-row>.task-type-box,
.compact-task-form .task-assignment-row>.task-project-field,
.compact-task-form .task-assignment-row>.responsible-dropdown-field{{
  grid-column:auto!important;
  width:100%!important;
  max-width:none!important;
  min-width:0!important;
}}
.compact-task-form .task-assignment-row [data-responsible-summary]{{
  display:block!important;
  white-space:nowrap!important;
  overflow:hidden!important;
  text-overflow:ellipsis!important;
}}
@media(max-width:1000px){{
  .compact-task-form .task-assignment-row{{grid-template-columns:1fr!important}}
}}
</style>
</head><body><header><div class="brand"><img class="brand-logo" src="/logo.png?v=27112" alt="Logo Santander" onerror="this.style.display=\'none\'"><span>Santander Mail Security · Proyectos <small style="font-size:10px;opacity:.8">V5.0.0</small></span></div><div class="header-actions"><a class="btn" href="/">← Atrás</a><a class="btn" href="{esc(PORTAL_URL)}">Inicio común</a><a class="btn primary" href="/project/new">+ Nuevo proyecto</a><a class="btn" href="/task/new">+ Nueva tarea</a></div></header><div class="shell"><aside><nav>{nav}</nav><div class="aside-note">Aplicación local<br>Sin usuarios<br>Datos en JSON</div></aside><main>{module_nav}{body}</main></div><script src="/static/app.js"></script>
<script>
document.addEventListener('DOMContentLoaded',function(){{
  document.querySelectorAll('[data-responsible-menu]').forEach(function(menu){{
    const summary=menu.querySelector('[data-responsible-summary]');
    const checks=Array.from(menu.querySelectorAll('.responsible-menu-checkbox'));
    function update(){{
      const names=checks.filter(x=>x.checked).map(x=>x.dataset.responsibleName||'').filter(Boolean);
      if(summary)summary.textContent=names.length?names.join(', '):'Seleccionar responsables';
    }}
    checks.forEach(x=>x.addEventListener('change',update));
    update();
  }});
  document.addEventListener('click',function(event){{
    document.querySelectorAll('[data-responsible-menu][open]').forEach(function(menu){{
      if(!menu.contains(event.target))menu.open=false;
    }});
  }});
}});
</script>
</body></html>'''

def badge(value, kind='status'):
    key=str(value or '').lower().replace(' ','-').replace('ó','o').replace('í','i')
    return f'<span class="badge {kind}-{esc(key)}">{esc(value)}</span>'

def dashboard():
    ps=projects(); ts=tasks(); today=date.today().isoformat()
    closed_statuses={'cerrado','cerrada','finalizado','finalizada','cancelado','cancelada'}
    active=[p for p in ps if str(p.get('status','')).strip().lower() not in closed_statuses]
    pending=[t for t in ts if t.get('status') not in ('Completada','Cancelada')]
    overdue=[t for t in pending if t.get('due_date') and t['due_date']<today]
    done=len([t for t in ts if t.get('status')=='Completada'])
    project_ids={str(p.get('id','')) for p in ps if str(p.get('id',''))}
    independent=[t for t in ts if t.get('task_type')=='independent' or (not t.get('task_type') and not str(t.get('project_id','')).strip())]
    independent_pending=[t for t in independent if t.get('status') not in ('Completada','Cancelada')]
    orphan=[t for t in ts if t.get('task_type')!='independent' and (not str(t.get('project_id','')).strip() or str(t.get('project_id','')) not in project_ids)]
    orphan_pending=[t for t in orphan if t.get('status') not in ('Completada','Cancelada')]

    cards=f'''<div class="stats">
    <div><strong>{len(active)}</strong><span>Proyectos activos</span></div>
    <div><strong>{len(pending)}</strong><span>Tareas pendientes</span></div>
    <div><strong>{len(independent)}</strong><span>Tareas independientes</span></div>
    <div><strong>{len(overdue)}</strong><span>Tareas vencidas</span></div>
    <div><strong>{done}</strong><span>Tareas completadas</span></div>
    </div>'''
    recent=sorted(active,key=lambda x:x.get('updated',''),reverse=True)[:6]
    plist=''.join(project_card(p, compact=True) for p in recent) or '<p class="empty">No hay proyectos abiertos.</p>'
    upcoming=sorted([t for t in pending if t.get('due_date')],key=lambda x:x['due_date'])[:8]
    rows=''.join(task_row(t,ps) for t in upcoming) or '<tr><td colspan="6" class="empty">No hay tareas próximas.</td></tr>'
    independent_rows=''.join(task_row(t,ps) for t in sorted(independent_pending,key=lambda x:(x.get('due_date') or '9999',x.get('title','')))[:10]) or '<tr><td colspan="6" class="empty">No hay tareas independientes pendientes.</td></tr>'
    orphan_notice=(f'<div class="notice orphan-notice"><strong>{len(orphan_pending)} tareas de proyecto sin asignar.</strong> <a href="/tasks?project=__unassigned__">Revisar y asociar</a></div>' if orphan_pending else '')
    body=f'''<div class="page-head"><div><h1>Panel principal</h1><p>Resumen general del trabajo pendiente y los proyectos en curso.</p></div></div>
    {orphan_notice}{cards}
    <section><div class="section-head"><h2>Proyectos recientes</h2><a href="/projects">Ver todos</a></div><div class="project-grid">{plist}</div></section>
    <section class="independent-section"><div class="section-head"><h2>Tareas independientes</h2><a href="/tasks?project=__independent__">Ver todas</a></div><div class="table-wrap"><table><thead><tr><th>Tarea</th><th>Tipo</th><th>Responsables</th><th>Estado</th><th>Prioridad</th><th>Vence</th></tr></thead><tbody>{independent_rows}</tbody></table></div></section>
    <section><div class="section-head"><h2>Próximas tareas</h2><a href="/tasks">Ver todas</a></div><div class="table-wrap"><table><thead><tr><th>Tarea</th><th>Proyecto</th><th>Responsables</th><th>Estado</th><th>Prioridad</th><th>Vence</th></tr></thead><tbody>{rows}</tbody></table></div></section>'''
    return layout('Inicio',body)

def project_card(p, compact=False):
    progress=int(p.get('progress',0) or 0)
    return f'''<article class="project-card"><div class="card-top"><h3><a href="/project?id={esc(p['id'])}">{esc(p.get('name'))}</a></h3>{badge(p.get('status','Planificado'))}</div><p>{esc(p.get('description','Sin descripción'))}</p><div class="progress"><span style="width:{progress}%"></span></div><div class="card-meta"><span>{progress}%</span><span>{esc(p.get('start_date',''))} → {esc(p.get('end_date',''))}</span></div><div class="card-people">{responsibles_badges(p)}</div></article>'''

def project_list(query=None):
    query=query or {}
    ps=projects()
    responsible=query.get('responsible',[''])[0]
    status=query.get('status',[''])[0]
    if responsible:
        ps=[p for p in ps if responsible in selected_responsibles(p)]
    if status:
        ps=[p for p in ps if p.get('status','Planificado')==status]
    q=''.join(project_card(p) for p in sorted(ps,key=lambda x:x.get('updated',''),reverse=True)) or '<p class="empty">No hay proyectos que coincidan con los filtros.</p>'
    ropts=''.join(f'<option value="{esc(r["id"])}" {"selected" if responsible==r["id"] else ""}>{esc(r["name"])}</option>' for r in sorted(responsibles(),key=responsible_sort_key))
    project_statuses=['Planificado','En curso','En pausa','Finalizado','Cancelado']
    sopts=''.join(f'<option value="{esc(value)}" {"selected" if status==value else ""}>{esc(value)}</option>' for value in project_statuses)
    filters=f'<form class="filters"><select name="responsible"><option value="">Todos los responsables</option>{ropts}</select><select name="status"><option value="">Todos los estados</option>{sopts}</select><button class="btn">Filtrar</button><a class="btn" href="/projects">Limpiar</a></form>'
    return layout('Proyectos',f'<div class="page-head"><div><h1>Proyectos</h1><p>Consulta el estado, avance, fechas y responsables de cada proyecto.</p></div><a class="btn primary" href="/project/new">Nuevo proyecto</a></div>{filters}<div class="project-grid">{q}</div>','projects')

def project_form(p=None):
    p=p or {}; edit=bool(p)
    statuses=['Planificado','En curso','En pausa','Finalizado','Cancelado']
    priorities=['Baja','Media','Alta','Crítica']
    opts=lambda values,current: ''.join(f'<option {"selected" if v==current else ""}>{v}</option>' for v in values)
    body=f'''<div class="page-head"><div><h1>{'Editar' if edit else 'Nuevo'} proyecto</h1><p>Información principal y planificación del proyecto.</p></div></div>
    <form class="form-card project-form" method="post" action="/project/save">
      <input type="hidden" name="id" value="{esc(p.get('id',''))}">
      <div class="project-top-row">
        <label class="project-name">Nombre
          <input required name="name" value="{esc(p.get('name',''))}">
        </label>
        {responsible_multiselect(selected_responsibles(p),'project')}
      </div>
      <div class="project-main">
        <label class="project-description">Descripción
          <textarea name="description" rows="8">{esc(p.get('description',''))}</textarea>
        </label>
        <div class="project-options">
          <label class="project-status">Estado<select name="status">{opts(statuses,p.get('status','Planificado'))}</select></label>
          <label class="project-priority">Prioridad<select name="priority">{opts(priorities,p.get('priority','Media'))}</select></label>
          <label class="project-progress">Avance (%)<input type="number" min="0" max="100" name="progress" value="{esc(p.get('progress',0))}"></label>
          <label class="project-start">Fecha de inicio<input type="date" name="start_date" value="{esc(p.get('start_date',''))}"></label>
          <label class="project-end">Fecha prevista de fin<input type="date" name="end_date" value="{esc(p.get('end_date',''))}"></label>
          <label class="project-wiki">Documentación Wiki relacionada <span class="field-help">Puedes seleccionar una o varias páginas</span><select name="wiki_pages" multiple size="7">{wiki_page_options(selected_wiki_pages(p))}</select></label>
        </div>
      </div>
      <div class="form-actions"><button class="btn primary">Guardar proyecto</button><a class="btn" href="/projects">Cancelar</a></div>
    </form>'''
    return layout('Proyecto',body,'projects')

def project_report(pid):
    p=next((x for x in projects() if x.get('id')==pid),None)
    if not p: return layout('No encontrado','<h1>Proyecto no encontrado</h1>','projects')
    pts=sorted([t for t in tasks() if t.get('project_id')==pid],key=lambda x:(x.get('due_date') or '9999',x.get('title','')))
    progress=max(0,min(100,int(p.get('progress',0) or 0)))
    names=', '.join(responsible_names(p)) or 'Sin asignar'
    counts={s:sum(1 for t in pts if t.get('status')==s) for s in ['Pendiente','En curso','Bloqueada','Completada','Cancelada']}

    if pts:
        task_cards=[]
        for index,t in enumerate(pts,1):
            comments=esc(t.get('comments') or 'Sin comentarios registrados.')
            task_history=''.join(f'<li><strong>{esc(h.get("date") or "")}</strong> — {esc(h.get("text") or "")}</li>' for h in t.get('history',[]))
            followups=f'<div class="task-followups"><strong>Seguimientos</strong><ul>{task_history}</ul></div>' if task_history else ''
            task_cards.append(f'''<article class="task-card"><h3>{index}. {esc(t.get('title') or 'Tarea sin título')}</h3><table class="task-facts"><tbody><tr><th>Estado</th><td>{esc(t.get('status') or '—')}</td><th>Prioridad</th><td>{esc(t.get('priority') or '—')}</td><th>Responsables</th><td class="wide-value">{esc(', '.join(responsible_names(t)) or 'Sin asignar')}</td></tr><tr><th>Inicio</th><td colspan="2">{esc(t.get('start_date') or '—')}</td><th>Fin</th><td colspan="2">{esc(t.get('due_date') or '—')}</td></tr></tbody></table><div class="task-comments"><strong>Comentarios</strong><p>{comments}</p></div>{followups}</article>''')
        task_html=''.join(task_cards)
    else:
        task_html='<p class="empty-report">No hay tareas asociadas.</p>'

    history_items=[]
    for h in reversed(p.get('history',[])):
        history_items.append(f'''<div class="timeline-item"><div class="timeline-dot"></div><div class="timeline-date">{esc(h.get('date') or 'Sin fecha')}</div><div class="timeline-body"><p>{esc(h.get('text') or '')}</p>{links_html(h.get('links',[]))}{attachments_html(h.get('attachments',[]))}</div></div>''')
    history=''.join(history_items) or '<p class="empty-report">No hay seguimientos registrados.</p>'
    summary=f'''Proyecto al {progress} %. {len(pts)} tareas: {counts['Completada']} completadas, {counts['En curso']} en curso, {counts['Pendiente']} pendientes y {counts['Bloqueada']} bloqueadas.'''
    generated=datetime.now().strftime('%d/%m/%Y %H:%M')

    report_content=f'''<header class="report-head"><div><div class="brandline">Santander Mail Security</div><h1>{esc(p.get('name'))}</h1><p class="summary">{esc(summary)}</p></div><div class="report-meta"><strong>Informe de proyecto</strong><span>Generado el {generated}</span></div></header><section class="metrics" aria-label="Resumen de tareas"><div><strong>{progress}%</strong><span>Progreso</span></div><div><strong>{len(pts)}</strong><span>Total tareas</span></div><div><strong>{counts['Completada']}</strong><span>Completadas</span></div><div><strong>{counts['En curso']}</strong><span>En curso</span></div><div><strong>{counts['Pendiente']}</strong><span>Pendientes</span></div><div><strong>{counts['Bloqueada']}</strong><span>Bloqueadas</span></div></section><section><h2>1. Información general</h2><table class="facts"><tbody><tr><th>Estado</th><td>{esc(p.get('status') or '—')}</td><th>Prioridad</th><td>{esc(p.get('priority') or '—')}</td><th>Progreso</th><td>{progress} %</td></tr><tr><th>Responsables</th><td colspan="5">{esc(names)}</td></tr><tr><th>Inicio</th><td colspan="2">{esc(p.get('start_date') or '—')}</td><th>Fin previsto</th><td colspan="2">{esc(p.get('end_date') or '—')}</td></tr></tbody></table></section><section><h2>2. Descripción</h2><div class="description-box">{esc(p.get('description') or 'Sin descripción')}</div></section><section><h2>3. Tareas</h2>{task_html}</section><section><h2>4. Historial de seguimiento</h2><div class="timeline-report">{history}</div></section><footer class="report-footer">Santander Mail Security · Informe generado el {generated}</footer>'''

    page=f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(p.get('name'))} · Informe</title><style>*{{box-sizing:border-box}}body{{margin:0;background:#f4f5f7;font-family:Arial,Helvetica,sans-serif;color:#20252b;font-size:11px;line-height:1.3}}.toolbar{{position:sticky;top:0;z-index:4;background:#fff;border-bottom:1px solid #d9dde2;padding:10px 16px;display:flex;gap:8px;align-items:center;flex-wrap:wrap}}button,a.btn{{border:1px solid #c8cdd3;background:#fff;padding:8px 12px;border-radius:5px;text-decoration:none;color:#222;font-weight:600;cursor:pointer}}button.primary{{background:#ec0000;color:#fff;border-color:#ec0000}}#status{{font-size:11px;color:#555}}.sheet{{width:794px;max-width:calc(100% - 32px);margin:18px auto;background:#fff;padding:24px 28px;box-shadow:0 2px 12px #0002}}.report-head{{display:flex;justify-content:space-between;gap:20px;border-bottom:2px solid #ec0000;padding-bottom:9px;margin-bottom:12px}}.brandline{{color:#ec0000;font-weight:700;font-size:11px}}h1{{margin:5px 0 3px;font-size:14px;font-weight:700;color:#0050a4}}h2{{font-size:13px;font-weight:700}}h3{{font-size:12px;font-weight:700}}h4{{font-size:11px;font-weight:400;font-style:italic}}.summary{{margin:0;font-weight:700;font-size:11px}}.report-meta{{text-align:right;font-size:11px;color:#4f5963;white-space:nowrap}}.report-meta strong,.report-meta span{{display:block}}section{{margin-top:15px;break-inside:auto}}h2{{font-size:13px;font-weight:700;margin:0 0 7px;border-left:4px solid #ec0000;padding-left:8px}}.metrics{{display:grid;grid-template-columns:repeat(6,1fr);border:1px solid #d6d9dd;border-radius:6px;overflow:hidden;margin-top:0}}.metrics div{{padding:8px 5px;text-align:center;border-right:1px solid #e0e3e6}}.metrics div:last-child{{border-right:0}}.metrics strong{{display:block;font-size:11px;font-weight:700;color:#b30000}}.metrics span{{font-size:11px;color:#59636d}}table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #bfc4c9;padding:5px 7px;vertical-align:top;text-align:left}}th{{background:#f3f4f5;font-weight:700}}.facts{{font-size:11px;table-layout:fixed;margin:0}}.facts th{{width:13%}}.facts td{{width:20%}}.description-box{{border:1px solid #d2d6da;border-radius:5px;padding:9px 11px;white-space:pre-wrap;font-size:11px}}.task-card{{border:1px solid #c9cdd1;border-radius:6px;margin:0 0 10px;overflow:hidden;break-inside:avoid}}.task-card h3{{margin:0;padding:8px 10px;background:#fafafa;font-size:12px;font-weight:700;border-bottom:1px solid #dadddf}}.task-facts{{table-layout:fixed;font-size:11px;margin:0}}.task-facts th{{width:7.5%}}.task-facts td{{width:12.5%;overflow-wrap:anywhere}}.task-comments{{padding:7px 10px;font-size:11px;border-top:0}}.task-comments strong{{display:block;margin-bottom:3px}}.task-comments p{{margin:0;white-space:pre-wrap}}.task-followups{{padding:7px 10px;border-top:1px solid #e1e4e7;font-size:11px}}.task-followups strong{{display:block;margin-bottom:3px}}.task-followups ul{{margin:0;padding-left:17px}}.task-followups li{{margin:2px 0}}.timeline-report{{position:relative;margin-left:5px}}.timeline-report:before{{content:"";position:absolute;left:6px;top:4px;bottom:4px;width:2px;background:#d4d8dc}}.timeline-item{{position:relative;display:grid;grid-template-columns:15px 110px 1fr;gap:8px;padding:0 0 10px;break-inside:avoid}}.timeline-dot{{width:10px;height:10px;border-radius:50%;background:#ec0000;margin-top:3px;z-index:1}}.timeline-date{{font-size:11px;font-weight:700}}.timeline-body{{border-bottom:1px solid #e1e4e7;padding-bottom:8px;font-size:11px}}.timeline-body p{{margin:0;white-space:pre-wrap}}.attachment-list{{margin:4px 0 0;padding-left:17px}}.attachment-list li{{margin:2px 0}}.empty-report{{margin:6px 0;color:#69737d;font-size:11px}}.report-footer{{margin-top:16px;border-top:1px solid #d8dce0;padding-top:7px;color:#6d757d;font-size:11px}}@page{{size:A4 portrait;margin:10mm}}@media print{{body{{background:#fff}}.toolbar{{display:none}}.sheet{{box-shadow:none;margin:0;max-width:none;padding:0;width:auto}}.report-head{{margin-bottom:8px}}section{{margin-top:11px}}h2{{font-size:13px;font-weight:700;margin-bottom:5px}}.metrics div{{padding:6px 4px}}.task-card{{margin-bottom:7px}}}}</style><style>{CORPORATE_THEME_CSS}
/* V26.1: logotipo configurable desde configuracion/logo/logo.png */
.brand::before{{display:none!important;content:none!important;background-image:none!important}}
.brand .brand-logo{{
  display:block!important;width:46px!important;height:46px!important;
  min-width:46px!important;max-width:46px!important;flex:0 0 46px!important;
  object-fit:contain!important;object-position:center!important;
  background:transparent!important;border:0!important;border-radius:0!important;
  box-shadow:none!important
}}
.brand>span{{display:block!important}}
@media(max-width:760px){{
  .brand .brand-logo{{width:38px!important;height:38px!important;min-width:38px!important;max-width:38px!important;flex-basis:38px!important}}
}}
</style><style>
/* V4.1.8: informe claro en pantalla e impresión; tablas adaptables */
html,body{{background:#f1f3f6!important;color:#20252b!important;color-scheme:light!important}}
body{{min-height:100vh}}
.toolbar{{background:#fff!important;color:#20252b!important;border-color:#d9dde2!important;box-shadow:0 2px 8px rgba(0,0,0,.08)!important}}
.toolbar button,.toolbar a.btn{{background:#0b2635!important;color:#fff!important;border-color:#214f63!important}}
.toolbar button:hover,.toolbar a.btn:hover{{background:#12394d!important;border-color:#00a8e8!important}}
.sheet{{background:#fff!important;color:#20252b!important;box-shadow:0 3px 18px rgba(0,0,0,.15)!important;border:1px solid #e0e3e7!important}}
#report-content,#report-content section,#report-content article,#report-content .metrics,#report-content .metrics div,#report-content .description-box,#report-content .task-card,#report-content .task-comments,#report-content .task-followups,#report-content .timeline-report,#report-content .timeline-body{{background:#fff!important;color:#20252b!important}}
#report-content .report-head{{border-bottom-color:#ec0000!important}}
#report-content .brandline{{color:#ec0000!important}}
#report-content h1{{color:#0050a4!important}}
#report-content h2,#report-content h3,#report-content h4,#report-content .summary{{color:#20252b!important}}
#report-content .report-meta,#report-content .metrics span,#report-content .empty-report,#report-content .report-footer{{color:#5f6973!important}}
#report-content .metrics strong{{color:#b30000!important}}
#report-content table{{width:100%!important;max-width:100%!important;border-collapse:collapse!important;table-layout:fixed!important}}
#report-content th,#report-content td{{background:#fff!important;color:#20252b!important;border-color:#bfc7ce!important;vertical-align:top!important;white-space:normal!important;overflow-wrap:anywhere!important;word-break:normal!important;hyphens:auto!important;line-height:1.35!important}}
#report-content th{{background:#f2f4f6!important;color:#28323b!important}}
#report-content .task-card h3{{background:#f8f9fa!important;color:#0050a4!important;border-bottom-color:#dadddf!important}}
#report-content .task-facts th{{width:14%!important;min-width:72px!important}}
#report-content .task-facts td{{width:auto!important}}
#report-content .task-facts td.wide-value{{width:30%!important}}
#report-content .task-facts tr:nth-child(2) th{{width:14%!important}}
#report-content .facts th{{width:13%!important}}
#report-content .facts td{{width:auto!important}}
#report-content .task-followups,#report-content .timeline-body,#report-content .report-footer{{border-color:#d6dce1!important}}
@media(max-width:900px){{
  .sheet{{width:auto!important;max-width:calc(100% - 20px)!important;padding:18px!important}}
  .metrics{{grid-template-columns:repeat(3,1fr)!important}}
  .metrics div:nth-child(3){{border-right:0!important}}
  .metrics div:nth-child(-n+3){{border-bottom:1px solid #e0e3e6!important}}
}}
@media(max-width:620px){{
  .report-head{{display:block!important}}
  .report-meta{{text-align:left!important;margin-top:8px!important;white-space:normal!important}}
  .metrics{{grid-template-columns:repeat(2,1fr)!important}}
  .metrics div{{border-bottom:1px solid #e0e3e6!important}}
  .metrics div:nth-child(even){{border-right:0!important}}
  #report-content .facts,#report-content .task-facts{{table-layout:auto!important}}
  #report-content .facts tbody,#report-content .task-facts tbody,#report-content .facts tr,#report-content .task-facts tr{{display:block!important;width:100%!important}}
  #report-content .facts th,#report-content .facts td,#report-content .task-facts th,#report-content .task-facts td{{display:block!important;width:100%!important;min-width:0!important}}
  #report-content .facts th,#report-content .task-facts th{{border-bottom:0!important;padding-bottom:2px!important}}
  #report-content .facts td,#report-content .task-facts td{{border-top:0!important;padding-top:2px!important;margin-bottom:5px!important}}
}}
@media print{{
  html,body{{background:#fff!important;color:#111!important}}
  .toolbar{{display:none!important}}
  .sheet{{box-shadow:none!important;border:0!important;margin:0!important;max-width:none!important;padding:0!important;width:auto!important}}
  #report-content table{{table-layout:fixed!important}}
  #report-content th,#report-content td{{font-size:10px!important;padding:4px 6px!important;overflow-wrap:anywhere!important}}
  #report-content .task-facts th{{width:14%!important}}
  #report-content .task-facts td.wide-value{{width:30%!important}}
}}
</style></style></head><body><div class="toolbar"><a class="btn" href="/project?id={esc(pid)}">← Volver al proyecto</a><button onclick="copyText()">Copiar texto</button><button onclick="window.print()">Imprimir / Guardar PDF</button><span id="status"></span></div><div class="sheet"><div id="report-content">{report_content}</div></div><script>const st=document.getElementById('status');function done(m){{st.textContent=m;setTimeout(()=>st.textContent='',2500)}}function mailHtml(n){{const c=n.cloneNode(true);c.style.cssText='width:680px;max-width:680px;box-sizing:border-box;font-family:Arial,Helvetica,sans-serif;color:#20252b;background:#fff;padding:16px;font-size:11px;line-height:1.3';c.querySelectorAll('table').forEach(x=>x.style.cssText+=';border-collapse:collapse;width:100%;max-width:100%;table-layout:fixed');c.querySelectorAll('th,td').forEach(x=>x.style.cssText+=';border:1px solid #bfc4c9;padding:5px 7px;vertical-align:top;text-align:left;overflow-wrap:anywhere;word-break:break-word');c.querySelectorAll('th').forEach(x=>x.style.background='#f3f4f5');c.querySelectorAll('.task-card').forEach(x=>x.style.cssText+=';border:1px solid #c9cdd1;margin:0 0 10px;page-break-inside:avoid');c.querySelectorAll('h1').forEach(x=>x.style.cssText+=';font-size:14px;font-weight:700;color:#0050a4');c.querySelectorAll('h2').forEach(x=>x.style.cssText+=';font-size:13px;font-weight:700');c.querySelectorAll('h3').forEach(x=>x.style.cssText+=';font-size:12px;font-weight:700');c.querySelectorAll('h4').forEach(x=>x.style.cssText+=';font-size:11px;font-weight:400;font-style:italic');c.querySelectorAll('.task-card h3').forEach(x=>x.style.cssText+=';margin:0;padding:8px 10px;background:#fafafa;border-bottom:1px solid #dadddf;font-size:12px;font-weight:700');c.querySelectorAll('.task-comments').forEach(x=>x.style.cssText+=';padding:7px 10px;font-size:11px');c.querySelectorAll('img').forEach(x=>x.style.cssText+=';max-width:100%;height:auto');return c.outerHTML}}async function copyRich(){{const n=document.getElementById('report-content'),h=mailHtml(n),t=n.innerText;try{{if(navigator.clipboard&&window.ClipboardItem)await navigator.clipboard.write([new ClipboardItem({{'text/html':new Blob([h],{{type:'text/html'}}),'text/plain':new Blob([t],{{type:'text/plain'}})}})]);else{{const r=document.createRange();r.selectNode(n);const s=getSelection();s.removeAllRanges();s.addRange(r);document.execCommand('copy');s.removeAllRanges()}}done('Informe copiado.')}}catch(e){{done('No se pudo copiar automáticamente. Usa Ctrl+C.')}}}}async function copyText(){{try{{await navigator.clipboard.writeText(document.getElementById('report-content').innerText);done('Texto copiado.')}}catch(e){{done('No se pudo copiar.')}}}}</script></body></html>'''
    return page

def project_detail(pid):
    ps=projects(); p=next((x for x in ps if x['id']==pid),None)
    if not p: return layout('No encontrado','<h1>Proyecto no encontrado</h1>','projects')
    related=[t for t in tasks() if t.get('project_id')==pid]; progress=int(p.get('progress',0) or 0)
    rows=''.join(task_row(t,ps) for t in related) or '<tr><td colspan="6" class="empty">Este proyecto todavía no tiene tareas.</td></tr>'
    history=p.setdefault('history',[])
    if ensure_note_ids(history):
        all_projects=projects()
        for item in all_projects:
            if item.get('id')==pid: item['history']=history
        write_json(PROJECTS,all_projects)
    linked_docs=[]
    selected=set(selected_wiki_pages(p))
    if WIKI_PAGES.exists():
        for path in WIKI_PAGES.glob('*.json'):
            doc=read_json(path,{})
            slug=str(doc.get('slug') or path.stem)
            if doc.get('project_id')==pid or slug in selected:
                doc['slug']=slug
                linked_docs.append(doc)
    # Evita duplicados si una página está vinculada por ambos mecanismos.
    linked_docs=list({str(d.get('slug')):d for d in linked_docs}.values())
    docs_html=''.join(f'<li class="linked-doc-item"><span class="linked-doc-dot"></span><div class="linked-doc-content"><a href="{esc(WIKI_URL)}/wiki/{esc(d.get("slug",""))}">{esc(d.get("title","Documento"))}</a><div class="linked-doc-meta"><span class="doc-category">{esc(d.get("category","General"))}</span><span>Actualizado: {esc(d.get("updated","").replace("T"," "))}</span></div></div></li>' for d in linked_docs) or '<li class="empty">No hay documentación vinculada.</li>'
    hist=''.join(f'<li><div class="note-head"><strong>{esc(h.get("date"))}</strong>{note_actions("project",pid,h.get("id"))}</div><p>{esc(h.get("text"))}</p>{links_html(h.get("links",[]))}{attachments_html(h.get("attachments",[]))}<small class="note-audit">{("Modificado: "+esc(h.get("modified"))) if h.get("modified") else ""}</small></li>' for h in reversed(history)) or '<li class="empty">Sin anotaciones.</li>'
    body=f'''<div class="page-head"><div><h1>{esc(p.get('name'))}</h1><p>{esc(p.get('description'))}</p></div><div><a class="btn" href="/project/edit?id={esc(pid)}">Editar</a> <a class="btn primary" href="/project/report?id={esc(pid)}">📄 Generar informe</a> <form class="inline" method="post" action="/project/delete" onsubmit="return confirm('¿Eliminar este proyecto y sus tareas?')"><input type="hidden" name="id" value="{esc(pid)}"><button class="btn danger">Eliminar</button></form></div></div><div class="detail-grid"><section class="info-card"><h2>Información</h2><dl><dt>Estado</dt><dd>{badge(p.get('status'))}</dd><dt>Prioridad</dt><dd>{badge(p.get('priority'),'priority')}</dd><dt>Responsables</dt><dd>{responsibles_badges(p)}</dd><dt>Fechas</dt><dd>{esc(p.get('start_date'))} → {esc(p.get('end_date'))}</dd></dl><h3>Avance: {progress}%</h3><div class="progress large"><span style="width:{progress}%"></span></div></section><section class="info-card"><h2>Añadir seguimiento</h2><form method="post" action="/project/note" enctype="multipart/form-data"><input type="hidden" name="id" value="{esc(pid)}"><textarea required name="text" rows="5" placeholder="Avance, incidencia, cambio o decisión..."></textarea><label>Enlaces relacionados <span class="field-help">Uno por línea. Formato opcional: Nombre | URL</span><textarea name="links" rows="3" placeholder="Consola CrowdStrike | https://...
Documento SharePoint | https://..."></textarea></label><label>Adjuntar archivos<input type="file" name="files" multiple></label><button class="btn primary">Guardar anotación</button></form></section></div><section><div class="section-head"><h2>Tareas del proyecto</h2><a class="btn" href="/task/new?project_id={esc(pid)}">Nueva tarea</a></div><div class="table-wrap"><table><thead><tr><th>Tarea</th><th>Proyecto</th><th>Responsables</th><th>Estado</th><th>Prioridad</th><th>Vence</th></tr></thead><tbody>{rows}</tbody></table></div></section><section><div class="section-head"><h2>Documentación Wiki vinculada</h2><a class="btn" href="{esc(WIKI_URL)}/new">Nuevo documento</a></div><ul class="timeline">{docs_html}</ul></section><section><h2>Historial de seguimiento</h2><ul class="timeline">{hist}</ul></section>'''
    return layout(p.get('name'),body,'projects')

def task_row(t, ps):
    p=next((x for x in ps if x['id']==t.get('project_id')),None)
    return f'<tr><td><a href="/task?id={esc(t["id"])}"><strong>{esc(t.get("title"))}</strong></a><small>{esc(t.get("description",""))}</small></td><td>{esc(p.get("name") if p else ("Tarea independiente" if t.get("task_type")=="independent" or not t.get("project_id") else "Proyecto no disponible"))}</td><td>{responsibles_badges(t)}</td><td>{badge(t.get("status"))}</td><td>{badge(t.get("priority"),"priority")}</td><td>{esc(t.get("due_date") or "—")}</td></tr>'

def task_detail(tid):
    t=next((x for x in tasks() if x.get('id')==tid),None)
    if not t:
        return layout('Tarea no encontrada','<h1>Tarea no encontrada</h1><p><a href="/tasks">Volver a tareas</a></p>','tasks')
    p=next((x for x in projects() if x.get('id')==t.get('project_id')),None)
    history=t.setdefault('history',[])
    if ensure_note_ids(history):
        all_tasks=tasks()
        for item in all_tasks:
            if item.get('id')==tid: item['history']=history
        write_json(TASKS,all_tasks)
    hist=''.join(
        f'<li><div class="note-head"><strong>{esc(h.get("date"))}</strong>{note_actions("task",tid,h.get("id"))}</div><p>{esc(h.get("text"))}</p>{links_html(h.get("links",[]))}{attachments_html(h.get("attachments",[]))}<small class="note-audit">{("Modificado: "+esc(h.get("modified"))) if h.get("modified") else ""}</small></li>'
        for h in reversed(history)
    ) or '<li class="empty">Sin seguimientos registrados.</li>'
    assets=wiki_links_html(t)+links_html(t.get('links',[]))+attachments_html(t.get('attachments',[]))
    project_html=f'<a href="/project?id={esc(p.get("id"))}">{esc(p.get("name"))}</a>' if p else 'Sin proyecto'
    assets_html=f'<div class="current-assets"><strong>Archivos y enlaces</strong>{assets}</div>' if assets else ''
    body=f'''<div class="page-head"><div><h1>{esc(t.get('title'))}</h1><p>{esc(t.get('description') or 'Sin descripción')}</p></div><div><a class="btn" href="/task/edit?id={esc(tid)}">Editar</a> <form class="inline" method="post" action="/task/delete" onsubmit="return confirm('¿Eliminar esta tarea?')"><input type="hidden" name="id" value="{esc(tid)}"><button class="btn danger">Eliminar</button></form></div></div><div class="detail-grid"><section class="info-card"><h2>Información</h2><dl><dt>Proyecto</dt><dd>{project_html}</dd><dt>Estado</dt><dd>{badge(t.get('status'))}</dd><dt>Prioridad</dt><dd>{badge(t.get('priority'),'priority')}</dd><dt>Responsables</dt><dd>{responsibles_badges(t)}</dd><dt>Inicio</dt><dd>{esc(t.get('start_date') or '—')}</dd><dt>Fecha límite</dt><dd>{esc(t.get('due_date') or '—')}</dd></dl>{assets_html}</section><section class="info-card"><h2>Añadir seguimiento</h2><form method="post" action="/task/note" enctype="multipart/form-data"><input type="hidden" name="id" value="{esc(tid)}"><textarea required name="text" rows="5" placeholder="Avance, incidencia, cambio, decisión o resultado..."></textarea><label>Enlaces relacionados <span class="field-help">Uno por línea. Formato opcional: Nombre | URL</span><textarea name="links" rows="3" placeholder="Documento SharePoint | https://..."></textarea></label><label>Adjuntar archivos<input type="file" name="files" multiple></label><button class="btn primary">Guardar seguimiento</button></form></section></div><section><h2>Historial de seguimiento de la tarea</h2><ul class="timeline">{hist}</ul></section>'''
    return layout(t.get('title') or 'Tarea',body,'tasks')

def task_list(query):
    ps=projects(); ts=tasks()
    status=query.get('status',[''])[0]
    project=query.get('project',[''])[0]
    responsible=query.get('responsible',[''])[0]

    if status:
        ts=[t for t in ts if t.get('status')==status]

    if project=='__independent__':
        ts=[t for t in ts if t.get('task_type')=='independent' or (not t.get('task_type') and not str(t.get('project_id','')).strip())]
    elif project=='__unassigned__':
        project_ids={str(p.get('id','')) for p in ps if str(p.get('id',''))}
        ts=[t for t in ts if t.get('task_type')!='independent' and (not str(t.get('project_id','')).strip() or str(t.get('project_id','')) not in project_ids)]
    elif project:
        ts=[t for t in ts if t.get('project_id')==project]

    if responsible:
        ts=[t for t in ts if responsible in selected_responsibles(t)]

    rows=''.join(
        task_row(t,ps)
        for t in sorted(ts,key=lambda x:(x.get('due_date') or '9999',x.get('title','')))
    ) or '<tr><td colspan="6" class="empty">No hay tareas que mostrar.</td></tr>'

    unassigned_selected='selected' if project=='__unassigned__' else ''
    popts=(
        f'<option value="__independent__" {"selected" if project=="__independent__" else ""}>Tareas independientes</option><option value="__unassigned__" {unassigned_selected}>Tareas de proyecto sin asignar</option>'
        + ''.join(
            f'<option value="{esc(p["id"])}" {"selected" if project==p["id"] else ""}>{esc(p["name"])}</option>'
            for p in ps
        )
    )
    sopts=''.join(
        f'<option {"selected" if status==value else ""}>{value}</option>'
        for value in ['Pendiente','En curso','Bloqueada','Completada','Cancelada']
    )
    ropts=''.join(
        f'<option value="{esc(r["id"])}" {"selected" if responsible==r["id"] else ""}>{esc(r["name"])}</option>'
        for r in sorted(responsibles(),key=responsible_sort_key)
    )

    heading='Tareas independientes' if project=='__independent__' else ('Tareas de proyecto sin asignar' if project=='__unassigned__' else 'Tareas')
    description=(
        'Tareas válidas que se gestionan sin depender de un proyecto.'
        if project=='__independent__'
        else ('Tareas de proyecto que todavía no tienen una asociación válida.' if project=='__unassigned__' else 'Listado general de tareas y vencimientos.')
    )

    body=f'''<div class="page-head"><div><h1>{heading}</h1><p>{description}</p></div><a class="btn primary" href="/task/new">Nueva tarea</a></div>
    <form class="filters">
      <select name="project"><option value="">Todos los proyectos</option>{popts}</select>
      <select name="status"><option value="">Todos los estados</option>{sopts}</select>
      <select name="responsible"><option value="">Todos los responsables</option>{ropts}</select>
      <button class="btn">Filtrar</button>
      <a class="btn" href="/tasks">Limpiar</a>
    </form>
    <div class="table-wrap"><table><thead><tr><th>Tarea</th><th>Proyecto</th><th>Responsables</th><th>Estado</th><th>Prioridad</th><th>Vence</th></tr></thead><tbody>{rows}</tbody></table></div>'''
    return layout('Tareas',body,'tasks')

def task_form(t=None, selected_project=''):
    t=t or {}; edit=bool(t); ps=projects()
    statuses=['Pendiente','En curso','Bloqueada','Completada','Cancelada']
    priorities=['Baja','Media','Alta','Crítica']
    opts=lambda values,current: ''.join(f'<option {"selected" if v==current else ""}>{v}</option>' for v in values)
    current=t.get('project_id',selected_project)
    task_type=t.get('task_type') or ('independent' if not current else 'project')
    popts=''.join(f'<option value="{esc(p["id"])}" {"selected" if current==p["id"] else ""}>{esc(p["name"])}</option>' for p in ps)
    existing_assets=(links_html(t.get('links',[]))+attachments_html(t.get('attachments',[]))) if edit else ''
    body=f'''<div class="page-head"><div><h1>{'Editar' if edit else 'Nueva'} tarea</h1><p>Define el trabajo, su prioridad y fecha límite.</p></div></div>
<form class="form-card compact-task-form" method="post" action="/task/save" enctype="multipart/form-data">
<input type="hidden" name="id" value="{esc(t.get('id',''))}">
<label class="wide">Título<input required name="title" value="{esc(t.get('title',''))}"></label>
<label class="wide">Descripción<textarea name="description" rows="4">{esc(t.get('description',''))}</textarea></label>
<div class="wide task-assignment-row">
  <div class="task-type-box">
    <div class="field-title">Tipo de tarea</div>
    <div class="task-type-options">
      <label class="inline-choice"><input type="radio" name="task_type" value="project" {"checked" if task_type=="project" else ""}> <span>De proyecto</span></label>
      <label class="inline-choice"><input type="radio" name="task_type" value="independent" {"checked" if task_type=="independent" else ""}> <span>Independiente</span></label>
    </div>
  </div>
  <label class="task-project-field">Proyecto
    <select name="project_id"><option value="">Selecciona un proyecto</option>{popts}</select>
    <span class="field-help">Obligatorio si es de proyecto.</span>
  </label>
  {responsible_multiselect(selected_responsibles(t),'task')}
</div>
<label class="wide">Documentación Wiki relacionada <span class="field-help">Puedes seleccionar una o varias páginas</span><select name="wiki_pages" multiple size="5">{wiki_page_options(selected_wiki_pages(t))}</select></label>
<label>Estado<select name="status">{opts(statuses,t.get('status','Pendiente'))}</select></label>
<label>Prioridad<select name="priority">{opts(priorities,t.get('priority','Media'))}</select></label>
<label>Fecha de inicio<input type="date" name="start_date" value="{esc(t.get('start_date',''))}"></label>
<label>Fecha límite<input type="date" name="due_date" value="{esc(t.get('due_date',''))}"></label>
<label class="wide">Comentarios de seguimiento<textarea name="comments" rows="4">{esc(t.get('comments',''))}</textarea></label>
<label class="wide">Enlaces relacionados <span class="field-help">Uno por línea. Formato opcional: Nombre | URL</span><textarea name="links" rows="3" placeholder="Panel SIEM | https://...">{esc(chr(10).join((x.get('title',x.get('url',''))+' | '+x.get('url','')) for x in t.get('links',[])))}</textarea></label>
<label class="wide">Adjuntar archivos<input type="file" name="files" multiple></label>
{f'<div class="wide current-assets"><strong>Archivos y enlaces actuales</strong>{existing_assets}<label class="remove-assets"><input type="checkbox" name="replace_assets" value="1"> Sustituir los adjuntos actuales por los nuevos</label></div>' if edit and existing_assets else ''}
<div class="form-actions wide"><button class="btn primary">Guardar tarea</button><a class="btn" href="/tasks">Cancelar</a>{f'<button form="delete-task" type="button" class="btn danger" onclick="document.getElementById(\'delete-task\').submit()">Eliminar</button>' if edit else ''}</div>
</form>
{f'<form id="delete-task" method="post" action="/task/delete" onsubmit="return confirm(\'¿Eliminar esta tarea?\')"><input type="hidden" name="id" value="{esc(t.get("id"))}"></form>' if edit else ''}
<script>
(function(){{
 const radios=document.querySelectorAll('input[name="task_type"]');
 const field=document.querySelector('.task-project-field');
 const select=field?field.querySelector('select'):null;
 function update(){{
   const selected=document.querySelector('input[name="task_type"]:checked');
   const independent=selected&&selected.value==='independent';
   if(field) field.style.display=independent?'none':'block';
   if(select) select.required=!independent;
   if(independent&&select) select.value='';
 }}
 radios.forEach(r=>r.addEventListener('change',update)); update();
}})();
</script>'''
    return layout('Tarea',body,'tasks')


def module_rows(path):
    return read_json(path,[]) if path.exists() else []

def wiki_pages_full():
    rows=[]
    if WIKI_PAGES.exists():
        for path in WIKI_PAGES.glob('*.json'):
            page=read_json(path,{})
            if page:
                page.setdefault('slug',path.stem)
                rows.append(page)
    return rows

def wiki_author_names(page):
    names=[]
    values=page.get('responsible_ids',[])
    if isinstance(values,str):
        values=[values] if values else []
    by_id={str(r.get('id')):str(r.get('name','')) for r in responsibles()}
    names.extend(by_id.get(str(x),'') for x in values)
    match=re.search(r'(?im)^\s*(?:Author|Autor)\s*:\s*(.+?)\s*$',str(page.get('content','')))
    if match:
        raw=re.sub(r'[*_`]+','',match.group(1))
        names.extend(x.strip() for x in re.split(r'[,;·|]+',raw) if x.strip())
    return {x.casefold() for x in names if x}

def item_has_responsible(item,rid,name):
    ids=item.get('responsible_ids',[])
    if isinstance(ids,str):
        ids=[ids] if ids else []
    single=item.get('responsible_id','')
    if single:
        ids=list(ids)+[single]
    if str(rid) in {str(x) for x in ids}:
        return True
    owner=str(item.get('owner','')).strip()
    return bool(owner and owner.casefold()==str(name).strip().casefold())

def responsible_activity(person):
    rid=str(person.get('id',''))
    name=str(person.get('name','')).strip()
    return {
        'projects':[x for x in projects() if item_has_responsible(x,rid,name)],
        'tasks':[x for x in tasks() if item_has_responsible(x,rid,name)],
        'wiki':[x for x in wiki_pages_full() if name.casefold() in wiki_author_names(x)],
        'bitacora':[x for x in module_rows(BITACORA_DB) if item_has_responsible(x,rid,name)],
        'biblioteca':[x for x in module_rows(BIBLIOTECA_DB) if item_has_responsible(x,rid,name)],
    }

def activity_rows(items,kind):
    if not items:
        return '<p class="empty">No hay elementos asociados.</p>'
    rows=[]
    for item in items:
        if kind=='projects':
            href='/project?id='+esc(item.get('id')); title=item.get('name') or 'Proyecto'; meta=item.get('status','')
        elif kind=='tasks':
            href='/task?id='+esc(item.get('id')); title=item.get('title') or 'Tarea'; meta=item.get('status','')
        elif kind=='wiki':
            href=esc(WIKI_URL)+'/view?slug='+esc(item.get('slug')); title=item.get('title') or 'Documento'; meta=item.get('category','')
        elif kind=='bitacora':
            href=esc(BITACORA_URL)+'/view?id='+esc(item.get('id')); title=item.get('title') or 'Entrada'; meta=item.get('group','')
        else:
            href=esc(BIBLIOTECA_URL)+'/view?id='+esc(item.get('id')); title=item.get('title') or 'Fragmento'; meta=item.get('category','')
        rows.append('<li><a href="'+href+'"><strong>'+esc(title)+'</strong></a><span>'+esc(meta)+'</span></li>')
    return '<ul class="responsible-activity-list">'+''.join(rows)+'</ul>'

def responsible_detail(rid):
    person=next((x for x in responsibles() if str(x.get('id'))==str(rid)),None)
    if not person:
        return layout('Responsable no encontrado','<h1>Responsable no encontrado</h1>','responsibles')
    activity=responsible_activity(person)
    labels=[('projects','Proyectos'),('tasks','Tareas'),('wiki','Documentos Wiki'),('bitacora','Bitácora'),('biblioteca','Biblioteca')]
    cards=''.join('<a class="activity-count-card" href="#'+key+'"><strong>'+str(len(activity[key]))+'</strong><span>'+label+'</span></a>' for key,label in labels)
    sections=''.join('<section id="'+key+'" class="info-card responsible-section"><div class="section-head"><h2>'+label+'</h2><span class="badge">'+str(len(activity[key]))+'</span></div>'+activity_rows(activity[key],key)+'</section>' for key,label in labels)
    body='<div class="page-head"><div><h1>'+esc(person.get('name'))+'</h1><p>'+esc(person.get('email') or 'Actividad asociada al responsable')+'</p></div><div><a class="btn" href="/responsibles">← Responsables</a><a class="btn" href="/responsible/edit?id='+esc(rid)+'">Editar</a></div></div><div class="activity-count-grid">'+cards+'</div><div class="responsible-sections">'+sections+'</div>'
    return layout(person.get('name') or 'Responsable',body,'responsibles')


def responsibles_page():
    people=sorted(responsibles(),key=responsible_sort_key)
    row_parts=[]
    for r in people:
        rid=r.get('id','')
        activity=responsible_activity(r)
        counts={k:len(v) for k,v in activity.items()}
        def count_link(key):
            return '<a class="count-link" href="/responsible?id='+esc(rid)+'#'+key+'">'+str(counts[key])+'</a>'
        row_parts.append('<tr><td><a href="/responsible?id='+esc(rid)+'"><strong>'+esc(r.get("name"))+'</strong></a><small>'+esc(r.get("email",""))+'</small></td><td>'+count_link("projects")+'</td><td>'+count_link("tasks")+'</td><td>'+count_link("wiki")+'</td><td>'+count_link("bitacora")+'</td><td>'+count_link("biblioteca")+'</td><td><a class="btn primary" href="/responsible?id='+esc(rid)+'">Ver actividad</a> <a class="btn" href="/responsible/edit?id='+esc(rid)+'">Editar</a> <form class="inline" method="post" action="/responsible/delete" onsubmit="return confirm(&quot;¿Eliminar este responsable?&quot;)"><input type="hidden" name="id" value="'+esc(rid)+'"><button class="btn danger">Eliminar</button></form></td></tr>')
    rows=''.join(row_parts) or '<tr><td colspan="7" class="empty">No hay responsables creados.</td></tr>'
    body='<div class="page-head"><div><h1>Responsables</h1><p>Accede a todos los proyectos, tareas y contenidos asociados a cada responsable.</p></div><a class="btn primary" href="/responsible/new">Nuevo responsable</a></div><div class="table-wrap"><table><thead><tr><th>Responsable</th><th>Proyectos</th><th>Tareas</th><th>Wiki</th><th>Bitácora</th><th>Biblioteca</th><th>Acciones</th></tr></thead><tbody>'+rows+'</tbody></table></div>'
    return layout('Responsables',body,'responsibles')

def responsible_form(person=None):
    person=person or {}; edit=bool(person)
    body=f'<div class="page-head"><div><h1>{"Editar" if edit else "Nuevo"} responsable</h1><p>Datos básicos de la persona responsable.</p></div></div><form class="form-card" method="post" action="/responsible/save"><input type="hidden" name="id" value="{esc(person.get("id",""))}"><label class="wide">Nombre<input required name="name" value="{esc(person.get("name",""))}"></label><label class="wide">Correo electrónico<input type="email" name="email" value="{esc(person.get("email",""))}"></label><div class="form-actions wide"><button class="btn primary">Guardar responsable</button><a class="btn" href="/responsibles">Cancelar</a></div></form>'
    return layout('Responsable',body,'responsibles')

def calendar_view():
    ps=projects(); ts=[t for t in tasks() if t.get('due_date')]
    groups={}
    for t in ts: groups.setdefault(t['due_date'],[]).append(t)
    months={}
    for day,items in groups.items(): months.setdefault(day[:7],[]).append((day,items))
    content=''
    for month in sorted(months):
        content+=f'<section><h2>{esc(month)}</h2><div class="calendar-list">'
        for day,items in sorted(months[month]):
            content+=f'<div class="calendar-day"><strong>{esc(day)}</strong><div>' + ''.join(f'<a href="/task?id={esc(t["id"])}">{esc(t["title"])} {badge(t.get("status"))}</a>' for t in items) + '</div></div>'
        content+='</div></section>'
    if not content: content='<p class="empty">No hay tareas con fecha límite.</p>'
    return layout('Calendario',f'<div class="page-head"><div><h1>Calendario</h1><p>Fechas límite agrupadas por mes.</p></div></div>{content}','calendar')



def corporate_logo_path():
    """Devuelve siempre el logo corporativo de la carpeta raíz del proyecto."""
    source=Path(__file__).resolve()
    try:
        app_root=source.parents[2]
    except IndexError:
        app_root=source.parent
    candidates=[
        app_root/"configuracion"/"logo"/"logo.png",
        source.parent/"logo.png",
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None

def serve_corporate_logo(handler):
    path = corporate_logo_path()
    if path is None:
        handler.send_response(404)
        handler.end_headers()
        return
    data = path.read_bytes()
    handler.send_response(200)
    handler.send_header("Content-Type", "image/png")
    handler.send_header("Content-Length", str(len(data)))
    handler.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
    handler.end_headers()
    handler.wfile.write(data)

class Handler(BaseHTTPRequestHandler):
    def send_html(self, text, code=200):
        data=text.encode('utf-8'); self.send_response(code); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def redirect(self, url): self.send_response(303); self.send_header('Location',url); self.end_headers()
    def form(self):
        n=int(self.headers.get('Content-Length','0') or 0); raw=self.rfile.read(n)
        content_type=self.headers.get('Content-Type','')
        if content_type.startswith('multipart/form-data'):
            message=BytesParser(policy=email_policy).parsebytes((f'Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n').encode()+raw)
            fields={}; uploads=[]
            for part in message.iter_parts():
                name=part.get_param('name',header='content-disposition')
                filename=part.get_filename()
                payload=part.get_payload(decode=True) or b''
                if filename:
                    if payload: uploads.append(save_upload(filename,payload))
                elif name:
                    value=payload.decode(part.get_content_charset() or 'utf-8',errors='replace')
                    if name in fields:
                        fields[name]=fields[name]+[value] if isinstance(fields[name],list) else [fields[name],value]
                    else: fields[name]=value
            fields['_uploads']=uploads
            return fields
        parsed=parse_qs(raw.decode(errors='replace'))
        return {k:(v if len(v)>1 else v[0]) for k,v in parsed.items()}
    def do_GET(self):
        u=urlparse(self.path); q=parse_qs(u.query)
        if u.path in {"/logo.png", "/corporate-logo.png"}: return serve_corporate_logo(self)
        if u.path.startswith('/static/'):
            path=STATIC/u.path.split('/')[-1]
            if path.exists():
                data=path.read_bytes(); self.send_response(200); self.send_header('Content-Type','text/css' if path.suffix=='.css' else 'application/javascript'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        if u.path=='/attachments/open':
            stored=Path(q.get('file',[''])[0]).name; path=(ATTACHMENTS/stored).resolve()
            if ATTACHMENTS.resolve() not in path.parents or not path.is_file():
                return self.send_html(layout('No encontrado','<h1>Adjunto no encontrado</h1>'),404)
            try:
                open_local_file(path)
                self.send_response(303); self.send_header('Location',self.headers.get('Referer','/')); self.end_headers()
            except Exception as exc:
                self.send_html(layout('No se pudo abrir','<h1>No se pudo abrir el adjunto</h1><p>'+esc(str(exc))+'</p>'),500)
            return
        if u.path.startswith('/attachments/'):
            stored=Path(u.path.split('/')[-1]).name; path=ATTACHMENTS/stored
            if path.exists() and path.is_file():
                data=path.read_bytes(); ctype=mimetypes.guess_type(path.name)[0] or 'application/octet-stream'
                disposition='attachment' if q.get('download',['0'])[0]=='1' else 'inline'
                self.send_response(200); self.send_header('Content-Type',ctype); self.send_header('Content-Disposition',f'{disposition}; filename="{safe_filename(path.name.split("_",1)[-1])}"'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        routes={'/':dashboard,'/projects':lambda:project_list(q),'/tasks':lambda:task_list(q),'/responsibles':responsibles_page,'/responsible':lambda:responsible_detail(q.get('id',[''])[0]),'/calendar':calendar_view,'/project/new':project_form,'/task/new':lambda:task_form(selected_project=q.get('project_id',[''])[0]),'/responsible/new':responsible_form}
        if u.path in routes: self.send_html(routes[u.path]()); return
        if u.path=='/project': self.send_html(project_detail(q.get('id',[''])[0])); return
        if u.path=='/project/report': self.send_html(project_report(q.get('id',[''])[0])); return
        if u.path=='/task': self.send_html(task_detail(q.get('id',[''])[0])); return
        if u.path=='/project/note/edit': self.send_html(note_form('project',q.get('id',[''])[0],q.get('note_id',[''])[0])); return
        if u.path=='/task/note/edit': self.send_html(note_form('task',q.get('id',[''])[0],q.get('note_id',[''])[0])); return
        if u.path=='/project/edit':
            p=next((x for x in projects() if x['id']==q.get('id',[''])[0]),None); self.send_html(project_form(p)); return
        if u.path=='/task/edit':
            t=next((x for x in tasks() if x['id']==q.get('id',[''])[0]),None); self.send_html(task_form(t)); return
        if u.path=='/responsible/edit':
            r=next((x for x in responsibles() if x['id']==q.get('id',[''])[0]),None); self.send_html(responsible_form(r)); return
        self.send_html(layout('No encontrado','<h1>Página no encontrada</h1>'),404)
    def do_POST(self):
        f=self.form()
        if self.path=='/responsible/save':
            people=responsibles(); rid=str(f.get('id','') or uid('rsp')); old=next((x for x in people if x.get('id')==rid),{})
            person={**old,'id':rid,'name':str(f.get('name','')).strip(),'email':str(f.get('email','')).strip(),'created':old.get('created',now()),'updated':now()}
            people=[person if x.get('id')==rid else x for x in people] if old else people+[person]; write_json(RESPONSIBLES,people); self.redirect('/responsibles'); return
        if self.path=='/responsible/delete':
            rid=str(f.get('id','')); write_json(RESPONSIBLES,[r for r in responsibles() if r.get('id')!=rid])
            ps=projects(); ts=tasks()
            for item in ps+ts:
                ids=selected_responsibles(item); item['responsible_ids']=[x for x in ids if x!=rid]; item['owner']=''
            write_json(PROJECTS,ps); write_json(TASKS,ts); self.redirect('/responsibles'); return
        if self.path=='/project/save':
            ps=projects(); pid=f.get('id') or uid('prj'); old=next((x for x in ps if x['id']==pid),{})
            p={**old,'id':pid,'name':f.get('name','').strip(),'description':f.get('description','').strip(),'wiki_pages':field_values(f,'wiki_pages'),'responsible_ids':field_values(f,'responsible_ids'),'owner':'','status':f.get('status','Planificado'),'priority':f.get('priority','Media'),'progress':max(0,min(100,int(f.get('progress','0') or 0))),'start_date':f.get('start_date',''),'end_date':f.get('end_date',''),'history':old.get('history',[]),'created':old.get('created',now()),'updated':now()}
            ps=[p if x['id']==pid else x for x in ps] if old else ps+[p]; write_json(PROJECTS,ps); self.redirect('/project?id='+pid); return
        if self.path=='/project/delete':
            pid=f.get('id'); doomed_projects=[p for p in projects() if p['id']==pid]; doomed_tasks=[t for t in tasks() if t.get('project_id')==pid]
            for p in doomed_projects:
                for h in p.get('history',[]): delete_uploads(h.get('attachments',[]))
            for t in doomed_tasks:
                delete_uploads(t.get('attachments',[]))
                for h in t.get('history',[]): delete_uploads(h.get('attachments',[]))
            write_json(PROJECTS,[p for p in projects() if p['id']!=pid]); write_json(TASKS,[t for t in tasks() if t.get('project_id')!=pid]); self.redirect('/projects'); return
        if self.path=='/project/note':
            ps=projects(); pid=f.get('id'); text=f.get('text','').strip()
            for p in ps:
                if p['id']==pid and text: p.setdefault('history',[]).append({'id':uid('note'),'date':datetime.now().strftime('%Y-%m-%d %H:%M'),'text':text,'links':parse_links(f.get('links','')),'attachments':f.get('_uploads',[]),'created':now()}); p['updated']=now()
            write_json(PROJECTS,ps); self.redirect('/project?id='+pid); return
        if self.path=='/task/note':
            ts=tasks(); tid=f.get('id'); text=str(f.get('text','')).strip()
            for t in ts:
                if t.get('id')==tid and text:
                    t.setdefault('history',[]).append({'id':uid('note'),'date':datetime.now().strftime('%Y-%m-%d %H:%M'),'text':text,'links':parse_links(f.get('links','')),'attachments':f.get('_uploads',[]),'created':now()})
                    t['updated']=now()
            write_json(TASKS,ts); self.redirect('/task?id='+str(tid)); return
        if self.path in ('/project/note/save','/task/note/save'):
            kind='project' if self.path.startswith('/project') else 'task'
            path=PROJECTS if kind=='project' else TASKS
            collection=projects() if kind=='project' else tasks()
            parent_id=str(f.get('id','')); note_id=str(f.get('note_id',''))
            for item in collection:
                if item.get('id')!=parent_id: continue
                history=item.setdefault('history',[]); ensure_note_ids(history)
                for note in history:
                    if note.get('id')!=note_id: continue
                    old_attachments=note.get('attachments',[])
                    if f.get('remove_attachments')=='1':
                        delete_uploads(old_attachments); old_attachments=[]
                    value=str(f.get('date','')).strip().replace('T',' ')
                    note['date']=value or note.get('date') or datetime.now().strftime('%Y-%m-%d %H:%M')
                    note['text']=str(f.get('text','')).strip()
                    note['links']=parse_links(f.get('links',''))
                    note['attachments']=old_attachments+f.get('_uploads',[])
                    note['modified']=datetime.now().strftime('%Y-%m-%d %H:%M')
                    note.setdefault('created',now())
                    item['updated']=now()
                    break
            write_json(path,collection); self.redirect(f'/{kind}?id='+parent_id); return
        if self.path in ('/project/note/delete','/task/note/delete'):
            kind='project' if self.path.startswith('/project') else 'task'
            path=PROJECTS if kind=='project' else TASKS
            collection=projects() if kind=='project' else tasks()
            parent_id=str(f.get('id','')); note_id=str(f.get('note_id',''))
            for item in collection:
                if item.get('id')!=parent_id: continue
                history=item.setdefault('history',[]); ensure_note_ids(history)
                doomed=next((n for n in history if n.get('id')==note_id),None)
                if doomed: delete_uploads(doomed.get('attachments',[]))
                item['history']=[n for n in history if n.get('id')!=note_id]
                item['updated']=now()
            write_json(path,collection); self.redirect(f'/{kind}?id='+parent_id); return
        if self.path=='/task/save':
            ts=tasks(); tid=f.get('id') or uid('tsk'); old=next((x for x in ts if x['id']==tid),{})
            new_uploads=f.get('_uploads',[])
            if f.get('replace_assets')=='1':
                delete_uploads(old.get('attachments',[])); attachments=new_uploads
            else:
                attachments=old.get('attachments',[])+new_uploads
            task_type=f.get('task_type','project')
            project_id='' if task_type=='independent' else f.get('project_id','')
            if task_type=='project' and not project_id:
                self.redirect('/task/edit?id='+quote(tid) if old else '/task/new')
                return
            t={**old,'id':tid,'title':f.get('title','').strip(),'description':f.get('description','').strip(),'task_type':task_type,'project_id':project_id,'wiki_pages':field_values(f,'wiki_pages'),'responsible_ids':field_values(f,'responsible_ids'),'owner':'','status':f.get('status','Pendiente'),'priority':f.get('priority','Media'),'start_date':f.get('start_date',''),'due_date':f.get('due_date',''),'comments':f.get('comments','').strip(),'links':parse_links(f.get('links','')),'attachments':attachments,'history':old.get('history',[]),'created':old.get('created',now()),'updated':now()}
            ts=[t if x['id']==tid else x for x in ts] if old else ts+[t]; write_json(TASKS,ts); self.redirect('/task?id='+tid); return
        if self.path=='/task/delete':
            tid=f.get('id'); doomed=next((t for t in tasks() if t['id']==tid),None)
            if doomed:
                delete_uploads(doomed.get('attachments',[]))
                for h in doomed.get('history',[]): delete_uploads(h.get('attachments',[]))
            write_json(TASKS,[t for t in tasks() if t['id']!=tid]); self.redirect('/tasks'); return
        self.redirect('/')
    def log_message(self,*args): pass

if __name__=='__main__':
    port=int(os.environ.get('GESTOR_PORT','8080')); print(f'Gestor disponible en http://127.0.0.1:{port}'); ThreadingHTTPServer(('127.0.0.1',port),Handler).serve_forever()
