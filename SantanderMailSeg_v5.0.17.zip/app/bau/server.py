from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, quote
from pathlib import Path
from datetime import datetime
import os, json, html, re, uuid, mimetypes

CORPORATE_THEME_CSS = r"""
:root{
 --cyber-bg:#05080d;--cyber-bg2:#09111a;--cyber-panel:#0d1721;--cyber-panel2:#111f2b;
 --cyber-line:#1e3b4c;--cyber-line-hot:#00c8ff;--cyber-red:#ec0000;--cyber-red2:#ff3347;
 --cyber-cyan:#00c8ff;--cyber-green:#24e6a1;--cyber-amber:#ffbf3f;--cyber-text:#e8f3f8;
 --cyber-muted:#8ba5b4;--cyber-shadow:0 14px 40px rgba(0,0,0,.38);
 --brand-font:"Segoe UI",Arial,sans-serif;--body-font:"Segoe UI",Arial,sans-serif;
}
*{box-sizing:border-box}html{background:var(--cyber-bg)}html,body{font-family:var(--body-font)!important}
body{background:radial-gradient(circle at 85% -10%,rgba(0,200,255,.10),transparent 34%),radial-gradient(circle at 5% 0%,rgba(236,0,0,.10),transparent 30%),linear-gradient(145deg,var(--cyber-bg),var(--cyber-bg2) 55%,#05090e)!important;color:var(--cyber-text)!important;min-height:100vh}
body:before{content:"";position:fixed;inset:0;pointer-events:none;z-index:-1;background-image:linear-gradient(rgba(255,255,255,.018) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.018) 1px,transparent 1px);background-size:32px 32px;mask-image:linear-gradient(to bottom,black,transparent 88%)}
header{min-height:72px!important;height:auto!important;padding:10px 22px!important;background:linear-gradient(90deg,rgba(8,15,22,.98),rgba(12,25,35,.98))!important;color:var(--cyber-text)!important;border:0!important;border-bottom:1px solid rgba(0,200,255,.35)!important;box-shadow:0 8px 28px rgba(0,0,0,.35)!important;position:sticky!important;top:0!important;z-index:30!important}
header:after{content:"";position:absolute;left:0;right:0;bottom:-1px;height:2px;background:linear-gradient(90deg,var(--cyber-red),transparent 26%,var(--cyber-cyan) 70%,transparent);opacity:.9}
.brand{color:var(--cyber-text)!important;font-size:19px!important;font-weight:700!important;letter-spacing:.4px!important;text-transform:none;display:flex!important;align-items:center!important;gap:12px!important}
.brand img,.brand-logo{width:45px!important;height:45px!important;object-fit:contain!important;filter:drop-shadow(0 0 10px rgba(236,0,0,.45))}
.brand::before{display:none!important}.brand small{color:var(--cyber-cyan)!important}
.shell{min-height:calc(100vh - 72px)!important}.shell aside,aside{background:linear-gradient(180deg,rgba(10,18,27,.97),rgba(7,13,20,.98))!important;border:0!important;border-right:1px solid rgba(0,200,255,.20)!important;box-shadow:8px 0 26px rgba(0,0,0,.2)!important}
aside nav a,nav a{position:relative;color:#a9bfca!important;border:1px solid transparent!important;border-radius:6px!important;letter-spacing:.2px!important;transition:background .16s ease,border-color .16s ease,color .16s ease,transform .16s ease!important}
aside nav a:before,nav a:before{content:"";position:absolute;left:0;top:25%;bottom:25%;width:2px;background:transparent;box-shadow:none}
aside nav a:hover,nav a:hover{background:rgba(0,200,255,.07)!important;color:#fff!important;border-color:rgba(0,200,255,.24)!important;transform:translateX(2px)}
aside nav a.active,nav a.active{background:linear-gradient(90deg,rgba(236,0,0,.20),rgba(0,200,255,.07))!important;color:#fff!important;border-color:rgba(236,0,0,.42)!important;border-left:1px solid rgba(236,0,0,.42)!important;font-weight:700!important;box-shadow:inset 3px 0 0 var(--cyber-red),0 0 18px rgba(236,0,0,.08)!important}
aside nav a.active:before{background:var(--cyber-red);box-shadow:0 0 10px var(--cyber-red)}.aside-note{color:#7896a6!important;border-color:rgba(0,200,255,.12)!important;background:transparent!important;box-shadow:none!important}
main{color:var(--cyber-text)!important}main h1,main h2,.page-title{color:#f2f8fb!important;letter-spacing:.25px!important}main h2:after{content:"";display:block;width:42px;height:2px;margin-top:7px;background:linear-gradient(90deg,var(--cyber-red),var(--cyber-cyan));box-shadow:0 0 8px rgba(0,200,255,.35)}main h3{color:#dcecf3!important}
p,small,.muted,.page-head p,.stats span,.stat span{color:var(--cyber-muted)!important}a{color:var(--cyber-cyan)!important}a:hover{color:#7ee6ff!important}
.card,.panel,.widget,.stat,.tile,.project-card,.task-card,.wiki-card,.bau-card,section,.hero,.info-card,.form-card,.filters,.module-tabs,.health-row,.pending-chip,.import-dialog,.summary-row,.current-assets{background:linear-gradient(145deg,rgba(15,27,38,.96),rgba(9,18,27,.96))!important;border:1px solid rgba(77,133,158,.28)!important;border-radius:8px!important;box-shadow:var(--cyber-shadow)!important;color:var(--cyber-text)!important;backdrop-filter:blur(8px)}
.card:hover,.project-card:hover,.task-card:hover,.pending-chip:hover{border-color:rgba(0,200,255,.42)!important}.stat strong,.stats strong,.health-value{color:#fff!important;text-shadow:0 0 16px rgba(0,200,255,.18)}
.btn,.button,button,input[type=submit],input[type=button]{min-height:36px;font-family:var(--body-font)!important;border-radius:5px!important;border:1px solid rgba(0,200,255,.35)!important;background:linear-gradient(180deg,#142734,#0d1a24)!important;color:#dff7ff!important;box-shadow:inset 0 1px rgba(255,255,255,.04),0 5px 16px rgba(0,0,0,.22)!important;transition:.16s ease!important;text-decoration:none!important}
.btn:hover,.button:hover,button:hover,input[type=submit]:hover,input[type=button]:hover{border-color:var(--cyber-cyan)!important;color:#fff!important;box-shadow:0 0 15px rgba(0,200,255,.18)!important;transform:translateY(-1px)}
.btn.primary,.btn-primary,.button-primary,button.primary,input[type=submit],.word-template-action{background:linear-gradient(180deg,var(--cyber-red2),var(--cyber-red))!important;border-color:#ff4c5c!important;color:#fff!important;box-shadow:0 0 18px rgba(236,0,0,.20)!important}
.btn.primary:hover,.btn-primary:hover,button.primary:hover,input[type=submit]:hover{background:linear-gradient(180deg,#ff4a5b,#c90000)!important;border-color:#ff7280!important}.btn.danger{background:#551520!important;border-color:#a92b3a!important;color:#ffd9dd!important}.secondary,.cancel{background:linear-gradient(180deg,#172a36,#101c25)!important;color:#d9edf5!important}
input,select,textarea{background:#07111a!important;color:var(--cyber-text)!important;border:1px solid #294757!important;border-radius:5px!important;font-family:var(--body-font)!important}input::placeholder,textarea::placeholder{color:#587180!important}input:focus,select:focus,textarea:focus{border-color:var(--cyber-cyan)!important;outline:0!important;box-shadow:0 0 0 2px rgba(0,200,255,.13),0 0 18px rgba(0,200,255,.08)!important}select option{background:#0a151e;color:#e7f4f8}
table{background:transparent!important;border-color:#29414e!important;color:var(--cyber-text)!important}thead th,table th{background:linear-gradient(180deg,#172b38,#10202b)!important;color:#dff7ff!important;border-color:#294958!important;text-transform:uppercase;letter-spacing:.45px}td,th{border-color:rgba(64,105,125,.28)!important}tbody tr:nth-child(even){background:rgba(255,255,255,.018)!important}tbody tr:hover{background:rgba(0,200,255,.045)!important}td a,.project-card h3 a{color:var(--cyber-cyan)!important}
.badge,.chip,.tag,.person-chip,.doc-category,.pending-filter,.search-filters a{border-radius:999px!important;background:#122631!important;color:#aeeeff!important;border:1px solid rgba(0,200,255,.25)!important}.status-finalizado,.status-completada{background:rgba(36,230,161,.10)!important;color:var(--cyber-green)!important;border-color:rgba(36,230,161,.28)!important}.status-en-curso,.badge.en-curso{background:rgba(0,200,255,.10)!important;color:#65ddff!important}.status-bloqueada,.status-cancelado,.priority-critica,.priority-crítica{background:rgba(236,0,0,.13)!important;color:#ff7180!important;border-color:rgba(236,0,0,.3)!important}.priority-alta{background:rgba(255,191,63,.11)!important;color:var(--cyber-amber)!important}
.notice,.alert,.callout,.import-warning{background:rgba(0,200,255,.055)!important;color:#ccecf5!important;border:1px solid rgba(0,200,255,.20)!important;border-left:4px solid var(--cyber-cyan)!important}.bar,.progress{background:#071119!important}.bar span,.progress span{background:linear-gradient(90deg,var(--cyber-red),var(--cyber-cyan))!important;box-shadow:0 0 12px rgba(0,200,255,.35)}
pre,code,.code-block,.summary-details{background:#03090d!important;color:#8fffd1!important;border:1px solid rgba(36,230,161,.22)!important;font-family:Consolas,"Courier New",monospace!important;text-shadow:0 0 7px rgba(36,230,161,.12)}.activity-icon,.linked-doc-dot,.timeline-dot{background:var(--cyber-red)!important;color:#fff!important;box-shadow:0 0 12px rgba(236,0,0,.55)!important}.import-modal{background:rgba(0,4,8,.82)!important}.import-dialog-head,.import-dialog-actions{border-color:#29414e!important;background:#0c1821!important}
::-webkit-scrollbar{width:11px;height:11px}::-webkit-scrollbar-track{background:#071019}::-webkit-scrollbar-thumb{background:#24404f;border:2px solid #071019;border-radius:8px}::-webkit-scrollbar-thumb:hover{background:#356477}
@media(max-width:900px){header{position:relative!important}.shell aside,aside{border-right:0!important;border-bottom:1px solid rgba(0,200,255,.2)!important}}

/* V5.0.17 sidebar-status hard override */
.aside-note,aside .aside-note{background:transparent!important;color:#7896a6!important;border:0!important;border-top:1px solid rgba(0,200,255,.14)!important;box-shadow:none!important;outline:0!important}
.aside-note *,aside .aside-note *{background:transparent!important;color:inherit!important}
.content .text-blue,.rendered-content .text-blue{color:#55bfff!important}.content .text-red,.rendered-content .text-red{color:#ff6674!important}.content strong,.rendered-content strong{font-weight:800!important}.content em,.rendered-content em{font-style:italic!important}
@media print{body,html{background:#fff!important;color:#111!important}body:before{display:none!important}header,aside,.header-actions,.actions,.toolbar,footer{display:none!important}main{width:100%!important;max-width:none!important;margin:0!important;padding:0!important}.card,.panel,.widget,.stat,.tile,.project-card,.task-card,.wiki-card,.bau-card,section,.hero,.info-card,.form-card{background:#fff!important;color:#111!important;border-color:#ccc!important;box-shadow:none!important;backdrop-filter:none!important}h1,h2,h3,p,small,.muted{color:#111!important;text-shadow:none!important}table{color:#111!important;background:#fff!important}table th,thead th{background:#ec0000!important;color:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}td{color:#111!important}pre,code,.code-block{background:#f2f2f2!important;color:#111!important;text-shadow:none!important}}


/* V4.1 Cyber Command visual refinement */
:root{
 --cc41-surface:#0b1721;--cc41-surface2:#0f202c;--cc41-surface3:#132936;
 --cc41-border:rgba(56,151,190,.34);--cc41-glow:rgba(0,200,255,.16);
}
body{background:
 radial-gradient(ellipse at 85% 0%,rgba(0,184,230,.12),transparent 38%),
 radial-gradient(ellipse at 8% 8%,rgba(236,0,0,.10),transparent 32%),
 linear-gradient(135deg,#05080d 0%,#07131c 55%,#061019 100%)!important}
body:after{content:"";position:fixed;inset:72px 0 0 0;pointer-events:none;z-index:-1;opacity:.24;background:
 linear-gradient(90deg,transparent 49.8%,rgba(0,200,255,.07) 50%,transparent 50.2%),
 linear-gradient(transparent 49.8%,rgba(0,200,255,.055) 50%,transparent 50.2%);background-size:96px 96px}
header{min-height:64px!important;padding:7px 16px!important}
header .brand{font-size:20px!important;text-shadow:0 0 18px rgba(0,200,255,.10)}
header .header-actions,header .actions{display:flex!important;gap:8px!important;align-items:center!important}
header .brand:after{content:"SOC // SECURE";font-size:9px;line-height:1;padding:5px 8px;margin-left:8px;color:#78e8ff;border:1px solid rgba(0,200,255,.33);border-radius:999px;background:rgba(0,200,255,.06);letter-spacing:1.1px;font-weight:700}
main{animation:cc41Fade .22s ease-out}
@keyframes cc41Fade{from{opacity:.25;transform:translateY(3px)}to{opacity:1;transform:none}}
/* Never use bright white application cards */
.stat,.stats>*,.metric,.metric-card,.summary-card,.template-card,.template-item,.template-type,.template-option,.type-card,.quick-card,.category-card,.counter-card,.word-template-card,.document-card,.attachment-card,.upload-card,.link-card,.mail-card,.mail-block,.note-block,.callout-note,.preview-card,.word-preview,.preview-box,.white-card{
 background:linear-gradient(145deg,rgba(17,34,46,.98),rgba(8,18,27,.98))!important;
 color:#eaf7fb!important;border:1px solid var(--cc41-border)!important;
 box-shadow:inset 0 1px rgba(255,255,255,.035),0 13px 28px rgba(0,0,0,.30)!important}
.stat:hover,.template-card:hover,.template-item:hover,.type-card:hover,.word-template-card:hover{transform:translateY(-2px);border-color:rgba(0,200,255,.60)!important;box-shadow:0 0 0 1px rgba(0,200,255,.08),0 16px 34px rgba(0,0,0,.35),0 0 20px var(--cc41-glow)!important}
.stat strong,.metric strong,.summary-card strong,.counter-card strong{font-size:28px!important;color:#70e8ff!important;text-shadow:0 0 18px rgba(0,200,255,.27)!important}
.stat span,.metric span,.summary-card span,.counter-card span{color:#9db5c1!important}
/* Explicitly catch common pale blocks from legacy CSS */
main [style*="background:white"],main [style*="background: white"],main [style*="background:#fff"],main [style*="background: #fff"],main [style*="background:#f"],main [style*="background: #f"]{background:linear-gradient(145deg,#10212d,#0a1720)!important;color:#e8f4f8!important}
section,.panel,.card,.form-card,.filters,.module-tabs,.current-assets{position:relative;overflow:hidden}
section:before,.panel:before,.card:before,.form-card:before{content:"";position:absolute;left:0;top:0;width:85px;height:1px;background:linear-gradient(90deg,#ec0000,#00c8ff,transparent);box-shadow:0 0 10px rgba(0,200,255,.30)}
/* Controls: sharper command-console geometry */
.btn,.button,button,input[type=submit],input[type=button]{border-radius:4px!important;letter-spacing:.1px!important;font-weight:600!important}
.btn:active,.button:active,button:active{transform:translateY(1px)!important}
.btn.primary,.btn-primary,button.primary,input[type=submit]{clip-path:polygon(7px 0,100% 0,100% calc(100% - 7px),calc(100% - 7px) 100%,0 100%,0 7px)}
/* Editor and technical blocks */
textarea,.editor-textarea,.editor-area,[contenteditable="true"]{background:#030d14!important;color:#e9f6fa!important;caret-color:#00d7ff!important}
pre,.code-block,.code-panel,.text-block{position:relative!important;background:linear-gradient(180deg,#02090e,#061117)!important;border-color:rgba(36,230,161,.28)!important;box-shadow:inset 0 0 28px rgba(0,0,0,.52),0 10px 25px rgba(0,0,0,.22)!important}
pre:before,.code-block:before,.code-panel:before{content:"TERMINAL / READ ONLY";display:block;color:#64f6c1;font:700 9px/1.2 Consolas,monospace;letter-spacing:1.1px;margin:0 0 10px;padding-bottom:7px;border-bottom:1px solid rgba(36,230,161,.18)}
/* Tables */
table{border-collapse:separate!important;border-spacing:0!important;overflow:hidden;border:1px solid rgba(49,111,139,.30)!important;border-radius:6px!important}
thead th,table th{height:40px!important;background:linear-gradient(180deg,#173140,#10232f)!important;border-bottom:1px solid rgba(0,200,255,.40)!important}
tbody td{padding-top:11px!important;padding-bottom:11px!important}
tbody tr{transition:background .14s ease,box-shadow .14s ease}
tbody tr:hover{box-shadow:inset 3px 0 0 #00c8ff!important}
/* White content previews stay readable but become intentional document canvases */
.document-preview,.word-document,.page-preview,.preview-paper,.rendered-content,.mail-preview,.note-preview{
 background:#eaf0f3!important;color:#16242d!important;border:1px solid #91a6b0!important;
 box-shadow:inset 0 0 0 1px #fff,0 14px 32px rgba(0,0,0,.28)!important}
.document-preview *,.word-document *,.page-preview *,.preview-paper *,.rendered-content *,.mail-preview *,.note-preview *{color:inherit}
/* Side navigation */
aside nav a{min-height:40px!important;display:flex!important;align-items:center!important}
aside nav a.active:after{content:"";position:absolute;right:9px;width:5px;height:5px;border-radius:50%;background:#00d5ff;box-shadow:0 0 10px #00d5ff}
/* Image presentation */
main img:not(.brand-logo):not(.logo){border-radius:5px;outline:1px solid rgba(0,200,255,.22);box-shadow:0 16px 35px rgba(0,0,0,.36)}
/* Improve readability of labels over dark UI */
label,legend,.field-label{color:#d9e8ee!important;font-weight:650!important}
hr{border:0!important;height:1px!important;background:linear-gradient(90deg,transparent,rgba(0,200,255,.55),rgba(236,0,0,.35),transparent)!important}
@media (prefers-reduced-motion:reduce){main{animation:none}.stat,.template-card,.template-item,.type-card,.word-template-card{transition:none!important}}

/* V4.1.8 · Corrección global de contraste y fondos residuales */
:root{color-scheme:dark}

/* Superficies de aplicación: nunca blancas ni gris muy claro */
main .content,
main .content-card,
main .editor-card,
main .editor-shell,
main .editor-container,
main .editor-preview,
main .preview,
main .preview-content,
main .preview-area,
main .details-card,
main .detail-card,
main .metadata-card,
main .date-card,
main .template-list,
main .template-row,
main .template-box,
main .template-selector,
main .template-choice,
main .attachment-panel,
main .attachments-panel,
main .attachment-box,
main .link-box,
main .upload-box,
main .mail,
main .communication,
main .admonition,
main .note,
main .toolbar,
main .toolbar-menu-panel,
main details,
main summary,
main fieldset{
 background:linear-gradient(145deg,#10212d,#091720)!important;
 color:#e7f4f8!important;
 border-color:rgba(66,139,169,.38)!important;
}

/* Texto sobre superficies oscuras */
main .content,
main .content p,
main .content li,
main .content div,
main .content span,
main .content strong,
main .content em,
main .content label,
main .communication,
main .communication p,
main .communication div,
main .communication span,
main .admonition,
main .admonition p,
main .admonition div,
main .note,
main .note p,
main .note div,
main .toolbar,
main .toolbar label,
main .attachment-panel,
main .attachments-panel,
main .attachment-box,
main .link-box,
main .upload-box,
main .template-row,
main .template-box,
main .template-selector,
main .template-choice{
 color:#e7f4f8!important;
}
main .content small,main .communication small,main .admonition small,
main .attachment-panel small,main .attachments-panel small,
main .template-row small,main .template-box small{color:#91acb9!important}

/* Captura fondos blancos/grises heredados o inline en contenedores */
main :is(div,section,article,form,aside,fieldset)[style*="background:white"],
main :is(div,section,article,form,aside,fieldset)[style*="background: white"],
main :is(div,section,article,form,aside,fieldset)[style*="background:#fff"],
main :is(div,section,article,form,aside,fieldset)[style*="background: #fff"],
main :is(div,section,article,form,aside,fieldset)[style*="background:#FFF"],
main :is(div,section,article,form,aside,fieldset)[style*="background-color:white"],
main :is(div,section,article,form,aside,fieldset)[style*="background-color: white"],
main :is(div,section,article,form,aside,fieldset)[style*="background-color:#fff"],
main :is(div,section,article,form,aside,fieldset)[style*="background-color: #fff"]{
 background:linear-gradient(145deg,#10212d,#091720)!important;
 color:#e7f4f8!important;
 border-color:rgba(66,139,169,.38)!important;
}

/* Barras de herramientas y botones: contraste completo */
main .toolbar button,main .editor-toolbar button,main .toolbar-menu summary,
main .toolbar .btn,main .editor-toolbar .btn{
 background:linear-gradient(180deg,#19303e,#0c1b25)!important;
 color:#e8f7fb!important;
 border-color:#31586b!important;
}
main .toolbar button:hover,main .editor-toolbar button:hover,
main .toolbar-menu summary:hover{background:#173746!important;color:#fff!important;border-color:#00c8ff!important}
main button:disabled,main .btn:disabled{background:#12202a!important;color:#617985!important;border-color:#273d48!important;opacity:.72!important}

/* Campos y selectores, incluidos date/file/múltiples */
main input,main select,main textarea,main [contenteditable="true"]{
 background:#06131c!important;color:#edf9fc!important;border-color:#31586b!important;
}
main input[type="file"]{color:#a9c2ce!important;padding:7px!important}
main input[type="file"]::file-selector-button{
 background:#18303d!important;color:#e8f7fb!important;border:1px solid #3a6477!important;
 border-radius:4px;padding:7px 11px;margin-right:10px;cursor:pointer
}
main select[multiple],main option{background:#071721!important;color:#edf9fc!important}

/* Tablas y filas que todavía traían blanco del tema clásico */
main table,main tbody,main tr,main td{color:#dcecf3!important}
main tbody tr{background:#0b1923!important}
main tbody tr:nth-child(even){background:#0e1e29!important}
main tbody tr:hover{background:#112a38!important}

/* Tarjetas de métricas, plantillas, adjuntos y elementos de selección */
main :is(.stats>div,.group-card,.project-card,.task-card,.template-card,.template-item,
.template-type,.template-option,.word-template-card,.document-card,.attachment-card,
.upload-card,.link-card,.meta-grid>div,.calendar-day,.info-card,.form-card){
 background:linear-gradient(145deg,#10212d,#091720)!important;
 color:#e7f4f8!important;border-color:rgba(66,139,169,.38)!important;
}
main :is(.stats>div,.group-card,.project-card,.task-card,.template-card,.template-item,
.template-type,.template-option,.word-template-card,.document-card,.attachment-card,
.upload-card,.link-card,.meta-grid>div,.calendar-day,.info-card,.form-card) p{color:#9bb4c0!important}

/* Vistas deliberadamente claras (documento/Word/PDF): texto siempre oscuro */
main :is(.document-preview,.word-document,.page-preview,.preview-paper,.rendered-document,
.document-canvas,.paper-preview,.docx-preview){
 background:#f4f7f8!important;color:#17252e!important;border-color:#90a6b1!important;
}
main :is(.document-preview,.word-document,.page-preview,.preview-paper,.rendered-document,
.document-canvas,.paper-preview,.docx-preview) *{color:#17252e!important;text-shadow:none!important}
main :is(.document-preview,.word-document,.page-preview,.preview-paper,.rendered-document,
.document-canvas,.paper-preview,.docx-preview) a{color:#006b91!important}

/* Correos y notas se integran en el tema oscuro, evitando texto claro sobre blanco */
main :is(.mail-preview,.mail-block,.mail-card,.communication,.note-preview,.note-block,.callout-note){
 background:#0c1c27!important;color:#e7f4f8!important;border-color:#315565!important;
}
main :is(.mail-preview,.mail-block,.mail-card,.communication,.note-preview,.note-block,.callout-note) *{
 color:inherit!important;text-shadow:none!important
}
main :is(.mail-preview,.mail-block,.mail-card,.communication,.note-preview,.note-block,.callout-note) a{color:#58d9ff!important}

/* Mantener impresión y exportación en blanco, solo fuera de pantalla */
@media print{
 :root{color-scheme:light}
 main .content,main .communication,main .admonition,main .note,
 main .mail-preview,main .mail-block,main .mail-card,
 main .document-preview,main .word-document,main .page-preview,main .preview-paper{
  background:#fff!important;color:#111!important;border-color:#ccc!important
 }
 main .content *,main .communication *,main .admonition *,main .note *,
 main .mail-preview *,main .mail-block *,main .mail-card *,
 main .document-preview *,main .word-document *,main .page-preview *,main .preview-paper *{color:#111!important}
}


/* === V4.1.8 FORCE DARK UI — sin superficies blancas en pantalla === */
@media screen {
  :root{color-scheme:dark!important}
  html,body,.shell,main,.main,.content-area,.page-content,.workspace,.layout,.app-shell{
    background:#050d14!important;color:#e7f4f8!important
  }
  main{background-image:radial-gradient(circle at 85% 0,rgba(0,200,255,.055),transparent 31%),radial-gradient(circle at 0 30%,rgba(236,0,0,.045),transparent 28%)!important}
  main :is(section,article,div,form,fieldset,details,dialog,table,tbody,tr,td,ul,ol,li){
    border-color:rgba(73,125,148,.30)
  }
  main :is(.card,.panel,.widget,.tile,.stat,.stats>div,.summary-card,.metric,.metric-card,
  .template-card,.template-grid>a,.template-grid a,.template-item,.template-row,.template-box,
  .template-selector,.template-choice,.template-type,.template-option,.type-card,.quick-card,
  .category-card,.counter-card,.project-card,.task-card,.wiki-card,.bau-card,.info-card,.form-card,
  .document-card,.attachment-card,.upload-card,.link-card,.mail-card,.mail-block,.communication,
  .note,.note-block,.admonition,.callout,.callout-note,.preview-card,.word-preview,.preview-box,
  .document-preview,.word-document,.page-preview,.preview-paper,.rendered-document,.document-canvas,
  .paper-preview,.docx-preview,.template-preview-panel,.template-editor-panel,.number-preview,
  .filters,.module-tabs,.calendar-list,.calendar-day,.content,.viewer,.editor-preview,.white-card){
    background:linear-gradient(145deg,#0d1c26,#07131b)!important;
    color:#e7f4f8!important;
    border-color:rgba(69,132,158,.42)!important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.025),0 10px 26px rgba(0,0,0,.23)!important
  }
  main :is(.template-card,.template-grid>a,.template-grid a,.template-item,.template-row,.template-box,
  .template-selector,.template-choice,.word-template-card,.document-card,.attachment-card,.upload-card,.link-card) *{
    background-color:transparent!important;color:#dff3f9!important
  }
  main :is(.template-card,.template-grid>a,.template-grid a,.template-item,.template-row,.template-box,
  .template-selector,.template-choice) a{color:#18d2ff!important}
  main :is(h1,h2,h3,h4,h5,h6,strong,label,legend,dt,th){color:#f1f8fb!important}
  main :is(p,span,small,em,li,dd,.muted,.meta,.help-text,.description){color:#9fb8c4!important}
  main a{color:#22cff8!important}
  main table,main thead,main tbody,main tr,main td,main th{background-color:#091720!important;color:#dcecf3!important}
  main thead th,main table th{background:#122936!important;color:#eaf8fc!important}
  main tbody tr:nth-child(even){background:#0b1b25!important}
  main tbody tr:hover{background:#102936!important}
  main input,main select,main textarea,main option,main [contenteditable=true]{
    background:#06131c!important;color:#edf9fc!important;border-color:#31586b!important
  }
  main input::placeholder,main textarea::placeholder{color:#6f8996!important;opacity:1}
  main input[type=file]{background:#071721!important;color:#a9c2ce!important}
  main input[type=file]::file-selector-button{background:#132b38!important;color:#e8f7fb!important;border:1px solid #386277!important}
  main button,main .btn,main .button,main a.btn,main .page-actions a,main .page-actions button,
  main .manage-templates-button,main summary{
    background:linear-gradient(180deg,#142c39,#0a1922)!important;color:#e7f4f8!important;border-color:#31586b!important
  }
  main button:hover,main .btn:hover,main .button:hover,main a.btn:hover,main summary:hover{
    background:#173746!important;color:#fff!important;border-color:#00c8ff!important
  }
  main .primary,main .btn.primary,main .btn-primary,main input[type=submit],main .danger.primary{
    background:linear-gradient(180deg,#ff293b,#c90000)!important;color:#fff!important;border-color:#ff4c5c!important
  }
  main button:disabled,main .btn:disabled{background:#101e27!important;color:#647b86!important;border-color:#263b46!important;opacity:.75!important}
  main .editor-toolbar,main .toolbar{background:#0b1a24!important;color:#e7f4f8!important;border-color:#31586b!important}
  main pre,main code,main .code-wrap,main .code-head,main .code-box{background:#02090e!important;color:#a8ffd8!important}
  main .wiki-image img,main img.preview,main .image-preview{background:#07131b!important;border-color:#31586b!important}
  footer{background:#07131b!important;color:#8da7b3!important;border-color:#29414e!important}
}


/* === V4.1.8 ABSOLUTE DARK SURFACE LOCK === */
@media screen {
  :root { color-scheme: dark !important; }
  html, body { background:#050d14 !important; color:#e7f4f8 !important; }

  /* Ventanas, modales y paneles fuera de main */
  .modal, .modal-content, .dialog, .dialog-content, dialog,
  .import-modal, .import-dialog, .import-dialog-head, .import-dialog-body,
  .import-dialog-actions, .import-summary, .summary-grid, .summary-row,
  .summary-details, .overlay-panel, .popup, .popover, .dropdown-menu {
    background:#091722 !important;
    color:#e7f4f8 !important;
    border-color:#294b5d !important;
  }
  .import-modal { background:rgba(1,8,13,.82) !important; }
  .import-dialog { box-shadow:0 24px 70px rgba(0,0,0,.72) !important; }
  .import-dialog-head, .import-dialog-actions { background:#0c1c27 !important; }
  .import-dialog-head h2, .import-file-label, .import-mode-title,
  .import-option strong, .summary-row strong { color:#edf9fc !important; }
  .import-option {
    background:#0b1a24 !important;
    color:#bdd2dc !important;
    border-color:#31586b !important;
  }
  .import-option:has(input:checked) {
    background:linear-gradient(90deg,rgba(236,0,0,.15),rgba(0,200,255,.07)) !important;
    border-color:#ec3040 !important;
  }
  .import-option small { color:#91adba !important; }
  .import-warning {
    background:#102632 !important;
    color:#d7edf5 !important;
    border-color:#00c8ff !important;
  }
  .import-close, .import-dialog-actions .cancel {
    background:#122633 !important;
    color:#edf9fc !important;
    border-color:#31586b !important;
  }

  /* Opciones, tarjetas y filas: nunca blancas en pantalla */
  :is(main,.main,.content-area,.page-content,.workspace,.layout,.app-shell)
  :is(.card,.panel,.tile,.widget,.stat,.stats>div,.template-card,.template-item,
  .template-grid>a,.template-grid a,.template-option,.template-type,.project-card,
  .task-card,.info-card,.form-card,.attachment-card,.upload-card,.link-card,
  .mail-card,.mail-block,.communication,.note,.note-block,.admonition,.callout,
  .preview-card,.preview-box,.document-preview,.word-document,.page-preview,
  .preview-paper,.rendered-document,.document-canvas,.paper-preview,.docx-preview,
  .template-preview-panel,.template-editor-panel,.filters,.module-tabs,.calendar-day,
  .content,.viewer,.editor-preview,.white-card,.health-row,.pending-chip,.summary-row) {
    background:linear-gradient(145deg,#0d1c26,#07131b) !important;
    color:#e7f4f8 !important;
    border-color:rgba(63,123,148,.42) !important;
  }

  /* Cualquier estilo inline claro dentro de la aplicación */
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background:white"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background: white"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background:#fff"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background: #fff"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background-color:white"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background-color: white"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background-color:#fff"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background-color: #fff"] {
    background:#0b1a24 !important;
    color:#e7f4f8 !important;
  }

  input, select, textarea, [contenteditable="true"] {
    background:#06131c !important;
    color:#edf9fc !important;
    border-color:#31586b !important;
  }
  input::placeholder, textarea::placeholder { color:#6f8b98 !important; }
  option { background:#071721 !important; color:#edf9fc !important; }
  input[type="file"] { background:#06131c !important; color:#a9c2ce !important; }
  input[type="file"]::file-selector-button {
    background:#18303d !important; color:#edf9fc !important;
    border:1px solid #3a6477 !important;
  }

  table, thead, tbody, tr, th, td { border-color:#294959 !important; }
  tbody tr { background:#0a1822 !important; }
  tbody tr:nth-child(even) { background:#0d1d27 !important; }
  th { background:#112a38 !important; color:#eaf8fc !important; }
  td { color:#dcecf3 !important; }

  /* Botones secundarios claros heredados */
  button:not(.primary):not(.danger), .btn:not(.primary):not(.danger),
  a.button:not(.primary):not(.danger) {
    background:#102531 !important;
    color:#e8f7fb !important;
    border-color:#31586b !important;
  }
  button:disabled, .btn:disabled {
    background:#101c24 !important; color:#607985 !important;
    border-color:#263b46 !important; opacity:.78 !important;
  }
}

/* La salida impresa y los informes deben seguir siendo blancos */
@media print {
  :root { color-scheme: light !important; }
  html, body { background:#fff !important; color:#111 !important; }
}


/* V5.0.17 · Formato inline global: los colores de autor prevalecen sobre el tema */
@media screen {
  html body main span.text-blue,
  html body main .text-blue,
  html body .wiki-content span.text-blue,
  html body .content span.text-blue,
  html body .rendered-content span.text-blue,
  html body article span.text-blue,
  html body .viewer span.text-blue {
    color:#39b9ff !important;
    -webkit-text-fill-color:#39b9ff !important;
  }
  html body main span.text-red,
  html body main .text-red,
  html body .wiki-content span.text-red,
  html body .content span.text-red,
  html body .rendered-content span.text-red,
  html body article span.text-red,
  html body .viewer span.text-red {
    color:#ff4f61 !important;
    -webkit-text-fill-color:#ff4f61 !important;
  }
  html body main strong,
  html body .wiki-content strong,
  html body .content strong,
  html body .rendered-content strong,
  html body article strong { font-weight:800 !important; }
  html body main em,
  html body .wiki-content em,
  html body .content em,
  html body .rendered-content em,
  html body article em { font-style:italic !important; }
}
"""

BASE=Path(__file__).resolve().parent
DATA=BASE/'data'; DB=DATA/'requests.json'; STATIC=BASE/'static'; LEGACY_UPLOADS=DATA/'uploads'; UPLOADS=BASE.parent.parent/'imagenes'
DATA.mkdir(exist_ok=True); LEGACY_UPLOADS.mkdir(parents=True,exist_ok=True); UPLOADS.mkdir(parents=True,exist_ok=True)
for old_image in LEGACY_UPLOADS.iterdir():
    if old_image.is_file() and not (UPLOADS/old_image.name).exists():
        try:
            import shutil; shutil.copy2(old_image,UPLOADS/old_image.name)
        except OSError: pass
PORTAL_URL=os.environ.get('PORTAL_URL','http://127.0.0.1:8079')
WIKI_URL=os.environ.get('WIKI_URL','http://127.0.0.1:8080')
GESTOR_URL=os.environ.get('GESTOR_URL','http://127.0.0.1:8081')
BITACORA_URL=os.environ.get('BITACORA_URL','http://127.0.0.1:8083')
BIBLIOTECA_URL=os.environ.get('BIBLIOTECA_URL','http://127.0.0.1:8084')
CAMBIOS_URL=os.environ.get('CAMBIOS_URL','http://127.0.0.1:8085')
SIEM_URL=os.environ.get('SIEM_URL','http://127.0.0.1:8086')
STATUSES=['Nueva','En curso','Pendiente','Resuelta','Cerrada']
PRIORITIES=['Baja','Media','Alta','Crítica']
TYPES=['Petición','Incidencia','Consulta','Cambio','Problema']
SYSTEMS=['Cisco ESA','Proofpoint','Splunk','CrowdStrike','Microsoft','Windows','Linux','Redes','Otro']

def esc(v): return html.escape(str(v or ''),quote=True)
def load():
    try:return json.loads(DB.read_text(encoding='utf-8')) if DB.exists() else []
    except Exception:return []
def save(rows): DB.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
def now(): return datetime.now().isoformat(timespec='seconds')
def getone(rid): return next((x for x in load() if x.get('id')==rid),None)
def badge(v,kind=''): return f'<span class="badge {kind} {esc(v).lower().replace("í","i").replace("á","a").replace(" ","-")}">{esc(v)}</span>'
def options(values,current=''): return ''.join(f'<option {"selected" if x==current else ""}>{esc(x)}</option>' for x in values)

def inline_format(value):
    # Mantener apóstrofes para interpretar la marca de cursiva del editor.
    s=html.escape(str(value or ''), quote=False)
    s=re.sub(r'\[azul\](.*?)\[/azul\]',r'<span class="text-blue">\1</span>',s,flags=re.S|re.I)
    s=re.sub(r'\[rojo\](.*?)\[/rojo\]',r'<span class="text-red">\1</span>',s,flags=re.S|re.I)
    s=re.sub(r'\[amarillo\](.*?)\[/amarillo\]',r'<mark>\1</mark>',s,flags=re.S|re.I)
    s=re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',s,flags=re.S)
    s=re.sub(r"''(.+?)''",r'<em>\1</em>',s,flags=re.S)
    s=re.sub(r'//(.+?)//',r'<em>\1</em>',s,flags=re.S)
    s=re.sub(r'(?<!\*)\*([^*\n]+?)\*(?!\*)',r'<em>\1</em>',s)
    s=re.sub(r'\[([^\]]+)\]\((https?://[^)]+)\)',r'<a href="\2" target="_blank" rel="noopener">\1</a>',s)
    return s

def render_leading_indent(raw_line, formatted_text):
    expanded=str(raw_line or '').expandtabs(4)
    leading=len(expanded)-len(expanded.lstrip(' '))
    return (('<span class="text-indent">'+('&#160;'*leading)+'</span>') if leading else '')+formatted_text

def render(text):
    lines=str(text or '').replace('\r\n','\n').split('\n')
    out=[]; paragraph=[]; list_tag=None; index=0

    def flush_paragraph():
        nonlocal paragraph
        if paragraph:
            out.append('<p>'+'<br>'.join(render_leading_indent(line, inline_format(line.lstrip().rstrip())) for line in paragraph)+'</p>')
            paragraph=[]

    def close_list():
        nonlocal list_tag
        if list_tag:
            out.append(f'</{list_tag}>')
            list_tag=None

    while index < len(lines):
        line=lines[index]
        stripped=line.strip()

        if stripped.startswith('```'):
            flush_paragraph(); close_list()
            language=stripped[3:].strip() or 'text'
            code=[]; index+=1
            while index < len(lines) and lines[index].strip()!='```':
                code.append(lines[index]); index+=1
            if index < len(lines): index+=1
            out.append(
                f'<div class="code-wrap"><div class="code-head"><span>{esc(language)}</span></div>'
                f'<pre class="code-box"><code class="language-{esc(language)}">'
                + html.escape('\n'.join(code))
                + '</code></pre></div>'
            )
            continue

        communication=re.fullmatch(r':::\s*(correo|email|caso|respuesta)(?:\s+(.+))?',stripped,re.I)
        if communication:
            flush_paragraph(); close_list()
            kind=communication.group(1).casefold()
            if kind=='email': kind='correo'
            title=(communication.group(2) or {'correo':'Correo','caso':'Caso','respuesta':'Respuesta'}[kind]).strip()
            block=[]; index+=1
            end_re=re.compile(rf':::\s*end(?:{re.escape(kind)}|correo|email|caso|respuesta)\s*$',re.I)
            while index < len(lines) and not end_re.fullmatch(lines[index].strip()):
                block.append(lines[index]); index+=1
            if index < len(lines): index+=1
            body='<br>'.join(inline_format(x) for x in block)
            out.append(f'<div class="communication {kind}"><div class="communication-title">{esc(title)}</div><div class="communication-body">{body}</div></div>')
            continue

        image=re.fullmatch(r'\[\[imagen:([^|\]]+)(?:\|([^\]]*))?\]\]',stripped)
        if image:
            flush_paragraph(); close_list()
            filename=image.group(1)
            description=image.group(2) or filename
            out.append(f'<img class="embedded-image" src="/uploads/{quote(filename)}" alt="{esc(description)}">')
            index+=1; continue

        heading=re.fullmatch(r'(={2,6})\s*(.*?)\s*\1',stripped)
        if heading:
            flush_paragraph(); close_list()
            level=min(len(heading.group(1)),6)
            out.append(f'<h{level}>{inline_format(heading.group(2))}</h{level}>')
            index+=1; continue

        # Sintaxis Wiki moderna:
        # !!! advertencia:
        # contenido
        # !!!
        notice_open=re.match(r'^!!!\s+(nota|advertencia|informacion|información)\s*:?\s*(.*)$',stripped,re.I)
        if notice_open:
            flush_paragraph(); close_list()
            kind=notice_open.group(1).casefold().replace('ó','o')
            trailing=notice_open.group(2).strip()
            block=[]; index+=1
            while index < len(lines) and lines[index].strip()!='!!!':
                block.append(lines[index]); index+=1
            if index < len(lines) and lines[index].strip()=='!!!':
                index+=1
            elif trailing:
                # Compatibilidad con avisos antiguos de una sola línea.
                block=[trailing]
            label={'advertencia':'Advertencia','nota':'Nota','informacion':'Información'}[kind]
            content='<br>'.join(inline_format(x) for x in block if x.strip())
            out.append(f'<div class="admonition {kind}"><strong>{label}</strong>{("<div>"+content+"</div>") if content else ""}</div>')
            continue

        bullet=re.match(r'^\s*[-*]\s+(.*)$',line)
        ordered=re.match(r'^\s*\d+\.\s+(.*)$',line)
        if bullet or ordered:
            flush_paragraph()
            wanted='ul' if bullet else 'ol'
            if list_tag != wanted:
                close_list(); out.append(f'<{wanted}>'); list_tag=wanted
            out.append('<li>'+inline_format((bullet or ordered).group(1))+'</li>')
            index+=1; continue

        if not stripped:
            flush_paragraph(); close_list(); index+=1; continue

        close_list(); paragraph.append(line); index+=1

    flush_paragraph(); close_list()
    return ''.join(out)

def layout(title,body,active='bau'):
    links=[('Inicio',PORTAL_URL),('Wiki',WIKI_URL),('Proyectos y tareas',GESTOR_URL),('BAU','/'),('Bitácora',BITACORA_URL),('Biblioteca',BIBLIOTECA_URL),('Búsquedas SIEM',SIEM_URL),('Plantillas',CAMBIOS_URL)]
    nav=''.join(f'<a class="{"active" if n.lower().startswith(active) else ""}" href="{esc(u)}">{esc(n)}</a>' for n,u in links)
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)} · BAU</title><link rel="stylesheet" href="/static/style.css"><style>{CORPORATE_THEME_CSS}
/* V26.1: logotipo configurable desde configuracion/logo/logo.png */
.brand::before{{display:none!important;content:none!important;background-image:none!important}}
.brand .brand-logo{{
  display:block!important;width:46px!important;height:46px!important;
  min-width:46px!important;max-width:46px!important;flex:0 0 46px!important;
  object-fit:contain!important;object-position:center!important;
  background:transparent!important;border:0!important;border-radius:0!important;
  box-shadow:none!important
}}
.brand>span{{display:block!important}}
@media(max-width:760px){{
  .brand .brand-logo{{width:38px!important;height:38px!important;min-width:38px!important;max-width:38px!important;flex-basis:38px!important}}
}}
</style>
<style>
/* V27.3 · Logotipo adaptable al espacio disponible */
header{{
  min-height:72px!important;
  height:auto!important;
  overflow:visible!important;
}}
.brand{{
  min-height:56px!important;
  max-width:min(70vw,760px)!important;
  display:flex!important;
  align-items:center!important;
  gap:14px!important;
  overflow:visible!important;
}}
.brand::before{{
  display:none!important;
  content:none!important;
  background-image:none!important;
}}
.brand .brand-logo{{
  display:block!important;
  width:auto!important;
  height:auto!important;
  min-width:0!important;
  min-height:0!important;
  max-width:210px!important;
  max-height:56px!important;
  flex:0 1 auto!important;
  object-fit:contain!important;
  object-position:left center!important;
  background:transparent!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
}}
.brand>span{{
  display:block!important;
  min-width:0!important;
  overflow:hidden!important;
  text-overflow:ellipsis!important;
}}
@media(max-width:760px){{
  header{{min-height:64px!important;padding:8px 14px!important}}
  .brand{{min-height:46px!important;gap:10px!important;max-width:76vw!important}}
  .brand .brand-logo{{
    width:auto!important;
    height:auto!important;
    max-width:145px!important;
    max-height:46px!important;
  }}
}}
@media(max-width:480px){{
  .brand .brand-logo{{max-width:105px!important;max-height:42px!important}}
  .brand>span{{font-size:15px!important}}
}}
</style>

<style>
/* V27.7 · Logotipo ajustado al encabezado */
header{{min-height:58px!important;height:auto!important;padding:6px 16px!important;overflow:hidden!important}}
.brand{{min-height:44px!important;display:flex!important;align-items:center!important;gap:10px!important;max-width:min(64vw,700px)!important;overflow:hidden!important}}
.brand::before{{display:none!important;content:none!important}}
.brand .brand-logo{{display:block!important;width:auto!important;height:auto!important;max-width:150px!important;max-height:40px!important;min-width:0!important;min-height:0!important;flex:0 1 auto!important;object-fit:contain!important;object-position:left center!important}}
.brand>span{{min-width:0!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important}}
@media(max-width:760px){{.brand .brand-logo{{max-width:110px!important;max-height:36px!important}}.brand>span{{font-size:15px!important}}}}
</style>

<style>
/* V27.8 · Editor BAU agrupado como Wiki */
.wiki-style-toolbar{{display:flex!important;flex-wrap:wrap;gap:7px!important;align-items:center!important;padding:8px!important;background:#0b1a24!important;border:1px solid #31586b!important;border-radius:7px!important}}
.toolbar-main,.toolbar-groups{{display:flex;flex-wrap:wrap;gap:6px;align-items:center}}
.toolbar-groups{{border-left:1px solid #31586b;padding-left:7px}}
.toolbar-menu{{position:relative}}
.toolbar-menu summary{{list-style:none;cursor:pointer;border:1px solid #31586b;background:#102431;color:#e8f4f8;border-radius:5px;padding:7px 10px;font-weight:600}}
.toolbar-menu summary::-webkit-details-marker{{display:none}}
.toolbar-menu-panel{{position:absolute;z-index:50;top:calc(100% + 4px);left:0;min-width:165px;background:#0b1a24;border:1px solid #31586b;border-radius:7px;padding:6px;box-shadow:0 5px 18px rgba(0,0,0,.15);display:grid;gap:4px}}
.toolbar-menu-panel button{{width:100%;text-align:left}}
.communication{{margin:12px 0;border:1px solid #31586b;border-left:5px solid #ec0000;border-radius:7px;background:#081720;color:#e8f4f8}}
.communication-title{{font-weight:700;background:#102431;padding:9px 12px;border-bottom:1px solid #31586b;color:#f4fbfd}}
.communication-body{{padding:12px;line-height:1.55}}
.communication.respuesta{{border-left-color:#007a3d}}
.communication.respuesta .communication-title{{background:#0d2a22;color:#9dffd4}}
.admonition{{margin:12px 0;padding:12px;border-left:5px solid #b30000;border-radius:6px}}
.admonition>div{{margin-top:6px}}
.admonition.advertencia{{background:#2a1b08;border-color:#ff9d2e;color:#ffe0ad}}
.admonition.nota{{background:#18131b;border-color:#ec0000;color:#f5e9ee}}
.admonition.informacion{{background:#0b2130;border-color:#00bfe8;color:#c9f4ff}}
.code-wrap{{margin:12px 0;border:1px solid #59636e;border-radius:7px;overflow:hidden}}
.code-head{{padding:7px 10px;background:#2d333b;color:#fff;font-weight:700}}
.code-box{{margin:0!important;border:0!important;border-radius:0!important}}
@media(max-width:800px){{.toolbar-groups{{border-left:0;padding-left:0}}.toolbar-menu-panel{{position:fixed;left:10%;right:10%;top:auto;min-width:0}}
</style>

<style>
/* V4.1.8 · Editor BAU completamente oscuro */
main .editor-block,main .editor-head,main .wiki-style-toolbar,main .toolbar,main .toolbar-main,main .toolbar-groups,main .toolbar-menu-panel{{background:#0b1a24!important;color:#e8f4f8!important;border-color:#31586b!important}}
main .editor-block{{overflow:hidden!important;border:1px solid #31586b!important;border-radius:8px!important}}
main .editor-head{{min-height:44px!important;padding:10px 12px!important;border-bottom:1px solid #31586b!important}}
main .editor-head:empty{{display:none!important}}
main .wiki-style-toolbar{{border-radius:0!important;border-left:0!important;border-right:0!important}}
main .toolbar-menu summary,main .toolbar button,main .wiki-style-toolbar button{{background:#102431!important;color:#e8f4f8!important;border-color:#31586b!important}}
main .toolbar-menu-panel button{{background:#0d202b!important;color:#e8f4f8!important;border-color:#31586b!important}}
main textarea.editor-textarea,main .editor-block textarea,main [contenteditable=true]{{background:#020d14!important;color:#f1fbff!important;border-color:#00a9d6!important}}
main .communication,main .communication-title,main .communication-body{{background:#081720!important;color:#e8f4f8!important;border-color:#31586b!important}}
main .communication-title{{background:#102431!important}}
main .communication.respuesta{{border-left-color:#22d68f!important}}
main .communication.respuesta .communication-title{{background:#0d2a22!important;color:#9dffd4!important}}
main .admonition{{color:#e8f4f8!important;border-top:1px solid #31586b!important;border-right:1px solid #31586b!important;border-bottom:1px solid #31586b!important}}
main .admonition.advertencia{{background:#2a1b08!important;color:#ffe0ad!important;border-left-color:#ff9d2e!important}}
main .admonition.nota{{background:#18131b!important;color:#f5e9ee!important;border-left-color:#ec0000!important}}
main .admonition.informacion{{background:#0b2130!important;color:#c9f4ff!important;border-left-color:#00bfe8!important}}
main .code-wrap,main .code-head,main .code-box,main .code-box code,main pre,main code{{background:#02090e!important;color:#a8ffd8!important;border-color:#31586b!important}}
main .code-head{{background:#0c1d27!important;border-bottom:1px solid #31586b!important}}
main .code-box{{box-shadow:none!important}}
main .editor-block>div:first-child:empty,main .editor-block>.spacer:empty{{display:none!important}}
</style>
</head><body><header><div class="brand"><img class="brand-logo" src="/logo.png?v=27112" alt="Logo Santander" onerror="this.style.display=\'none\'"><span>Santander Mail Security · BAU</span></div><div class="header-actions"><a class="btn" href="/">← Atrás</a><a class="btn" href="{esc(PORTAL_URL)}">Inicio común</a><a class="btn primary" href="/new">+ Nueva BAU</a></div></header><div class="shell"><aside><nav>{nav}</nav><div class="aside-note">Aplicación local<br>Sin usuarios<br>Datos en JSON</div></aside><main>{body}</main></div><script src="/static/editor.js"></script></body></html>'''

def dashboard(qs):
    rows=load()
    status=qs.get('status',[''])[0]
    term=qs.get('q',[''])[0].strip().casefold()
    period=qs.get('period',['all'])[0]
    if period not in ('all','today'):
        period='all'
    today=datetime.now().date().isoformat()
    filtered=[r for r in rows if (period!='today' or r.get('opened')==today) and (not status or r.get('status')==status) and (not term or term in ' '.join(str(r.get(k,'')) for k in ('number','title','request','investigation','resolution','system')).casefold())]
    filtered.sort(key=lambda x:x.get('opened',''),reverse=True)
    stats=''.join(f'<a class="stat" href="/?status={quote(s)}&period={quote(period)}"><strong>{sum(1 for r in rows if r.get("status")==s and (period!="today" or r.get("opened")==today))}</strong><span>{esc(s)}</span></a>' for s in STATUSES)
    trs=''.join(f'''<tr><td><a href="/view?id={esc(r['id'])}"><strong>{esc(r.get('number'))}</strong></a></td><td class="bau-title"><a href="/view?id={esc(r['id'])}">{esc(r.get('title'))}</a></td><td>{badge(r.get('type'))}</td><td>{badge(r.get('status'))}</td><td>{badge(r.get('priority'),'priority')}</td><td>{esc(r.get('system'))}</td><td>{esc(r.get('opened'))}</td></tr>''' for r in filtered) or '<tr><td colspan="7" class="empty">No hay registros.</td></tr>'
    period_options=f'<option value="all" {"selected" if period=="all" else ""}>Todas</option><option value="today" {"selected" if period=="today" else ""}>Solo hoy</option>'
    body=f'''<div class="page-head"><div><h1>Gestión BAU</h1><p>Control de peticiones, incidencias, consultas, cambios y problemas operativos.</p></div></div><div class="stats">{stats}</div><section class="card"><form class="filters bau-filters" method="get"><input name="q" value="{esc(qs.get('q',[''])[0])}" placeholder="Número, título, sistema, solicitud o resolución"><select name="period" aria-label="Periodo">{period_options}</select><select name="status"><option value="">Todos los estados</option>{options(STATUSES,status)}</select><button class="btn">Filtrar</button><a class="btn ghost" href="/">Limpiar</a></form></section><section class="card"><div class="section-head"><h2>Registros BAU</h2><a class="btn primary" href="/new">+ Nueva BAU</a></div><div class="table-wrap"><table class="bau-table"><colgroup><col class="col-number"><col class="col-title"><col class="col-type"><col class="col-status"><col class="col-priority"><col class="col-system"><col class="col-date"></colgroup><thead><tr><th>Número</th><th>Título</th><th>Tipo</th><th>Estado</th><th>Prioridad</th><th>Sistema</th><th>Fecha</th></tr></thead><tbody>{trs}</tbody></table></div></section>'''
    return layout('Gestión BAU',body)

def editor_field(label,name,value):
    return f'''<section class="editor-block">
    <div class="editor-head"><h2>{label}</h2></div>
    <div class="toolbar wiki-style-toolbar" data-target="{name}">
      <div class="toolbar-main">
        <button type="button" data-heading="2">Título</button>
        <button type="button" data-wrap="**">Negrita</button>
        <button type="button" data-wrap="''">Cursiva</button>
        <button type="button" data-wrap-open="[u]" data-wrap-close="[/u]">Subrayado</button>
        <button type="button" data-wrap-open="[azul]" data-wrap-close="[/azul]">Azul</button>
        <button type="button" data-wrap-open="[rojo]" data-wrap-close="[/rojo]">Rojo</button>
        <button type="button" data-wrap-open="[amarillo]" data-wrap-close="[/amarillo]">Resaltar</button>
        <button type="button" data-insert="- ">Lista</button>
        <button type="button" data-indent="1">→ Tab +4</button>
        <button type="button" data-outdent="1">← Quitar tab</button>
      </div>
      <div class="toolbar-groups">
        <details class="toolbar-menu">
          <summary>✉ Comunicación</summary>
          <div class="toolbar-menu-panel">
            <button type="button" data-communication="correo">Correo</button>
            <button type="button" data-communication="caso">Caso</button>
            <button type="button" data-communication="respuesta">Respuesta</button>
          </div>
        </details>
        <details class="toolbar-menu">
          <summary>⚠ Avisos</summary>
          <div class="toolbar-menu-panel">
            <button type="button" data-notice="nota">Nota</button>
            <button type="button" data-notice="advertencia">Advertencia</button>
            <button type="button" data-notice="informacion">Información</button>
          </div>
        </details>
        <details class="toolbar-menu">
          <summary>⌨ Código</summary>
          <div class="toolbar-menu-panel">
            <button type="button" data-code="spl">SPL</button>
            <button type="button" data-code="python">Python</button>
            <button type="button" data-code="text">Texto</button>
          </div>
        </details>
        <button type="button" data-image="1">🖼 Imagen</button>
      </div>
    </div>
    <textarea wrap="soft" id="{name}" name="{name}" rows="12">{esc(value)}</textarea>
    <input class="bau-image-input" data-editor="{name}" type="file" accept="image/*" hidden>
    <span class="upload-status" data-status="{name}"></span>
    </section>'''

def form_page(r=None):
    r=r or {}; editing=bool(r)
    body=f'''<div class="page-head"><div><h1>{'Editar' if editing else 'Nueva'} BAU</h1><p>La solicitud, investigación y resolución usan el mismo editor técnico de la Wiki.</p></div></div><form class="card form" method="post" action="/save"><input type="hidden" name="id" value="{esc(r.get('id'))}"><div class="grid"><label>Número de petición o incidencia<input name="number" value="{esc(r.get('number'))}" placeholder="Ej.: INC12345, RITM-00821 o SR-ABC-77" required maxlength="80"></label><label>Fecha apertura<input type="date" name="opened" value="{esc(r.get('opened') or datetime.now().date())}" required></label><label>Estado<select name="status">{options(STATUSES,r.get('status','Nueva'))}</select></label><label>Prioridad<select name="priority">{options(PRIORITIES,r.get('priority','Media'))}</select></label><label>Tipo<select name="type">{options(TYPES,r.get('type','Petición'))}</select></label><label>Sistema<select name="system">{options(SYSTEMS,r.get('system','Otro'))}</select></label></div><label>Título / breve descripción<input name="title" value="{esc(r.get('title'))}" required maxlength="180"></label>{editor_field('Solicitud','request',r.get('request',''))}{editor_field('Investigación','investigation',r.get('investigation',''))}{editor_field('Resolución','resolution',r.get('resolution',''))}<div class="actions"><button class="btn primary">Guardar BAU</button><a class="btn ghost" href="/">Cancelar</a></div></form>'''
    return layout('Editor BAU',body)

def section(title,text): return f'<section class="card content"><h2>{title}</h2>{render(text or "Sin información.")}</section>'
def view_page(r):
    comments=''.join(f'<li><strong>{esc(c.get("date"))}</strong><div>{render(c.get("text",""))}</div></li>' for c in reversed(r.get('comments',[]))) or '<li class="empty">Sin comentarios.</li>'
    body=f'''<div class="page-head"><div><div class="eyebrow">{esc(r.get('number'))}</div><h1>{esc(r.get('title'))}</h1><div class="badges">{badge(r.get('type'))}{badge(r.get('status'))}{badge(r.get('priority'),'priority')}{badge(r.get('system'))}</div></div><div><a class="btn" href="/edit?id={esc(r['id'])}">Editar</a> <form class="inline" method="post" action="/delete" onsubmit="return confirm('¿Eliminar esta BAU?')"><input type="hidden" name="id" value="{esc(r['id'])}"><button class="btn danger">Eliminar</button></form></div></div><div class="meta-grid"><div><strong>Fecha de apertura</strong><span>{esc(r.get('opened'))}</span></div><div><strong>Última actualización</strong><span>{esc(r.get('updated') or '—')}</span></div></div>{section('Solicitud',r.get('request'))}{section('Investigación',r.get('investigation'))}{section('Resolución',r.get('resolution'))}<section class="card"><h2>Seguimiento</h2><form method="post" action="/comment"><input type="hidden" name="id" value="{esc(r['id'])}"><textarea wrap="soft" name="text" rows="4" required placeholder="Añadir avance, respuesta, incidencia o decisión..."></textarea><button class="btn primary">Añadir comentario</button></form><ul class="timeline">{comments}</ul></section>'''
    return layout(r.get('number','BAU'),body)



def corporate_logo_path():
    """Devuelve siempre el logo corporativo de la carpeta raíz del proyecto."""
    source=Path(__file__).resolve()
    try:
        app_root=source.parents[2]
    except IndexError:
        app_root=source.parent
    candidates=[
        app_root/"configuracion"/"logo"/"logo.png",
        source.parent/"logo.png",
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None

def serve_corporate_logo(handler):
    path = corporate_logo_path()
    if path is None:
        handler.send_response(404)
        handler.end_headers()
        return
    data = path.read_bytes()
    handler.send_response(200)
    handler.send_header("Content-Type", "image/png")
    handler.send_header("Content-Length", str(len(data)))
    handler.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
    handler.end_headers()
    handler.wfile.write(data)

class Handler(BaseHTTPRequestHandler):
    def send_html(self,s,status=200):
        b=s.encode(); self.send_response(status); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def send_json(self,value,status=200):
        b=json.dumps(value,ensure_ascii=False).encode('utf-8'); self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def redirect(self,u): self.send_response(303); self.send_header('Location',u); self.end_headers()
    def read_form(self):
        n=int(self.headers.get('Content-Length','0') or 0); return {k:v[-1] for k,v in parse_qs(self.rfile.read(n).decode('utf-8','replace'),keep_blank_values=True).items()}
    def multipart(self,max_size=15*1024*1024):
        ct=self.headers.get('Content-Type',''); m=re.search(r'boundary="?([^";]+)',ct); n=int(self.headers.get('Content-Length','0') or 0)
        if not m or n<=0 or n>max_size:return {},[]
        raw=self.rfile.read(n); boundary=('--'+m.group(1)).encode(); fields={}; files=[]
        for part in raw.split(boundary):
            if b'\r\n\r\n' not in part: continue
            head,body=part.split(b'\r\n\r\n',1); body=body.rstrip(b'\r\n-'); nm=re.search(br'name="([^"]+)"',head)
            if not nm: continue
            name=nm.group(1).decode('utf-8','replace'); fm=re.search(br'filename="([^"]*)"',head)
            if fm:
                fn=Path(fm.group(1).decode('utf-8','replace')).name
                if fn: files.append((name,fn,body))
            else: fields[name]=body.decode('utf-8','replace')
        return fields,files
    def do_GET(self):
        u=urlparse(self.path); qs=parse_qs(u.query)
        if u.path in {"/logo.png", "/corporate-logo.png"}: return serve_corporate_logo(self)
        if u.path=='/': return self.send_html(dashboard(qs))
        if u.path=='/new': return self.send_html(form_page())
        if u.path in ('/view','/edit'):
            r=getone(qs.get('id',[''])[0])
            if not r:return self.send_error(404)
            return self.send_html(form_page(r) if u.path=='/edit' else view_page(r))
        if u.path.startswith('/static/'):
            p=(STATIC/u.path.removeprefix('/static/')).resolve()
            if STATIC.resolve() not in p.parents or not p.is_file(): return self.send_error(404)
            b=p.read_bytes(); self.send_response(200); self.send_header('Content-Type',mimetypes.guess_type(p)[0] or 'application/octet-stream'); self.send_header('Content-Length',str(len(b))); self.end_headers(); return self.wfile.write(b)
        if u.path.startswith('/uploads/'):
            p=(UPLOADS/Path(u.path).name).resolve()
            if UPLOADS.resolve() not in p.parents or not p.is_file():return self.send_error(404)
            b=p.read_bytes(); self.send_response(200); self.send_header('Content-Type',mimetypes.guess_type(p)[0] or 'application/octet-stream'); self.send_header('Content-Length',str(len(b))); self.end_headers(); return self.wfile.write(b)
        self.send_error(404)
    def do_POST(self):
        u=urlparse(self.path)
        if u.path=='/upload-image':
            _,files=self.multipart()
            if not files:return self.send_json({'ok':False,'error':'No se recibió ninguna imagen.'},400)
            _,fn,data=files[0]; ext=Path(fn).suffix.lower()
            if ext not in ('.png','.jpg','.jpeg','.gif','.webp'):return self.send_json({'ok':False,'error':'Formato no permitido.'},400)
            stored=f'{uuid.uuid4().hex}{ext}'; (UPLOADS/stored).write_bytes(data)
            return self.send_json({'ok':True,'filename':stored})
        if u.path=='/save':
            f=self.read_form(); rows=load(); rid=f.get('id') or uuid.uuid4().hex; old=next((x for x in rows if x.get('id')==rid),{})
            r={**old,**{k:f.get(k,'').strip() for k in ('number','opened','status','priority','type','system','title','request','investigation','resolution')}}
            if not r.get('number'): return self.send_html(layout('Número obligatorio','<section class="card"><h1>Falta el número</h1><p>Introduce manualmente el número de petición o incidencia.</p><a class="btn" href="javascript:history.back()">Volver</a></section>'),400)
            r['id']=rid; r['created']=old.get('created') or now(); r['updated']=now(); r.setdefault('comments',[])
            rows=[x for x in rows if x.get('id')!=rid]+[r]; save(rows); return self.redirect('/view?id='+rid)
        f=self.read_form(); rid=f.get('id',''); rows=load(); r=next((x for x in rows if x.get('id')==rid),None)
        if u.path=='/comment' and r:
            r.setdefault('comments',[]).append({'date':now(),'text':f.get('text','').strip()}); r['updated']=now(); save(rows); return self.redirect('/view?id='+rid)
        if u.path=='/delete':
            save([x for x in rows if x.get('id')!=rid]); return self.redirect('/')
        self.send_error(404)
    def log_message(self,*args): pass

if __name__=='__main__': ThreadingHTTPServer(('127.0.0.1',int(os.environ.get('BAU_PORT','8082'))),Handler).serve_forever()
