from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path
from datetime import datetime
import os, json, html, uuid
import re

CORPORATE_THEME_CSS = r"""
:root{
 --cyber-bg:#05080d;--cyber-bg2:#09111a;--cyber-panel:#0d1721;--cyber-panel2:#111f2b;
 --cyber-line:#1e3b4c;--cyber-line-hot:#00c8ff;--cyber-red:#ec0000;--cyber-red2:#ff3347;
 --cyber-cyan:#00c8ff;--cyber-green:#24e6a1;--cyber-amber:#ffbf3f;--cyber-text:#e8f3f8;
 --cyber-muted:#8ba5b4;--cyber-shadow:0 14px 40px rgba(0,0,0,.38);
 --brand-font:"Segoe UI",Arial,sans-serif;--body-font:"Segoe UI",Arial,sans-serif;
}
*{box-sizing:border-box}html{background:var(--cyber-bg)}html,body{font-family:var(--body-font)!important}
body{background:radial-gradient(circle at 85% -10%,rgba(0,200,255,.10),transparent 34%),radial-gradient(circle at 5% 0%,rgba(236,0,0,.10),transparent 30%),linear-gradient(145deg,var(--cyber-bg),var(--cyber-bg2) 55%,#05090e)!important;color:var(--cyber-text)!important;min-height:100vh}
body:before{content:"";position:fixed;inset:0;pointer-events:none;z-index:-1;background-image:linear-gradient(rgba(255,255,255,.018) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.018) 1px,transparent 1px);background-size:32px 32px;mask-image:linear-gradient(to bottom,black,transparent 88%)}
header{min-height:72px!important;height:auto!important;padding:10px 22px!important;background:linear-gradient(90deg,rgba(8,15,22,.98),rgba(12,25,35,.98))!important;color:var(--cyber-text)!important;border:0!important;border-bottom:1px solid rgba(0,200,255,.35)!important;box-shadow:0 8px 28px rgba(0,0,0,.35)!important;position:sticky!important;top:0!important;z-index:30!important}
header:after{content:"";position:absolute;left:0;right:0;bottom:-1px;height:2px;background:linear-gradient(90deg,var(--cyber-red),transparent 26%,var(--cyber-cyan) 70%,transparent);opacity:.9}
.brand{color:var(--cyber-text)!important;font-size:19px!important;font-weight:700!important;letter-spacing:.4px!important;text-transform:none;display:flex!important;align-items:center!important;gap:12px!important}
.brand img,.brand-logo{width:45px!important;height:45px!important;object-fit:contain!important;filter:drop-shadow(0 0 10px rgba(236,0,0,.45))}
.brand::before{display:none!important}.brand small{color:var(--cyber-cyan)!important}
.shell{min-height:calc(100vh - 72px)!important}.shell aside,aside{background:linear-gradient(180deg,rgba(10,18,27,.97),rgba(7,13,20,.98))!important;border:0!important;border-right:1px solid rgba(0,200,255,.20)!important;box-shadow:8px 0 26px rgba(0,0,0,.2)!important}
aside nav a,nav a{position:relative;color:#a9bfca!important;border:1px solid transparent!important;border-radius:6px!important;letter-spacing:.2px!important;transition:background .16s ease,border-color .16s ease,color .16s ease,transform .16s ease!important}
aside nav a:before,nav a:before{content:"";position:absolute;left:0;top:25%;bottom:25%;width:2px;background:transparent;box-shadow:none}
aside nav a:hover,nav a:hover{background:rgba(0,200,255,.07)!important;color:#fff!important;border-color:rgba(0,200,255,.24)!important;transform:translateX(2px)}
aside nav a.active,nav a.active{background:linear-gradient(90deg,rgba(236,0,0,.20),rgba(0,200,255,.07))!important;color:#fff!important;border-color:rgba(236,0,0,.42)!important;border-left:1px solid rgba(236,0,0,.42)!important;font-weight:700!important;box-shadow:inset 3px 0 0 var(--cyber-red),0 0 18px rgba(236,0,0,.08)!important}
aside nav a.active:before{background:var(--cyber-red);box-shadow:0 0 10px var(--cyber-red)}.aside-note{color:#7896a6!important;border-color:rgba(0,200,255,.12)!important;background:transparent!important;box-shadow:none!important}
main{color:var(--cyber-text)!important}main h1,main h2,.page-title{color:#f2f8fb!important;letter-spacing:.25px!important}main h2:after{content:"";display:block;width:42px;height:2px;margin-top:7px;background:linear-gradient(90deg,var(--cyber-red),var(--cyber-cyan));box-shadow:0 0 8px rgba(0,200,255,.35)}main h3{color:#dcecf3!important}
p,small,.muted,.page-head p,.stats span,.stat span{color:var(--cyber-muted)!important}a{color:var(--cyber-cyan)!important}a:hover{color:#7ee6ff!important}
.card,.panel,.widget,.stat,.tile,.project-card,.task-card,.wiki-card,.bau-card,section,.hero,.info-card,.form-card,.filters,.module-tabs,.health-row,.pending-chip,.import-dialog,.summary-row,.current-assets{background:linear-gradient(145deg,rgba(15,27,38,.96),rgba(9,18,27,.96))!important;border:1px solid rgba(77,133,158,.28)!important;border-radius:8px!important;box-shadow:var(--cyber-shadow)!important;color:var(--cyber-text)!important;backdrop-filter:blur(8px)}
.card:hover,.project-card:hover,.task-card:hover,.pending-chip:hover{border-color:rgba(0,200,255,.42)!important}.stat strong,.stats strong,.health-value{color:#fff!important;text-shadow:0 0 16px rgba(0,200,255,.18)}
.btn,.button,button,input[type=submit],input[type=button]{min-height:36px;font-family:var(--body-font)!important;border-radius:5px!important;border:1px solid rgba(0,200,255,.35)!important;background:linear-gradient(180deg,#142734,#0d1a24)!important;color:#dff7ff!important;box-shadow:inset 0 1px rgba(255,255,255,.04),0 5px 16px rgba(0,0,0,.22)!important;transition:.16s ease!important;text-decoration:none!important}
.btn:hover,.button:hover,button:hover,input[type=submit]:hover,input[type=button]:hover{border-color:var(--cyber-cyan)!important;color:#fff!important;box-shadow:0 0 15px rgba(0,200,255,.18)!important;transform:translateY(-1px)}
.btn.primary,.btn-primary,.button-primary,button.primary,input[type=submit],.word-template-action{background:linear-gradient(180deg,var(--cyber-red2),var(--cyber-red))!important;border-color:#ff4c5c!important;color:#fff!important;box-shadow:0 0 18px rgba(236,0,0,.20)!important}
.btn.primary:hover,.btn-primary:hover,button.primary:hover,input[type=submit]:hover{background:linear-gradient(180deg,#ff4a5b,#c90000)!important;border-color:#ff7280!important}.btn.danger{background:#551520!important;border-color:#a92b3a!important;color:#ffd9dd!important}.secondary,.cancel{background:linear-gradient(180deg,#172a36,#101c25)!important;color:#d9edf5!important}
input,select,textarea{background:#07111a!important;color:var(--cyber-text)!important;border:1px solid #294757!important;border-radius:5px!important;font-family:var(--body-font)!important}input::placeholder,textarea::placeholder{color:#587180!important}input:focus,select:focus,textarea:focus{border-color:var(--cyber-cyan)!important;outline:0!important;box-shadow:0 0 0 2px rgba(0,200,255,.13),0 0 18px rgba(0,200,255,.08)!important}select option{background:#0a151e;color:#e7f4f8}
table{background:transparent!important;border-color:#29414e!important;color:var(--cyber-text)!important}thead th,table th{background:linear-gradient(180deg,#172b38,#10202b)!important;color:#dff7ff!important;border-color:#294958!important;text-transform:uppercase;letter-spacing:.45px}td,th{border-color:rgba(64,105,125,.28)!important}tbody tr:nth-child(even){background:rgba(255,255,255,.018)!important}tbody tr:hover{background:rgba(0,200,255,.045)!important}td a,.project-card h3 a{color:var(--cyber-cyan)!important}
.badge,.chip,.tag,.person-chip,.doc-category,.pending-filter,.search-filters a{border-radius:999px!important;background:#122631!important;color:#aeeeff!important;border:1px solid rgba(0,200,255,.25)!important}.status-finalizado,.status-completada{background:rgba(36,230,161,.10)!important;color:var(--cyber-green)!important;border-color:rgba(36,230,161,.28)!important}.status-en-curso,.badge.en-curso{background:rgba(0,200,255,.10)!important;color:#65ddff!important}.status-bloqueada,.status-cancelado,.priority-critica,.priority-crítica{background:rgba(236,0,0,.13)!important;color:#ff7180!important;border-color:rgba(236,0,0,.3)!important}.priority-alta{background:rgba(255,191,63,.11)!important;color:var(--cyber-amber)!important}
.notice,.alert,.callout,.import-warning{background:rgba(0,200,255,.055)!important;color:#ccecf5!important;border:1px solid rgba(0,200,255,.20)!important;border-left:4px solid var(--cyber-cyan)!important}.bar,.progress{background:#071119!important}.bar span,.progress span{background:linear-gradient(90deg,var(--cyber-red),var(--cyber-cyan))!important;box-shadow:0 0 12px rgba(0,200,255,.35)}
pre,code,.code-block,.summary-details{background:#03090d!important;color:#8fffd1!important;border:1px solid rgba(36,230,161,.22)!important;font-family:Consolas,"Courier New",monospace!important;text-shadow:0 0 7px rgba(36,230,161,.12)}.activity-icon,.linked-doc-dot,.timeline-dot{background:var(--cyber-red)!important;color:#fff!important;box-shadow:0 0 12px rgba(236,0,0,.55)!important}.import-modal{background:rgba(0,4,8,.82)!important}.import-dialog-head,.import-dialog-actions{border-color:#29414e!important;background:#0c1821!important}
::-webkit-scrollbar{width:11px;height:11px}::-webkit-scrollbar-track{background:#071019}::-webkit-scrollbar-thumb{background:#24404f;border:2px solid #071019;border-radius:8px}::-webkit-scrollbar-thumb:hover{background:#356477}
@media(max-width:900px){header{position:relative!important}.shell aside,aside{border-right:0!important;border-bottom:1px solid rgba(0,200,255,.2)!important}}

/* V5.0.17 sidebar-status hard override */
.aside-note,aside .aside-note{background:transparent!important;color:#7896a6!important;border:0!important;border-top:1px solid rgba(0,200,255,.14)!important;box-shadow:none!important;outline:0!important}
.aside-note *,aside .aside-note *{background:transparent!important;color:inherit!important}
@media print{body,html{background:#fff!important;color:#111!important}body:before{display:none!important}header,aside,.header-actions,.actions,.toolbar,footer{display:none!important}main{width:100%!important;max-width:none!important;margin:0!important;padding:0!important}.card,.panel,.widget,.stat,.tile,.project-card,.task-card,.wiki-card,.bau-card,section,.hero,.info-card,.form-card{background:#fff!important;color:#111!important;border-color:#ccc!important;box-shadow:none!important;backdrop-filter:none!important}h1,h2,h3,p,small,.muted{color:#111!important;text-shadow:none!important}table{color:#111!important;background:#fff!important}table th,thead th{background:#ec0000!important;color:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}td{color:#111!important}pre,code,.code-block{background:#f2f2f2!important;color:#111!important;text-shadow:none!important}}


/* V4.1 Cyber Command visual refinement */
:root{
 --cc41-surface:#0b1721;--cc41-surface2:#0f202c;--cc41-surface3:#132936;
 --cc41-border:rgba(56,151,190,.34);--cc41-glow:rgba(0,200,255,.16);
}
body{background:
 radial-gradient(ellipse at 85% 0%,rgba(0,184,230,.12),transparent 38%),
 radial-gradient(ellipse at 8% 8%,rgba(236,0,0,.10),transparent 32%),
 linear-gradient(135deg,#05080d 0%,#07131c 55%,#061019 100%)!important}
body:after{content:"";position:fixed;inset:72px 0 0 0;pointer-events:none;z-index:-1;opacity:.24;background:
 linear-gradient(90deg,transparent 49.8%,rgba(0,200,255,.07) 50%,transparent 50.2%),
 linear-gradient(transparent 49.8%,rgba(0,200,255,.055) 50%,transparent 50.2%);background-size:96px 96px}
header{min-height:64px!important;padding:7px 16px!important}
header .brand{font-size:20px!important;text-shadow:0 0 18px rgba(0,200,255,.10)}
header .header-actions,header .actions{display:flex!important;gap:8px!important;align-items:center!important}
header .brand:after{content:"SOC // SECURE";font-size:9px;line-height:1;padding:5px 8px;margin-left:8px;color:#78e8ff;border:1px solid rgba(0,200,255,.33);border-radius:999px;background:rgba(0,200,255,.06);letter-spacing:1.1px;font-weight:700}
main{animation:cc41Fade .22s ease-out}
@keyframes cc41Fade{from{opacity:.25;transform:translateY(3px)}to{opacity:1;transform:none}}
/* Never use bright white application cards */
.stat,.stats>*,.metric,.metric-card,.summary-card,.template-card,.template-item,.template-type,.template-option,.type-card,.quick-card,.category-card,.counter-card,.word-template-card,.document-card,.attachment-card,.upload-card,.link-card,.mail-card,.mail-block,.note-block,.callout-note,.preview-card,.word-preview,.preview-box,.white-card{
 background:linear-gradient(145deg,rgba(17,34,46,.98),rgba(8,18,27,.98))!important;
 color:#eaf7fb!important;border:1px solid var(--cc41-border)!important;
 box-shadow:inset 0 1px rgba(255,255,255,.035),0 13px 28px rgba(0,0,0,.30)!important}
.stat:hover,.template-card:hover,.template-item:hover,.type-card:hover,.word-template-card:hover{transform:translateY(-2px);border-color:rgba(0,200,255,.60)!important;box-shadow:0 0 0 1px rgba(0,200,255,.08),0 16px 34px rgba(0,0,0,.35),0 0 20px var(--cc41-glow)!important}
.stat strong,.metric strong,.summary-card strong,.counter-card strong{font-size:28px!important;color:#70e8ff!important;text-shadow:0 0 18px rgba(0,200,255,.27)!important}
.stat span,.metric span,.summary-card span,.counter-card span{color:#9db5c1!important}
/* Explicitly catch common pale blocks from legacy CSS */
main [style*="background:white"],main [style*="background: white"],main [style*="background:#fff"],main [style*="background: #fff"],main [style*="background:#f"],main [style*="background: #f"]{background:linear-gradient(145deg,#10212d,#0a1720)!important;color:#e8f4f8!important}
section,.panel,.card,.form-card,.filters,.module-tabs,.current-assets{position:relative;overflow:hidden}
section:before,.panel:before,.card:before,.form-card:before{content:"";position:absolute;left:0;top:0;width:85px;height:1px;background:linear-gradient(90deg,#ec0000,#00c8ff,transparent);box-shadow:0 0 10px rgba(0,200,255,.30)}
/* Controls: sharper command-console geometry */
.btn,.button,button,input[type=submit],input[type=button]{border-radius:4px!important;letter-spacing:.1px!important;font-weight:600!important}
.btn:active,.button:active,button:active{transform:translateY(1px)!important}
.btn.primary,.btn-primary,button.primary,input[type=submit]{clip-path:polygon(7px 0,100% 0,100% calc(100% - 7px),calc(100% - 7px) 100%,0 100%,0 7px)}
/* Editor and technical blocks */
textarea,.editor-textarea,.editor-area,[contenteditable="true"]{background:#030d14!important;color:#e9f6fa!important;caret-color:#00d7ff!important}
pre,.code-block,.code-panel,.text-block{position:relative!important;background:linear-gradient(180deg,#02090e,#061117)!important;border-color:rgba(36,230,161,.28)!important;box-shadow:inset 0 0 28px rgba(0,0,0,.52),0 10px 25px rgba(0,0,0,.22)!important}
pre:before,.code-block:before,.code-panel:before{content:"TERMINAL / READ ONLY";display:block;color:#64f6c1;font:700 9px/1.2 Consolas,monospace;letter-spacing:1.1px;margin:0 0 10px;padding-bottom:7px;border-bottom:1px solid rgba(36,230,161,.18)}
/* Tables */
table{border-collapse:separate!important;border-spacing:0!important;overflow:hidden;border:1px solid rgba(49,111,139,.30)!important;border-radius:6px!important}
thead th,table th{height:40px!important;background:linear-gradient(180deg,#173140,#10232f)!important;border-bottom:1px solid rgba(0,200,255,.40)!important}
tbody td{padding-top:11px!important;padding-bottom:11px!important}
tbody tr{transition:background .14s ease,box-shadow .14s ease}
tbody tr:hover{box-shadow:inset 3px 0 0 #00c8ff!important}
/* White content previews stay readable but become intentional document canvases */
.document-preview,.word-document,.page-preview,.preview-paper,.rendered-content,.mail-preview,.note-preview{
 background:#eaf0f3!important;color:#16242d!important;border:1px solid #91a6b0!important;
 box-shadow:inset 0 0 0 1px #fff,0 14px 32px rgba(0,0,0,.28)!important}
.document-preview *,.word-document *,.page-preview *,.preview-paper *,.rendered-content *,.mail-preview *,.note-preview *{color:inherit}
/* Side navigation */
aside nav a{min-height:40px!important;display:flex!important;align-items:center!important}
aside nav a.active:after{content:"";position:absolute;right:9px;width:5px;height:5px;border-radius:50%;background:#00d5ff;box-shadow:0 0 10px #00d5ff}
/* Image presentation */
main img:not(.brand-logo):not(.logo){border-radius:5px;outline:1px solid rgba(0,200,255,.22);box-shadow:0 16px 35px rgba(0,0,0,.36)}
/* Improve readability of labels over dark UI */
label,legend,.field-label{color:#d9e8ee!important;font-weight:650!important}
hr{border:0!important;height:1px!important;background:linear-gradient(90deg,transparent,rgba(0,200,255,.55),rgba(236,0,0,.35),transparent)!important}
@media (prefers-reduced-motion:reduce){main{animation:none}.stat,.template-card,.template-item,.type-card,.word-template-card{transition:none!important}}

/* V4.1.8 · Corrección global de contraste y fondos residuales */
:root{color-scheme:dark}

/* Superficies de aplicación: nunca blancas ni gris muy claro */
main .content,
main .content-card,
main .editor-card,
main .editor-shell,
main .editor-container,
main .editor-preview,
main .preview,
main .preview-content,
main .preview-area,
main .details-card,
main .detail-card,
main .metadata-card,
main .date-card,
main .template-list,
main .template-row,
main .template-box,
main .template-selector,
main .template-choice,
main .attachment-panel,
main .attachments-panel,
main .attachment-box,
main .link-box,
main .upload-box,
main .mail,
main .communication,
main .admonition,
main .note,
main .toolbar,
main .toolbar-menu-panel,
main details,
main summary,
main fieldset{
 background:linear-gradient(145deg,#10212d,#091720)!important;
 color:#e7f4f8!important;
 border-color:rgba(66,139,169,.38)!important;
}

/* Texto sobre superficies oscuras */
main .content,
main .content p,
main .content li,
main .content div,
main .content span,
main .content strong,
main .content em,
main .content label,
main .communication,
main .communication p,
main .communication div,
main .communication span,
main .admonition,
main .admonition p,
main .admonition div,
main .note,
main .note p,
main .note div,
main .toolbar,
main .toolbar label,
main .attachment-panel,
main .attachments-panel,
main .attachment-box,
main .link-box,
main .upload-box,
main .template-row,
main .template-box,
main .template-selector,
main .template-choice{
 color:#e7f4f8!important;
}
main .content small,main .communication small,main .admonition small,
main .attachment-panel small,main .attachments-panel small,
main .template-row small,main .template-box small{color:#91acb9!important}

/* Captura fondos blancos/grises heredados o inline en contenedores */
main :is(div,section,article,form,aside,fieldset)[style*="background:white"],
main :is(div,section,article,form,aside,fieldset)[style*="background: white"],
main :is(div,section,article,form,aside,fieldset)[style*="background:#fff"],
main :is(div,section,article,form,aside,fieldset)[style*="background: #fff"],
main :is(div,section,article,form,aside,fieldset)[style*="background:#FFF"],
main :is(div,section,article,form,aside,fieldset)[style*="background-color:white"],
main :is(div,section,article,form,aside,fieldset)[style*="background-color: white"],
main :is(div,section,article,form,aside,fieldset)[style*="background-color:#fff"],
main :is(div,section,article,form,aside,fieldset)[style*="background-color: #fff"]{
 background:linear-gradient(145deg,#10212d,#091720)!important;
 color:#e7f4f8!important;
 border-color:rgba(66,139,169,.38)!important;
}

/* Barras de herramientas y botones: contraste completo */
main .toolbar button,main .editor-toolbar button,main .toolbar-menu summary,
main .toolbar .btn,main .editor-toolbar .btn{
 background:linear-gradient(180deg,#19303e,#0c1b25)!important;
 color:#e8f7fb!important;
 border-color:#31586b!important;
}
main .toolbar button:hover,main .editor-toolbar button:hover,
main .toolbar-menu summary:hover{background:#173746!important;color:#fff!important;border-color:#00c8ff!important}
main button:disabled,main .btn:disabled{background:#12202a!important;color:#617985!important;border-color:#273d48!important;opacity:.72!important}

/* Campos y selectores, incluidos date/file/múltiples */
main input,main select,main textarea,main [contenteditable="true"]{
 background:#06131c!important;color:#edf9fc!important;border-color:#31586b!important;
}
main input[type="file"]{color:#a9c2ce!important;padding:7px!important}
main input[type="file"]::file-selector-button{
 background:#18303d!important;color:#e8f7fb!important;border:1px solid #3a6477!important;
 border-radius:4px;padding:7px 11px;margin-right:10px;cursor:pointer
}
main select[multiple],main option{background:#071721!important;color:#edf9fc!important}

/* Tablas y filas que todavía traían blanco del tema clásico */
main table,main tbody,main tr,main td{color:#dcecf3!important}
main tbody tr{background:#0b1923!important}
main tbody tr:nth-child(even){background:#0e1e29!important}
main tbody tr:hover{background:#112a38!important}

/* Tarjetas de métricas, plantillas, adjuntos y elementos de selección */
main :is(.stats>div,.group-card,.project-card,.task-card,.template-card,.template-item,
.template-type,.template-option,.word-template-card,.document-card,.attachment-card,
.upload-card,.link-card,.meta-grid>div,.calendar-day,.info-card,.form-card){
 background:linear-gradient(145deg,#10212d,#091720)!important;
 color:#e7f4f8!important;border-color:rgba(66,139,169,.38)!important;
}
main :is(.stats>div,.group-card,.project-card,.task-card,.template-card,.template-item,
.template-type,.template-option,.word-template-card,.document-card,.attachment-card,
.upload-card,.link-card,.meta-grid>div,.calendar-day,.info-card,.form-card) p{color:#9bb4c0!important}

/* Vistas deliberadamente claras (documento/Word/PDF): texto siempre oscuro */
main :is(.document-preview,.word-document,.page-preview,.preview-paper,.rendered-document,
.document-canvas,.paper-preview,.docx-preview){
 background:#f4f7f8!important;color:#17252e!important;border-color:#90a6b1!important;
}
main :is(.document-preview,.word-document,.page-preview,.preview-paper,.rendered-document,
.document-canvas,.paper-preview,.docx-preview) *{color:#17252e!important;text-shadow:none!important}
main :is(.document-preview,.word-document,.page-preview,.preview-paper,.rendered-document,
.document-canvas,.paper-preview,.docx-preview) a{color:#006b91!important}

/* Correos y notas se integran en el tema oscuro, evitando texto claro sobre blanco */
main :is(.mail-preview,.mail-block,.mail-card,.communication,.note-preview,.note-block,.callout-note){
 background:#0c1c27!important;color:#e7f4f8!important;border-color:#315565!important;
}
main :is(.mail-preview,.mail-block,.mail-card,.communication,.note-preview,.note-block,.callout-note) *{
 color:inherit!important;text-shadow:none!important
}
main :is(.mail-preview,.mail-block,.mail-card,.communication,.note-preview,.note-block,.callout-note) a{color:#58d9ff!important}

/* Mantener impresión y exportación en blanco, solo fuera de pantalla */
@media print{
 :root{color-scheme:light}
 main .content,main .communication,main .admonition,main .note,
 main .mail-preview,main .mail-block,main .mail-card,
 main .document-preview,main .word-document,main .page-preview,main .preview-paper{
  background:#fff!important;color:#111!important;border-color:#ccc!important
 }
 main .content *,main .communication *,main .admonition *,main .note *,
 main .mail-preview *,main .mail-block *,main .mail-card *,
 main .document-preview *,main .word-document *,main .page-preview *,main .preview-paper *{color:#111!important}
}


/* === V4.1.8 FORCE DARK UI — sin superficies blancas en pantalla === */
@media screen {
  :root{color-scheme:dark!important}
  html,body,.shell,main,.main,.content-area,.page-content,.workspace,.layout,.app-shell{
    background:#050d14!important;color:#e7f4f8!important
  }
  main{background-image:radial-gradient(circle at 85% 0,rgba(0,200,255,.055),transparent 31%),radial-gradient(circle at 0 30%,rgba(236,0,0,.045),transparent 28%)!important}
  main :is(section,article,div,form,fieldset,details,dialog,table,tbody,tr,td,ul,ol,li){
    border-color:rgba(73,125,148,.30)
  }
  main :is(.card,.panel,.widget,.tile,.stat,.stats>div,.summary-card,.metric,.metric-card,
  .template-card,.template-grid>a,.template-grid a,.template-item,.template-row,.template-box,
  .template-selector,.template-choice,.template-type,.template-option,.type-card,.quick-card,
  .category-card,.counter-card,.project-card,.task-card,.wiki-card,.bau-card,.info-card,.form-card,
  .document-card,.attachment-card,.upload-card,.link-card,.mail-card,.mail-block,.communication,
  .note,.note-block,.admonition,.callout,.callout-note,.preview-card,.word-preview,.preview-box,
  .document-preview,.word-document,.page-preview,.preview-paper,.rendered-document,.document-canvas,
  .paper-preview,.docx-preview,.template-preview-panel,.template-editor-panel,.number-preview,
  .filters,.module-tabs,.calendar-list,.calendar-day,.content,.viewer,.editor-preview,.white-card){
    background:linear-gradient(145deg,#0d1c26,#07131b)!important;
    color:#e7f4f8!important;
    border-color:rgba(69,132,158,.42)!important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.025),0 10px 26px rgba(0,0,0,.23)!important
  }
  main :is(.template-card,.template-grid>a,.template-grid a,.template-item,.template-row,.template-box,
  .template-selector,.template-choice,.word-template-card,.document-card,.attachment-card,.upload-card,.link-card) *{
    background-color:transparent!important;color:#dff3f9!important
  }
  main :is(.template-card,.template-grid>a,.template-grid a,.template-item,.template-row,.template-box,
  .template-selector,.template-choice) a{color:#18d2ff!important}
  main :is(h1,h2,h3,h4,h5,h6,strong,label,legend,dt,th){color:#f1f8fb!important}
  main :is(p,span,small,em,li,dd,.muted,.meta,.help-text,.description){color:#9fb8c4!important}
  main a{color:#22cff8!important}
  main table,main thead,main tbody,main tr,main td,main th{background-color:#091720!important;color:#dcecf3!important}
  main thead th,main table th{background:#122936!important;color:#eaf8fc!important}
  main tbody tr:nth-child(even){background:#0b1b25!important}
  main tbody tr:hover{background:#102936!important}
  main input,main select,main textarea,main option,main [contenteditable=true]{
    background:#06131c!important;color:#edf9fc!important;border-color:#31586b!important
  }
  main input::placeholder,main textarea::placeholder{color:#6f8996!important;opacity:1}
  main input[type=file]{background:#071721!important;color:#a9c2ce!important}
  main input[type=file]::file-selector-button{background:#132b38!important;color:#e8f7fb!important;border:1px solid #386277!important}
  main button,main .btn,main .button,main a.btn,main .page-actions a,main .page-actions button,
  main .manage-templates-button,main summary{
    background:linear-gradient(180deg,#142c39,#0a1922)!important;color:#e7f4f8!important;border-color:#31586b!important
  }
  main button:hover,main .btn:hover,main .button:hover,main a.btn:hover,main summary:hover{
    background:#173746!important;color:#fff!important;border-color:#00c8ff!important
  }
  main .primary,main .btn.primary,main .btn-primary,main input[type=submit],main .danger.primary{
    background:linear-gradient(180deg,#ff293b,#c90000)!important;color:#fff!important;border-color:#ff4c5c!important
  }
  main button:disabled,main .btn:disabled{background:#101e27!important;color:#647b86!important;border-color:#263b46!important;opacity:.75!important}
  main .editor-toolbar,main .toolbar{background:#0b1a24!important;color:#e7f4f8!important;border-color:#31586b!important}
  main pre,main code,main .code-wrap,main .code-head,main .code-box{background:#02090e!important;color:#a8ffd8!important}
  main .wiki-image img,main img.preview,main .image-preview{background:#07131b!important;border-color:#31586b!important}
  footer{background:#07131b!important;color:#8da7b3!important;border-color:#29414e!important}
}


/* === V4.1.8 ABSOLUTE DARK SURFACE LOCK === */
@media screen {
  :root { color-scheme: dark !important; }
  html, body { background:#050d14 !important; color:#e7f4f8 !important; }

  /* Ventanas, modales y paneles fuera de main */
  .modal, .modal-content, .dialog, .dialog-content, dialog,
  .import-modal, .import-dialog, .import-dialog-head, .import-dialog-body,
  .import-dialog-actions, .import-summary, .summary-grid, .summary-row,
  .summary-details, .overlay-panel, .popup, .popover, .dropdown-menu {
    background:#091722 !important;
    color:#e7f4f8 !important;
    border-color:#294b5d !important;
  }
  .import-modal { background:rgba(1,8,13,.82) !important; }
  .import-dialog { box-shadow:0 24px 70px rgba(0,0,0,.72) !important; }
  .import-dialog-head, .import-dialog-actions { background:#0c1c27 !important; }
  .import-dialog-head h2, .import-file-label, .import-mode-title,
  .import-option strong, .summary-row strong { color:#edf9fc !important; }
  .import-option {
    background:#0b1a24 !important;
    color:#bdd2dc !important;
    border-color:#31586b !important;
  }
  .import-option:has(input:checked) {
    background:linear-gradient(90deg,rgba(236,0,0,.15),rgba(0,200,255,.07)) !important;
    border-color:#ec3040 !important;
  }
  .import-option small { color:#91adba !important; }
  .import-warning {
    background:#102632 !important;
    color:#d7edf5 !important;
    border-color:#00c8ff !important;
  }
  .import-close, .import-dialog-actions .cancel {
    background:#122633 !important;
    color:#edf9fc !important;
    border-color:#31586b !important;
  }

  /* Opciones, tarjetas y filas: nunca blancas en pantalla */
  :is(main,.main,.content-area,.page-content,.workspace,.layout,.app-shell)
  :is(.card,.panel,.tile,.widget,.stat,.stats>div,.template-card,.template-item,
  .template-grid>a,.template-grid a,.template-option,.template-type,.project-card,
  .task-card,.info-card,.form-card,.attachment-card,.upload-card,.link-card,
  .mail-card,.mail-block,.communication,.note,.note-block,.admonition,.callout,
  .preview-card,.preview-box,.document-preview,.word-document,.page-preview,
  .preview-paper,.rendered-document,.document-canvas,.paper-preview,.docx-preview,
  .template-preview-panel,.template-editor-panel,.filters,.module-tabs,.calendar-day,
  .content,.viewer,.editor-preview,.white-card,.health-row,.pending-chip,.summary-row) {
    background:linear-gradient(145deg,#0d1c26,#07131b) !important;
    color:#e7f4f8 !important;
    border-color:rgba(63,123,148,.42) !important;
  }

  /* Cualquier estilo inline claro dentro de la aplicación */
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background:white"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background: white"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background:#fff"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background: #fff"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background-color:white"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background-color: white"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background-color:#fff"],
  :is(main,.main,.content-area,.page-content,.workspace)
  [style*="background-color: #fff"] {
    background:#0b1a24 !important;
    color:#e7f4f8 !important;
  }

  input, select, textarea, [contenteditable="true"] {
    background:#06131c !important;
    color:#edf9fc !important;
    border-color:#31586b !important;
  }
  input::placeholder, textarea::placeholder { color:#6f8b98 !important; }
  option { background:#071721 !important; color:#edf9fc !important; }
  input[type="file"] { background:#06131c !important; color:#a9c2ce !important; }
  input[type="file"]::file-selector-button {
    background:#18303d !important; color:#edf9fc !important;
    border:1px solid #3a6477 !important;
  }

  table, thead, tbody, tr, th, td { border-color:#294959 !important; }
  tbody tr { background:#0a1822 !important; }
  tbody tr:nth-child(even) { background:#0d1d27 !important; }
  th { background:#112a38 !important; color:#eaf8fc !important; }
  td { color:#dcecf3 !important; }

  /* Botones secundarios claros heredados */
  button:not(.primary):not(.danger), .btn:not(.primary):not(.danger),
  a.button:not(.primary):not(.danger) {
    background:#102531 !important;
    color:#e8f7fb !important;
    border-color:#31586b !important;
  }
  button:disabled, .btn:disabled {
    background:#101c24 !important; color:#607985 !important;
    border-color:#263b46 !important; opacity:.78 !important;
  }
}

/* La salida impresa y los informes deben seguir siendo blancos */
@media print {
  :root { color-scheme: light !important; }
  html, body { background:#fff !important; color:#111 !important; }
}

/* V5.0.17 · Código limpio: evitar bordes por fragmento de línea */
pre > code,
.code-wrap .code-box > code,
.library-code-block .syntax-code > code,
.syntax-code > code,
.code-box > code {
  display:block !important;
  width:100% !important;
  margin:0 !important;
  padding:0 !important;
  background:transparent !important;
  border:0 !important;
  border-top:0 !important;
  border-right:0 !important;
  border-bottom:0 !important;
  border-left:0 !important;
  outline:0 !important;
  box-shadow:none !important;
  text-decoration:none !important;
}
pre > code *,
.code-wrap .code-box code *,
.library-code-block .syntax-code code *,
.syntax-code code *,
.code-box code * {
  background-color:transparent !important;
  border:0 !important;
  border-bottom:0 !important;
  outline:0 !important;
  box-shadow:none !important;
  text-decoration:none !important;
}



/* V5.0.17 · Formato inline global: los colores de autor prevalecen sobre el tema */
@media screen {
  html body main span.text-blue,
  html body main .text-blue,
  html body .wiki-content span.text-blue,
  html body .content span.text-blue,
  html body .rendered-content span.text-blue,
  html body article span.text-blue,
  html body .viewer span.text-blue {
    color:#39b9ff !important;
    -webkit-text-fill-color:#39b9ff !important;
  }
  html body main span.text-red,
  html body main .text-red,
  html body .wiki-content span.text-red,
  html body .content span.text-red,
  html body .rendered-content span.text-red,
  html body article span.text-red,
  html body .viewer span.text-red {
    color:#ff4f61 !important;
    -webkit-text-fill-color:#ff4f61 !important;
  }
  html body main strong,
  html body .wiki-content strong,
  html body .content strong,
  html body .rendered-content strong,
  html body article strong { font-weight:800 !important; }
  html body main em,
  html body .wiki-content em,
  html body .content em,
  html body .rendered-content em,
  html body article em { font-style:italic !important; }
}
"""

BASE = Path(__file__).resolve().parent
DB = BASE / 'data' / 'snippets.json'
RESPONSIBLES_DB=BASE.parent/'gestor'/'data'/'responsibles.json'
PORTAL_URL = os.environ.get('PORTAL_URL', 'http://127.0.0.1:8079')
WIKI_URL = os.environ.get('WIKI_URL', 'http://127.0.0.1:8080')
GESTOR_URL = os.environ.get('GESTOR_URL', 'http://127.0.0.1:8081')
BAU_URL = os.environ.get('BAU_URL', 'http://127.0.0.1:8082')
BITACORA_URL = os.environ.get('BITACORA_URL', 'http://127.0.0.1:8083')
CAMBIOS_URL = os.environ.get('CAMBIOS_URL', 'http://127.0.0.1:8085')
SIEM_URL = os.environ.get('SIEM_URL', 'http://127.0.0.1:8086')
CATEGORIES = ['CrowdStrike NG SIEM','Splunk','Python','PowerShell','Bash','SQL','KQL','JSON','XML','Regex','Cisco CES','Proofpoint','Microsoft 365','Power Automate','Snow','Otros']
CODE_TYPES = ['Splunk SPL','Python','PowerShell','Bash','CMD','SQL','KQL','JSON','XML','HTML','CSS','JavaScript','YAML','Regex','Cisco CES','Proofpoint','CrowdStrike Query','Texto plano']

CATEGORY_CODE_MAP = {
    'CrowdStrike NG SIEM':'CrowdStrike Query',
    'Splunk':'Splunk SPL',
    'Python':'Python',
    'PowerShell':'PowerShell',
    'Bash':'Bash',
    'SQL':'SQL',
    'KQL':'KQL',
    'JSON':'JSON',
    'XML':'XML',
    'Regex':'Regex',
    'Cisco CES':'Cisco CES',
    'Proofpoint':'Proofpoint',
    'Power Automate':'JSON',
}

def esc(value):
    return html.escape(str(value or ''), quote=True)

def load():
    try:
        return json.loads(DB.read_text(encoding='utf-8')) if DB.exists() else []
    except Exception:
        return []

def save(rows):
    DB.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')

def now():
    return datetime.now().isoformat(timespec='seconds')

def get_one(item_id):
    return next((x for x in load() if x.get('id') == item_id), None)

def options(current=''):
    return ''.join(f'<option value="{esc(x)}" {"selected" if x == current else ""}>{esc(x)}</option>' for x in CATEGORIES)

def code_type_options(current=''):
    current=current or 'Texto plano'
    return ''.join(
        f'<option value="{esc(value)}" {"selected" if value==current else ""}>{esc(value)}</option>'
        for value in CODE_TYPES
    )

def resolved_code_type(row):
    value=str(row.get('code_type','')).strip()
    if value in CODE_TYPES:
        return value
    return CATEGORY_CODE_MAP.get(str(row.get('category','')).strip(),'Texto plano')

def _protect_tokens(text, patterns):
    tokens=[]
    def store(value, css_class):
        marker=f'@@SMS_TOKEN_{len(tokens)}@@'
        tokens.append((marker,f'<span class="{css_class}">{value}</span>'))
        return marker
    for pattern,css_class,flags in patterns:
        text=re.sub(pattern,lambda m:store(m.group(0),css_class),text,flags=flags)
    return text,tokens

def _restore_tokens(text,tokens):
    for marker,value in tokens:
        text=text.replace(marker,value)
    return text

def highlight_code(value,code_type):
    source=esc(value)
    kind=str(code_type or 'Texto plano')
    protected=[]

    if kind in ('Python','PowerShell','Bash','CMD','JavaScript','CSS','SQL','KQL','Splunk SPL','CrowdStrike Query','Cisco CES','Proofpoint'):
        patterns=[]
        if kind in ('Python','PowerShell','Bash'):
            patterns.append((r'(?m)(?<!\\)#.*$', 'tok-comment', re.M))
        elif kind in ('JavaScript','CSS'):
            patterns.append((r'(?m)//.*$|/\*.*?\*/', 'tok-comment', re.S|re.M))
        elif kind in ('SQL','KQL'):
            patterns.append((r'(?m)--.*$', 'tok-comment', re.M))
        elif kind=='CMD':
            patterns.append((r'(?mi)^\s*(?:REM\b|::).*$', 'tok-comment', re.M))
        patterns.append((r'''(&quot;.*?&quot;|&#x27;.*?&#x27;)''', 'tok-string', re.S))
        source,protected=_protect_tokens(source,patterns)

    if kind=='JSON':
        source=re.sub(r'(&quot;(?:\\.|[^&])*?&quot;)(\s*:)',r'<span class="tok-key">\1</span>\2',source)
        source=re.sub(r'(:\s*)(&quot;(?:\\.|[^&])*?&quot;)',r'\1<span class="tok-string">\2</span>',source)
        source=re.sub(r'\b(true|false|null)\b',r'<span class="tok-keyword">\1</span>',source)
        source=re.sub(r'(?<![\w.])-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?',r'<span class="tok-number">\g<0></span>',source)

    elif kind in ('XML','HTML'):
        source=re.sub(r'(&lt;/?)([\w:-]+)',r'\1<span class="tok-tag">\2</span>',source)
        source=re.sub(r'([\w:-]+)(=)(&quot;.*?&quot;)',r'<span class="tok-key">\1</span>\2<span class="tok-string">\3</span>',source)
        source=re.sub(r'(&lt;!--.*?--&gt;)',r'<span class="tok-comment">\1</span>',source,flags=re.S)

    elif kind=='CSS':
        source=re.sub(r'(?m)(^|[;{]\s*)([-\w]+)(\s*:)',r'\1<span class="tok-key">\2</span>\3',source)
        source=re.sub(r'#[0-9A-Fa-f]{3,8}\b',r'<span class="tok-number">\g<0></span>',source)
        source=re.sub(r'\b\d+(?:\.\d+)?(?:px|em|rem|%|vh|vw|s|ms)?\b',r'<span class="tok-number">\g<0></span>',source)

    elif kind=='Python':
        keywords='and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|False|finally|for|from|global|if|import|in|is|lambda|match|None|nonlocal|not|or|pass|raise|return|True|try|while|with|yield'
        builtins='print|len|range|str|int|float|dict|list|set|tuple|open|enumerate|zip|sum|min|max|sorted|super|self'
        source=re.sub(rf'\b({keywords})\b',r'<span class="tok-keyword">\1</span>',source)
        source=re.sub(rf'\b({builtins})(?=\s*\()',r'<span class="tok-builtin">\1</span>',source)
        source=re.sub(r'\b\d+(?:\.\d+)?\b',r'<span class="tok-number">\g<0></span>',source)

    elif kind=='PowerShell':
        source=re.sub(r'(?<!\w)(\$[\w:]+)',r'<span class="tok-variable">\1</span>',source)
        source=re.sub(r'\b(?:Get|Set|New|Remove|Add|Invoke|Import|Export|ConvertTo|ConvertFrom|Write|Where|ForEach|Select|Sort|Measure|Test|Start|Stop|Restart)-[A-Za-z0-9]+\b',r'<span class="tok-builtin">\g<0></span>',source,flags=re.I)
        source=re.sub(r'\b(function|param|if|elseif|else|foreach|for|while|switch|return|try|catch|finally|throw|class|filter|begin|process|end)\b',r'<span class="tok-keyword">\1</span>',source,flags=re.I)
        source=re.sub(r'(?<!\w)-(?:eq|ne|gt|ge|lt|le|like|notlike|match|notmatch|contains|notcontains|in|notin|and|or|not)\b',r'<span class="tok-operator">\g<0></span>',source,flags=re.I)

    elif kind in ('Bash','CMD'):
        source=re.sub(r'(?<!\w)(\$[\w@#?*!-]+|\$\{[^}]+\}|%[^%\r\n]+%)',r'<span class="tok-variable">\1</span>',source)
        source=re.sub(r'\b(if|then|else|elif|fi|for|while|do|done|case|esac|function|in|exit|set|export|echo|call|goto|setlocal|endlocal)\b',r'<span class="tok-keyword">\1</span>',source,flags=re.I)
        source=re.sub(r'\b(curl|grep|awk|sed|find|xargs|cat|chmod|chown|mkdir|rm|cp|mv|python|powershell|nslookup|ping)\b',r'<span class="tok-builtin">\1</span>',source,flags=re.I)

    elif kind in ('SQL','KQL'):
        keywords='select|from|where|join|inner|left|right|full|outer|on|group|by|order|having|union|all|distinct|insert|into|update|delete|create|alter|drop|table|view|as|case|when|then|else|end|and|or|not|null|is|in|like|between|limit|top|with|let|project|extend|summarize|render|take|count|ago|bin|contains|has'
        source=re.sub(rf'\b({keywords})\b',r'<span class="tok-keyword">\1</span>',source,flags=re.I)
        source=re.sub(r'\b(count|sum|avg|min|max|coalesce|cast|convert|datetime|tostring|tolower|toupper)\s*(?=\()',r'<span class="tok-builtin">\g<0></span>',source,flags=re.I)
        source=re.sub(r'\b\d+(?:\.\d+)?\b',r'<span class="tok-number">\g<0></span>',source)

    elif kind in ('Splunk SPL','CrowdStrike Query'):
        commands='search|where|stats|eventstats|streamstats|eval|rex|regex|lookup|inputlookup|outputlookup|join|append|appendcols|transaction|tstats|spath|table|fields|rename|sort|dedup|bin|bucket|chart|timechart|top|rare|makeresults|mvexpand|fillnull|coalesce|convert|foreach|map|collect|metadata|mstats|from|groupBy|case|test|filter'
        source=re.sub(r'(\|)',r'<span class="tok-pipe">\1</span>',source)
        source=re.sub(rf'(?<![\w])({commands})\b',r'<span class="tok-keyword">\1</span>',source,flags=re.I)
        source=re.sub(r'\b(index|sourcetype|source|host|earliest|latest|limit|maxEvents)\s*=',r'<span class="tok-key">\1</span>=',source,flags=re.I)
        source=re.sub(r'\b(count|sum|avg|min|max|dc|values|list|first|last|if|case|coalesce|match|like|isnull|isnotnull)\s*(?=\()',r'<span class="tok-builtin">\g<0></span>',source,flags=re.I)
        source=re.sub(r'\b\d+(?:\.\d+)?\b',r'<span class="tok-number">\g<0></span>',source)

    elif kind=='JavaScript':
        keywords='const|let|var|function|return|if|else|for|while|do|switch|case|break|continue|class|extends|new|this|async|await|try|catch|finally|throw|import|export|from|default|true|false|null|undefined'
        source=re.sub(rf'\b({keywords})\b',r'<span class="tok-keyword">\1</span>',source)
        source=re.sub(r'\b(console|document|window|JSON|Array|Object|String|Number|Promise|Map|Set)\b',r'<span class="tok-builtin">\1</span>',source)
        source=re.sub(r'\b\d+(?:\.\d+)?\b',r'<span class="tok-number">\g<0></span>',source)

    elif kind=='YAML':
        source=re.sub(r'(?m)^(\s*)([\w.-]+)(\s*:)',r'\1<span class="tok-key">\2</span>\3',source)
        source=re.sub(r'\b(true|false|null|yes|no)\b',r'<span class="tok-keyword">\1</span>',source,flags=re.I)
        source=re.sub(r'(?m)(#.*$)',r'<span class="tok-comment">\1</span>',source)

    elif kind=='Regex':
        source=re.sub(r'(\\[dDsSwWbBAZzG]|\\.|[\[\]{}()*+?|^$])',r'<span class="tok-keyword">\1</span>',source)
        source=re.sub(r'(\(\?[:=!&lt;].*?\))',r'<span class="tok-builtin">\1</span>',source)

    elif kind in ('Cisco CES','Proofpoint'):
        source=re.sub(r'\b(ACCEPT|REJECT|QUARANTINE|DELIVER|BOUNCE|DROP|ALLOW|BLOCK|WARN|MESSAGE|FILTER|CONTENT|POLICY|MAIL|RCPT|IF|ELSE|AND|OR|NOT)\b',r'<span class="tok-keyword">\1</span>',source,flags=re.I)
        source=re.sub(r'\b\d{1,3}(?:\.\d{1,3}){3}\b',r'<span class="tok-number">\g<0></span>',source)
        source=re.sub(r'\b[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b',r'<span class="tok-variable">\g<0></span>',source)

    source=_restore_tokens(source,protected)
    return source

def highlighted_block(row,element_id=''):
    code_type=resolved_code_type(row)
    identifier=f' id="{esc(element_id)}"' if element_id else ''
    return (
        '<div class="library-code-block">'
        '<div class="code-language">'+esc(code_type)+'</div>'
        '<pre class="syntax-code"><code'+identifier+'>'+highlight_code(row.get("code",""),code_type)+'</code></pre>'
        '</div>'
    )


def responsible_people():
    try:
        rows=json.loads(RESPONSIBLES_DB.read_text(encoding='utf-8')) if RESPONSIBLES_DB.exists() else []
    except Exception:
        rows=[]
    return sorted(rows,key=lambda x:(0 if str(x.get('name','')).casefold()=='emailsecurity' else 1,str(x.get('name','')).casefold()))

def responsible_options(current=''):
    return '<option value="">Sin responsable</option>'+''.join('<option value="'+esc(x.get('id'))+'" '+('selected' if str(x.get('id'))==str(current) else '')+'>'+esc(x.get('name'))+'</option>' for x in responsible_people())

def responsible_name(rid):
    return next((str(x.get('name','')) for x in responsible_people() if str(x.get('id'))==str(rid)),'Sin asignar')

def tag_badges(value):
    values=[x.strip() for x in re.split(r'[,;]', str(value or '')) if x.strip()]
    return '<div class="tag-list">'+''.join(f'<span class="tag">{esc(x)}</span>' for x in values)+'</div>' if values else ''

def layout(title, body):
    links=[('Inicio',PORTAL_URL),('Wiki',WIKI_URL),('Proyectos y tareas',GESTOR_URL),('BAU',BAU_URL),('Bitácora',BITACORA_URL),('Biblioteca','/'),('Búsquedas SIEM',SIEM_URL),('Plantillas',CAMBIOS_URL)]
    nav=''.join(f'<a class="{"active" if n=="Biblioteca" else ""}" href="{esc(u)}">{esc(n)}</a>' for n,u in links)
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)} · Biblioteca</title><style>{CSS}
/* V19.5 · Word wrap visual en cajas de edición */
textarea{{white-space:pre-wrap!important;overflow-wrap:anywhere;word-break:normal;overflow-x:hidden}}
.form textarea.code{{white-space:pre-wrap!important;overflow-wrap:anywhere;word-break:normal;overflow-x:hidden}}
</style><style>{CORPORATE_THEME_CSS}
/* V26.1: logotipo configurable desde configuracion/logo/logo.png */
.brand::before{{display:none!important;content:none!important;background-image:none!important}}
.brand .brand-logo{{
  display:block!important;width:46px!important;height:46px!important;
  min-width:46px!important;max-width:46px!important;flex:0 0 46px!important;
  object-fit:contain!important;object-position:center!important;
  background:transparent!important;border:0!important;border-radius:0!important;
  box-shadow:none!important
}}
.brand>span{{display:block!important}}
@media(max-width:760px){{
  .brand .brand-logo{{width:38px!important;height:38px!important;min-width:38px!important;max-width:38px!important;flex-basis:38px!important}}
}}
</style>
<style>
/* V27.3 · Logotipo adaptable al espacio disponible */
header{{
  min-height:72px!important;
  height:auto!important;
  overflow:visible!important;
}}
.brand{{
  min-height:56px!important;
  max-width:min(70vw,760px)!important;
  display:flex!important;
  align-items:center!important;
  gap:14px!important;
  overflow:visible!important;
}}
.brand::before{{
  display:none!important;
  content:none!important;
  background-image:none!important;
}}
.brand .brand-logo{{
  display:block!important;
  width:auto!important;
  height:auto!important;
  min-width:0!important;
  min-height:0!important;
  max-width:210px!important;
  max-height:56px!important;
  flex:0 1 auto!important;
  object-fit:contain!important;
  object-position:left center!important;
  background:transparent!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
}}
.brand>span{{
  display:block!important;
  min-width:0!important;
  overflow:hidden!important;
  text-overflow:ellipsis!important;
}}
@media(max-width:760px){{
  header{{min-height:64px!important;padding:8px 14px!important}}
  .brand{{min-height:46px!important;gap:10px!important;max-width:76vw!important}}
  .brand .brand-logo{{
    width:auto!important;
    height:auto!important;
    max-width:145px!important;
    max-height:46px!important;
  }}
}}
@media(max-width:480px){{
  .brand .brand-logo{{max-width:105px!important;max-height:42px!important}}
  .brand>span{{font-size:15px!important}}
}}
</style>

<style>
/* V27.7 · Logotipo ajustado al encabezado */
header{{min-height:58px!important;height:auto!important;padding:6px 16px!important;overflow:hidden!important}}
.brand{{min-height:44px!important;display:flex!important;align-items:center!important;gap:10px!important;max-width:min(64vw,700px)!important;overflow:hidden!important}}
.brand::before{{display:none!important;content:none!important}}
.brand .brand-logo{{display:block!important;width:auto!important;height:auto!important;max-width:150px!important;max-height:40px!important;min-width:0!important;min-height:0!important;flex:0 1 auto!important;object-fit:contain!important;object-position:left center!important}}
.brand>span{{min-width:0!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important}}
@media(max-width:760px){{.brand .brand-logo{{max-width:110px!important;max-height:36px!important}}.brand>span{{font-size:15px!important}}}}
</style>

<style>
/* V27.11.4 · Acciones de Biblioteca */
.library-card-actions,.library-view-actions{{display:flex;align-items:center;gap:7px;flex-wrap:wrap}}
.library-card-actions form,.library-view-actions form{{margin:0}}
.inline{{display:inline-block}}
</style>

<style>
/* V4.1.8 · Bloques de código sin superposición */
.library-code-block{{
  display:block!important;
  position:relative!important;
  width:100%!important;
  margin:12px 0 0!important;
  overflow:visible!important;
}}
.code-language{{
  position:static!important;
  float:none!important;
  display:inline-flex!important;align-items:center!important;margin:0!important;padding:5px 10px!important;
  background:#2d333b;color:#fff;border-radius:7px 7px 0 0;font-size:12px;font-weight:700;
}}
.syntax-code{{
  position:static!important;clear:both!important;display:block!important;
  width:100%!important;margin:0!important;padding:15px!important;border-radius:0 7px 7px 7px!important;
  background:#1f2328!important;color:#f0f3f6!important;white-space:pre-wrap!important;
  overflow-wrap:anywhere;tab-size:4;line-height:1.58!important;
}}
.syntax-code code{{color:#f0f3f6!important;font-family:Consolas,"Courier New",monospace!important}}
.tok-keyword{{color:#ff7b72!important;font-weight:700}}
.tok-string{{color:#a5d6ff!important}}
.tok-comment{{color:#8b949e!important;font-style:italic}}
.tok-number{{color:#79c0ff!important}}
.tok-builtin{{color:#d2a8ff!important;font-weight:600}}
.tok-variable{{color:#ffa657!important}}
.tok-operator{{color:#ff7b72!important;font-weight:700}}
.tok-pipe{{color:#f2cc60!important;font-weight:800}}
.tok-key,.tok-tag{{color:#7ee787!important}}
.code-actions{{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}}
.code-type-badge{{display:inline-flex!important;align-items:center!important;gap:6px!important;padding:5px 10px!important;border-radius:999px!important;background:#0a2230!important;color:#68e6ff!important;border:1px solid rgba(0,200,255,.42)!important;font-weight:700!important;font-size:11px!important;letter-spacing:.25px!important;box-shadow:inset 0 0 12px rgba(0,200,255,.04)!important}}
.code-type-badge::before{{content:"</>";font:700 9px Consolas,monospace;color:#24e6a1}}
.badge{{display:inline-flex!important;align-items:center!important;gap:5px!important;background:#0b2230!important;color:#69e8ff!important;border:1px solid rgba(0,200,255,.36)!important;border-radius:999px!important;padding:4px 9px!important;font-weight:650!important;font-size:11px!important;line-height:1.2!important;box-shadow:none!important}}
.badge::before{{content:"#";color:#24e6a1;font-family:Consolas,monospace;font-weight:700}}
.tag-list{{display:flex!important;flex-wrap:wrap!important;gap:6px!important;margin:8px 0 2px!important}}
.tag-list .tag{{display:inline-flex!important;align-items:center!important;background:#101f2a!important;color:#b9dbe8!important;border:1px solid rgba(94,155,181,.28)!important;border-radius:999px!important;padding:3px 8px!important;font-size:11px!important;line-height:1.2!important}}
.tag-list .tag::before{{content:"#";color:#00c8ff;margin-right:2px}}
.library-code-block{{margin-top:8px!important;border:1px solid rgba(36,230,161,.30)!important;border-radius:7px!important;overflow:hidden!important;background:#02090e!important}}
.code-language{{display:flex!important;align-items:center!important;gap:8px!important;padding:8px 12px!important;background:linear-gradient(90deg,#0b1e28,#09141c)!important;color:#71eaff!important;border-bottom:1px solid rgba(36,230,161,.25)!important;font:700 11px/1.2 Consolas,monospace!important;letter-spacing:.35px!important;text-transform:none!important}}
.code-language::before{{content:"TERMINAL";color:#24e6a1;font-size:9px;letter-spacing:1px;border-right:1px solid rgba(36,230,161,.25);padding-right:9px}}
.library-code-block pre.syntax-code{{margin:0!important;border:0!important;border-radius:0!important;background:linear-gradient(180deg,#02090e,#061117)!important;padding:12px 14px!important}}
.library-code-block pre.syntax-code::before{{display:none!important}}

</style>
</head><body><header><div class="brand"><img class="brand-logo" src="/logo.png?v=27112" alt="Logo Santander" onerror="this.style.display=\'none\'"><span>Santander Mail Security · Biblioteca</span></div><div class="header-actions"><a class="btn" href="/">← Atrás</a><a class="btn" href="{esc(PORTAL_URL)}">Inicio común</a><a class="btn primary" href="/new">+ Nuevo fragmento</a></div></header><div class="shell"><aside><nav>{nav}</nav><div class="aside-note">Aplicación local<br>Sin usuarios<br>Datos en JSON</div></aside><main>{body}</main></div></body></html>'''

def home(qs):
    rows = load()
    query = qs.get('q', [''])[0].strip().casefold()
    category = qs.get('category', [''])[0]
    favorites = qs.get('fav', [''])[0]
    filtered = []
    for row in rows:
        haystack = ' '.join(str(row.get(k, '')) for k in ('title','category','tags','description','code','notes','responsible_id')).casefold()
        if query and query not in haystack:
            continue
        if category and row.get('category') != category:
            continue
        if favorites and not row.get('favorite'):
            continue
        filtered.append(row)
    filtered.sort(key=lambda r: (not r.get('favorite', False), r.get('title', '').casefold()))
    cards = ''.join(
        f'''<article class="card"><div class="row"><span class="badge">{esc(r.get('category'))}</span><span>{'★' if r.get('favorite') else '☆'}</span></div><h2><a href="/view?id={esc(r['id'])}">{esc(r.get('title'))}</a></h2><p>{esc(r.get('description'))}</p>{tag_badges(r.get('tags'))}{highlighted_block(r)}<div class="library-card-actions"><button onclick="navigator.clipboard.writeText(this.closest('article').querySelector('code').innerText)">Copiar</button> <a class="btn" href="/edit?id={esc(r['id'])}">Editar</a> <form class="inline" method="post" action="/delete" onsubmit="return confirm('¿Eliminar este fragmento de la biblioteca?')"><input type="hidden" name="id" value="{esc(r['id'])}"><button class="danger" type="submit">Eliminar</button></form></div></article>'''
        for r in filtered
    ) or '<div class="card">No hay fragmentos.</div>'
    body = f'''<div class="head"><div><h1>Biblioteca Técnica</h1><p>Consultas, scripts, expresiones y fragmentos reutilizables.</p></div></div><form class="filters"><input name="q" value="{esc(qs.get('q',[''])[0])}" placeholder="Buscar por título, código, etiquetas o notas"><select name="category"><option value="">Todas las categorías</option>{options(category)}</select><label><input type="checkbox" name="fav" value="1" {'checked' if favorites else ''}> Solo favoritos</label><button>Buscar</button></form><div class="grid">{cards}</div>'''
    return layout('Biblioteca', body)

def form_page(row=None):
    row = row or {}
    return layout('Editar fragmento', f'''<h1>{'Editar' if row else 'Nuevo'} fragmento</h1><form class="card form" method="post" action="/save"><input type="hidden" name="id" value="{esc(row.get('id'))}"><label>Título<input name="title" required value="{esc(row.get('title'))}"></label><label>Categoría<select name="category">{options(row.get('category','Splunk'))}</select></label><label>Tipo de código<select name="code_type">{code_type_options(resolved_code_type(row))}</select></label><label>Responsable<select name="responsible_id">{responsible_options(row.get('responsible_id',''))}</select></label><label>Etiquetas<input name="tags" value="{esc(row.get('tags'))}" placeholder="correo, búsqueda, auditoría"></label><label>Descripción<textarea wrap="soft" name="description" rows="3">{esc(row.get('description'))}</textarea></label><label>Código<textarea wrap="soft" class="code" name="code" rows="18" required>{esc(row.get('code'))}</textarea></label><label>Notas<textarea wrap="soft" name="notes" rows="5">{esc(row.get('notes'))}</textarea></label><label><input type="checkbox" name="favorite" value="1" {'checked' if row.get('favorite') else ''}> Favorito</label><button class="primary">Guardar</button> <a class="btn" href="/">Cancelar</a></form>''')

def view_page(row):
    notes = esc(row.get('notes')).replace('\n', '<br>')
    return layout(row.get('title','Fragmento'), f'''<div class="head"><div><span class="badge">{esc(row.get('category'))}</span><h1>{esc(row.get('title'))} {'★' if row.get('favorite') else ''}</h1><p>{esc(row.get('description'))}</p></div><div class="library-view-actions"><a class="btn" href="/edit?id={esc(row['id'])}">Editar</a> <form class="inline" method="post" action="/delete" onsubmit="return confirm('¿Eliminar este fragmento de la biblioteca?')"><input type="hidden" name="id" value="{esc(row['id'])}"><button class="danger" type="submit">Eliminar</button></form></div></div><section class="card"><div class="code-actions"><button onclick="navigator.clipboard.writeText(document.getElementById('code').innerText)">Copiar código</button><span class="code-type-badge">{esc(resolved_code_type(row))}</span></div>{highlighted_block(row,'code')}</section><section class="card"><h2>Notas</h2><p class="notes">{notes}</p><div><b>Etiquetas:</b>{tag_badges(row.get('tags'))}</div><p><b>Responsable:</b> {esc(responsible_name(row.get('responsible_id','')))}</p><form method="post" action="/delete" onsubmit="return confirm('¿Eliminar este fragmento?')"><input type="hidden" name="id" value="{esc(row['id'])}"><button class="danger">Eliminar</button></form></section>''')



def corporate_logo_path():
    """Devuelve siempre el logo corporativo de la carpeta raíz del proyecto."""
    source=Path(__file__).resolve()
    try:
        app_root=source.parents[2]
    except IndexError:
        app_root=source.parent
    candidates=[
        app_root/"configuracion"/"logo"/"logo.png",
        source.parent/"logo.png",
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None

def serve_corporate_logo(handler):
    path = corporate_logo_path()
    if path is None:
        handler.send_response(404)
        handler.end_headers()
        return
    data = path.read_bytes()
    handler.send_response(200)
    handler.send_header("Content-Type", "image/png")
    handler.send_header("Content-Length", str(len(data)))
    handler.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
    handler.end_headers()
    handler.wfile.write(data)

class Handler(BaseHTTPRequestHandler):
    def send_html(self, text):
        data = text.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def redirect(self, url):
        self.send_response(303)
        self.send_header('Location', url)
        self.end_headers()

    def read_form(self):
        size = int(self.headers.get('Content-Length','0') or 0)
        return {k: v[-1] for k, v in parse_qs(self.rfile.read(size).decode('utf-8','replace'), keep_blank_values=True).items()}

    def do_GET(self):
        parsed = urlparse(self.path)
        qs = parse_qs(parsed.query)
        if parsed.path in {"/logo.png", "/corporate-logo.png"}: return serve_corporate_logo(self)
        if parsed.path == '/':
            return self.send_html(home(qs))
        if parsed.path == '/new':
            return self.send_html(form_page())
        if parsed.path in ('/view','/edit'):
            row = get_one(qs.get('id',[''])[0])
            if not row:
                return self.send_error(404)
            return self.send_html(form_page(row) if parsed.path == '/edit' else view_page(row))
        self.send_error(404)

    def do_POST(self):
        form = self.read_form()
        if self.path == '/save':
            rows = load()
            item_id = form.get('id') or uuid.uuid4().hex
            old = next((x for x in rows if x.get('id') == item_id), {})
            row = {**old, **{k: form.get(k,'').strip() for k in ('title','category','code_type','tags','description','code','notes')}}
            row.update(id=item_id, favorite=form.get('favorite') == '1', created=old.get('created') or now(), updated=now())
            save([x for x in rows if x.get('id') != item_id] + [row])
            return self.redirect('/view?id=' + item_id)
        if self.path == '/delete':
            save([x for x in load() if x.get('id') != form.get('id')])
            return self.redirect('/')
        self.send_error(404)

    def log_message(self, *args):
        pass

CSS = '''*{box-sizing:border-box}body{margin:0;font:14px Arial,sans-serif;color:#26384a;background:#f3f6f9}header{height:62px;background:#25364a;color:#fff;padding:0 24px;display:flex;justify-content:space-between;align-items:center}.brand{font-size:19px;font-weight:bold}.header-actions{display:flex;gap:8px}.shell{display:grid;grid-template-columns:210px minmax(0,1fr);min-height:calc(100vh - 62px)}aside{background:#fff;border-right:1px solid #d9e1e8;padding:20px 14px}nav a{display:block;padding:10px 12px;color:#38516b;text-decoration:none;border-radius:5px;margin-bottom: 5px}nav a.active,nav a:hover{background:#FFF0F0;color:#B30000;font-weight:bold}.aside-note{margin:25px 10px;color:#7b8996;font-size:12px;line-height:1.6}main{padding:24px;max-width:1450px;width:100%;margin:0 auto}h1{margin-top:0}.head,.row{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}.filters{background:white;border:1px solid #d7e0e8;padding:14px;border-radius:8px;display:grid;grid-template-columns:1fr 220px auto auto;gap:9px;margin-bottom:16px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(310px,1fr));gap:15px}.card{background:white;border:1px solid #d7e0e8;border-radius:8px;padding:17px;box-shadow:0 1px 4px #0001}.card h2 a{text-decoration:none;color:#B30000}.btn,button{display:inline-block;border:1px solid #bdcad5;background:white;color:#31516e;padding:9px 13px;border-radius:5px;text-decoration:none;cursor:pointer;font:inherit}.crowdstrike-code{border:1px solid #EC0000!important;box-shadow:inset 0 3px 0 #EC0000}.primary{background:#EC0000!important;color:white!important;border-color:#EC0000!important}.danger{background:#a53b3b;color:white}.badge{background:#e7eef5;color:#B30000;border-radius:12px;padding:4px 8px;font-size:11px}input,select,textarea{width:100%;padding:10px;border:1px solid #bdcad5;border-radius:5px;font:inherit}.form label{display:block;font-weight:bold;margin-bottom:13px}.form label input,.form label select,.form label textarea{margin-top:6px;font-weight:normal}.code,pre{font-family:Consolas,monospace}pre{background:#17222d;color:#eaf2f8;padding:14px;border-radius:5px;overflow:auto;white-space:pre-wrap;word-break:break-word}.notes{line-height:1.6}@media(max-width:850px){.shell{grid-template-columns:1fr}aside{display:none}.filters{grid-template-columns:1fr}.head{display:block}}

/* V15.5 · Tipografía del editor unificada con Wiki */
.form label{font-size:12px;line-height:1.3}
.form input,.form select,.form textarea{
  font-size:12px;
  line-height:1.42;
}
.form textarea{
  padding:10px 12px;
  font-family:Arial,sans-serif;
  font-size:13px;
  line-height:1.42;
  resize:vertical;
}
.form textarea.code{
  min-height:430px;
  font-family:Consolas,"Courier New",monospace;
  font-size:13px;
  line-height:20px;
  tab-size:4;
  white-space:pre;
}

/* V16.0 · Tipografía común de Biblioteca */
:root{
  --doc-text-size:12px;
  --doc-h4-size:12px;
  --doc-h3-size:13px;
  --doc-h2-size:14px;
  --doc-h1-size:15px;
  --doc-h1-color:#EC0000;
}
main p,.notes,.card p{font-size:var(--doc-text-size);line-height:1.6}
main h1{font-size:var(--doc-h1-size);color:var(--doc-h1-color);font-weight:700;line-height:1.3}
main h2{font-size:var(--doc-h2-size);font-weight:700;line-height:1.3}
main h3{font-size:var(--doc-h3-size);font-weight:700;line-height:1.3}
main h4{font-size:var(--doc-h4-size);font-weight:700;font-style:italic;line-height:1.3}

.text-indent{white-space:pre;display:inline}

'''

if __name__ == '__main__':
    ThreadingHTTPServer(('127.0.0.1', int(os.environ.get('BIBLIOTECA_PORT','8084'))), Handler).serve_forever()
