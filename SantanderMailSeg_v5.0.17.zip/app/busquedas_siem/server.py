from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path
from datetime import datetime
import os, json, html, uuid, re

BASE = Path(__file__).resolve().parent
DATA = BASE / 'data' / 'searches.json'
PORT = int(os.environ.get('SIEM_PORT', '8086'))
PORTAL_URL=os.environ.get('PORTAL_URL','http://127.0.0.1:8079')
WIKI_URL=os.environ.get('WIKI_URL','http://127.0.0.1:8080')
GESTOR_URL=os.environ.get('GESTOR_URL','http://127.0.0.1:8081')
BAU_URL=os.environ.get('BAU_URL','http://127.0.0.1:8082')
BITACORA_URL=os.environ.get('BITACORA_URL','http://127.0.0.1:8083')
BIBLIOTECA_URL=os.environ.get('BIBLIOTECA_URL','http://127.0.0.1:8084')
CAMBIOS_URL=os.environ.get('CAMBIOS_URL','http://127.0.0.1:8085')
VERSION='5.0.17'

PLATFORMS = {
    'splunk': ('Splunk', 'Splunk SPL', 'spl'),
    'defender': ('Microsoft Defender · Entregas avanzadas', 'KQL', 'kql'),
    'crowdstrike': ('CrowdStrike Falcon SIEM', 'CQL', 'cql'),
    'cisco_ces': ('Cisco CES', 'Cisco CES', 'ces'),
}

def esc(v): return html.escape(str(v or ''), quote=True)

def load_all():
    try:
        data=json.loads(DATA.read_text(encoding='utf-8'))
        return data if isinstance(data,list) else []
    except Exception:
        return []

def save_all(items):
    DATA.parent.mkdir(parents=True, exist_ok=True)
    DATA.write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding='utf-8')

def now(): return datetime.now().isoformat(timespec='seconds')

def tags_list(value):
    if isinstance(value,list): return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in str(value or '').split(',') if x.strip()]

def platform_info(key): return PLATFORMS.get(key, PLATFORMS['splunk'])

CSS=r'''
:root{--bg:#05080d;--bg2:#09111a;--panel:#0d1721;--panel2:#111f2b;--line:#25495b;--cyan:#00c8ff;--red:#ec0000;--green:#24e6a1;--amber:#ffbf3f;--text:#e8f3f8;--muted:#8ba5b4}
*{box-sizing:border-box}html,body{margin:0;min-height:100%;font-family:"Segoe UI",Arial,sans-serif;background:radial-gradient(circle at 90% 0,rgba(0,200,255,.08),transparent 32%),linear-gradient(145deg,var(--bg),var(--bg2));color:var(--text)}
a{color:var(--cyan);text-decoration:none}a:hover{color:#8be9ff}
header{height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 18px;border-bottom:1px solid rgba(0,200,255,.38);background:#08131c;position:sticky;top:0;z-index:10}.brand{font-weight:800;font-size:20px}.brand small{color:var(--cyan);font-size:10px;margin-left:6px}.brand .soc{font-size:10px;color:#8be9ff;border:1px solid rgba(0,200,255,.35);border-radius:999px;padding:4px 10px;margin-left:14px;letter-spacing:.7px}
.shell{display:grid;grid-template-columns:220px 1fr;min-height:calc(100vh - 64px)}aside{padding:18px 10px;background:#08111a;border-right:1px solid rgba(0,200,255,.18)}nav a{display:block;color:#abc0cb;padding:11px 13px;margin:4px 0;border:1px solid transparent;border-radius:6px}nav a:hover{background:rgba(0,200,255,.06);border-color:rgba(0,200,255,.22);color:#fff}nav a.active{background:linear-gradient(90deg,rgba(236,0,0,.18),rgba(0,200,255,.06));border-color:rgba(236,0,0,.48);box-shadow:inset 3px 0 0 var(--red);color:#fff;font-weight:700}main{padding:20px 26px;min-width:0}.page-head{display:flex;justify-content:space-between;gap:15px;align-items:flex-start;margin-bottom:16px}h1{margin:0 0 5px;font-size:29px}h2{margin-top:0}.muted{color:var(--muted)}
.btn,button,input[type=submit]{display:inline-flex;align-items:center;justify-content:center;gap:7px;min-height:38px;padding:8px 13px;border:1px solid rgba(0,200,255,.35);border-radius:5px;background:linear-gradient(#142734,#0d1a24);color:#e9f8fc;font-weight:650;cursor:pointer}.btn:hover,button:hover{border-color:var(--cyan)}.btn.primary,input[type=submit].primary{background:linear-gradient(#ff3347,#ec0000);border-color:#ff5968;color:#fff}.btn.danger{background:#4c131d;border-color:#9f2b39}.actions{display:flex;gap:8px;flex-wrap:wrap}
.panel,.card,.filters{background:linear-gradient(145deg,rgba(15,27,38,.97),rgba(9,18,27,.97));border:1px solid rgba(77,133,158,.30);border-radius:8px;box-shadow:0 14px 40px rgba(0,0,0,.28)}.filters{display:grid;grid-template-columns:1fr 240px auto;gap:10px;padding:11px;margin-bottom:14px}input,select,textarea{width:100%;background:#07131c;color:var(--text);border:1px solid #31586b;border-radius:5px;padding:10px 11px;font:inherit}textarea{min-height:115px;resize:vertical}input:focus,select:focus,textarea:focus{outline:none;border-color:var(--cyan);box-shadow:0 0 0 2px rgba(0,200,255,.11)}label{font-weight:700;font-size:13px;color:#dcecf3}.field{display:grid;gap:6px}.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.form-grid .wide{grid-column:1/-1}.form-panel{padding:18px}.hint{font-size:12px;color:var(--muted)}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:14px}.search-card{padding:16px;position:relative}.search-card h3{margin:8px 0 6px;color:#46dbff;font-size:17px}.badges{display:flex;gap:7px;flex-wrap:wrap}.badge,.tag{display:inline-flex;align-items:center;border-radius:999px;padding:4px 9px;font-size:11px;background:#102631;color:#aeeeff;border:1px solid rgba(0,200,255,.27)}.badge.splunk{color:#62e2ff}.badge.defender{color:#90c8ff}.badge.crowdstrike{color:#ffc36a}.badge.cisco_ces{color:#7dffb2}.tag:before{content:'#';margin-right:1px;color:#56d9ff}.favorite{position:absolute;right:13px;top:12px;color:#899fab;font-size:20px}.favorite.on{color:#ffcc45;text-shadow:0 0 8px rgba(255,204,69,.35)}.description{color:#a9bfca;min-height:38px}.meta{font-size:11px;color:#718c9a;margin:8px 0}.card-actions{display:flex;gap:7px;flex-wrap:wrap;margin-top:10px}
.code-shell{border:1px solid rgba(36,230,161,.30);border-radius:7px;overflow:hidden;background:#02090e;margin:12px 0}.code-head{display:flex;justify-content:space-between;align-items:center;padding:9px 12px;border-bottom:1px solid rgba(36,230,161,.18);background:#07151c;font:700 11px Consolas,monospace;color:#64f6c1;letter-spacing:.4px}.code-head span+span{color:#64dbff}.code-body{margin:0;padding:14px 16px;white-space:pre-wrap;overflow:auto;color:#dff9ef;background:#02090e;border:0;font:13px/1.55 Consolas,"Courier New",monospace}.tok-pipe{color:#ff6b7b}.tok-key{color:#55d9ff;font-weight:700}.tok-string{color:#ffd36a}.tok-number{color:#a7ed78}.tok-func{color:#c997ff}.tok-comment{color:#667e88;font-style:italic}
.detail-head{display:flex;justify-content:space-between;align-items:flex-start;gap:15px}.detail-panel{padding:18px;margin-top:12px}.description-box{padding:14px;border-left:3px solid var(--cyan);background:#0a1923;color:#c5dae4;border-radius:4px}.meta-grid{display:grid;grid-template-columns:repeat(4,minmax(130px,1fr));gap:8px;margin:13px 0}.meta-box{padding:10px;background:#0a1923;border:1px solid #203f4f;border-radius:5px}.meta-box small{display:block;color:#7896a6}.meta-box strong{display:block;margin-top:4px}
.empty{padding:34px;text-align:center;color:#8da5b1}.top-actions{display:flex;gap:8px}.copy-ok{color:var(--green)!important}
@media(max-width:900px){.shell{grid-template-columns:1fr}aside{border-right:0;border-bottom:1px solid rgba(0,200,255,.18)}.filters,.form-grid{grid-template-columns:1fr}.form-grid .wide{grid-column:auto}.meta-grid{grid-template-columns:1fr 1fr}}
'''

JS=r'''
function copyQuery(id, btn){const el=document.getElementById(id);if(!el)return;navigator.clipboard.writeText(el.textContent).then(()=>{const old=btn.textContent;btn.textContent='Copiado';btn.classList.add('copy-ok');setTimeout(()=>{btn.textContent=old;btn.classList.remove('copy-ok')},1200)})}
function confirmDelete(){return confirm('¿Eliminar esta búsqueda SIEM?')}
'''

def sidebar(active='Búsquedas SIEM'):
    links=[('Inicio',PORTAL_URL),('Wiki',WIKI_URL),('Proyectos y tareas',GESTOR_URL),('BAU',BAU_URL),('Bitácora',BITACORA_URL),('Biblioteca',BIBLIOTECA_URL),('Búsquedas SIEM','/'),('Plantillas',CAMBIOS_URL)]
    return '<nav>'+''.join(f'<a class="{"active" if n==active else ""}" href="{esc(u)}">{esc(n)}</a>' for n,u in links)+'</nav>'

def layout(title, body, active='Búsquedas SIEM'):
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)} · Búsquedas SIEM</title><style>{CSS}</style></head><body><header><div class="brand">Santander Mail Security · Búsquedas SIEM <small>V{VERSION}</small><span class="soc">SOC // SECURE</span></div><div class="top-actions"><a class="btn" href="{esc(PORTAL_URL)}">Inicio común</a><a class="btn primary" href="/new">+ Nueva búsqueda</a></div></header><div class="shell"><aside>{sidebar(active)}</aside><main>{body}</main></div><script>{JS}</script></body></html>'''

def highlight(query, lang):
    s=esc(query)
    # lightweight highlighter, preserving escaped markup
    # comments first
    if lang in ('spl','kql','cql','ces'):
        s=re.sub(r'(?m)(^\s*#.*$)',r'<span class="tok-comment">\1</span>',s)
        s=re.sub(r'(&quot;.*?&quot;|\'.*?\')',r'<span class="tok-string">\1</span>',s)
        s=re.sub(r'\b(\d+(?:\.\d+)?)\b',r'<span class="tok-number">\1</span>',s)
        s=re.sub(r'(?m)(\|)',r'<span class="tok-pipe">\1</span>',s)
        keys = ['search','where','stats','timechart','table','fields','rename','eval','sort','dedup','rex','spath','lookup','join','append','transaction','summarize','project','extend','filter','groupBy','select','parse','case','in','and','or','not','contains','has','if','else','match','accept','reject','drop','quarantine','deliver','route','sender','recipient','subject','mail-from','rcpt-to','message-filter','content-filter']
        pattern=r'\b('+'|'.join(re.escape(k) for k in keys)+r')\b'
        s=re.sub(pattern,r'<span class="tok-key">\1</span>',s,flags=re.I)
        funcs=['count','sum','avg','min','max','dc','values','coalesce','if','isnotnull','tolower','toupper','strlen']
        s=re.sub(r'\b('+'|'.join(funcs)+r')\s*(?=\()',r'<span class="tok-func">\1</span>',s,flags=re.I)
    return s

def code_block(item, ident='query-code'):
    pkey=item.get('platform','splunk'); _, label, lang=platform_info(pkey)
    q=item.get('query','')
    return f'''<div class="code-shell"><div class="code-head"><span>TERMINAL / {esc(label)}</span><button class="btn" type="button" onclick="copyQuery('{ident}',this)">Copiar consulta</button></div><pre class="code-body" id="{ident}">{highlight(q,lang)}</pre></div>'''

def list_page(qs):
    items=load_all(); term=(qs.get('q',[''])[0] or '').strip(); platform=(qs.get('platform',[''])[0] or '').strip()
    def ok(x):
        if platform and x.get('platform')!=platform:return False
        if term:
            hay=' '.join([x.get('title',''),x.get('description',''),x.get('query',''),' '.join(tags_list(x.get('tags',[]))) ]).lower()
            if term.lower() not in hay:return False
        return True
    filtered=[x for x in items if ok(x)]
    filtered.sort(key=lambda x:(not bool(x.get('favorite')), x.get('title','').lower()))
    opts='<option value="">Todas las plataformas</option>'+''.join(f'<option value="{k}" {"selected" if k==platform else ""}>{esc(v[0])}</option>' for k,v in PLATFORMS.items())
    cards=[]
    for x in filtered:
        p=x.get('platform','splunk'); pname, langlabel, _=platform_info(p); tags=''.join(f'<span class="tag">{esc(t)}</span>' for t in tags_list(x.get('tags',[])))
        fav='★' if x.get('favorite') else '☆'
        cards.append(f'''<article class="card search-card"><span class="favorite {'on' if x.get('favorite') else ''}">{fav}</span><div class="badges"><span class="badge {esc(p)}">{esc(pname)}</span><span class="badge">{esc(langlabel)}</span></div><h3><a href="/view?id={esc(x.get('id'))}">{esc(x.get('title'))}</a></h3><div class="description">{esc(x.get('description'))}</div><div class="badges">{tags}</div><div class="meta">Actualizada: {esc(x.get('updated_at','').replace('T',' '))} · Autor: {esc(x.get('author',''))}</div><div class="card-actions"><a class="btn" href="/view?id={esc(x.get('id'))}">Ver</a><a class="btn" href="/edit?id={esc(x.get('id'))}">Editar</a><a class="btn" href="/duplicate?id={esc(x.get('id'))}">Duplicar</a><a class="btn" href="/favorite?id={esc(x.get('id'))}">{'Quitar favorito' if x.get('favorite') else 'Favorito'}</a></div></article>''')
    body=f'''<div class="page-head"><div><h1>Búsquedas SIEM</h1><div class="muted">Consultas operativas reutilizables para Splunk, Microsoft Defender, CrowdStrike Falcon SIEM y Cisco CES.</div></div><a class="btn primary" href="/new">+ Nueva búsqueda SIEM</a></div><form class="filters" method="get"><input name="q" value="{esc(term)}" placeholder="Buscar por título, comentario, consulta o etiqueta..."><select name="platform">{opts}</select><button>Buscar</button></form><div class="grid">{''.join(cards) if cards else '<div class="panel empty">No hay búsquedas que coincidan con los filtros.</div>'}</div>'''
    return layout('Búsquedas SIEM',body)

def form_page(item=None, error=''):
    item=item or {}; editing=bool(item.get('id')); opts=''.join(f'<option value="{k}" {"selected" if item.get("platform","splunk")==k else ""}>{esc(v[0])}</option>' for k,v in PLATFORMS.items())
    error_html=f'<div class="panel" style="padding:10px;border-left:4px solid #ec0000">{esc(error)}</div>' if error else ''
    body=f'''<div class="page-head"><div><h1>{'Editar' if editing else 'Nueva'} búsqueda SIEM</h1><div class="muted">Guarde la consulta junto con una explicación clara de su finalidad.</div></div><a class="btn" href="/">Cancelar</a></div>{error_html}<form class="panel form-panel" method="post" action="/save"><input type="hidden" name="id" value="{esc(item.get('id',''))}"><div class="form-grid"><div class="field wide"><label>Título</label><input name="title" required value="{esc(item.get('title',''))}" placeholder="Ej.: Correos bloqueados por Temporal Spam Suspect"></div><div class="field"><label>Plataforma</label><select name="platform" id="platform">{opts}</select><div class="hint">Splunk usa SPL; Defender usa KQL; CrowdStrike Falcon SIEM usa CQL.</div></div><div class="field"><label>Autor</label><input name="author" value="{esc(item.get('author','EmailSecurity'))}"></div><div class="field wide"><label>Comentario / qué hace la búsqueda</label><textarea name="description" required placeholder="Explique qué devuelve, cuándo utilizarla y cualquier consideración importante.">{esc(item.get('description',''))}</textarea></div><div class="field wide"><label>Consulta</label><textarea name="query" required style="min-height:300px;font-family:Consolas,'Courier New',monospace" placeholder="Pegue aquí la query...">{esc(item.get('query',''))}</textarea></div><div class="field wide"><label>Etiquetas</label><input name="tags" value="{esc(', '.join(tags_list(item.get('tags',[]))))}" placeholder="ProofPoint, Correo, Auditoría"><div class="hint">Sepárelas por comas.</div></div><div class="field"><label><input type="checkbox" name="favorite" value="1" style="width:auto" {'checked' if item.get('favorite') else ''}> Favorito</label></div></div><div class="actions" style="margin-top:16px"><input class="primary" type="submit" value="Guardar búsqueda"><a class="btn" href="/">Cancelar</a></div></form>'''
    return layout(('Editar' if editing else 'Nueva')+' búsqueda',body)

def view_page(item):
    pname,label,_=platform_info(item.get('platform','splunk')); tags=''.join(f'<span class="tag">{esc(t)}</span>' for t in tags_list(item.get('tags',[])))
    body=f'''<div class="detail-head"><div><div class="badges"><span class="badge {esc(item.get('platform',''))}">{esc(pname)}</span><span class="badge">{esc(label)}</span>{'<span class="badge">★ Favorito</span>' if item.get('favorite') else ''}</div><h1 style="margin-top:9px">{esc(item.get('title'))}</h1></div><div class="actions"><a class="btn" href="/edit?id={esc(item.get('id'))}">Editar</a><a class="btn" href="/duplicate?id={esc(item.get('id'))}">Duplicar</a><a class="btn danger" onclick="return confirmDelete()" href="/delete?id={esc(item.get('id'))}">Eliminar</a></div></div><div class="panel detail-panel"><div class="meta-grid"><div class="meta-box"><small>Autor</small><strong>{esc(item.get('author'))}</strong></div><div class="meta-box"><small>Creada</small><strong>{esc(item.get('created_at','').replace('T',' '))}</strong></div><div class="meta-box"><small>Actualizada</small><strong>{esc(item.get('updated_at','').replace('T',' '))}</strong></div><div class="meta-box"><small>Plataforma</small><strong>{esc(pname)}</strong></div></div><h2>Qué hace la búsqueda</h2><div class="description-box">{esc(item.get('description')).replace(chr(10),'<br>')}</div><h2 style="margin-top:22px">Consulta</h2>{code_block(item)}<h2 style="margin-top:20px">Etiquetas</h2><div class="badges">{tags if tags else '<span class="muted">Sin etiquetas</span>'}</div></div>'''
    return layout(item.get('title','Búsqueda SIEM'),body)

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt,*args): pass
    def send_html(self, text, status=200):
        data=text.encode('utf-8'); self.send_response(status); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def redirect(self,url): self.send_response(303); self.send_header('Location',url); self.end_headers()
    def parse_post(self):
        n=int(self.headers.get('Content-Length','0') or 0); raw=self.rfile.read(n).decode('utf-8','replace'); return {k:v[0] if v else '' for k,v in parse_qs(raw,keep_blank_values=True).items()}
    def find_item(self, ident):
        for x in load_all():
            if x.get('id')==ident:return x
        return None
    def do_GET(self):
        u=urlparse(self.path); qs=parse_qs(u.query); path=u.path
        if path=='/': return self.send_html(list_page(qs))
        if path=='/new': return self.send_html(form_page())
        if path in ('/view','/edit'):
            item=self.find_item((qs.get('id') or [''])[0])
            if not item:return self.send_html(layout('No encontrada','<div class="panel empty">La búsqueda no existe.</div>'),404)
            return self.send_html(view_page(item) if path=='/view' else form_page(item))
        if path=='/delete':
            ident=(qs.get('id') or [''])[0]; save_all([x for x in load_all() if x.get('id')!=ident]); return self.redirect('/')
        if path=='/favorite':
            ident=(qs.get('id') or [''])[0]; items=load_all()
            for x in items:
                if x.get('id')==ident: x['favorite']=not bool(x.get('favorite')); x['updated_at']=now()
            save_all(items); return self.redirect('/')
        if path=='/duplicate':
            ident=(qs.get('id') or [''])[0]; items=load_all(); src=next((x for x in items if x.get('id')==ident),None)
            if not src:return self.redirect('/')
            dup=dict(src); dup['id']='qry_'+uuid.uuid4().hex[:12]; dup['title']=(src.get('title') or 'Búsqueda')+' (copia)'; dup['favorite']=False; dup['created_at']=dup['updated_at']=now(); items.append(dup); save_all(items); return self.redirect('/edit?id='+dup['id'])
        return self.send_html(layout('No encontrada','<div class="panel empty">Página no encontrada.</div>'),404)
    def do_POST(self):
        u=urlparse(self.path)
        if u.path!='/save': return self.send_html('No encontrado',404)
        f=self.parse_post(); title=f.get('title','').strip(); query=f.get('query','').strip(); description=f.get('description','').strip(); platform=f.get('platform','splunk')
        if not title or not query or not description or platform not in PLATFORMS:return self.send_html(form_page(f,'Título, comentario, plataforma y consulta son obligatorios.'),400)
        items=load_all(); ident=f.get('id','').strip(); existing=next((x for x in items if x.get('id')==ident),None) if ident else None; stamp=now()
        obj={
            'id': ident if existing else 'qry_'+uuid.uuid4().hex[:12],
            'title':title,'platform':platform,'language':platform_info(platform)[2],
            'description':description,'query':query,'tags':tags_list(f.get('tags','')),
            'author':f.get('author','').strip() or 'EmailSecurity','favorite':f.get('favorite')=='1',
            'created_at': existing.get('created_at',stamp) if existing else stamp,'updated_at':stamp,
        }
        if existing: items[items.index(existing)]=obj
        else: items.append(obj)
        save_all(items); return self.redirect('/view?id='+obj['id'])

if __name__=='__main__':
    DATA.parent.mkdir(parents=True,exist_ok=True)
    if not DATA.exists(): DATA.write_text('[]',encoding='utf-8')
    print(f'Búsquedas SIEM: http://127.0.0.1:{PORT}')
    ThreadingHTTPServer(('127.0.0.1',PORT),Handler).serve_forever()
