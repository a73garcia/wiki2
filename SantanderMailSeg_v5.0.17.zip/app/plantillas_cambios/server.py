from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, quote
from pathlib import Path
from datetime import datetime, timezone
from email.parser import BytesParser
from email.policy import default as email_policy
from xml.etree import ElementTree as ET
import subprocess, sys
import os, json, html, uuid, re, zipfile, shutil
import traceback

BASE=Path(__file__).resolve().parent
ROOT=BASE.parent.parent
DATA=BASE/'data'
TEMPLATES=DATA/'templates.json'
CATEGORIES=DATA/'categories.json'
WORD_FILES=DATA/'word_templates'
GENERATION_WORD_FILES=ROOT/'templates_word'
GENERATION_WORD_CONFIG=GENERATION_WORD_FILES/'config.json'

PORTAL_URL=os.environ.get('PORTAL_URL','http://127.0.0.1:8079')
WIKI_URL=os.environ.get('WIKI_URL','http://127.0.0.1:8080')
GESTOR_URL=os.environ.get('GESTOR_URL','http://127.0.0.1:8081')
BAU_URL=os.environ.get('BAU_URL','http://127.0.0.1:8082')
BITACORA_URL=os.environ.get('BITACORA_URL','http://127.0.0.1:8083')
BIBLIOTECA_URL=os.environ.get('BIBLIOTECA_URL','http://127.0.0.1:8084')
CAMBIOS_URL=os.environ.get('CAMBIOS_URL','http://127.0.0.1:8085')
SIEM_URL=os.environ.get('SIEM_URL','http://127.0.0.1:8086')

def read(path,default):
    try:
        return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default
    except Exception:
        return default

def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(path)

def now(): return datetime.now().isoformat(timespec='seconds')
def esc(value): return html.escape(str(value or ''),quote=True)
def xml_escape(value): return html.escape(str(value or ''),quote=False)
def categories(): return [str(x).strip() for x in read(CATEGORIES,['CES','ProofPoint']) if str(x).strip()]
def templates():
    rows=read(TEMPLATES,[])
    return rows if isinstance(rows,list) else []
def find_item(item_id): return next((x for x in templates() if str(x.get('id'))==str(item_id)),None)

def logo_path():
    candidates=[ROOT/'configuracion'/'logo'/'logo.png']
    return next((p for p in candidates if p.is_file()),None)

def safe_filename(value):
    value=re.sub(r'[^\w\- .()]','_',str(value or ''),flags=re.UNICODE).strip(' .')
    return value[:120] or 'plantilla'

def document_path(item):
    filename=str(item.get('document_file') or f"{item.get('id','plantilla')}.docx").strip()
    path=(WORD_FILES/Path(filename).name).resolve()
    if WORD_FILES.resolve() not in path.parents:
        raise ValueError('Ruta no válida')
    return path

def open_local_path(path):
    """Abre un archivo o carpeta con Word o la aplicación predeterminada."""
    path=Path(path).resolve()
    if not path.exists():
        raise FileNotFoundError(f'No se encuentra: {path}')

    if os.name=='nt':
        # Para DOC/DOCX se intenta abrir Word de forma explícita. En algunos
        # equipos corporativos os.startfile no inicia Word desde un servidor local.
        if path.is_file() and path.suffix.lower() in ('.doc','.docx'):
            candidates=[]
            for env_name in ('PROGRAMFILES','PROGRAMFILES(X86)','LOCALAPPDATA'):
                base=os.environ.get(env_name)
                if not base:
                    continue
                base=Path(base)
                candidates.extend([
                    base/'Microsoft Office'/'root'/'Office16'/'WINWORD.EXE',
                    base/'Microsoft Office'/'Office16'/'WINWORD.EXE',
                    base/'Microsoft Office'/'Office15'/'WINWORD.EXE',
                    base/'Microsoft'/'Office'/'root'/'Office16'/'WINWORD.EXE',
                ])
            for exe in candidates:
                if exe.is_file():
                    subprocess.Popen([str(exe),str(path)],cwd=str(path.parent))
                    return

        # Asociación predeterminada de Windows.
        try:
            os.startfile(str(path))
            return
        except OSError as first_error:
            # ShellExecuteW ofrece un segundo método independiente de startfile.
            try:
                import ctypes
                result=ctypes.windll.shell32.ShellExecuteW(None,'open',str(path),None,str(path.parent),1)
                if int(result)>32:
                    return
            except Exception:
                pass
            # Último recurso: comando START de Windows.
            try:
                subprocess.Popen(
                    ['cmd.exe','/c','start','','%s' % str(path)],
                    cwd=str(path.parent),
                    creationflags=getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0)
                )
                return
            except Exception as final_error:
                raise RuntimeError(
                    'Windows no pudo abrir el archivo. Compruebe que Microsoft Word '
                    'está instalado y asociado a los archivos DOCX. '
                    f'Detalle: {final_error or first_error}'
                ) from final_error

    if sys.platform=='darwin':
        subprocess.Popen(['open',str(path)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        return
    opener=shutil.which('xdg-open')
    if not opener:
        raise RuntimeError('No se encontró una aplicación para abrir el archivo.')
    subprocess.Popen([opener,str(path)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)



def plain_html(value):
    source=str(value or '')
    source=re.sub(r'(?is)<br\s*/?>','\n',source)
    source=re.sub(r'(?is)</(?:p|div|li|h[1-6])>','\n',source)
    source=re.sub(r'(?is)<[^>]+>','',source)
    return html.unescape(source).strip()

def paragraph_xml(text,bold=False):
    props='<w:rPr><w:b/></w:rPr>' if bold else ''
    return '<w:p><w:r>'+props+f'<w:t xml:space="preserve">{xml_escape(text)}</w:t></w:r></w:p>'

def create_docx(path,title,category,author='A. Garcia',version='1.0',body=''):
    path.parent.mkdir(parents=True,exist_ok=True)
    created=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    body_lines=[x.rstrip() for x in str(body or '').replace('\r\n','\n').split('\n')]
    parts=[
        paragraph_xml(title or 'Nueva plantilla',True),
        paragraph_xml(f'Categoría: {category or "General"}'),
        paragraph_xml(f'Autor: {author or "A. Garcia"}'),
        paragraph_xml(f'Versión: {version or "1.0"}'),
        paragraph_xml(f'Fecha: {datetime.now().strftime("%d/%m/%Y")}'),
        '<w:p/>',
    ]
    if body_lines and any(x.strip() for x in body_lines):
        parts.extend(paragraph_xml(line) if line else '<w:p/>' for line in body_lines)
    else:
        parts.extend([paragraph_xml('Contenido de la plantilla',True),paragraph_xml('Escriba aquí el contenido del documento.')])
    document_xml='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>%s<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>''' % ''.join(parts)
    content_types='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>'''
    rels='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>'''
    doc_rels='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>'''
    styles='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:sz w:val="20"/></w:rPr></w:rPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style></w:styles>'''
    core=f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>{xml_escape(title)}</dc:title><dc:creator>{xml_escape(author)}</dc:creator><cp:lastModifiedBy>{xml_escape(author)}</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">{created}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">{created}</dcterms:modified></cp:coreProperties>'''
    app='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Santander Mail Security</Application></Properties>'''
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('[Content_Types].xml',content_types)
        archive.writestr('_rels/.rels',rels)
        archive.writestr('word/document.xml',document_xml)
        archive.writestr('word/styles.xml',styles)
        archive.writestr('word/_rels/document.xml.rels',doc_rels)
        archive.writestr('docProps/core.xml',core)
        archive.writestr('docProps/app.xml',app)

def docx_text(path,limit=1800):
    try:
        with zipfile.ZipFile(path) as archive:
            data=archive.read('word/document.xml')
        root=ET.fromstring(data)
        ns='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
        paragraphs=[]
        for p in root.iter(ns+'p'):
            chunks=[]
            for node in p.iter():
                if node.tag==ns+'t': chunks.append(node.text or '')
                elif node.tag==ns+'tab': chunks.append('\t')
                elif node.tag==ns+'br': chunks.append('\n')
            text=''.join(chunks).strip()
            if text: paragraphs.append(text)
        return '\n'.join(paragraphs)[:limit]
    except Exception:
        return ''

def valid_docx(data):
    try:
        from io import BytesIO
        with zipfile.ZipFile(BytesIO(data)) as archive:
            names=set(archive.namelist())
            return '[Content_Types].xml' in names and 'word/document.xml' in names
    except Exception:
        return False

def migrate_templates():
    rows=templates(); changed=False
    for item in rows:
        item.setdefault('author','A. Garcia'); item.setdefault('version','1.0')
        item.setdefault('observations',[]); item.setdefault('created_at',now()); item.setdefault('updated_at',item.get('created_at') or now())
        for observation in item.get('observations',[]):
            observation.setdefault('author','A. Garcia')
        if 'content' not in item:
            content=str(item.get('template') or '')
            try:
                path=document_path(item)
                if path.is_file(): content=docx_text(path,50000) or content
            except Exception: pass
            item['content']=content; changed=True
        if item.get('file_type')!='json': item['file_type']='json'; changed=True
    if changed: write(TEMPLATES,rows)

def render_content(value):
    # Mantener apóstrofes para interpretar la marca de cursiva del editor.
    text=html.escape(str(value or ''), quote=False)
    text=re.sub(r'^======\s*(.*?)\s*======$',r'<h4>\1</h4>',text,flags=re.M)
    text=re.sub(r'^=====\s*(.*?)\s*=====$',r'<h3>\1</h3>',text,flags=re.M)
    text=re.sub(r'^====\s*(.*?)\s*====$',r'<h2>\1</h2>',text,flags=re.M)
    text=re.sub(r'^===\s*(.*?)\s*===$',r'<h1>\1</h1>',text,flags=re.M)
    text=re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',text,flags=re.S)
    text=re.sub(r"''(.+?)''",r'<em>\1</em>',text,flags=re.S)
    text=re.sub(r'//(.+?)//',r'<em>\1</em>',text,flags=re.S)
    text=re.sub(r'(?<!\*)\*([^*\n]+?)\*(?!\*)',r'<em>\1</em>',text)
    text=re.sub(r'\[u\](.+?)\[/u\]',r'<u>\1</u>',text,flags=re.I|re.S)
    text=re.sub(r'\[azul\](.+?)\[/azul\]',r'<span class="text-blue">\1</span>',text,flags=re.I|re.S)
    text=re.sub(r'\[rojo\](.+?)\[/rojo\]',r'<span class="text-red">\1</span>',text,flags=re.I|re.S)
    text=re.sub(r'\[amarillo\](.+?)\[/amarillo\]',r'<mark class="highlight-yellow">\1</mark>',text,flags=re.I|re.S)
    text=re.sub(r'```(.*?)```',lambda m:'<pre><code>'+m.group(1).strip()+'</code></pre>',text,flags=re.S)
    return '<div class="rendered-content">'+text.replace('\n','<br>')+'</div>'

CSS='''
:root{--red:#EC0000;--dark:#B30000;--soft:#FDECEC;--bg:#F7F7F7;--text:#242424;--muted:#666;--border:#D8D8D8;--font:"Santander Headline","Segoe UI",Arial,sans-serif}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:14px var(--font)}
header{height:58px;padding:6px 16px;background:#fff;border-bottom:4px solid var(--red);display:flex;justify-content:space-between;align-items:center;gap:16px}.brand{display:flex;align-items:center;gap:10px;font-size:20px;font-weight:600;min-width:0}.brand-logo{display:block;width:auto;height:auto;max-width:120px;max-height:38px;object-fit:contain}.brand span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.shell{display:grid;grid-template-columns:215px minmax(0,1fr);min-height:calc(100vh - 58px)}aside{background:#fff;border-right:1px solid var(--border);padding:18px 10px}nav a{display:block;padding:10px 12px;margin-bottom:5px;color:#3b3b3b;text-decoration:none;border-radius:6px}nav a:hover,nav a.active{background:var(--soft);color:var(--dark);border-left:4px solid var(--red);font-weight:700}
main{padding:12px 18px 30px;width:100%;max-width:none;margin:0}h1,h2{color:var(--dark)}h1{margin:0}.card{background:#fff;border:1px solid var(--border);border-radius:10px;padding:14px}.btn,button{display:inline-block;border:1px solid var(--red);border-radius:6px;padding:9px 13px;background:var(--red);color:#fff;text-decoration:none;cursor:pointer;font:inherit}.btn.secondary,button.secondary{background:#fff;color:var(--dark)}button.danger,.btn.danger{background:#8A0000;border-color:#8A0000}
.actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.page-tools{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin:0 0 10px}.search-card{margin-bottom:10px;padding:10px}.search{display:grid;grid-template-columns:minmax(260px,1fr) 220px auto;gap:8px}
input,select,textarea{width:100%;padding:10px;border:1px solid #B8B8B8;border-radius:6px;font:inherit;background:#fff}label{display:block;font-weight:700;margin:10px 0 5px}.form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 14px}.wide{grid-column:1/-1}
.template-list{display:grid;gap:9px}.template-card{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:14px;align-items:center;padding:13px 15px}.template-card h2{font-size:17px;margin:2px 0 6px}.template-card p{margin:0;color:#555}.meta{color:var(--muted);font-size:12px}.word-badge{display:inline-flex;align-items:center;gap:6px;background:#eaf2ff;color:#174a7e;border-radius:999px;padding:5px 9px;font-weight:700;font-size:12px}.empty{padding:24px;text-align:center;color:var(--muted)}
.detail-head{display:flex;justify-content:space-between;align-items:flex-start;gap:14px;flex-wrap:wrap;margin-bottom:10px}.preview{white-space:pre-wrap;line-height:1.55;max-height:520px;overflow:auto;background:#02090e!important;color:#a8ffd8!important;border:1px solid rgba(36,230,161,.28)!important;border-radius:7px;padding:14px;font-family:Consolas,"Courier New",monospace;overflow-wrap:anywhere}.observation{border-left:4px solid var(--red);background:#091720!important;color:#e7f4f8!important;padding:12px;margin:10px 0;border-radius:5px}.observation p{white-space:pre-wrap}.category-row{display:grid;grid-template-columns:minmax(0,1fr) auto auto;gap:8px;margin:8px 0}.inline{display:inline-block;margin:0}.help{font-size:12px;color:#666;margin-top:5px}.file-current{padding:10px;background:#091720!important;color:#e7f4f8!important;border:1px solid #31586b;border-radius:7px;margin-top:5px}
@media(max-width:800px){.shell{grid-template-columns:1fr}aside{display:none}.search,.form-grid{grid-template-columns:1fr}.template-card{grid-template-columns:1fr}.brand-logo{max-width:90px}}

/* V4.0 Santander Cyber Command */

:root{
 --cyber-bg:#05080d;--cyber-bg2:#09111a;--cyber-panel:#0d1721;--cyber-panel2:#111f2b;
 --cyber-line:#1e3b4c;--cyber-line-hot:#00c8ff;--cyber-red:#ec0000;--cyber-red2:#ff3347;
 --cyber-cyan:#00c8ff;--cyber-green:#24e6a1;--cyber-amber:#ffbf3f;--cyber-text:#e8f3f8;
 --cyber-muted:#8ba5b4;--cyber-shadow:0 14px 40px rgba(0,0,0,.38);
 --brand-font:"Segoe UI",Arial,sans-serif;--body-font:"Segoe UI",Arial,sans-serif;
}
*{box-sizing:border-box}html{background:var(--cyber-bg)}html,body{font-family:var(--body-font)!important}
body{background:radial-gradient(circle at 85% -10%,rgba(0,200,255,.10),transparent 34%),radial-gradient(circle at 5% 0%,rgba(236,0,0,.10),transparent 30%),linear-gradient(145deg,var(--cyber-bg),var(--cyber-bg2) 55%,#05090e)!important;color:var(--cyber-text)!important;min-height:100vh}
body:before{content:"";position:fixed;inset:0;pointer-events:none;z-index:-1;background-image:linear-gradient(rgba(255,255,255,.018) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.018) 1px,transparent 1px);background-size:32px 32px;mask-image:linear-gradient(to bottom,black,transparent 88%)}
header{min-height:72px!important;height:auto!important;padding:10px 22px!important;background:linear-gradient(90deg,rgba(8,15,22,.98),rgba(12,25,35,.98))!important;color:var(--cyber-text)!important;border:0!important;border-bottom:1px solid rgba(0,200,255,.35)!important;box-shadow:0 8px 28px rgba(0,0,0,.35)!important;position:sticky!important;top:0!important;z-index:30!important}
header:after{content:"";position:absolute;left:0;right:0;bottom:-1px;height:2px;background:linear-gradient(90deg,var(--cyber-red),transparent 26%,var(--cyber-cyan) 70%,transparent);opacity:.9}
.brand{color:var(--cyber-text)!important;font-size:19px!important;font-weight:700!important;letter-spacing:.4px!important;text-transform:none;display:flex!important;align-items:center!important;gap:12px!important}
.brand img,.brand-logo{width:45px!important;height:45px!important;object-fit:contain!important;filter:drop-shadow(0 0 10px rgba(236,0,0,.45))}
.brand::before{display:none!important}.brand small{color:var(--cyber-cyan)!important}
.shell{min-height:calc(100vh - 72px)!important}.shell aside,aside{background:linear-gradient(180deg,rgba(10,18,27,.97),rgba(7,13,20,.98))!important;border:0!important;border-right:1px solid rgba(0,200,255,.20)!important;box-shadow:8px 0 26px rgba(0,0,0,.2)!important}
aside nav a,nav a{position:relative;color:#a9bfca!important;border:1px solid transparent!important;border-radius:6px!important;letter-spacing:.2px!important;transition:background .16s ease,border-color .16s ease,color .16s ease,transform .16s ease!important}
aside nav a:before,nav a:before{content:"";position:absolute;left:0;top:25%;bottom:25%;width:2px;background:transparent;box-shadow:none}
aside nav a:hover,nav a:hover{background:rgba(0,200,255,.07)!important;color:#fff!important;border-color:rgba(0,200,255,.24)!important;transform:translateX(2px)}
aside nav a.active,nav a.active{background:linear-gradient(90deg,rgba(236,0,0,.20),rgba(0,200,255,.07))!important;color:#fff!important;border-color:rgba(236,0,0,.42)!important;border-left:1px solid rgba(236,0,0,.42)!important;font-weight:700!important;box-shadow:inset 3px 0 0 var(--cyber-red),0 0 18px rgba(236,0,0,.08)!important}
aside nav a.active:before{background:var(--cyber-red);box-shadow:0 0 10px var(--cyber-red)}.aside-note{color:#7896a6!important;border-color:rgba(0,200,255,.12)!important;background:transparent!important;box-shadow:none!important}
main{color:var(--cyber-text)!important}main h1,main h2,.page-title{color:#f2f8fb!important;letter-spacing:.25px!important}main h2:after{content:"";display:block;width:42px;height:2px;margin-top:7px;background:linear-gradient(90deg,var(--cyber-red),var(--cyber-cyan));box-shadow:0 0 8px rgba(0,200,255,.35)}main h3{color:#dcecf3!important}
p,small,.muted,.page-head p,.stats span,.stat span{color:var(--cyber-muted)!important}a{color:var(--cyber-cyan)!important}a:hover{color:#7ee6ff!important}
.card,.panel,.widget,.stat,.tile,.project-card,.task-card,.wiki-card,.bau-card,section,.hero,.info-card,.form-card,.filters,.module-tabs,.health-row,.pending-chip,.import-dialog,.summary-row,.current-assets{background:linear-gradient(145deg,rgba(15,27,38,.96),rgba(9,18,27,.96))!important;border:1px solid rgba(77,133,158,.28)!important;border-radius:8px!important;box-shadow:var(--cyber-shadow)!important;color:var(--cyber-text)!important;backdrop-filter:blur(8px)}
.card:hover,.project-card:hover,.task-card:hover,.pending-chip:hover{border-color:rgba(0,200,255,.42)!important}.stat strong,.stats strong,.health-value{color:#fff!important;text-shadow:0 0 16px rgba(0,200,255,.18)}
.btn,.button,button,input[type=submit],input[type=button]{min-height:36px;font-family:var(--body-font)!important;border-radius:5px!important;border:1px solid rgba(0,200,255,.35)!important;background:linear-gradient(180deg,#142734,#0d1a24)!important;color:#dff7ff!important;box-shadow:inset 0 1px rgba(255,255,255,.04),0 5px 16px rgba(0,0,0,.22)!important;transition:.16s ease!important;text-decoration:none!important}
.btn:hover,.button:hover,button:hover,input[type=submit]:hover,input[type=button]:hover{border-color:var(--cyber-cyan)!important;color:#fff!important;box-shadow:0 0 15px rgba(0,200,255,.18)!important;transform:translateY(-1px)}
.btn.primary,.btn-primary,.button-primary,button.primary,input[type=submit],.word-template-action{background:linear-gradient(180deg,var(--cyber-red2),var(--cyber-red))!important;border-color:#ff4c5c!important;color:#fff!important;box-shadow:0 0 18px rgba(236,0,0,.20)!important}
.btn.primary:hover,.btn-primary:hover,button.primary:hover,input[type=submit]:hover{background:linear-gradient(180deg,#ff4a5b,#c90000)!important;border-color:#ff7280!important}.btn.danger{background:#551520!important;border-color:#a92b3a!important;color:#ffd9dd!important}.secondary,.cancel{background:linear-gradient(180deg,#172a36,#101c25)!important;color:#d9edf5!important}
input,select,textarea{background:#07111a!important;color:var(--cyber-text)!important;border:1px solid #294757!important;border-radius:5px!important;font-family:var(--body-font)!important}input::placeholder,textarea::placeholder{color:#587180!important}input:focus,select:focus,textarea:focus{border-color:var(--cyber-cyan)!important;outline:0!important;box-shadow:0 0 0 2px rgba(0,200,255,.13),0 0 18px rgba(0,200,255,.08)!important}select option{background:#0a151e;color:#e7f4f8}
table{background:transparent!important;border-color:#29414e!important;color:var(--cyber-text)!important}thead th,table th{background:linear-gradient(180deg,#172b38,#10202b)!important;color:#dff7ff!important;border-color:#294958!important;text-transform:uppercase;letter-spacing:.45px}td,th{border-color:rgba(64,105,125,.28)!important}tbody tr:nth-child(even){background:rgba(255,255,255,.018)!important}tbody tr:hover{background:rgba(0,200,255,.045)!important}td a,.project-card h3 a{color:var(--cyber-cyan)!important}
.badge,.chip,.tag,.person-chip,.doc-category,.pending-filter,.search-filters a{border-radius:999px!important;background:#122631!important;color:#aeeeff!important;border:1px solid rgba(0,200,255,.25)!important}.status-finalizado,.status-completada{background:rgba(36,230,161,.10)!important;color:var(--cyber-green)!important;border-color:rgba(36,230,161,.28)!important}.status-en-curso,.badge.en-curso{background:rgba(0,200,255,.10)!important;color:#65ddff!important}.status-bloqueada,.status-cancelado,.priority-critica,.priority-crítica{background:rgba(236,0,0,.13)!important;color:#ff7180!important;border-color:rgba(236,0,0,.3)!important}.priority-alta{background:rgba(255,191,63,.11)!important;color:var(--cyber-amber)!important}
.notice,.alert,.callout,.import-warning{background:rgba(0,200,255,.055)!important;color:#ccecf5!important;border:1px solid rgba(0,200,255,.20)!important;border-left:4px solid var(--cyber-cyan)!important}.bar,.progress{background:#071119!important}.bar span,.progress span{background:linear-gradient(90deg,var(--cyber-red),var(--cyber-cyan))!important;box-shadow:0 0 12px rgba(0,200,255,.35)}
pre,code,.code-block,.summary-details{background:#03090d!important;color:#8fffd1!important;border:1px solid rgba(36,230,161,.22)!important;font-family:Consolas,"Courier New",monospace!important;text-shadow:0 0 7px rgba(36,230,161,.12)}.activity-icon,.linked-doc-dot,.timeline-dot{background:var(--cyber-red)!important;color:#fff!important;box-shadow:0 0 12px rgba(236,0,0,.55)!important}.import-modal{background:rgba(0,4,8,.82)!important}.import-dialog-head,.import-dialog-actions{border-color:#29414e!important;background:#0c1821!important}
::-webkit-scrollbar{width:11px;height:11px}::-webkit-scrollbar-track{background:#071019}::-webkit-scrollbar-thumb{background:#24404f;border:2px solid #071019;border-radius:8px}::-webkit-scrollbar-thumb:hover{background:#356477}
@media(max-width:900px){header{position:relative!important}.shell aside,aside{border-right:0!important;border-bottom:1px solid rgba(0,200,255,.2)!important}}
@media print{body,html{background:#fff!important;color:#111!important}body:before{display:none!important}header,aside,.header-actions,.actions,.toolbar,footer{display:none!important}main{width:100%!important;max-width:none!important;margin:0!important;padding:0!important}.card,.panel,.widget,.stat,.tile,.project-card,.task-card,.wiki-card,.bau-card,section,.hero,.info-card,.form-card{background:#fff!important;color:#111!important;border-color:#ccc!important;box-shadow:none!important;backdrop-filter:none!important}h1,h2,h3,p,small,.muted{color:#111!important;text-shadow:none!important}table{color:#111!important;background:#fff!important}table th,thead th{background:#ec0000!important;color:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}td{color:#111!important}pre,code,.code-block{background:#f2f2f2!important;color:#111!important;text-shadow:none!important}}


/* V4.1 Cyber Command visual refinement */
:root{
 --cc41-surface:#0b1721;--cc41-surface2:#0f202c;--cc41-surface3:#132936;
 --cc41-border:rgba(56,151,190,.34);--cc41-glow:rgba(0,200,255,.16);
}
body{background:
 radial-gradient(ellipse at 85% 0%,rgba(0,184,230,.12),transparent 38%),
 radial-gradient(ellipse at 8% 8%,rgba(236,0,0,.10),transparent 32%),
 linear-gradient(135deg,#05080d 0%,#07131c 55%,#061019 100%)!important}
body:after{content:"";position:fixed;inset:72px 0 0 0;pointer-events:none;z-index:-1;opacity:.24;background:
 linear-gradient(90deg,transparent 49.8%,rgba(0,200,255,.07) 50%,transparent 50.2%),
 linear-gradient(transparent 49.8%,rgba(0,200,255,.055) 50%,transparent 50.2%);background-size:96px 96px}
header{min-height:64px!important;padding:7px 16px!important}
header .brand{font-size:20px!important;text-shadow:0 0 18px rgba(0,200,255,.10)}
header .header-actions,header .actions{display:flex!important;gap:8px!important;align-items:center!important}
header .brand:after{content:"SOC // SECURE";font-size:9px;line-height:1;padding:5px 8px;margin-left:8px;color:#78e8ff;border:1px solid rgba(0,200,255,.33);border-radius:999px;background:rgba(0,200,255,.06);letter-spacing:1.1px;font-weight:700}
main{animation:cc41Fade .22s ease-out}
@keyframes cc41Fade{from{opacity:.25;transform:translateY(3px)}to{opacity:1;transform:none}}
/* Never use bright white application cards */
.stat,.stats>*,.metric,.metric-card,.summary-card,.template-card,.template-item,.template-type,.template-option,.type-card,.quick-card,.category-card,.counter-card,.word-template-card,.document-card,.attachment-card,.upload-card,.link-card,.mail-card,.mail-block,.note-block,.callout-note,.preview-card,.word-preview,.preview-box,.white-card{
 background:linear-gradient(145deg,rgba(17,34,46,.98),rgba(8,18,27,.98))!important;
 color:#eaf7fb!important;border:1px solid var(--cc41-border)!important;
 box-shadow:inset 0 1px rgba(255,255,255,.035),0 13px 28px rgba(0,0,0,.30)!important}
.stat:hover,.template-card:hover,.template-item:hover,.type-card:hover,.word-template-card:hover{transform:translateY(-2px);border-color:rgba(0,200,255,.60)!important;box-shadow:0 0 0 1px rgba(0,200,255,.08),0 16px 34px rgba(0,0,0,.35),0 0 20px var(--cc41-glow)!important}
.stat strong,.metric strong,.summary-card strong,.counter-card strong{font-size:28px!important;color:#70e8ff!important;text-shadow:0 0 18px rgba(0,200,255,.27)!important}
.stat span,.metric span,.summary-card span,.counter-card span{color:#9db5c1!important}
/* Explicitly catch common pale blocks from legacy CSS */
main [style*="background:white"],main [style*="background: white"],main [style*="background:#fff"],main [style*="background: #fff"],main [style*="background:#f"],main [style*="background: #f"]{background:linear-gradient(145deg,#10212d,#0a1720)!important;color:#e8f4f8!important}
section,.panel,.card,.form-card,.filters,.module-tabs,.current-assets{position:relative;overflow:hidden}
section:before,.panel:before,.card:before,.form-card:before{content:"";position:absolute;left:0;top:0;width:85px;height:1px;background:linear-gradient(90deg,#ec0000,#00c8ff,transparent);box-shadow:0 0 10px rgba(0,200,255,.30)}
/* Controls: sharper command-console geometry */
.btn,.button,button,input[type=submit],input[type=button]{border-radius:4px!important;letter-spacing:.1px!important;font-weight:600!important}
.btn:active,.button:active,button:active{transform:translateY(1px)!important}
.btn.primary,.btn-primary,button.primary,input[type=submit]{clip-path:polygon(7px 0,100% 0,100% calc(100% - 7px),calc(100% - 7px) 100%,0 100%,0 7px)}
/* Editor and technical blocks */
textarea,.editor-textarea,.editor-area,[contenteditable="true"]{background:#030d14!important;color:#e9f6fa!important;caret-color:#00d7ff!important}
pre,.code-block,.code-panel,.text-block{position:relative!important;background:linear-gradient(180deg,#02090e,#061117)!important;border-color:rgba(36,230,161,.28)!important;box-shadow:inset 0 0 28px rgba(0,0,0,.52),0 10px 25px rgba(0,0,0,.22)!important}
pre:before,.code-block:before,.code-panel:before{content:"TERMINAL / READ ONLY";display:block;color:#64f6c1;font:700 9px/1.2 Consolas,monospace;letter-spacing:1.1px;margin:0 0 10px;padding-bottom:7px;border-bottom:1px solid rgba(36,230,161,.18)}
/* Tables */
table{border-collapse:separate!important;border-spacing:0!important;overflow:hidden;border:1px solid rgba(49,111,139,.30)!important;border-radius:6px!important}
thead th,table th{height:40px!important;background:linear-gradient(180deg,#173140,#10232f)!important;border-bottom:1px solid rgba(0,200,255,.40)!important}
tbody td{padding-top:11px!important;padding-bottom:11px!important}
tbody tr{transition:background .14s ease,box-shadow .14s ease}
tbody tr:hover{box-shadow:inset 3px 0 0 #00c8ff!important}
/* White content previews stay readable but become intentional document canvases */
.document-preview,.word-document,.page-preview,.preview-paper,.rendered-content,.mail-preview,.note-preview{
 background:#eaf0f3!important;color:#16242d!important;border:1px solid #91a6b0!important;
 box-shadow:inset 0 0 0 1px #fff,0 14px 32px rgba(0,0,0,.28)!important}
.document-preview *,.word-document *,.page-preview *,.preview-paper *,.rendered-content *,.mail-preview *,.note-preview *{color:inherit}
/* Side navigation */
aside nav a{min-height:40px!important;display:flex!important;align-items:center!important}
aside nav a.active:after{content:"";position:absolute;right:9px;width:5px;height:5px;border-radius:50%;background:#00d5ff;box-shadow:0 0 10px #00d5ff}
/* Image presentation */
main img:not(.brand-logo):not(.logo){border-radius:5px;outline:1px solid rgba(0,200,255,.22);box-shadow:0 16px 35px rgba(0,0,0,.36)}
/* Improve readability of labels over dark UI */
label,legend,.field-label{color:#d9e8ee!important;font-weight:650!important}
hr{border:0!important;height:1px!important;background:linear-gradient(90deg,transparent,rgba(0,200,255,.55),rgba(236,0,0,.35),transparent)!important}
@media (prefers-reduced-motion:reduce){main{animation:none}.stat,.template-card,.template-item,.type-card,.word-template-card{transition:none!important}}


/* === V4.2.2 FORCE DARK UI — sin superficies blancas en pantalla === */
@media screen {
  :root{color-scheme:dark!important}
  html,body,.shell,main,.main,.content-area,.page-content,.workspace,.layout,.app-shell{
    background:#050d14!important;color:#e7f4f8!important
  }
  main{background-image:radial-gradient(circle at 85% 0,rgba(0,200,255,.055),transparent 31%),radial-gradient(circle at 0 30%,rgba(236,0,0,.045),transparent 28%)!important}
  main :is(section,article,div,form,fieldset,details,dialog,table,tbody,tr,td,ul,ol,li){
    border-color:rgba(73,125,148,.30)
  }
  main :is(.card,.panel,.widget,.tile,.stat,.stats>div,.summary-card,.metric,.metric-card,
  .template-card,.template-grid>a,.template-grid a,.template-item,.template-row,.template-box,
  .template-selector,.template-choice,.template-type,.template-option,.type-card,.quick-card,
  .category-card,.counter-card,.project-card,.task-card,.wiki-card,.bau-card,.info-card,.form-card,
  .document-card,.attachment-card,.upload-card,.link-card,.mail-card,.mail-block,.communication,
  .note,.note-block,.admonition,.callout,.callout-note,.preview-card,.word-preview,.preview-box,
  .document-preview,.word-document,.page-preview,.preview-paper,.rendered-document,.document-canvas,
  .paper-preview,.docx-preview,.template-preview-panel,.template-editor-panel,.number-preview,
  .filters,.module-tabs,.calendar-list,.calendar-day,.content,.viewer,.editor-preview,.white-card){
    background:linear-gradient(145deg,#0d1c26,#07131b)!important;
    color:#e7f4f8!important;
    border-color:rgba(69,132,158,.42)!important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.025),0 10px 26px rgba(0,0,0,.23)!important
  }
  main :is(.template-card,.template-grid>a,.template-grid a,.template-item,.template-row,.template-box,
  .template-selector,.template-choice,.word-template-card,.document-card,.attachment-card,.upload-card,.link-card) *{
    background-color:transparent!important;color:#dff3f9!important
  }
  main :is(.template-card,.template-grid>a,.template-grid a,.template-item,.template-row,.template-box,
  .template-selector,.template-choice) a{color:#18d2ff!important}
  main :is(h1,h2,h3,h4,h5,h6,strong,label,legend,dt,th){color:#f1f8fb!important}
  main :is(p,span,small,em,li,dd,.muted,.meta,.help-text,.description){color:#9fb8c4!important}
  main a{color:#22cff8!important}
  main table,main thead,main tbody,main tr,main td,main th{background-color:#091720!important;color:#dcecf3!important}
  main thead th,main table th{background:#122936!important;color:#eaf8fc!important}
  main tbody tr:nth-child(even){background:#0b1b25!important}
  main tbody tr:hover{background:#102936!important}
  main input,main select,main textarea,main option,main [contenteditable=true]{
    background:#06131c!important;color:#edf9fc!important;border-color:#31586b!important
  }
  main input::placeholder,main textarea::placeholder{color:#6f8996!important;opacity:1}
  main input[type=file]{background:#071721!important;color:#a9c2ce!important}
  main input[type=file]::file-selector-button{background:#132b38!important;color:#e8f7fb!important;border:1px solid #386277!important}
  main button,main .btn,main .button,main a.btn,main .page-actions a,main .page-actions button,
  main .manage-templates-button,main summary{
    background:linear-gradient(180deg,#142c39,#0a1922)!important;color:#e7f4f8!important;border-color:#31586b!important
  }
  main button:hover,main .btn:hover,main .button:hover,main a.btn:hover,main summary:hover{
    background:#173746!important;color:#fff!important;border-color:#00c8ff!important
  }
  main .primary,main .btn.primary,main .btn-primary,main input[type=submit],main .danger.primary{
    background:linear-gradient(180deg,#ff293b,#c90000)!important;color:#fff!important;border-color:#ff4c5c!important
  }
  main button:disabled,main .btn:disabled{background:#101e27!important;color:#647b86!important;border-color:#263b46!important;opacity:.75!important}
  main .editor-toolbar,main .toolbar{background:#0b1a24!important;color:#e7f4f8!important;border-color:#31586b!important}
  main pre,main code,main .code-wrap,main .code-head,main .code-box{background:#02090e!important;color:#a8ffd8!important}
  main .wiki-image img,main img.preview,main .image-preview{background:#07131b!important;border-color:#31586b!important}
  footer{background:#07131b!important;color:#8da7b3!important;border-color:#29414e!important}
}
/* Editor JSON de plantillas de cambios */
.wiki-style-toolbar{display:flex;flex-wrap:wrap;gap:7px;align-items:center;padding:8px;background:#0b1a24!important;border:1px solid #31586b!important;border-bottom:0!important;border-radius:7px 7px 0 0!important}.toolbar-main{display:flex;flex-wrap:wrap;gap:6px;align-items:center}.toolbar-menu{position:relative}.toolbar-menu summary{list-style:none;cursor:pointer;border:1px solid #31586b;background:#102531;color:#e7f4f8;border-radius:5px;padding:8px 10px;font-weight:600}.toolbar-menu summary::-webkit-details-marker{display:none}.toolbar-menu-panel{position:absolute;z-index:50;top:calc(100% + 4px);left:0;min-width:175px;background:#07131b!important;border:1px solid #31586b!important;border-radius:7px;padding:6px;box-shadow:0 10px 26px rgba(0,0,0,.5);display:grid;gap:4px}.toolbar-menu-panel button{width:100%;text-align:left}.editor-shell textarea{border-radius:0 0 7px 7px!important;min-height:480px;font-family:Consolas,"Courier New",monospace;line-height:1.55}.rendered-content{line-height:1.6;overflow-wrap:anywhere}.rendered-content pre{padding:14px;border:1px solid #31586b;border-radius:7px;overflow:auto}.rendered-content h1,.rendered-content h2,.rendered-content h3,.rendered-content h4{margin-top:18px}.text-blue{color:#4fb8ff}.text-red{color:#ff6674}

'''

def layout(body):
    links=[('Inicio',PORTAL_URL),('Wiki',WIKI_URL),('Proyectos y tareas',GESTOR_URL),('BAU',BAU_URL),('Bitácora',BITACORA_URL),('Biblioteca',BIBLIOTECA_URL),('Búsquedas SIEM',SIEM_URL),('Plantillas',CAMBIOS_URL)]
    nav=''.join(f'<a class="{"active" if name=="Plantillas" else ""}" href="{esc(url)}">{esc(name)}</a>' for name,url in links)
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Plantillas</title><style>{CSS}
.word-local-actions{{margin-top:10px}}
.file-current{{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}}
.detail-head{{display:grid!important;grid-template-columns:minmax(280px,1fr)!important;gap:14px!important}}
.detail-head>.actions{{display:flex!important;flex-wrap:wrap!important;max-width:100%!important;overflow:visible!important}}
.detail-head>.actions .btn,.detail-head>.actions button{{white-space:nowrap!important}}
.preview,.observation{{background:#020d14!important;color:#dff7e9!important;border-color:#31586b!important}}
.rendered-content{{background:#06131c!important;color:#e8f3f8!important;border:1px solid #31586b!important;border-radius:7px;padding:14px;min-height:180px;box-shadow:none!important}}
.rendered-content *{{color:inherit!important;background-color:transparent!important}}.rendered-content .text-blue{{color:#55bfff!important}}.rendered-content .text-red{{color:#ff6674!important}}.rendered-content strong{{font-weight:800!important}}.rendered-content em{{font-style:italic!important}}.rendered-content u{{text-decoration:underline!important;text-underline-offset:2px!important}}.rendered-content mark.highlight-yellow{{background:#5a4300!important;color:#fff1a6!important;border:1px solid #9d7600!important;border-radius:3px;padding:0 .28em}}

/* V5.0.17 · Formato inline global */
.rendered-content span.text-blue,.content span.text-blue,article span.text-blue{{color:#39b9ff!important;-webkit-text-fill-color:#39b9ff!important}}
.rendered-content span.text-red,.content span.text-red,article span.text-red{{color:#ff4f61!important;-webkit-text-fill-color:#ff4f61!important}}
.rendered-content strong,.content strong,article strong{{font-weight:800!important}}
.rendered-content em,.content em,article em{{font-style:italic!important}}
.rendered-content pre,.rendered-content code{{background:#02090e!important;color:#a8ffd8!important;border-color:#31586b!important}}
.preview::before{{content:"DOCUMENTO WORD / TEXTO EXTRAÍDO";display:block;color:#64f6c1;font:700 9px Consolas,monospace;letter-spacing:1px;margin-bottom:10px;padding-bottom:7px;border-bottom:1px solid rgba(36,230,161,.18)}}

@media(max-width:700px){{.file-current{{align-items:flex-start;flex-direction:column}}}}
</style></head><body><header><div class="brand"><img class="brand-logo" src="/logo.png?v=27115" alt="Logo Santander"><span>Santander Mail Security · Plantillas <small style="font-size:10px;opacity:.8">V5.0.17</small></span></div><div class="actions"><a class="btn secondary" href="/">← Atrás</a><a class="btn secondary" href="{PORTAL_URL}">Portal</a></div></header><div class="shell"><aside><nav>{nav}</nav></aside><main>{body}</main></div><script src="/editor.js"></script></body></html>'''

def cambios_home(query='',category=''):
    migrate_templates(); rows=templates(); term=query.strip().casefold()
    if category: rows=[x for x in rows if x.get('category')==category]
    if term: rows=[x for x in rows if term in ' '.join(map(str,[x.get('title',''),x.get('category',''),x.get('author',''),x.get('version',''),x.get('content','')])).casefold()]
    options='<option value="">Todas las categorías</option>'+''.join(f'<option value="{esc(c)}" {"selected" if c==category else ""}>{esc(c)}</option>' for c in categories())
    cards=[]
    for item in sorted(rows,key=lambda x:x.get('updated_at',''),reverse=True):
        intro=plain_html(item.get('content',''))[:360].replace('\n',' · ')
        cards.append(f'''<article class="card template-card"><div><div class="meta">{esc(item.get('category'))} · {esc(item.get('updated_at','').replace('T',' '))}</div><h2><a href="/view?id={esc(item.get('id'))}">{esc(item.get('title'))}</a></h2><p>{esc(intro or 'Plantilla JSON sin contenido.')}</p><div class="meta">Autor: {esc(item.get('author','A. Garcia'))} · Versión: {esc(item.get('version','1.0'))}</div></div><div class="actions"><span class="word-badge">&#123;&#125; JSON</span><a class="btn secondary" href="/edit?id={esc(item.get('id'))}">✎ Editar plantilla</a><form class="inline" method="post" action="/duplicate"><input type="hidden" name="id" value="{esc(item.get('id'))}"><button class="secondary">Duplicar</button></form><form class="inline" method="post" action="/delete" onsubmit="return confirm('¿Eliminar esta plantilla de cambio?')"><input type="hidden" name="id" value="{esc(item.get('id'))}"><button class="danger">Eliminar</button></form></div></article>''')
    return layout(f'''<div class="page-tools"><div><h1>Plantillas de cambios</h1><p class="help">Plantillas JSON editables con el mismo editor técnico de la Wiki.</p></div><div class="actions"><a class="btn" href="/new">+ Nueva plantilla de cambio</a><a class="btn secondary" href="/categories">Categorías</a><a class="btn secondary" href="/">← Plantillas</a></div></div><section class="card search-card"><form class="search"><input name="q" value="{esc(query)}" placeholder="Buscar por nombre, categoría, autor o contenido"><select name="category">{options}</select><button>Buscar</button></form></section><section class="template-list">{''.join(cards) if cards else '<div class="card empty">No hay plantillas de cambios.</div>'}</section>''')

def module_home():
    body = """
    <div class="page-tools"><div><h1>Plantillas</h1>
    <p class="help">Seleccione el tipo de plantilla que desea administrar.</p></div></div>
    <section class="template-section-grid">
      <a class="template-section-card" href="/cambios">
        <span class="template-section-icon">🧩</span>
        <span><strong>Plantillas de cambios</strong>
        <small>Plantillas JSON de cambios con categoría, autor, versión, observaciones y editor técnico tipo Wiki.</small></span>
      </a>
      <a class="template-section-card" href="/word-templates">
        <span class="template-section-icon">📄</span>
        <span><strong>Plantillas Word para generar documentos</strong>
        <small>Archivos DOCX utilizados desde la Wiki al pulsar «Generar Word».</small></span>
      </a>
    </section>
    <style>
    .template-section-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}
    .template-section-card{display:flex;gap:16px;align-items:flex-start;padding:22px;background:linear-gradient(145deg,#10212d,#091720);border:1px solid rgba(66,139,169,.45);border-radius:10px;text-decoration:none;color:#e7f4f8;box-shadow:inset 0 1px 0 rgba(255,255,255,.025),0 10px 26px rgba(0,0,0,.25)}
    .template-section-card:hover{border-color:#00c8ff;background:linear-gradient(145deg,#132936,#0b1b25);text-decoration:none;transform:translateY(-2px);box-shadow:0 16px 34px rgba(0,0,0,.35),0 0 20px rgba(0,200,255,.10)}
    .template-section-card strong{display:block;font-size:18px;color:#22cff8;margin-bottom:7px}
    .template-section-card small{display:block;color:#9fb8c4;line-height:1.45}
    .template-section-icon{font-size:30px;line-height:1}
    @media(max-width:800px){.template-section-grid{grid-template-columns:1fr}}
    </style>
    """
    return layout(body)


def generation_word_config():
    GENERATION_WORD_FILES.mkdir(parents=True,exist_ok=True)
    try:
        data=json.loads(GENERATION_WORD_CONFIG.read_text(encoding='utf-8')) if GENERATION_WORD_CONFIG.exists() else {}
        return data if isinstance(data,dict) else {}
    except Exception:
        return {}


def save_generation_word_config(data):
    GENERATION_WORD_FILES.mkdir(parents=True,exist_ok=True)
    GENERATION_WORD_CONFIG.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')


def generation_word_name(name):
    name=Path(str(name or '')).name.strip()
    return name if name.lower().endswith('.docx') and name not in ('.','..') else None


def generation_word_templates_page(message=''):
    GENERATION_WORD_FILES.mkdir(parents=True,exist_ok=True)
    cfg=generation_word_config()
    default=Path(str(cfg.get('default',''))).name
    files=sorted(GENERATION_WORD_FILES.glob('*.docx'),key=lambda p:p.name.casefold())
    rows=[]
    for file in files:
        is_default=file.name==default
        default_action = (
            '<span class="tag">Predeterminada</span>'
            if is_default else
            '<form class="inline" method="post" action="/word-templates/default?name='+quote(file.name)+'"><button class="word-template-action" type="submit">Hacer predeterminada</button></form>'
        )
        rows.append(
            '<tr><td><strong>'+esc(file.name)+'</strong>'+(' <span class="tag">Predeterminada</span>' if is_default else '')+'</td>'
            '<td>'+str(max(1,file.stat().st_size//1024))+' KB</td>'
            '<td class="actions">'
            '<a class="btn word-template-action" href="'+esc(PORTAL_URL)+'/templates/edit?name='+quote(file.name)+'">✎ Editar plantilla</a>'
            '<a class="btn word-template-action" href="/word-templates/open?name='+quote(file.name)+'" target="word-template-action">📝 Abrir en Word</a>'
            +default_action+
            '<form class="inline" method="post" action="/word-templates/delete" onsubmit="return confirm(\'¿Eliminar esta plantilla Word?\')">'
            '<input type="hidden" name="name" value="'+esc(file.name)+'"><button class="word-template-action">Eliminar</button></form>'
            '</td></tr>'
        )
    notice='<div class="notice">'+esc(message)+'</div>' if message else ''
    table=''.join(rows) if rows else '<tr><td colspan="3"><strong>No existen plantillas Word.</strong><br><small>La aplicación continuará funcionando. Suba un DOCX cuando necesite volver a generar documentos Word.</small></td></tr>'
    body=(
        '<div class="page-tools"><div><h1>Plantillas Word para generar documentos</h1>'
        '<p class="help">Estas plantillas aparecen en la Wiki al utilizar «Generar Word».</p></div>'
        '<div class="actions"><a class="btn secondary" href="/">← Plantillas</a></div></div>'
        +notice+
        '<style>.word-template-action{display:inline-flex!important;align-items:center!important;justify-content:center!important;min-height:38px!important;padding:9px 14px!important;border:1px solid #ec0000!important;border-radius:6px!important;background:#ec0000!important;color:#fff!important;font-weight:600!important;text-decoration:none!important;box-shadow:none!important}.word-template-action:hover{background:#c00000!important;border-color:#c00000!important;color:#fff!important}.actions form.inline{display:inline-flex!important;margin:0!important}.actions .word-template-action{margin:0!important}</style>'+'<section class="card"><table><thead><tr><th>Plantilla</th><th>Tamaño</th><th>Acciones</th></tr></thead><tbody>'+table+'</tbody></table>'
        '<hr style="border:0;border-top:1px solid #ddd;margin:20px 0">'
        '<h2>Añadir o sustituir plantilla Word</h2>'
        '<p class="help">Al subir un DOCX con el mismo nombre se sustituye el archivo existente.</p>'
        '<form method="post" action="/word-templates/upload" enctype="multipart/form-data">'
        '<div class="actions"><input type="file" name="document" accept=".docx" required><button>Subir plantilla</button></div>'
        '</form><iframe name="word-template-action" hidden></iframe></section>'
    )
    return layout(body)


def editor_toolbar(target='content'):
    return f'''<div class="toolbar wiki-style-toolbar" data-target="{target}"><div class="toolbar-main"><button type="button" data-action="heading">Título</button><button type="button" data-open="**" data-close="**">Negrita</button><button type="button" data-open="''" data-close="''">Cursiva</button><button type="button" data-open="[u]" data-close="[/u]">Subrayado</button><button type="button" data-open="[azul]" data-close="[/azul]">Azul</button><button type="button" data-open="[rojo]" data-close="[/rojo]">Rojo</button><button type="button" data-open="* " data-mode="insert">Lista</button><button type="button" data-action="indent">→ Tab +4</button><button type="button" data-action="outdent">← Quitar tab</button><details class="toolbar-menu"><summary>Comunicación</summary><div class="toolbar-menu-panel"><button type="button" data-open="::: correo\nPara:\nCC:\nCCO:\nAsunto:\n\n" data-close="\n::: endcorreo">Correo</button><button type="button" data-open="::: caso\n" data-close="\n::: endcaso">Caso</button><button type="button" data-open="::: respuesta\n" data-close="\n::: endrespuesta">Respuesta</button></div></details><details class="toolbar-menu"><summary>Avisos</summary><div class="toolbar-menu-panel"><button type="button" data-open="!!! nota:\n" data-mode="insert">Nota</button><button type="button" data-open="!!! advertencia:\n" data-mode="insert">Advertencia</button></div></details><details class="toolbar-menu"><summary>Código</summary><div class="toolbar-menu-panel"><button type="button" data-open="plaintext" data-mode="code">Texto</button><button type="button" data-open="spl" data-mode="code">Splunk</button><button type="button" data-open="python" data-mode="code">Python</button><button type="button" data-open="powershell" data-mode="code">PowerShell</button></div></details></div></div>'''

def form_page(item=None,error=''):
    item=item or {}
    options=''.join(f'<option value="{esc(c)}" {"selected" if c==item.get("category") else ""}>{esc(c)}</option>' for c in categories())
    return layout(f'''<div class="page-tools"><div><h1>{'Editar plantilla de cambio' if item.get('id') else 'Nueva plantilla de cambio'}</h1><p class="help">El contenido se guarda en JSON y usa el mismo formato técnico de la Wiki.</p></div></div>{f'<div class="card">{esc(error)}</div>' if error else ''}<section class="card"><form method="post" action="/save"><input type="hidden" name="id" value="{esc(item.get('id'))}"><div class="form-grid"><label>Título<input name="title" value="{esc(item.get('title'))}" required maxlength="240"></label><label>Categoría<select name="category" required>{options}</select></label><label>Autor<input name="author" value="{esc(item.get('author','A. Garcia'))}" required></label><label>Versión<input name="version" value="{esc(item.get('version','1.0'))}" required></label><div class="wide editor-shell"><label>Contenido</label>{editor_toolbar('content')}<textarea id="content" name="content" rows="24" required>{esc(item.get('content',''))}</textarea></div></div><div class="actions" style="margin-top:14px"><button>Guardar</button><a class="btn secondary" href="/cambios">Cancelar</a></div></form></section>''')

def view_page(item):
    comments=[]
    for o in sorted(item.get('observations',[]),key=lambda x:x.get('updated_at',''),reverse=True):
        created=esc(o.get('created_at','').replace('T',' '))
        updated=esc(o.get('updated_at','').replace('T',' '))
        date_text=f"Creado {created}" if created==updated else f"Creado {created} · Modificado {updated}"
        comments.append(f'''<div class="observation"><div class="meta"><strong>{esc(o.get('author','A. Garcia'))}</strong> · {date_text}</div><p>{esc(o.get('text'))}</p><div class="actions"><a class="btn secondary" href="/observation/edit?template_id={esc(item.get('id'))}&id={esc(o.get('id'))}">Editar comentario</a><form method="post" action="/observation/delete" onsubmit="return confirm('¿Eliminar este comentario?')"><input type="hidden" name="template_id" value="{esc(item.get('id'))}"><input type="hidden" name="id" value="{esc(o.get('id'))}"><button class="danger">Eliminar</button></form></div></div>''')
    return layout(f'''<div class="detail-head"><div><div class="meta">{esc(item.get('category'))} · Modificada {esc(item.get('updated_at','').replace('T',' '))}</div><h1>{esc(item.get('title'))}</h1><div class="meta">Autor: {esc(item.get('author'))} · Versión: {esc(item.get('version'))} · Formato: JSON</div></div><div class="actions"><a class="btn" href="/edit?id={esc(item.get('id'))}">✎ Editar plantilla</a><form method="post" action="/duplicate"><input type="hidden" name="id" value="{esc(item.get('id'))}"><button class="secondary">Duplicar</button></form><form method="post" action="/delete" onsubmit="return confirm('¿Eliminar esta plantilla de cambio?')"><input type="hidden" name="id" value="{esc(item.get('id'))}"><button class="danger">Eliminar</button></form></div></div><section class="card"><h2>Plantilla para cambio</h2>{render_content(item.get('content',''))}</section><section class="card"><h2>Comentarios</h2><form method="post" action="/observation/save"><input type="hidden" name="template_id" value="{esc(item.get('id'))}"><div class="form-grid"><label>Autor<input name="author" value="A. Garcia" required></label><label class="wide">Comentario<textarea name="text" rows="4" placeholder="Añadir comentario" required></textarea></label></div><button>Añadir comentario</button></form>{''.join(comments) if comments else '<p class="empty">Sin comentarios.</p>'}</section>''')


def categories_page():
    rows=''.join(f'''<form class="category-row" method="post" action="/category/save"><input type="hidden" name="old" value="{esc(c)}"><input name="name" value="{esc(c)}" required><button>Guardar</button><button class="danger" formaction="/category/delete" onclick="return confirm('¿Eliminar categoría?')">Eliminar</button></form>''' for c in categories())
    return layout(f'''<div class="page-tools"><h1>Categorías</h1></div><section class="card"><h2>Añadir categoría</h2><form class="category-row" method="post" action="/category/save"><input type="hidden" name="old"><input name="name" placeholder="Nueva categoría" required><button>Añadir</button><span></span></form></section><section class="card"><h2>Categorías existentes</h2>{rows}</section>''')

def observation_form(item,obs):
    return layout(f'''<div class="page-tools"><h1>Editar comentario</h1></div><section class="card"><form method="post" action="/observation/save"><input type="hidden" name="template_id" value="{esc(item.get('id'))}"><input type="hidden" name="id" value="{esc(obs.get('id'))}"><label>Autor<input name="author" value="{esc(obs.get('author','A. Garcia'))}" required></label><label>Comentario<textarea name="text" rows="8" required>{esc(obs.get('text'))}</textarea></label><div class="actions"><button>Guardar cambios</button><a class="btn secondary" href="/view?id={esc(item.get('id'))}">Cancelar</a></div></form></section>''')

class Handler(BaseHTTPRequestHandler):
    def send_html(self,text,status=200):
        data=text.encode('utf-8'); self.send_response(status); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def redirect(self,url):
        self.send_response(303)
        self.send_header('Location',url)
        self.send_header('Content-Length','0')
        self.send_header('Cache-Control','no-store')
        self.end_headers()
    def read_request(self):
        size=int(self.headers.get('Content-Length','0') or 0); data=self.rfile.read(size); content_type=self.headers.get('Content-Type',''); fields={}; files={}
        if content_type.startswith('multipart/form-data'):
            message=BytesParser(policy=email_policy).parsebytes(b'Content-Type: '+content_type.encode()+b'\r\nMIME-Version: 1.0\r\n\r\n'+data)
            for part in message.iter_parts():
                name=part.get_param('name',header='content-disposition'); filename=part.get_filename(); payload=part.get_payload(decode=True) or b''
                if not name: continue
                if filename: files[name]={'filename':Path(filename).name,'data':payload,'content_type':part.get_content_type()}
                else: fields[name]=payload.decode(part.get_content_charset() or 'utf-8','replace')
        else:
            fields={k:v[-1] for k,v in parse_qs(data.decode('utf-8','replace'),keep_blank_values=True).items()}
        return fields,files
    def serve_document(self,item):
        path=document_path(item)
        if not path.is_file(): return self.send_error(404)
        data=path.read_bytes(); name=safe_filename(item.get('title'))+'.docx'
        self.send_response(200); self.send_header('Content-Type','application/vnd.openxmlformats-officedocument.wordprocessingml.document'); self.send_header('Content-Disposition',f'attachment; filename="{name}"'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        migrate_templates(); u=urlparse(self.path); q=parse_qs(u.query)
        if u.path=='/editor.js':
            path=BASE/'editor.js'; data=path.read_bytes(); self.send_response(200); self.send_header('Content-Type','text/javascript; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); return self.wfile.write(data)
        if u.path=='/logo.png':
            path=logo_path()
            if not path: return self.send_error(404)
            data=path.read_bytes(); self.send_response(200); self.send_header('Content-Type','image/png'); self.send_header('Cache-Control','no-cache, no-store, must-revalidate'); self.send_header('Content-Length',str(len(data))); self.end_headers(); return self.wfile.write(data)
        if u.path=='/': return self.send_html(module_home())
        if u.path=='/cambios': return self.send_html(cambios_home(q.get('q',[''])[0],q.get('category',[''])[0]))
        if u.path=='/word-templates':
            return self.send_html(generation_word_templates_page(q.get('message',[''])[0]))
        if u.path=='/word-templates/open':
            name=generation_word_name(q.get('name',[''])[0])
            path=GENERATION_WORD_FILES/name if name else None
            if not path or not path.is_file(): return self.send_error(404)
            try:
                open_local_path(path)
                return self.send_html(
                    '<!doctype html><html lang="es"><head><meta charset="utf-8"><title>Abrir Word</title></head>'
                    '<body><script>setTimeout(function(){window.close()},500)</script>'
                    '<p>La plantilla se ha enviado a Microsoft Word.</p></body></html>'
                )
            except Exception as exc:
                return self.send_html(layout('<div class="card"><h1>No se pudo abrir Word</h1><p>'+esc(exc)+'</p></div>'),500)
        if u.path=='/new': return self.send_html(form_page())
        if u.path=='/edit':
            item=find_item(q.get('id',[''])[0]); return self.send_html(form_page(item) if item else layout('<h1>No encontrada</h1>'),200 if item else 404)
        if u.path=='/view':
            item=find_item(q.get('id',[''])[0]); return self.send_html(view_page(item) if item else layout('<h1>No encontrada</h1>'),200 if item else 404)
        if u.path=='/download':
            item=find_item(q.get('id',[''])[0]); return self.serve_document(item) if item else self.send_error(404)
        if u.path=='/open-word':
            item=find_item(q.get('id',[''])[0])
            if not item:
                return self.send_error(404)
            try:
                open_local_path(document_path(item))
                self.send_response(204)
                self.send_header('Cache-Control','no-store')
                self.end_headers()
                return
            except Exception as exc:
                return self.send_html(layout('<div class="card"><h1>No se pudo abrir Word</h1><p>'+esc(exc)+'</p></div>'),500)
        if u.path=='/open-folder':
            try:
                WORD_FILES.mkdir(parents=True,exist_ok=True)
                open_local_path(WORD_FILES)
                self.send_response(204)
                self.send_header('Cache-Control','no-store')
                self.end_headers()
                return
            except Exception as exc:
                return self.send_html(layout('<div class="card"><h1>No se pudo abrir la carpeta</h1><p>'+esc(exc)+'</p></div>'),500)
        if u.path=='/categories': return self.send_html(categories_page())
        if u.path=='/observation/edit':
            item=find_item(q.get('template_id',[''])[0]); obs=next((o for o in item.get('observations',[]) if str(o.get('id'))==q.get('id',[''])[0]),None) if item else None
            return self.send_html(observation_form(item,obs) if item and obs else layout('<h1>No encontrada</h1>'),200 if item and obs else 404)
        return self.send_html(layout('<h1>Página no encontrada</h1>'),404)
    def do_POST(self):
        try:
            return self._do_POST_impl()
        except (BrokenPipeError,ConnectionAbortedError,ConnectionResetError):
            return
        except Exception as exc:
            traceback.print_exc()
            try:
                message=(
                    '<div class="card"><h1>No se pudo guardar la plantilla Word</h1>'
                    '<p>Se produjo un error al procesar el formulario.</p>'
                    '<p style="white-space:pre-wrap;overflow-wrap:anywhere"><strong>Detalle:</strong> '
                    +esc(exc)+'</p>'
                    '<div class="actions"><a class="btn" href="/">Volver a Plantillas</a></div></div>'
                )
                return self.send_html(layout(message),500)
            except Exception:
                try:
                    data=('Error al guardar: '+str(exc)).encode('utf-8','replace')
                    self.send_response(500)
                    self.send_header('Content-Type','text/plain; charset=utf-8')
                    self.send_header('Content-Length',str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                except Exception:
                    return

    def _do_POST_impl(self):
        migrate_templates(); u=urlparse(self.path); fields,files=self.read_request()
        if u.path=='/word-templates/upload':
            upload=files.get('document')
            if not upload or not upload.get('data'):
                return self.send_html(generation_word_templates_page('Seleccione un archivo DOCX.'),400)
            name=generation_word_name(upload.get('filename',''))
            if not name or not valid_docx(upload['data']):
                return self.send_html(generation_word_templates_page('El archivo seleccionado no es un DOCX válido.'),400)
            GENERATION_WORD_FILES.mkdir(parents=True,exist_ok=True)
            (GENERATION_WORD_FILES/name).write_bytes(upload['data'])
            cfg=generation_word_config()
            current=Path(str(cfg.get('default',''))).name
            if not current or not (GENERATION_WORD_FILES/current).is_file():
                cfg['default']=name
                save_generation_word_config(cfg)
            return self.redirect('/word-templates?message=Plantilla Word guardada correctamente.')
        if u.path=='/word-templates/default':
            name=generation_word_name(parse_qs(u.query).get('name',[''])[0])
            target=GENERATION_WORD_FILES/name if name else None
            if not target or not target.is_file():
                return self.send_html(generation_word_templates_page('La plantilla no existe.'),404)
            cfg=generation_word_config(); cfg['default']=name; save_generation_word_config(cfg)
            return self.redirect('/word-templates?message=Plantilla predeterminada actualizada.')
        if u.path=='/word-templates/delete':
            name=generation_word_name(fields.get('name',''))
            target=GENERATION_WORD_FILES/name if name else None
            if not target or not target.is_file():
                return self.redirect('/word-templates?message=La plantilla ya no existe.')
            try:
                try: os.chmod(target,0o666)
                except OSError: pass
                target.unlink()
            except PermissionError:
                return self.send_html(generation_word_templates_page('No se puede eliminar porque la plantilla está abierta en Word. Cierre el documento y vuelva a intentarlo.'),409)
            cfg=generation_word_config()
            remaining=sorted(GENERATION_WORD_FILES.glob('*.docx'),key=lambda x:x.name.casefold())
            if cfg.get('default')==name or (cfg.get('default') and not (GENERATION_WORD_FILES/Path(str(cfg.get('default'))).name).is_file()):
                if remaining: cfg['default']=remaining[0].name
                else: cfg.pop('default',None)
            save_generation_word_config(cfg)
            message='Plantilla eliminada. '+('Se ha asignado otra como predeterminada.' if remaining else 'No existen plantillas Word; la aplicación seguirá funcionando normalmente.')
            return self.redirect('/word-templates?message='+quote(message))
        if u.path=='/save':
            rows=templates(); item_id=fields.get('id','').strip(); current=find_item(item_id) if item_id else None; stamp=now(); record=current or {'id':uuid.uuid4().hex,'created_at':stamp,'observations':[]}
            record.update({'category':fields.get('category','').strip(),'title':fields.get('title','').strip(),'author':fields.get('author','A. Garcia').strip() or 'A. Garcia','version':fields.get('version','1.0').strip() or '1.0','content':fields.get('content',''),'updated_at':stamp,'file_type':'json'})
            if not record['category'] or not record['title']: return self.send_html(form_page(record,'Categoría y título son obligatorios.'),400)
            rows=[record if str(x.get('id'))==record['id'] else x for x in rows] if current else rows+[record]
            write(TEMPLATES,rows); return self.redirect(f'/view?id={record["id"]}')
        if u.path=='/duplicate':
            item=find_item(fields.get('id',''))
            if item:
                rows=templates(); stamp=now(); copy_item=json.loads(json.dumps(item)); copy_item['id']=uuid.uuid4().hex; copy_item['title']=f"{item.get('title','Plantilla')} - Copia"; copy_item['created_at']=stamp; copy_item['updated_at']=stamp; copy_item['observations']=[]; rows.append(copy_item); write(TEMPLATES,rows); return self.redirect(f'/view?id={copy_item["id"]}')
            return self.redirect('/cambios')
        if u.path=='/delete':
            write(TEMPLATES,[x for x in templates() if str(x.get('id'))!=fields.get('id','')]); return self.redirect('/cambios')
        if u.path=='/observation/save':
            rows=templates(); item=find_item(fields.get('template_id','')); oid=fields.get('id','').strip(); stamp=now()
            if not item: return self.redirect('/')
            observations=item.setdefault('observations',[]); existing=next((o for o in observations if str(o.get('id'))==oid),None) if oid else None
            if existing: existing.update({'author':fields.get('author','A. Garcia').strip() or 'A. Garcia','text':fields.get('text','').strip(),'updated_at':stamp})
            else: observations.append({'id':uuid.uuid4().hex,'author':fields.get('author','A. Garcia').strip() or 'A. Garcia','text':fields.get('text','').strip(),'created_at':stamp,'updated_at':stamp})
            item['updated_at']=stamp; write(TEMPLATES,rows); return self.redirect(f'/view?id={item["id"]}')
        if u.path=='/observation/delete':
            rows=templates(); item=find_item(fields.get('template_id',''))
            if item:
                item['observations']=[o for o in item.get('observations',[]) if str(o.get('id'))!=fields.get('id','')]; item['updated_at']=now(); write(TEMPLATES,rows); return self.redirect(f'/view?id={item["id"]}')
            return self.redirect('/')
        if u.path=='/category/save':
            old=fields.get('old','').strip(); name=fields.get('name','').strip(); cats=categories()
            if name:
                if old:
                    cats=[name if c==old else c for c in cats]; rows=templates()
                    for item in rows:
                        if item.get('category')==old: item['category']=name; item['updated_at']=now()
                    write(TEMPLATES,rows)
                elif name not in cats: cats.append(name)
                write(CATEGORIES,list(dict.fromkeys(cats)))
            return self.redirect('/categories')
        if u.path=='/category/delete':
            old=fields.get('old','').strip()
            if not any(x.get('category')==old for x in templates()): write(CATEGORIES,[c for c in categories() if c!=old])
            return self.redirect('/categories')
        return self.send_html(layout('<h1>Acción no válida</h1>'),404)
    def log_message(self,*args): pass

if __name__=='__main__':
    DATA.mkdir(parents=True,exist_ok=True); WORD_FILES.mkdir(parents=True,exist_ok=True)
    if not CATEGORIES.exists(): write(CATEGORIES,['CES','ProofPoint'])
    if not TEMPLATES.exists(): write(TEMPLATES,[])
    migrate_templates()
    ThreadingHTTPServer(('127.0.0.1',int(os.environ.get('CAMBIOS_PORT','8085'))),Handler).serve_forever()
