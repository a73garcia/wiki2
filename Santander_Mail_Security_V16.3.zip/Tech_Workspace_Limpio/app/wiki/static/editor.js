document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.copy-code').forEach(button => {
    button.addEventListener('click', async () => {
      const code = button.closest('.code-wrap').querySelector('code').innerText;
      await navigator.clipboard.writeText(code);
      const old = button.textContent;
      button.textContent = 'Copiado';
      setTimeout(() => button.textContent = old, 1200);
    });
  });


  document.querySelectorAll('.toggle-code').forEach(button => {
    button.addEventListener('click', () => {
      const wrapper = button.closest('.code-wrap');
      const box = wrapper?.querySelector('.code-box');
      if (!box) return;
      const collapsed = wrapper.classList.toggle('collapsed');
      box.hidden = collapsed;
      button.textContent = collapsed ? 'Expandir' : 'Contraer';
    });
  });

  const textarea = document.getElementById('content-editor') || document.getElementById('template-content-editor');
  if (!textarea) return;
  const fileInput = document.getElementById('image-file');
  const imageButton = document.getElementById('insert-image-button');
  const status = document.getElementById('image-upload-status');

  const insertAtCursor = (text, wrap = false) => {
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selected = textarea.value.slice(start, end);
    const value = wrap ? text + selected + text : text;
    textarea.setRangeText(value, start, end, 'end');
    textarea.focus();
  };

  document.querySelectorAll('[data-insert]').forEach(btn => btn.addEventListener('click', () => insertAtCursor(btn.dataset.insert)));
  document.querySelectorAll('[data-wrap]').forEach(btn => btn.addEventListener('click', () => insertAtCursor(btn.dataset.wrap, true)));
  document.querySelectorAll('[data-wrap-open]').forEach(btn => btn.addEventListener('click', () => {
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selected = textarea.value.slice(start, end);
    textarea.setRangeText((btn.dataset.wrapOpen || '') + selected + (btn.dataset.wrapClose || ''), start, end, 'end');
    textarea.focus();
  }));
  document.querySelectorAll('[data-notice]').forEach(btn => btn.addEventListener('click', () => {
    const labels = {advertencia: 'Escriba aquí la advertencia...', nota: 'Escriba aquí la nota...', informacion: 'Escriba aquí la información...'};
    const kind = btn.dataset.notice || 'nota';
    insertAtCursor(`\n\n!!! ${kind}:\n\n${labels[kind] || 'Escriba aquí...'}\n\n!!!\n\n`);
    const menu = btn.closest('details');
    if (menu) menu.open = false;
  }));

  document.querySelectorAll('[data-table]').forEach(btn => btn.addEventListener('click', () => {
    const type = btn.dataset.table || 'simple';
    let snippet = '';
    if (type === 'simple') {
      snippet = '\n\n| Columna 1 | Columna 2 | Columna 3 |\n| --- | --- | --- |\n| Dato 1 | Dato 2 | Dato 3 |\n| Dato 4 | Dato 5 | Dato 6 |\n\n';
    } else if (type === 'header') {
      snippet = '\n\n| Campo | Valor | Descripción |\n| --- | --- | --- |\n| Campo 1 | Valor 1 | Descripción 1 |\n| Campo 2 | Valor 2 | Descripción 2 |\n\n';
    } else if (type === 'checklist') {
      snippet = '\n\n| Comprobación | Estado | Observaciones |\n| --- | --- | --- |\n| Verificación 1 | Pendiente |  |\n| Verificación 2 | Pendiente |  |\n\n';
    } else if (type === 'double') {
      snippet = '\n\n| Elemento | Detalle |\n| --- | --- |\n| Elemento 1 | Detalle 1 |\n| Elemento 2 | Detalle 2 |\n\n';
    } else if (type === 'compare') {
      snippet = '\n\n| Característica | Opción A | Opción B | Recomendación |\n| --- | --- | --- | --- |\n| Rendimiento |  |  |  |\n| Seguridad |  |  |  |\n| Mantenimiento |  |  |  |\n\n';
    } else {
      const cols = Math.max(2, Math.min(8, Number(window.prompt('Número de columnas (2-8):', '3')) || 3));
      const rows = Math.max(1, Math.min(20, Number(window.prompt('Número de filas de datos (1-20):', '3')) || 3));
      const headers = Array.from({length: cols}, (_, i) => `Columna ${i + 1}`);
      const separator = Array(cols).fill('---');
      const bodyRows = Array.from({length: rows}, (_, r) => Array.from({length: cols}, (_, c) => `Dato ${r + 1}.${c + 1}`));
      snippet = '\n\n| ' + headers.join(' | ') + ' |\n| ' + separator.join(' | ') + ' |\n' + bodyRows.map(row => '| ' + row.join(' | ') + ' |').join('\n') + '\n\n';
    }
    insertAtCursor(snippet);
    textarea.dispatchEvent(new Event('input', {bubbles: true}));
    const menu = btn.closest('details');
    if (menu) menu.open = false;
  }));

  document.querySelectorAll('[data-columns]').forEach(btn => btn.addEventListener('click', () => {
    const layout = btn.dataset.columns || '50/50';
    let snippet;
    if (layout === '3') {
      snippet = '\n\n::: columns 3\n::: column\nContenido de la primera columna.\n::: column\nContenido de la segunda columna.\n::: column\nContenido de la tercera columna.\n::: endcolumns\n\n';
    } else {
      snippet = `\n\n::: columns ${layout}\n::: column\nContenido de la columna izquierda.\n::: column\nContenido de la columna derecha.\n::: endcolumns\n\n`;
    }
    insertAtCursor(snippet);
    textarea.dispatchEvent(new Event('input', {bubbles: true}));
    const menu = btn.closest('details');
    if (menu) menu.open = false;
  }));

  document.querySelectorAll('[data-code]').forEach(btn => btn.addEventListener('click', () => {
    insertAtCursor(`

\`\`\`${btn.dataset.code}

\`\`\`

`);
    const menu = btn.closest('details');
    if (menu) menu.open = false;
  }));

  document.querySelectorAll('[data-separator-text]').forEach(btn => btn.addEventListener('click', () => {
    insertAtCursor(`\n\n---[${btn.dataset.separatorText}]---\n\n`);
    const menu = btn.closest('details');
    if (menu) menu.open = false;
  }));

  document.querySelectorAll('[data-custom-separator]').forEach(btn => btn.addEventListener('click', () => {
    const text = window.prompt('Texto del separador:');
    if (!text || !text.trim()) return;
    insertAtCursor(`\n\n---[${text.trim().replace(/[\[\]\r\n]/g, '')}]---\n\n`);
    const menu = btn.closest('details');
    if (menu) menu.open = false;
  }));

  const changeIndentation = (remove = false) => {
    const value = textarea.value;
    const originalStart = textarea.selectionStart;
    const originalEnd = textarea.selectionEnd;
    const lineStart = value.lastIndexOf('\n', Math.max(0, originalStart - 1)) + 1;
    let lineEnd = value.indexOf('\n', originalEnd);
    if (lineEnd === -1) lineEnd = value.length;

    const block = value.slice(lineStart, lineEnd);
    const lines = block.split('\n');
    let removedFromFirstLine = 0;
    let totalDelta = 0;

    const changed = lines.map((line, index) => {
      if (!remove) {
        totalDelta += 4;
        return '    ' + line;
      }
      let count = 0;
      if (line.startsWith('\t')) count = 1;
      else {
        const match = line.match(/^ {1,4}/);
        count = match ? match[0].length : 0;
      }
      if (index === 0) removedFromFirstLine = count;
      totalDelta -= count;
      return line.slice(count);
    }).join('\n');

    textarea.setRangeText(changed, lineStart, lineEnd, 'select');
    if (!remove) {
      textarea.selectionStart = originalStart + 4;
      textarea.selectionEnd = originalEnd + (4 * lines.length);
    } else {
      textarea.selectionStart = Math.max(lineStart, originalStart - removedFromFirstLine);
      textarea.selectionEnd = Math.max(textarea.selectionStart, originalEnd + totalDelta);
    }
    textarea.focus();
    textarea.dispatchEvent(new Event('input', {bubbles: true}));
  };

  document.getElementById('indent-button')?.addEventListener('click', () => changeIndentation(false));
  document.getElementById('outdent-button')?.addEventListener('click', () => changeIndentation(true));

  textarea.addEventListener('keydown', event => {
    if (event.key !== 'Tab') return;
    event.preventDefault();
    changeIndentation(event.shiftKey);
  });

  async function uploadAndInsert(file) {
    if (!file || !file.type.startsWith('image/')) return;
    const cursor = textarea.selectionStart;
    status.textContent = 'Subiendo imagen…'; status.className = 'upload-status working';
    const form = new FormData(); form.append('image', file);
    try {
      const response = await fetch('/upload-image', {method:'POST', body:form});
      const result = await response.json();
      if (!response.ok || !result.ok) throw new Error(result.error || 'No se pudo subir la imagen.');
      const description = file.name.replace(/\.[^.]+$/, '').replace(/[-_]+/g, ' ');
      const snippet = `\n\n[[imagen:${result.filename}|${description}]]\n\n`;
      textarea.setRangeText(snippet, cursor, cursor, 'end'); textarea.focus();
      status.textContent = 'Imagen insertada.'; status.className = 'upload-status success';
    } catch (error) {
      status.textContent = error.message; status.className = 'upload-status error';
    }
  }

  imageButton?.addEventListener('click', () => { fileInput.value = ''; fileInput.click(); });
  fileInput?.addEventListener('change', () => uploadAndInsert(fileInput.files?.[0]));
  textarea.addEventListener('paste', event => {
    const image = [...(event.clipboardData?.items || [])].find(item => item.type.startsWith('image/'));
    if (image) { event.preventDefault(); uploadAndInsert(image.getAsFile()); }
  });
  textarea.addEventListener('dragover', event => { if ([...(event.dataTransfer?.files || [])].some(f => f.type.startsWith('image/'))) event.preventDefault(); });
  textarea.addEventListener('drop', event => {
    const image = [...(event.dataTransfer?.files || [])].find(f => f.type.startsWith('image/'));
    if (image) { event.preventDefault(); uploadAndInsert(image); }
  });

  const editorForm = textarea.closest('form');
  editorForm?.addEventListener('submit', event => {
    const lines = textarea.value.replace(/\r\n/g, '\n').split('\n');
    let openNotice = null;
    for (let index = 0; index < lines.length; index += 1) {
      const line = lines[index].trim();
      if (/^!!!\s+(?:advertencia|warning|nota|note|informaci[oó]n|information)\s*:/i.test(line)) {
        if (openNotice !== null) {
          event.preventDefault();
          window.alert(`Hay un aviso sin cerrar iniciado en la línea ${openNotice + 1}. Añada una línea con !!! antes de guardar.`);
          textarea.focus();
          return;
        }
        openNotice = index;
      } else if (line === '!!!' && openNotice !== null) {
        openNotice = null;
      }
    }
    if (openNotice !== null) {
      event.preventDefault();
      window.alert(`Hay un aviso sin cerrar iniciado en la línea ${openNotice + 1}. Añada una línea con !!! antes de guardar.`);
      textarea.focus();
    }
  });
});

// Adjuntos: selección múltiple y arrastrar/soltar en el editor.
document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('attachment-files');
  const zone = document.getElementById('attachment-dropzone');
  const list = document.getElementById('selected-attachments');
  if (!input || !zone || !list) return;
  const renderFiles = () => {
    const files = Array.from(input.files || []);
    if (!files.length) { list.textContent = 'Ningún archivo seleccionado.'; return; }
    const total = files.reduce((sum, f) => sum + f.size, 0);
    list.innerHTML = '<strong>' + files.length + ' archivo(s), ' + (total / 1024 / 1024).toFixed(2) + ' MB</strong><ul>' +
      files.map(f => '<li>' + f.name.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])) + '</li>').join('') + '</ul>';
  };
  input.addEventListener('change', renderFiles);
  ['dragenter','dragover'].forEach(type => zone.addEventListener(type, e => { e.preventDefault(); zone.classList.add('dragover'); }));
  ['dragleave','drop'].forEach(type => zone.addEventListener(type, e => { e.preventDefault(); zone.classList.remove('dragover'); }));
  zone.addEventListener('drop', e => {
    if (!e.dataTransfer || !e.dataTransfer.files.length) return;
    try { input.files = e.dataTransfer.files; renderFiles(); }
    catch (_) { /* Algunos navegadores no permiten asignar FileList; el selector normal sigue disponible. */ }
  });
});


// Sincroniza el título principal con la línea Title: del encabezado técnico.
document.addEventListener('DOMContentLoaded', () => {
  const titleInput = document.getElementById('editor-title');
  const textarea = document.getElementById('content-editor');
  if (!titleInput || !textarea) return;

  const syncDocumentTitle = () => {
    const title = titleInput.value.trim();
    const lines = textarea.value.replace(/\r\n/g, '\n').split('\n');
    let found = false;
    for (let i = 0; i < lines.length; i += 1) {
      if (/^\s*(?:Title|T[ií]tulo)\s*:/i.test(lines[i])) {
        lines[i] = 'Title: ' + (title ? '**' + title + '**' : '');
        found = true;
        break;
      }
    }
    if (!found && title) {
      const at = lines.length && /^\s*(?:Number|N[uú]mero)\s*:/i.test(lines[0]) ? 1 : 0;
      lines.splice(at, 0, 'Title: **' + title + '**');
    }
    const next = lines.join('\n');
    if (next !== textarea.value) {
      textarea.value = next;
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
    }
  };

  titleInput.addEventListener('input', syncDocumentTitle);
  titleInput.addEventListener('change', syncDocumentTitle);
  syncDocumentTitle();
});


// V13: herramientas avanzadas del editor, control de cambios y bloques plegables.
document.addEventListener('DOMContentLoaded', () => {
  const textarea = document.getElementById('content-editor') || document.getElementById('template-content-editor');
  if (textarea) {
    const form = textarea.closest('form');
    const saveState = document.getElementById('editor-save-state');
    const position = document.getElementById('editor-position');
    const counts = document.getElementById('editor-counts');
    const initialValue = textarea.value;
    let submitted = false;
    const lineNumbers = document.getElementById('editor-line-numbers');

    const updateLineNumbers = () => {
      if (!lineNumbers) return;
      const total = Math.max(1, textarea.value.split('\n').length);
      lineNumbers.textContent = Array.from({length: total}, (_, index) => String(index + 1)).join('\n');
      lineNumbers.scrollTop = textarea.scrollTop;
    };

    const lineColumn = () => {
      const before = textarea.value.slice(0, textarea.selectionStart);
      const lines = before.split('\n');
      return {line: lines.length, column: lines[lines.length - 1].length + 1};
    };

    const updateStatus = () => {
      const value = textarea.value;
      const words = (value.trim().match(/\S+/g) || []).length;
      const pos = lineColumn();
      if (counts) counts.textContent = `${words} palabras · ${value.length} caracteres`;
      if (position) position.textContent = `Línea ${pos.line}, columna ${pos.column}`;
      updateLineNumbers();
      if (saveState) {
        const dirty = value !== initialValue;
        saveState.textContent = dirty ? 'Cambios sin guardar' : 'Sin cambios';
        saveState.classList.toggle('dirty', dirty);
      }
    };

    const selectMatch = (query, from = textarea.selectionEnd) => {
      if (!query) return false;
      const source = textarea.value.toLocaleLowerCase();
      const needle = query.toLocaleLowerCase();
      let index = source.indexOf(needle, from);
      if (index < 0 && from > 0) index = source.indexOf(needle, 0);
      if (index < 0) return false;
      textarea.focus();
      textarea.setSelectionRange(index, index + query.length);
      const before = textarea.value.slice(0, index).split('\n').length;
      const lineHeight = parseFloat(getComputedStyle(textarea).lineHeight) || 20;
      textarea.scrollTop = Math.max(0, (before - 3) * lineHeight);
      updateStatus();
      return true;
    };

    document.getElementById('find-button')?.addEventListener('click', () => {
      const selected = textarea.value.slice(textarea.selectionStart, textarea.selectionEnd);
      const query = window.prompt('Texto que desea buscar:', selected);
      if (query === null || query === '') return;
      if (!selectMatch(query)) window.alert('No se encontró el texto indicado.');
    });

    document.getElementById('replace-button')?.addEventListener('click', () => {
      const selected = textarea.value.slice(textarea.selectionStart, textarea.selectionEnd);
      const query = window.prompt('Texto que desea buscar:', selected);
      if (query === null || query === '') return;
      const replacement = window.prompt('Reemplazar por:', '');
      if (replacement === null) return;
      const all = window.confirm('Aceptar: reemplazar todas las coincidencias.\nCancelar: reemplazar solo la siguiente.');
      if (all) {
        const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const next = textarea.value.replace(new RegExp(escaped, 'gi'), replacement);
        if (next === textarea.value) {
          window.alert('No se encontró el texto indicado.');
          return;
        }
        textarea.value = next;
        textarea.dispatchEvent(new Event('input', {bubbles: true}));
      } else if (selectMatch(query)) {
        textarea.setRangeText(replacement, textarea.selectionStart, textarea.selectionEnd, 'end');
        textarea.dispatchEvent(new Event('input', {bubbles: true}));
      } else {
        window.alert('No se encontró el texto indicado.');
      }
    });

    document.getElementById('goto-line-button')?.addEventListener('click', () => {
      const total = textarea.value.split('\n').length;
      const requested = Number(window.prompt(`Número de línea (1-${total}):`, '1'));
      if (!Number.isFinite(requested)) return;
      const line = Math.max(1, Math.min(total, Math.trunc(requested)));
      let index = 0;
      for (let n = 1; n < line; n += 1) {
        index = textarea.value.indexOf('\n', index) + 1;
      }
      textarea.focus();
      textarea.setSelectionRange(index, index);
      const lineHeight = parseFloat(getComputedStyle(textarea).lineHeight) || 20;
      textarea.scrollTop = Math.max(0, (line - 3) * lineHeight);
      updateStatus();
    });

    textarea.addEventListener('input', updateStatus);
    textarea.addEventListener('keyup', updateStatus);
    textarea.addEventListener('click', updateStatus);
    textarea.addEventListener('select', updateStatus);
    textarea.addEventListener('scroll', () => {
      if (lineNumbers) lineNumbers.scrollTop = textarea.scrollTop;
    });
    form?.addEventListener('submit', () => { submitted = true; });
    window.addEventListener('beforeunload', event => {
      if (!submitted && textarea.value !== initialValue) {
        event.preventDefault();
        event.returnValue = '';
      }
    });

    document.addEventListener('keydown', event => {
      if (!(event.ctrlKey || event.metaKey)) return;
      if (event.key.toLowerCase() === 'f' && document.activeElement === textarea) {
        event.preventDefault();
        document.getElementById('find-button')?.click();
      }
      if (event.key.toLowerCase() === 'h' && document.activeElement === textarea) {
        event.preventDefault();
        document.getElementById('replace-button')?.click();
      }
    });

    updateStatus();
    updateLineNumbers();
  }

  // V16.3: los bloques renderizados ya incluyen el botón .toggle-code.
  // No crear un segundo botón nativo (.collapse-code), que aparecía blanco
  // únicamente en la vista normal y duplicaba la acción Contraer/Expandir.
  document.querySelectorAll('.code-wrap').forEach(wrap => {
    const toggle = wrap.querySelector('.toggle-code');
    if (!toggle) return;
    toggle.setAttribute('aria-expanded', String(!wrap.classList.contains('collapsed')));
  });
});


// V14: inserción estructurada de títulos y tabulación consistente.
document.addEventListener('DOMContentLoaded', () => {
  const textarea = document.getElementById('content-editor') || document.getElementById('template-content-editor');
  if (!textarea) return;

  const emitInput = () => textarea.dispatchEvent(new Event('input', {bubbles: true}));

  document.querySelectorAll('[data-heading]').forEach(button => {
    button.addEventListener('click', () => {
      const level = Math.max(2, Math.min(6, Number(button.dataset.heading) || 2));
      const marks = '='.repeat(level);
      const value = textarea.value;
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const selected = value.slice(start, end).trim() || 'Título';

      const lineStart = value.lastIndexOf('\n', Math.max(0, start - 1)) + 1;
      let lineEnd = value.indexOf('\n', end);
      if (lineEnd < 0) lineEnd = value.length;

      const heading = `${marks} ${selected} ${marks}`;
      textarea.setRangeText(heading, lineStart, lineEnd, 'end');
      const titleStart = lineStart + marks.length + 1;
      textarea.setSelectionRange(titleStart, titleStart + selected.length);
      textarea.focus();
      emitInput();
    });
  });

  // Captura TAB incluso cuando otros componentes del navegador intentan cambiar el foco.
  textarea.addEventListener('keydown', event => {
    if (event.key !== 'Tab') return;
    event.preventDefault();
    event.stopImmediatePropagation();

    const value = textarea.value;
    const originalStart = textarea.selectionStart;
    const originalEnd = textarea.selectionEnd;
    const lineStart = value.lastIndexOf('\n', Math.max(0, originalStart - 1)) + 1;
    let lineEnd = value.indexOf('\n', originalEnd);
    if (lineEnd < 0) lineEnd = value.length;

    const lines = value.slice(lineStart, lineEnd).split('\n');
    let firstDelta = 0;
    let totalDelta = 0;

    const changed = lines.map((line, index) => {
      if (!event.shiftKey) {
        if (index === 0) firstDelta = 4;
        totalDelta += 4;
        return '    ' + line;
      }
      const match = line.match(/^(\t| {1,4})/);
      const count = match ? match[0].length : 0;
      if (index === 0) firstDelta = -count;
      totalDelta -= count;
      return line.slice(count);
    }).join('\n');

    textarea.setRangeText(changed, lineStart, lineEnd, 'select');
    textarea.selectionStart = Math.max(lineStart, originalStart + firstDelta);
    textarea.selectionEnd = Math.max(textarea.selectionStart, originalEnd + totalDelta);
    textarea.focus();
    emitInput();
  }, true);
});
