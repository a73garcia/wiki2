from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path
from datetime import datetime, date, timedelta
import html, io, json, os, shutil, tempfile, zipfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent
BACKUPS = ROOT / 'backups'
WIKI_PAGES = BASE/'wiki'/'data'/'pages'
PROJECTS = BASE/'gestor'/'data'/'projects.json'
TASKS = BASE/'gestor'/'data'/'tasks.json'
BAU = BASE/'bau'/'data'/'requests.json'
BITACORA = BASE/'bitacora'/'data'/'entries.json'
BIBLIOTECA = BASE/'biblioteca'/'data'/'snippets.json'
WIKI_URL=os.environ.get('WIKI_URL','http://127.0.0.1:8080'); GESTOR_URL=os.environ.get('GESTOR_URL','http://127.0.0.1:8081'); BAU_URL=os.environ.get('BAU_URL','http://127.0.0.1:8082'); BITACORA_URL=os.environ.get('BITACORA_URL','http://127.0.0.1:8083'); BIBLIOTECA_URL=os.environ.get('BIBLIOTECA_URL','http://127.0.0.1:8084')
TARGETS=[Path('app/wiki/data'),Path('app/gestor/data'),Path('app/bau/data'),Path('app/bitacora/data'),Path('app/biblioteca/data'),Path('imagenes')]

def read(path, default):
    try: return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default
    except Exception: return default

def pages():
    return [d for p in (WIKI_PAGES.glob('*.json') if WIKI_PAGES.exists() else []) if (d:=read(p,{}))]

def backup_bytes():
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('backup_manifest.json',json.dumps({'format':'Santander Mail Security Backup','version':1,'created':datetime.now().isoformat(timespec='seconds')},ensure_ascii=False,indent=2))
        for rel in TARGETS:
            base=ROOT/rel
            if base.exists():
                for f in base.rglob('*'):
                    if f.is_file() and '__pycache__' not in f.parts: z.write(f,f.relative_to(ROOT).as_posix())
    return buf.getvalue()

def valid_rel(name):
    rel=Path(name.replace('\\','/'))
    if rel.is_absolute() or '..' in rel.parts or not rel.parts: return None
    if rel.as_posix()=='backup_manifest.json': return rel
    return rel if any(rel==t or t in rel.parents for t in TARGETS) else None

def merge_json(src,dst):
    try: incoming=json.loads(src.read_text(encoding='utf-8'))
    except Exception: return
    if not dst.exists(): dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst); return
    try: current=json.loads(dst.read_text(encoding='utf-8'))
    except Exception: current=None
    if isinstance(current,list) and isinstance(incoming,list):
        def key(x):
            if isinstance(x,dict):
                for f in ('id','slug','number','title'):
                    if x.get(f) not in (None,''): return (f,str(x.get(f)))
            return ('raw',json.dumps(x,ensure_ascii=False,sort_keys=True))
        have={key(x) for x in current}; current.extend(x for x in incoming if key(x) not in have)
        dst.write_text(json.dumps(current,ensure_ascii=False,indent=2),encoding='utf-8')
    elif isinstance(current,dict) and isinstance(incoming,dict):
        merged=dict(incoming); merged.update(current); dst.write_text(json.dumps(merged,ensure_ascii=False,indent=2),encoding='utf-8')

def import_backup(raw,mode):
    if mode not in ('merge','replace'): return False,'Modo de importación no válido.'
    try: z=zipfile.ZipFile(io.BytesIO(raw),'r')
    except Exception: return False,'El archivo seleccionado no es un ZIP válido.'
    if 'backup_manifest.json' not in z.namelist(): return False,'El ZIP no es una copia exportada por Santander Mail Security.'
    files=[]
    for name in z.namelist():
        rel=valid_rel(name)
        if rel is None: return False,f'Ruta no permitida en la copia: {name}'
        if name!='backup_manifest.json' and not name.endswith('/'): files.append((name,rel))
    BACKUPS.mkdir(exist_ok=True)
    safety=BACKUPS/f'Santander_Mail_Security_Antes_Importar_{datetime.now():%Y-%m-%d_%H%M%S}.zip'
    safety.write_bytes(backup_bytes())
    with tempfile.TemporaryDirectory(prefix='tw_import_') as tmp:
        td=Path(tmp)
        for name,rel in files:
            out=td/rel; out.parent.mkdir(parents=True,exist_ok=True)
            with z.open(name) as a,out.open('wb') as b: shutil.copyfileobj(a,b)
        if mode=='replace':
            for rel in TARGETS:
                base=ROOT/rel
                if base.exists():
                    for child in base.iterdir():
                        if child.name=='LEEME.txt': continue
                        shutil.rmtree(child) if child.is_dir() else child.unlink()
        for _,rel in files:
            src,dst=td/rel,ROOT/rel; dst.parent.mkdir(parents=True,exist_ok=True)
            if mode=='merge' and dst.exists():
                if dst.suffix.lower()=='.json': merge_json(src,dst)
                continue
            shutil.copy2(src,dst)
    return True,f'Importación completada. Copia previa creada: {safety.name}'

def layout(body):
    links=[('Inicio','/'),('Wiki',WIKI_URL),('Proyectos y tareas',GESTOR_URL),('BAU',BAU_URL),('Bitácora',BITACORA_URL),('Biblioteca',BIBLIOTECA_URL)]
    nav=''.join(f'<a class="{"active" if n=="Inicio" else ""}" href="{html.escape(u,quote=True)}">{html.escape(n)}</a>' for n,u in links)
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Santander Mail Security v17.2</title><style>
*{{box-sizing:border-box}}body{{margin:0;font:14px Arial,sans-serif;color:#26384a;background:#f3f6f9}}header{{height:62px;background:#25364a;color:#fff;padding:0 24px;display:flex;justify-content:space-between;align-items:center}}.brand{{font-size:19px;font-weight:bold}}.shell{{display:grid;grid-template-columns:210px minmax(0,1fr);min-height:calc(100vh - 62px)}}aside{{background:#fff;border-right:1px solid #d9e1e8;padding:20px 14px}}aside nav a{{display:block;padding:10px 12px;color:#38516b;text-decoration:none;border-radius:5px;margin-bottom: 5px}}aside nav a.active,aside nav a:hover{{background:#FFF0F0;color:#B30000;font-weight:bold}}.aside-note{{margin:25px 10px;color:#7b8996;font-size:12px;line-height:1.6}}main{{padding:24px;max-width:1450px;width:100%;margin:0 auto}}.hero,.card{{background:white;border:1px solid #d9e1e8;border-radius:8px;padding:18px;box-shadow:0 1px 4px #0001}}.hero{{margin-bottom:16px}}.search{{display:flex;gap:8px}}input{{flex:1;padding:10px;border:1px solid #bfcbd6;border-radius:5px}}button,.btn{{padding:9px 13px;border:1px solid #bdcad5;border-radius:5px;background:#EC0000;color:white;text-decoration:none;cursor:pointer}}.secondary{{background:#596b7c}}.stats,.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px;margin:16px 0}}.stat strong{{font-size:28px;display:block}}.stat span,small,p{{color:#607080}}h2{{margin-top:0}}.result{{border-top:1px solid #e3e8ed;padding:14px 0}}.tag{{font-size:11px;background:#e8eef4;padding:3px 6px;border-radius:10px}}.backup{{margin-top:16px}}.actions{{display:flex;gap:10px;flex-wrap:wrap}}.notice{{padding:11px;margin:12px 0;background:#e9f6ec;border:1px solid #aed8b8;border-radius:5px;color:#245c31}}.pending-card{{margin:16px 0}}.pending-head{{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap}}.pending-head h2{{margin:0 0 4px}}.pending-summary{{display:grid;grid-template-columns:repeat(4,minmax(120px,1fr));gap:10px;margin:14px 0}}.pending-chip{{display:block;text-decoration:none;border:1px solid #d7e0e8;border-radius:7px;padding:10px;background:#f8fafc;color:#38516b}}.pending-chip strong{{font-size:20px;display:block;color:#24384d}}.pending-chip.overdue strong{{color:#b42318}}.pending-chip.today strong{{color:#b54708}}.pending-chip.week strong{{color:#9a6700}}.pending-filters{{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0 14px}}.pending-filter{{padding:6px 10px;border:1px solid #c7d2dc;border-radius:16px;text-decoration:none;color:#38516b;background:#fff;font-size:12px}}.pending-filter.active{{background:#EC0000;color:#fff;border-color:#EC0000}}.pending-table{{width:100%;border-collapse:collapse}}.pending-table th,.pending-table td{{padding:9px 8px;border-top:1px solid #e5ebf0;text-align:left;vertical-align:top}}.pending-table th{{font-size:12px;color:#607080;background:#f8fafc}}.pending-table a{{color:#B30000;text-decoration:none}}.pending-table .late{{color:#b42318;font-weight:bold}}.pending-table .today-label{{color:#b54708;font-weight:bold}}.pending-empty{{padding:18px;text-align:center;color:#607080}}.import-modal{{position:fixed;inset:0;z-index:1000;display:flex;align-items:center;justify-content:center;padding:20px;background:#16253599}}.import-modal[hidden]{{display:none}}.import-dialog{{width:min(620px,100%);max-height:90vh;overflow:auto;background:#fff;border:1px solid #b9c5cf;border-radius:10px;box-shadow:0 18px 55px #0005}}.import-dialog-head{{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:16px 18px;border-bottom:1px solid #dce3e9}}.import-dialog-head h2{{margin:0}}.import-close{{padding:4px 9px;background:#fff;color:#43586c;font-size:20px;line-height:1}}.import-dialog-body{{padding:18px}}.import-file-label{{display:block;font-weight:bold;color:#26384a}}.import-file-label input{{display:block;width:100%;margin-top:7px;background:#fff}}.import-mode-title{{display:block;margin:18px 0 8px;color:#26384a}}.import-option{{display:grid;grid-template-columns:auto 1fr;gap:10px;padding:12px;margin:8px 0;border:1px solid #ccd6df;border-radius:7px;background:#f9fbfc;cursor:pointer}}.import-option:has(input:checked){{border-color:#EC0000;background:#edf4fb}}.import-option input{{margin-top:3px}}.import-option strong{{display:block;color:#26384a;margin-bottom:3px}}.import-option small{{display:block;color:#607080;line-height:1.45}}.import-warning{{margin-top:10px;padding:9px 11px;border-left:4px solid #b54708;background:#fff5e8;color:#7a3b00}}.import-dialog-actions{{display:flex;justify-content:flex-end;gap:9px;padding:14px 18px;border-top:1px solid #dce3e9;background:#f8fafc}}.import-dialog-actions .cancel{{background:#fff;color:#38516b}}body.modal-open{{overflow:hidden}}@media(max-width:850px){{.shell{{grid-template-columns:1fr}}aside{{display:none}}.search{{display:block}}.search input{{width:100%;margin-bottom:8px}}.pending-summary{{grid-template-columns:repeat(2,1fr)}}.pending-table{{font-size:12px}}}}</style></head><body><header><div class="brand">Santander Mail Security</div></header><div class="shell"><aside><nav>{nav}</nav><div class="aside-note">Aplicación local<br>Sin usuarios<br>Datos en JSON</div></aside><main>{body}</main></div></body></html>'''

def backup_panel(message=''):
    notice=f'<div class="notice">{html.escape(message)}</div>' if message else ''
    return f'''<section class="card backup">
<h2>Copias de seguridad</h2>
<p>Exporta toda la información guardada o restaura una copia anterior.</p>
{notice}
<div id="import-status" class="notice" style="display:none"></div>
<div class="actions">
  <a class="btn" href="/backup/export">Exportar información</a>
  <button id="import-button" class="btn secondary" type="button">Importar información</button>
</div>
<p><small>Selecciona el archivo y el tipo de importación en la misma ventana.</small></p>
</section>

<div id="import-modal" class="import-modal" hidden aria-hidden="true">
  <section class="import-dialog" role="dialog" aria-modal="true" aria-labelledby="import-modal-title">
    <div class="import-dialog-head">
      <h2 id="import-modal-title">Importar copia de seguridad</h2>
      <button id="import-close" class="import-close" type="button" aria-label="Cerrar">×</button>
    </div>
    <div class="import-dialog-body">
      <label class="import-file-label">Archivo ZIP
        <input id="backup-file" type="file" accept=".zip,application/zip,application/x-zip-compressed">
      </label>
      <strong class="import-mode-title">Tipo de importación</strong>
      <label class="import-option">
        <input type="radio" name="import-mode" value="merge" checked>
        <span><strong>Combinar con los datos actuales</strong><small>Conserva la información existente y añade los registros de la copia que todavía no estén guardados.</small></span>
      </label>
      <label class="import-option">
        <input type="radio" name="import-mode" value="replace">
        <span><strong>Reemplazar todos los datos</strong><small>Elimina los datos actuales y los sustituye por el contenido de la copia importada.</small></span>
      </label>
      <div class="import-warning">Antes de reemplazar se crea automáticamente una copia de seguridad de los datos actuales.</div>
      <div id="modal-import-status" class="notice" style="display:none"></div>
    </div>
    <div class="import-dialog-actions">
      <button id="import-cancel" class="btn cancel" type="button">Cancelar</button>
      <button id="import-confirm" class="btn" type="button">Importar</button>
    </div>
  </section>
</div>

<script>
(function () {{
  const openButton = document.getElementById('import-button');
  const modal = document.getElementById('import-modal');
  const closeButton = document.getElementById('import-close');
  const cancelButton = document.getElementById('import-cancel');
  const confirmButton = document.getElementById('import-confirm');
  const fileInput = document.getElementById('backup-file');
  const pageStatus = document.getElementById('import-status');
  const modalStatus = document.getElementById('modal-import-status');

  function showStatus(target, message, isError) {{
    if (!target) return;
    target.style.display = 'block';
    target.style.background = isError ? '#fff0f0' : '#e9f6ec';
    target.style.borderColor = isError ? '#e0aaaa' : '#aed8b8';
    target.style.color = isError ? '#8b1e1e' : '#245c31';
    target.textContent = message;
  }}

  function clearModalStatus() {{
    if (!modalStatus) return;
    modalStatus.style.display = 'none';
    modalStatus.textContent = '';
  }}

  function openModal() {{
    clearModalStatus();
    fileInput.value = '';
    const merge = document.querySelector('input[name="import-mode"][value="merge"]');
    if (merge) merge.checked = true;
    modal.hidden = false;
    modal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('modal-open');
    setTimeout(() => fileInput.focus(), 0);
  }}

  function closeModal() {{
    if (confirmButton.disabled) return;
    modal.hidden = true;
    modal.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('modal-open');
    openButton.focus();
  }}

  openButton?.addEventListener('click', openModal);
  closeButton?.addEventListener('click', closeModal);
  cancelButton?.addEventListener('click', closeModal);

  modal?.addEventListener('click', event => {{
    if (event.target === modal) closeModal();
  }});

  document.addEventListener('keydown', event => {{
    if (event.key === 'Escape' && modal && !modal.hidden) closeModal();
  }});

  confirmButton?.addEventListener('click', async function () {{
    const file = fileInput.files && fileInput.files[0];
    if (!file) {{
      showStatus(modalStatus, 'Selecciona primero una copia de seguridad ZIP.', true);
      fileInput.focus();
      return;
    }}
    if (!file.name.toLowerCase().endsWith('.zip')) {{
      showStatus(modalStatus, 'El archivo seleccionado debe tener extensión .zip.', true);
      fileInput.focus();
      return;
    }}

    const selectedMode = document.querySelector('input[name="import-mode"]:checked');
    const mode = selectedMode ? selectedMode.value : 'merge';

    confirmButton.disabled = true;
    closeButton.disabled = true;
    cancelButton.disabled = true;
    showStatus(modalStatus, mode === 'replace'
      ? 'Creando copia previa y reemplazando los datos…'
      : 'Combinando la copia con los datos actuales…', false);

    try {{
      const response = await fetch('/backup/import?mode=' + encodeURIComponent(mode), {{
        method: 'POST',
        headers: {{'Content-Type': 'application/zip'}},
        body: file
      }});
      const resultHtml = await response.text();
      if (!response.ok) {{
        const plain = resultHtml.replace(/<[^>]+>/g, ' ').replace(/\\s+/g, ' ').trim();
        throw new Error(plain || 'No se pudo importar la copia.');
      }}
      document.open();
      document.write(resultHtml);
      document.close();
    }} catch (error) {{
      showStatus(modalStatus, error && error.message ? error.message : 'Error inesperado durante la importación.', true);
      showStatus(pageStatus, 'La importación no pudo completarse.', true);
      confirmButton.disabled = false;
      closeButton.disabled = false;
      cancelButton.disabled = false;
    }}
  }});
}})();
</script>'''
def parse_day(value):
    value=str(value or '').strip()
    if not value:
        return None
    try:
        return date.fromisoformat(value[:10])
    except ValueError:
        return None

def wiki_header(content, key):
    aliases={
        'status':{'status','estado'},
        'title':{'title','titulo','título'},
        'number':{'number','numero','número'},
        'owner':{'owner','responsable','asignado','assigned to'},
    }
    wanted=aliases.get(key,{key.casefold()})
    for line in str(content or '').splitlines()[:20]:
        if ':' not in line:
            continue
        field,value=line.split(':',1)
        if field.strip().casefold() in wanted:
            return value.strip().strip('*')
    return ''

def pending_items():
    today=date.today()
    items=[]
    project_map={str(p.get('id','')):p for p in read(PROJECTS,[])}
    for t in read(TASKS,[]):
        status=str(t.get('status','')).strip()
        if status in ('Completada','Cancelada'):
            continue
        project=project_map.get(str(t.get('project_id','')),{}).get('name','')
        items.append({
            'kind':'Tarea','ref':project,
            'title':t.get('title') or 'Tarea sin título',
            'owner':t.get('owner',''),
            'status':status or 'Pendiente','due':parse_day(t.get('due_date')),
            'url':f'{GESTOR_URL}/task/edit?id={t.get("id","")}'
        })
    for p in read(PROJECTS,[]):
        status=str(p.get('status','')).strip()
        if status in ('Finalizado','Cancelado'):
            continue
        items.append({
            'kind':'Proyecto','ref':'',
            'title':p.get('name') or 'Proyecto sin título',
            'owner':p.get('owner',''),
            'status':status or 'Planificado','due':parse_day(p.get('end_date')),
            'url':f'{GESTOR_URL}/project?id={p.get("id","")}'
        })
    for r in read(BAU,[]):
        status=str(r.get('status','')).strip()
        if status in ('Resuelta','Cerrada'):
            continue
        items.append({
            'kind':'BAU','ref':r.get('number',''),
            'title':r.get('title') or 'BAU sin título',
            'owner':r.get('owner') or r.get('responsible') or r.get('responsable') or r.get('assigned_to') or '',
            'status':status or 'Nueva',
            'due':parse_day(r.get('due_date') or r.get('resolution_date')),
            'url':f'{BAU_URL}/view?id={r.get("id","")}'
        })
    pending_statuses={'draft','borrador','in review','en revisión','en revision','obsolete','obsoleto'}
    shown_status={'draft':'Draft','borrador':'Borrador','in review':'In review','en revisión':'En revisión','en revision':'En revisión','obsolete':'Obsolete','obsoleto':'Obsoleto'}
    for d in pages():
        raw=wiki_header(d.get('content',''),'status').casefold()
        if raw not in pending_statuses:
            continue
        items.append({
            'kind':'Wiki','ref':wiki_header(d.get('content',''),'number'),
            'title':d.get('title') or wiki_header(d.get('content',''),'title') or 'Documento sin título',
            'owner':wiki_header(d.get('content',''),'owner'),
            'status':shown_status.get(raw,raw.title()),'due':None,
            'url':f'{WIKI_URL}/wiki/{d.get("slug","")}'
        })
    def rank(item):
        due=item['due']
        if due is None:
            return (3,date.max,item['kind'],str(item['title']).casefold())
        if due < today:
            return (0,due,item['kind'],str(item['title']).casefold())
        if due == today:
            return (1,due,item['kind'],str(item['title']).casefold())
        return (2,due,item['kind'],str(item['title']).casefold())
    items.sort(key=rank)
    return items

def pending_panel(filter_name='all'):
    today=date.today()
    end_week=today+timedelta(days=7)
    items=pending_items()
    counts={
        'overdue':sum(1 for x in items if x['due'] and x['due']<today),
        'today':sum(1 for x in items if x['due']==today),
        'week':sum(1 for x in items if x['due'] and today<x['due']<=end_week),
        'nodate':sum(1 for x in items if x['due'] is None),
    }
    if filter_name not in {'all','overdue','today','week','nodate'}:
        filter_name='all'
    def matches(item):
        if filter_name=='all': return True
        if filter_name=='overdue': return bool(item['due'] and item['due']<today)
        if filter_name=='today': return item['due']==today
        if filter_name=='week': return bool(item['due'] and today<item['due']<=end_week)
        return item['due'] is None
    shown=[x for x in items if matches(x)]
    labels=[('all','Todos',len(items)),('overdue','Vencidos',counts['overdue']),('today','Hoy',counts['today']),('week','7 días',counts['week']),('nodate','Sin fecha',counts['nodate'])]
    filters=''.join(
        f'<a class="pending-filter {"active" if key==filter_name else ""}" href="/?pending={key}">{html.escape(label)} · {amount}</a>'
        for key,label,amount in labels
    )
    rows=[]
    for item in shown[:20]:
        due=item['due']
        if due is None:
            due_html='Sin fecha'
        elif due<today:
            due_html=f'<span class="late">Vencido · {due.strftime("%d/%m/%Y")}</span>'
        elif due==today:
            due_html='<span class="today-label">Hoy</span>'
        else:
            due_html=due.strftime('%d/%m/%Y')
        reference_html=html.escape(str(item.get("ref") or ""))
        owner_html=html.escape(str(item.get("owner") or ""))
        rows.append(
            f'<tr><td><span class="tag">{html.escape(item["kind"])}</span></td>'
            f'<td>{reference_html}</td>'
            f'<td><a href="{html.escape(item["url"],quote=True)}"><strong>{html.escape(str(item["title"]))}</strong></a></td>'
            f'<td>{owner_html}</td>'
            f'<td>{html.escape(str(item["status"]))}</td><td>{due_html}</td></tr>'
        )
    if rows:
        table='<div style="overflow:auto"><table class="pending-table"><thead><tr><th>Tipo</th><th>Referencia</th><th>Pendiente</th><th>Responsable</th><th>Estado</th><th>Fecha</th></tr></thead><tbody>'+''.join(rows)+'</tbody></table></div>'
    else:
        table='<div class="pending-empty">No hay elementos pendientes en este filtro.</div>'
    extra=f'<p><small>Mostrando los primeros 20 de {len(shown)} pendientes.</small></p>' if len(shown)>20 else ''
    return (
        '<section class="card pending-card">'
        '<div class="pending-head"><div><h2>Pendientes</h2><p>Resumen de elementos que todavía requieren atención.</p></div>'
        f'<strong>{len(items)} en total</strong></div>'
        '<div class="pending-summary">'
        f'<a class="pending-chip overdue" href="/?pending=overdue"><strong>{counts["overdue"]}</strong>Vencidos</a>'
        f'<a class="pending-chip today" href="/?pending=today"><strong>{counts["today"]}</strong>Para hoy</a>'
        f'<a class="pending-chip week" href="/?pending=week"><strong>{counts["week"]}</strong>Próximos 7 días</a>'
        f'<a class="pending-chip" href="/?pending=nodate"><strong>{counts["nodate"]}</strong>Sin fecha</a>'
        f'</div><div class="pending-filters">{filters}</div>{table}{extra}</section>'
    )

def home(pending_filter='all'):
    ps=read(PROJECTS,[]); ts=read(TASKS,[]); docs=pages(); bau=read(BAU,[]); bit=read(BITACORA,[]); bib=read(BIBLIOTECA,[]); pending=[t for t in ts if t.get('status') not in ('Completada','Cancelada')]
    searchbox='<div class="hero"><h2>Buscador global</h2><form class="search" action="/search"><input name="q" placeholder="Buscar en todo el espacio de trabajo"><button>Buscar</button></form></div>'
    stats=f'<div class="stats"><div class="card stat"><strong>{len(docs)}</strong><span>Documentos Wiki</span></div><div class="card stat"><strong>{len(ps)}</strong><span>Proyectos</span></div><div class="card stat"><strong>{len(pending)}</strong><span>Tareas pendientes</span></div><div class="card stat"><strong>{len(bau)}</strong><span>Registros BAU</span></div><div class="card stat"><strong>{len(bit)}</strong><span>Entradas Bitácora</span></div><div class="card stat"><strong>{len(bib)}</strong><span>Fragmentos técnicos</span></div></div>'
    return layout(searchbox+pending_panel(pending_filter)+stats+backup_panel())

def search(q):
    term=q.strip().casefold(); results=[]
    if term:
        for d in pages():
            if term in ' '.join([d.get('title',''),d.get('category',''),d.get('content',''),' '.join(d.get('tags',[]))]).casefold(): results.append(('Documento',d.get('title',''),f'{WIKI_URL}/wiki/{d.get("slug","")}',d.get('category','')))
        for p in read(PROJECTS,[]):
            if term in json.dumps(p,ensure_ascii=False).casefold(): results.append(('Proyecto',p.get('name',''),f'{GESTOR_URL}/project?id={p.get("id","")}',p.get('status','')))
        for t in read(TASKS,[]):
            if term in json.dumps(t,ensure_ascii=False).casefold(): results.append(('Tarea',t.get('title',''),f'{GESTOR_URL}/task/edit?id={t.get("id","")}',t.get('status','')))
        for r in read(BAU,[]):
            if term in json.dumps(r,ensure_ascii=False).casefold(): results.append(('BAU',f'{r.get("number","")} · {r.get("title","")}',f'{BAU_URL}/view?id={r.get("id","")}',r.get('status','')))
        for r in read(BITACORA,[]):
            if term in json.dumps(r,ensure_ascii=False).casefold(): results.append(('Bitácora',r.get('title',''),f'{BITACORA_URL}/view?id={r.get("id","")}',r.get('group','')))
        for r in read(BIBLIOTECA,[]):
            if term in json.dumps(r,ensure_ascii=False).casefold(): results.append(('Biblioteca',r.get('title',''),f'{BIBLIOTECA_URL}/view?id={r.get("id","")}',r.get('category','')))
    rows=''.join(f'<div class="result"><span class="tag">{html.escape(k)}</span> <a href="{html.escape(u,quote=True)}"><strong>{html.escape(title)}</strong></a><p>{html.escape(str(meta))}</p></div>' for k,title,u,meta in results) or '<p>No se encontraron coincidencias.</p>'
    return layout(f'<div class="hero"><h2>Resultados para “{html.escape(q)}”</h2><form class="search" action="/search"><input name="q" value="{html.escape(q,quote=True)}"><button>Buscar</button></form></div><section class="card">{rows}</section>')

class Handler(BaseHTTPRequestHandler):
    def send_html(self,body,status=200):
        data=body.encode('utf-8'); self.send_response(status); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        u=urlparse(self.path)
        if u.path=='/backup/export':
            data=backup_bytes(); name=f'Santander_Mail_Security_Backup_{datetime.now():%Y-%m-%d_%H%M}.zip'; self.send_response(200); self.send_header('Content-Type','application/zip'); self.send_header('Content-Disposition',f'attachment; filename="{name}"'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        qs=parse_qs(u.query); q=qs.get('q',[''])[0]; self.send_html(search(q) if u.path=='/search' else home(qs.get('pending',['all'])[0]))
    def do_POST(self):
        u=urlparse(self.path)
        if u.path!='/backup/import': self.send_html(layout('<section class="card"><h2>Ruta no encontrada</h2></section>'),404); return
        try: length=int(self.headers.get('Content-Length','0'))
        except ValueError: length=0
        if length<=0 or length>500*1024*1024: self.send_html(layout(backup_panel('Archivo vacío o demasiado grande.')),400); return
        ok,msg=import_backup(self.rfile.read(length),parse_qs(u.query).get('mode',['merge'])[0]); self.send_html(layout(backup_panel(msg)),200 if ok else 400)
    def log_message(self,*args): pass

if __name__=='__main__': ThreadingHTTPServer(('127.0.0.1',int(os.environ.get('PORTAL_PORT','8079'))),Handler).serve_forever()
