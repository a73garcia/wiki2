from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from email.parser import BytesParser
from email.policy import default as email_policy
import mimetypes, re
from pathlib import Path
from datetime import date, datetime
import json, os, html, uuid

BASE=Path(__file__).resolve().parent
DATA=BASE/'data'; STATIC=BASE/'static'
PROJECTS=DATA/'projects.json'; TASKS=DATA/'tasks.json'; RESPONSIBLES=DATA/'responsibles.json'; ATTACHMENTS=DATA/'attachments'
DATA.mkdir(exist_ok=True); STATIC.mkdir(exist_ok=True); ATTACHMENTS.mkdir(exist_ok=True)
WIKI_URL=os.environ.get('WIKI_URL','http://127.0.0.1:8080')
PORTAL_URL=os.environ.get('PORTAL_URL','http://127.0.0.1:8079')
BAU_URL=os.environ.get('BAU_URL','http://127.0.0.1:8082')
BITACORA_URL=os.environ.get('BITACORA_URL','http://127.0.0.1:8083')
BIBLIOTECA_URL=os.environ.get('BIBLIOTECA_URL','http://127.0.0.1:8084')
WIKI_PAGES=BASE.parent/'wiki'/'data'/'pages'

def read_json(path, default):
    try: return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default
    except Exception: return default

def write_json(path, value):
    tmp=path.with_suffix('.tmp'); tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(path)

def esc(v): return html.escape(str(v or ''), quote=True)
def now(): return datetime.now().isoformat(timespec='seconds')
def uid(prefix): return prefix+'_'+uuid.uuid4().hex[:10]
def projects(): return read_json(PROJECTS, [])
def tasks(): return read_json(TASKS, [])
def responsibles(): return read_json(RESPONSIBLES, [])

def field_values(form, name):
    value=form.get(name, [])
    if isinstance(value, list): return [str(x) for x in value if str(x).strip()]
    return [str(value)] if str(value or '').strip() else []

def selected_responsibles(item):
    ids=item.get('responsible_ids', [])
    if isinstance(ids, str): ids=[ids] if ids else []
    if not ids and item.get('owner'):
        owner=str(item.get('owner')).strip().lower()
        ids=[r['id'] for r in responsibles() if str(r.get('name','')).strip().lower()==owner]
    return ids

def responsible_names(item):
    selected=set(selected_responsibles(item)); people=responsibles()
    names=[r.get('name','') for r in people if r.get('id') in selected]
    if not names and item.get('owner'): names=[item.get('owner')]
    return [n for n in names if n]

def responsibles_badges(item):
    names=responsible_names(item)
    return ''.join(f'<span class="person-chip">{esc(n)}</span>' for n in names) or '<span class="muted">Sin asignar</span>'

def responsible_options(selected=None):
    chosen=set(selected or [])
    return ''.join(f'<option value="{esc(r.get("id"))}" {"selected" if r.get("id") in chosen else ""}>{esc(r.get("name"))}</option>' for r in sorted(responsibles(),key=lambda x:x.get('name','').lower()))

def responsible_checkboxes(selected=None):
    chosen=set(selected or [])
    people=sorted(responsibles(),key=lambda x:x.get('name','').lower())
    if not people:
        return '<div class="responsible-empty">No hay responsables creados.</div>'
    return ''.join(
        f'<label class="responsible-check"><input type="checkbox" name="responsible_ids" value="{esc(r.get("id"))}" {"checked" if r.get("id") in chosen else ""}><span>{esc(r.get("name"))}</span></label>'
        for r in people
    )


def safe_filename(name):
    name=Path(str(name or 'archivo')).name
    clean=re.sub(r'[^A-Za-z0-9._-]+','_',name).strip('._') or 'archivo'
    return clean[:140]

def save_upload(filename, content):
    original=safe_filename(filename)
    stored=uuid.uuid4().hex[:12]+'_'+original
    (ATTACHMENTS/stored).write_bytes(content)
    return {'name':original,'file':stored}

def delete_uploads(items):
    for item in items or []:
        stored=item.get('file','') if isinstance(item,dict) else ''
        if stored:
            try: (ATTACHMENTS/stored).unlink(missing_ok=True)
            except Exception: pass

def normalize_url(value):
    value=str(value or '').strip()
    if value and not value.lower().startswith(('http://','https://','file://')):
        value='https://'+value
    return value

def parse_links(text):
    links=[]
    for raw in str(text or '').splitlines():
        raw=raw.strip()
        if not raw: continue
        if '|' in raw:
            title,url=[x.strip() for x in raw.split('|',1)]
        else:
            title,url=raw,raw
        url=normalize_url(url)
        if url: links.append({'title':title or url,'url':url})
    return links

def attachments_html(items):
    if not items: return ''
    rows=''.join(f'<li><a href="/attachments/{esc(a.get("file"))}" download="{esc(a.get("name"))}">📎 {esc(a.get("name"))}</a></li>' for a in items)
    return f'<ul class="attachment-list">{rows}</ul>'

def links_html(items):
    if not items: return ''
    rows=''.join(f'<li><a href="{esc(a.get("url"))}" target="_blank" rel="noopener">🔗 {esc(a.get("title") or a.get("url"))}</a></li>' for a in items)
    return f'<ul class="attachment-list">{rows}</ul>'

def layout(title, body, active='dashboard'):
    main_links=[('Inicio',PORTAL_URL),('Wiki',WIKI_URL),('Proyectos y tareas','/'),('BAU',BAU_URL),('Bitácora',BITACORA_URL),('Biblioteca',BIBLIOTECA_URL)]
    nav=''.join(f'<a class="{"active" if n=="Proyectos y tareas" else ""}" href="{esc(u)}">{esc(n)}</a>' for n,u in main_links)
    tabs=[('dashboard','Resumen','/'),('projects','Proyectos','/projects'),('tasks','Tareas','/tasks'),('responsibles','Responsables','/responsibles'),('calendar','Calendario','/calendar')]
    module_nav='<div class="module-tabs">'+''.join(f'<a class="{"active" if active==k else ""}" href="{u}">{esc(label)}</a>' for k,label,u in tabs)+'</div>'
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)} · Proyectos</title><link rel="stylesheet" href="/static/style.css"></head><body><header><div class="brand">Santander Mail Security · Proyectos</div><div class="header-actions"><a class="btn" href="{esc(PORTAL_URL)}">Inicio común</a><a class="btn primary" href="/project/new">+ Nuevo proyecto</a><a class="btn" href="/task/new">+ Nueva tarea</a></div></header><div class="shell"><aside><nav>{nav}</nav><div class="aside-note">Aplicación local<br>Sin usuarios<br>Datos en JSON</div></aside><main>{module_nav}{body}</main></div><script src="/static/app.js"></script></body></html>'''

def badge(value, kind='status'):
    key=str(value or '').lower().replace(' ','-').replace('ó','o').replace('í','i')
    return f'<span class="badge {kind}-{esc(key)}">{esc(value)}</span>'

def dashboard():
    ps=projects(); ts=tasks(); today=date.today().isoformat()
    active=[p for p in ps if p.get('status') not in ('Finalizado','Cancelado')]
    pending=[t for t in ts if t.get('status') not in ('Completada','Cancelada')]
    overdue=[t for t in pending if t.get('due_date') and t['due_date']<today]
    done=len([t for t in ts if t.get('status')=='Completada'])
    cards=f'''<div class="stats"><div><strong>{len(active)}</strong><span>Proyectos activos</span></div><div><strong>{len(pending)}</strong><span>Tareas pendientes</span></div><div><strong>{len(overdue)}</strong><span>Tareas vencidas</span></div><div><strong>{done}</strong><span>Tareas completadas</span></div></div>'''
    recent=sorted(ps,key=lambda x:x.get('updated',''),reverse=True)[:6]
    plist=''.join(project_card(p, compact=True) for p in recent) or '<p class="empty">Todavía no hay proyectos.</p>'
    upcoming=sorted([t for t in pending if t.get('due_date')],key=lambda x:x['due_date'])[:8]
    rows=''.join(task_row(t,ps) for t in upcoming) or '<tr><td colspan="6" class="empty">No hay tareas próximas.</td></tr>'
    body=f'''<div class="page-head"><div><h1>Panel principal</h1><p>Resumen general del trabajo pendiente y los proyectos en curso.</p></div></div>{cards}<section><div class="section-head"><h2>Proyectos recientes</h2><a href="/projects">Ver todos</a></div><div class="project-grid">{plist}</div></section><section><div class="section-head"><h2>Próximas tareas</h2><a href="/tasks">Ver todas</a></div><div class="table-wrap"><table><thead><tr><th>Tarea</th><th>Proyecto</th><th>Responsables</th><th>Estado</th><th>Prioridad</th><th>Vence</th></tr></thead><tbody>{rows}</tbody></table></div></section>'''
    return layout('Inicio',body)

def project_card(p, compact=False):
    progress=int(p.get('progress',0) or 0)
    return f'''<article class="project-card"><div class="card-top"><h3><a href="/project?id={esc(p['id'])}">{esc(p.get('name'))}</a></h3>{badge(p.get('status','Planificado'))}</div><p>{esc(p.get('description','Sin descripción'))}</p><div class="progress"><span style="width:{progress}%"></span></div><div class="card-meta"><span>{progress}%</span><span>{esc(p.get('start_date',''))} → {esc(p.get('end_date',''))}</span></div><div class="card-people">{responsibles_badges(p)}</div></article>'''

def project_list(query=None):
    query=query or {}; ps=projects(); responsible=query.get('responsible',[''])[0]
    if responsible: ps=[p for p in ps if responsible in selected_responsibles(p)]
    q=''.join(project_card(p) for p in sorted(ps,key=lambda x:x.get('updated',''),reverse=True)) or '<p class="empty">No hay proyectos que mostrar.</p>'
    ropts=''.join(f'<option value="{esc(r["id"])}" {"selected" if responsible==r["id"] else ""}>{esc(r["name"])}</option>' for r in sorted(responsibles(),key=lambda x:x.get('name','').lower()))
    filters=f'<form class="filters"><select name="responsible"><option value="">Todos los responsables</option>{ropts}</select><button class="btn">Filtrar</button><a class="btn" href="/projects">Limpiar</a></form>'
    return layout('Proyectos',f'<div class="page-head"><div><h1>Proyectos</h1><p>Consulta el estado, avance, fechas y responsables de cada proyecto.</p></div><a class="btn primary" href="/project/new">Nuevo proyecto</a></div>{filters}<div class="project-grid">{q}</div>','projects')

def project_form(p=None):
    p=p or {}; edit=bool(p)
    statuses=['Planificado','En curso','En pausa','Finalizado','Cancelado']; priorities=['Baja','Media','Alta','Crítica']
    opts=lambda values,current: ''.join(f'<option {"selected" if v==current else ""}>{v}</option>' for v in values)
    body=f'''<div class="page-head"><div><h1>{'Editar' if edit else 'Nuevo'} proyecto</h1><p>Información principal y planificación del proyecto.</p></div></div><form class="form-card project-form" method="post" action="/project/save"><input type="hidden" name="id" value="{esc(p.get('id',''))}"><label class="project-name">Nombre<input required name="name" value="{esc(p.get('name',''))}"></label><div class="project-main"><label class="project-description">Descripción<textarea name="description" rows="16">{esc(p.get('description',''))}</textarea></label><div class="project-options"><label class="project-status">Estado<select name="status">{opts(statuses,p.get('status','Planificado'))}</select></label><label class="project-priority">Prioridad<select name="priority">{opts(priorities,p.get('priority','Media'))}</select></label><label class="project-progress">Avance (%)<input type="number" min="0" max="100" name="progress" value="{esc(p.get('progress',0))}"></label><label class="project-start">Fecha de inicio<input type="date" name="start_date" value="{esc(p.get('start_date',''))}"></label><label class="project-end">Fecha prevista de fin<input type="date" name="end_date" value="{esc(p.get('end_date',''))}"></label><div class="project-responsibles"><div class="field-title">Responsables <span class="field-help">Selecciona o deselecciona uno o varios</span></div><div class="responsible-checklist">{responsible_checkboxes(selected_responsibles(p))}</div><div class="responsible-count" data-responsible-count>0 seleccionados</div></div></div></div><div class="form-actions"><button class="btn primary">Guardar proyecto</button><a class="btn" href="/projects">Cancelar</a></div></form>'''
    return layout('Proyecto',body,'projects')

def project_report(pid):
    p=next((x for x in projects() if x.get('id')==pid),None)
    if not p: return layout('No encontrado','<h1>Proyecto no encontrado</h1>','projects')
    pts=[t for t in tasks() if t.get('project_id')==pid]
    progress=max(0,min(100,int(p.get('progress',0) or 0)))
    names=', '.join(responsible_names(p)) or 'Sin asignar'
    counts={s:sum(1 for t in pts if t.get('status')==s) for s in ['Pendiente','En curso','Bloqueada','Completada','Cancelada']}
    task_rows=''.join(f'''<tr><td>{esc(t.get('title'))}</td><td>{esc(t.get('status'))}</td><td>{esc(t.get('priority'))}</td><td>{esc(', '.join(responsible_names(t)) or 'Sin asignar')}</td><td>{esc(t.get('start_date') or '—')}</td><td>{esc(t.get('due_date') or '—')}</td><td>{esc(t.get('comments') or '')}</td></tr>''' for t in sorted(pts,key=lambda x:(x.get('due_date') or '9999',x.get('title','')))) or '<tr><td colspan="7">No hay tareas asociadas.</td></tr>'
    history=''.join(f'''<div class="follow"><strong>{esc(h.get('date'))}</strong><p>{esc(h.get('text'))}</p>{links_html(h.get('links',[]))}{attachments_html(h.get('attachments',[]))}</div>''' for h in reversed(p.get('history',[]))) or '<p>No hay seguimientos registrados.</p>'
    summary=f'''Proyecto al {progress} %. {len(pts)} tareas: {counts['Completada']} completadas, {counts['En curso']} en curso, {counts['Pendiente']} pendientes y {counts['Bloqueada']} bloqueadas.'''
    report_content=f'''<div class="project-header"><div class="brandline">Santander Mail Security · Informe de proyecto</div><h1>{esc(p.get('name'))}</h1><p class="summary">{esc(summary)}</p><table class="facts"><tr><th>Estado</th><td>{esc(p.get('status'))}</td><th>Prioridad</th><td>{esc(p.get('priority'))}</td></tr><tr><th>Responsables</th><td colspan="3">{esc(names)}</td></tr><tr><th>Inicio</th><td>{esc(p.get('start_date') or '—')}</td><th>Fin previsto</th><td>{esc(p.get('end_date') or '—')}</td></tr><tr><th>Progreso</th><td colspan="3">{progress} %</td></tr></table></div><h2>Descripción</h2><p>{esc(p.get('description') or 'Sin descripción')}</p><h2>Tareas</h2><table><thead><tr><th>Tarea</th><th>Estado</th><th>Prioridad</th><th>Responsables</th><th>Inicio</th><th>Vence</th><th>Comentarios</th></tr></thead><tbody>{task_rows}</tbody></table><h2>Historial de seguimiento</h2>{history}<div class="report-footer">Generado el {datetime.now().strftime('%d/%m/%Y %H:%M')} desde Santander Mail Security</div>'''
    page=f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(p.get('name'))} · Informe</title><style>body{{margin:0;background:#f4f5f7;font-family:Arial,Helvetica,sans-serif;color:#222}}.toolbar{{position:sticky;top:0;z-index:4;background:#fff;border-bottom:1px solid #ddd;padding:12px 18px;display:flex;gap:8px;align-items:center;flex-wrap:wrap}}button,a.btn{{border:1px solid #ccc;background:#fff;padding:9px 13px;border-radius:5px;text-decoration:none;color:#222;font-weight:600;cursor:pointer}}button.primary{{background:#ec0000;color:#fff;border-color:#ec0000}}#status{{font-size:13px;color:#555}}.sheet{{width:680px;max-width:calc(100% - 48px);margin:24px auto;background:#fff;padding:28px 34px;box-sizing:border-box;box-shadow:0 2px 12px #0002}}.brandline{{color:#ec0000;font-weight:700;border-bottom:3px solid #ec0000;padding-bottom:9px}}h1{{color:#ec0000;font-size:24px}}h2{{font-size:18px;margin-top:26px}}.summary{{font-weight:700;background:#fff5f5;border-left:4px solid #ec0000;padding:12px}}table{{border-collapse:collapse;width:100%;font-size:12px;margin:10px 0}}th,td{{border:1px solid #bbb;padding:7px;vertical-align:top;text-align:left}}th{{background:#f1f1f1}}.project-header{{min-height:260px;box-sizing:border-box}}.facts{{height:160px;table-layout:fixed}}.facts th{{width:17%}}.facts td{{width:33%}}.follow{{border-left:3px solid #ec0000;padding:2px 0 8px 12px;margin:12px 0}}.follow p{{white-space:pre-wrap}}.attachment-list{{margin:5px 0}}.report-footer{{margin-top:30px;border-top:1px solid #ddd;padding-top:10px;color:#777;font-size:11px}}@page{{size:A4 portrait;margin:12mm}}@media print{{.toolbar{{display:none}}body{{background:#fff}}.sheet{{box-shadow:none;margin:0;max-width:none;padding:0;width:auto}}table{{font-size:9px;table-layout:fixed}}th,td{{padding:4px;overflow-wrap:anywhere;word-break:break-word}}h1{{font-size:20px}}h2{{font-size:15px;margin-top:18px}}}}</style></head><body><div class="toolbar"><a class="btn" href="/project?id={esc(pid)}">← Volver al proyecto</a><button class="primary" onclick="copyRich()">📋 Copiar para Outlook / Teams</button><button onclick="copyText()">Copiar texto</button><button onclick="window.print()">Imprimir / Guardar PDF</button><span id="status"></span></div><div class="sheet"><div id="report-content">{report_content}</div></div><script>const st=document.getElementById('status');function done(m){{st.textContent=m;setTimeout(()=>st.textContent='',2500)}}function mailHtml(n){{const c=n.cloneNode(true);c.style.cssText='width:680px;max-width:680px;box-sizing:border-box;font-family:Arial,Helvetica,sans-serif;color:#222;background:#fff;padding:18px';const ph=c.querySelector('.project-header');if(ph)ph.style.cssText='min-height:260px;box-sizing:border-box';c.querySelectorAll('table').forEach(x=>x.style.cssText='border-collapse:collapse;width:100%;max-width:100%;table-layout:fixed;font-size:12px;margin:10px 0');c.querySelectorAll('th,td').forEach(x=>x.style.cssText+=';border:1px solid #bbbbbb;padding:7px;vertical-align:top;text-align:left;overflow-wrap:anywhere;word-break:break-word');c.querySelectorAll('th').forEach(x=>x.style.background='#f1f1f1');const f=c.querySelector('.facts');if(f)f.style.cssText+=';height:160px';c.querySelectorAll('img').forEach(x=>x.style.cssText+=';max-width:100%;height:auto');return c.outerHTML}}async function copyRich(){{const n=document.getElementById('report-content'),h=mailHtml(n),t=n.innerText;try{{if(navigator.clipboard&&window.ClipboardItem)await navigator.clipboard.write([new ClipboardItem({{'text/html':new Blob([h],{{type:'text/html'}}),'text/plain':new Blob([t],{{type:'text/plain'}})}})]);else{{const r=document.createRange();r.selectNode(n);const s=getSelection();s.removeAllRanges();s.addRange(r);document.execCommand('copy');s.removeAllRanges()}}done('Informe copiado. Pégalo en Outlook o Teams.')}}catch(e){{done('No se pudo copiar automáticamente. Usa Ctrl+C.')}}}}async function copyText(){{try{{await navigator.clipboard.writeText(document.getElementById('report-content').innerText);done('Texto copiado.')}}catch(e){{done('No se pudo copiar.')}}}}</script></body></html>'''
    return page

def project_detail(pid):
    ps=projects(); p=next((x for x in ps if x['id']==pid),None)
    if not p: return layout('No encontrado','<h1>Proyecto no encontrado</h1>','projects')
    related=[t for t in tasks() if t.get('project_id')==pid]; progress=int(p.get('progress',0) or 0)
    rows=''.join(task_row(t,ps) for t in related) or '<tr><td colspan="6" class="empty">Este proyecto todavía no tiene tareas.</td></tr>'
    history=p.get('history',[])
    linked_docs=[]
    if WIKI_PAGES.exists():
        for path in WIKI_PAGES.glob('*.json'):
            doc=read_json(path,{})
            if doc.get('project_id')==pid: linked_docs.append(doc)
    docs_html=''.join(f'<li class="linked-doc-item"><span class="linked-doc-dot"></span><div class="linked-doc-content"><a href="{esc(WIKI_URL)}/wiki/{esc(d.get("slug",""))}">{esc(d.get("title","Documento"))}</a><div class="linked-doc-meta"><span class="doc-category">{esc(d.get("category","General"))}</span><span>Actualizado: {esc(d.get("updated","").replace("T"," "))}</span></div></div></li>' for d in linked_docs) or '<li class="empty">No hay documentación vinculada.</li>'
    hist=''.join(f'<li><strong>{esc(h.get("date"))}</strong><p>{esc(h.get("text"))}</p>{links_html(h.get("links",[]))}{attachments_html(h.get("attachments",[]))}</li>' for h in reversed(history)) or '<li class="empty">Sin anotaciones.</li>'
    body=f'''<div class="page-head"><div><h1>{esc(p.get('name'))}</h1><p>{esc(p.get('description'))}</p></div><div><a class="btn" href="/project/edit?id={esc(pid)}">Editar</a> <a class="btn primary" href="/project/report?id={esc(pid)}">📄 Generar informe</a> <form class="inline" method="post" action="/project/delete" onsubmit="return confirm('¿Eliminar este proyecto y sus tareas?')"><input type="hidden" name="id" value="{esc(pid)}"><button class="btn danger">Eliminar</button></form></div></div><div class="detail-grid"><section class="info-card"><h2>Información</h2><dl><dt>Estado</dt><dd>{badge(p.get('status'))}</dd><dt>Prioridad</dt><dd>{badge(p.get('priority'),'priority')}</dd><dt>Responsables</dt><dd>{responsibles_badges(p)}</dd><dt>Fechas</dt><dd>{esc(p.get('start_date'))} → {esc(p.get('end_date'))}</dd></dl><h3>Avance: {progress}%</h3><div class="progress large"><span style="width:{progress}%"></span></div></section><section class="info-card"><h2>Añadir seguimiento</h2><form method="post" action="/project/note" enctype="multipart/form-data"><input type="hidden" name="id" value="{esc(pid)}"><textarea required name="text" rows="5" placeholder="Avance, incidencia, cambio o decisión..."></textarea><label>Enlaces relacionados <span class="field-help">Uno por línea. Formato opcional: Nombre | URL</span><textarea name="links" rows="3" placeholder="Consola CrowdStrike | https://...
Documento SharePoint | https://..."></textarea></label><label>Adjuntar archivos<input type="file" name="files" multiple></label><button class="btn primary">Guardar anotación</button></form></section></div><section><div class="section-head"><h2>Tareas del proyecto</h2><a class="btn" href="/task/new?project_id={esc(pid)}">Nueva tarea</a></div><div class="table-wrap"><table><thead><tr><th>Tarea</th><th>Proyecto</th><th>Responsables</th><th>Estado</th><th>Prioridad</th><th>Vence</th></tr></thead><tbody>{rows}</tbody></table></div></section><section><div class="section-head"><h2>Documentación Wiki vinculada</h2><a class="btn" href="{esc(WIKI_URL)}/new">Nuevo documento</a></div><ul class="timeline">{docs_html}</ul></section><section><h2>Historial de seguimiento</h2><ul class="timeline">{hist}</ul></section>'''
    return layout(p.get('name'),body,'projects')

def task_row(t, ps):
    p=next((x for x in ps if x['id']==t.get('project_id')),None)
    return f'<tr><td><a href="/task/edit?id={esc(t["id"])}"><strong>{esc(t.get("title"))}</strong></a><small>{esc(t.get("description",""))}</small></td><td>{esc(p.get("name") if p else "Sin proyecto")}</td><td>{responsibles_badges(t)}</td><td>{badge(t.get("status"))}</td><td>{badge(t.get("priority"),"priority")}</td><td>{esc(t.get("due_date") or "—")}</td></tr>'

def task_list(query):
    ps=projects(); ts=tasks(); status=query.get('status',[''])[0]; project=query.get('project',[''])[0]; responsible=query.get('responsible',[''])[0]
    if status: ts=[t for t in ts if t.get('status')==status]
    if project: ts=[t for t in ts if t.get('project_id')==project]
    if responsible: ts=[t for t in ts if responsible in selected_responsibles(t)]
    rows=''.join(task_row(t,ps) for t in sorted(ts,key=lambda x:(x.get('due_date') or '9999',x.get('title','')))) or '<tr><td colspan="6" class="empty">No hay tareas que mostrar.</td></tr>'
    popts=''.join(f'<option value="{esc(p["id"])}" {"selected" if project==p["id"] else ""}>{esc(p["name"])}</option>' for p in ps)
    sopts=''.join(f'<option {"selected" if status==s else ""}>{s}</option>' for s in ['Pendiente','En curso','Bloqueada','Completada','Cancelada'])
    ropts=''.join(f'<option value="{esc(r["id"])}" {"selected" if responsible==r["id"] else ""}>{esc(r["name"])}</option>' for r in sorted(responsibles(),key=lambda x:x.get('name','').lower()))
    body=f'''<div class="page-head"><div><h1>Tareas</h1><p>Listado general de tareas y vencimientos.</p></div><a class="btn primary" href="/task/new">Nueva tarea</a></div><form class="filters"><select name="project"><option value="">Todos los proyectos</option>{popts}</select><select name="status"><option value="">Todos los estados</option>{sopts}</select><select name="responsible"><option value="">Todos los responsables</option>{ropts}</select><button class="btn">Filtrar</button><a class="btn" href="/tasks">Limpiar</a></form><div class="table-wrap"><table><thead><tr><th>Tarea</th><th>Proyecto</th><th>Responsables</th><th>Estado</th><th>Prioridad</th><th>Vence</th></tr></thead><tbody>{rows}</tbody></table></div>'''
    return layout('Tareas',body,'tasks')

def task_form(t=None, selected_project=''):
    t=t or {}; edit=bool(t); ps=projects(); statuses=['Pendiente','En curso','Bloqueada','Completada','Cancelada']; priorities=['Baja','Media','Alta','Crítica']
    opts=lambda values,current: ''.join(f'<option {"selected" if v==current else ""}>{v}</option>' for v in values)
    current=t.get('project_id',selected_project); popts=''.join(f'<option value="{esc(p["id"])}" {"selected" if current==p["id"] else ""}>{esc(p["name"])}</option>' for p in ps)
    existing_assets=(links_html(t.get('links',[]))+attachments_html(t.get('attachments',[]))) if edit else ''
    body=f'''<div class="page-head"><div><h1>{'Editar' if edit else 'Nueva'} tarea</h1><p>Define el trabajo, su prioridad y fecha límite.</p></div></div><form class="form-card" method="post" action="/task/save" enctype="multipart/form-data"><input type="hidden" name="id" value="{esc(t.get('id',''))}"><label class="wide">Título<input required name="title" value="{esc(t.get('title',''))}"></label><label class="wide">Descripción<textarea name="description" rows="4">{esc(t.get('description',''))}</textarea></label><label>Proyecto<select name="project_id"><option value="">Sin proyecto</option>{popts}</select></label><label class="wide">Responsables <span class="field-help">Puedes seleccionar uno o varios</span><select name="responsible_ids" multiple size="5">{responsible_options(selected_responsibles(t))}</select></label><label>Estado<select name="status">{opts(statuses,t.get('status','Pendiente'))}</select></label><label>Prioridad<select name="priority">{opts(priorities,t.get('priority','Media'))}</select></label><label>Fecha de inicio<input type="date" name="start_date" value="{esc(t.get('start_date',''))}"></label><label>Fecha límite<input type="date" name="due_date" value="{esc(t.get('due_date',''))}"></label><label class="wide">Comentarios de seguimiento<textarea name="comments" rows="5">{esc(t.get('comments',''))}</textarea></label><label class="wide">Enlaces relacionados <span class="field-help">Uno por línea. Formato opcional: Nombre | URL</span><textarea name="links" rows="4" placeholder="Panel SIEM | https://...">{esc(chr(10).join((x.get('title',x.get('url',''))+' | '+x.get('url','')) for x in t.get('links',[])))}</textarea></label><label class="wide">Adjuntar archivos<input type="file" name="files" multiple></label>{f'<div class="wide current-assets"><strong>Archivos y enlaces actuales</strong>{existing_assets}<label class="remove-assets"><input type="checkbox" name="replace_assets" value="1"> Sustituir los adjuntos actuales por los nuevos</label></div>' if edit and existing_assets else ''}<div class="form-actions wide"><button class="btn primary">Guardar tarea</button><a class="btn" href="/tasks">Cancelar</a>{f'<button form="delete-task" type="button" class="btn danger" onclick="document.getElementById(\'delete-task\').submit()">Eliminar</button>' if edit else ''}</div></form>{f'<form id="delete-task" method="post" action="/task/delete" onsubmit="return confirm(\'¿Eliminar esta tarea?\')"><input type="hidden" name="id" value="{esc(t.get("id"))}"></form>' if edit else ''}'''
    return layout('Tarea',body,'tasks')

def responsibles_page():
    people=sorted(responsibles(),key=lambda x:x.get('name','').lower())
    ps=projects(); ts=tasks(); row_parts=[]
    for r in people:
        rid=r.get('id','')
        project_count=sum(rid in selected_responsibles(p) for p in ps)
        task_count=sum(rid in selected_responsibles(t) for t in ts)
        row_parts.append(f'<tr><td><strong>{esc(r.get("name"))}</strong><small>{esc(r.get("email",""))}</small></td><td>{project_count}</td><td>{task_count}</td><td><a class="btn" href="/responsible/edit?id={esc(rid)}">Editar</a> <form class="inline" method="post" action="/responsible/delete" onsubmit="return confirm(&quot;¿Eliminar este responsable? Se quitará de proyectos y tareas.&quot;)"><input type="hidden" name="id" value="{esc(rid)}"><button class="btn danger">Eliminar</button></form></td></tr>')
    rows=''.join(row_parts) or '<tr><td colspan="4" class="empty">No hay responsables creados.</td></tr>'
    body=f'<div class="page-head"><div><h1>Responsables</h1><p>Lista reutilizable para asignar una o varias personas a proyectos y tareas.</p></div><a class="btn primary" href="/responsible/new">Nuevo responsable</a></div><div class="table-wrap"><table><thead><tr><th>Responsable</th><th>Proyectos</th><th>Tareas</th><th>Acciones</th></tr></thead><tbody>{rows}</tbody></table></div>'
    return layout('Responsables',body,'responsibles')

def responsible_form(person=None):
    person=person or {}; edit=bool(person)
    body=f'<div class="page-head"><div><h1>{"Editar" if edit else "Nuevo"} responsable</h1><p>Datos básicos de la persona responsable.</p></div></div><form class="form-card" method="post" action="/responsible/save"><input type="hidden" name="id" value="{esc(person.get("id",""))}"><label class="wide">Nombre<input required name="name" value="{esc(person.get("name",""))}"></label><label class="wide">Correo electrónico<input type="email" name="email" value="{esc(person.get("email",""))}"></label><div class="form-actions wide"><button class="btn primary">Guardar responsable</button><a class="btn" href="/responsibles">Cancelar</a></div></form>'
    return layout('Responsable',body,'responsibles')

def calendar_view():
    ps=projects(); ts=[t for t in tasks() if t.get('due_date')]
    groups={}
    for t in ts: groups.setdefault(t['due_date'],[]).append(t)
    months={}
    for day,items in groups.items(): months.setdefault(day[:7],[]).append((day,items))
    content=''
    for month in sorted(months):
        content+=f'<section><h2>{esc(month)}</h2><div class="calendar-list">'
        for day,items in sorted(months[month]):
            content+=f'<div class="calendar-day"><strong>{esc(day)}</strong><div>' + ''.join(f'<a href="/task/edit?id={esc(t["id"])}">{esc(t["title"])} {badge(t.get("status"))}</a>' for t in items) + '</div></div>'
        content+='</div></section>'
    if not content: content='<p class="empty">No hay tareas con fecha límite.</p>'
    return layout('Calendario',f'<div class="page-head"><div><h1>Calendario</h1><p>Fechas límite agrupadas por mes.</p></div></div>{content}','calendar')

class Handler(BaseHTTPRequestHandler):
    def send_html(self, text, code=200):
        data=text.encode('utf-8'); self.send_response(code); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def redirect(self, url): self.send_response(303); self.send_header('Location',url); self.end_headers()
    def form(self):
        n=int(self.headers.get('Content-Length','0') or 0); raw=self.rfile.read(n)
        content_type=self.headers.get('Content-Type','')
        if content_type.startswith('multipart/form-data'):
            message=BytesParser(policy=email_policy).parsebytes((f'Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n').encode()+raw)
            fields={}; uploads=[]
            for part in message.iter_parts():
                name=part.get_param('name',header='content-disposition')
                filename=part.get_filename()
                payload=part.get_payload(decode=True) or b''
                if filename:
                    if payload: uploads.append(save_upload(filename,payload))
                elif name:
                    value=payload.decode(part.get_content_charset() or 'utf-8',errors='replace')
                    if name in fields:
                        fields[name]=fields[name]+[value] if isinstance(fields[name],list) else [fields[name],value]
                    else: fields[name]=value
            fields['_uploads']=uploads
            return fields
        parsed=parse_qs(raw.decode(errors='replace'))
        return {k:(v if len(v)>1 else v[0]) for k,v in parsed.items()}
    def do_GET(self):
        u=urlparse(self.path); q=parse_qs(u.query)
        if u.path.startswith('/static/'):
            path=STATIC/u.path.split('/')[-1]
            if path.exists():
                data=path.read_bytes(); self.send_response(200); self.send_header('Content-Type','text/css' if path.suffix=='.css' else 'application/javascript'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        if u.path.startswith('/attachments/'):
            stored=Path(u.path.split('/')[-1]).name; path=ATTACHMENTS/stored
            if path.exists() and path.is_file():
                data=path.read_bytes(); ctype=mimetypes.guess_type(path.name)[0] or 'application/octet-stream'
                self.send_response(200); self.send_header('Content-Type',ctype); self.send_header('Content-Disposition',f'attachment; filename="{safe_filename(path.name.split("_",1)[-1])}"'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        routes={'/':dashboard,'/projects':lambda:project_list(q),'/tasks':lambda:task_list(q),'/responsibles':responsibles_page,'/calendar':calendar_view,'/project/new':project_form,'/task/new':lambda:task_form(selected_project=q.get('project_id',[''])[0]),'/responsible/new':responsible_form}
        if u.path in routes: self.send_html(routes[u.path]()); return
        if u.path=='/project': self.send_html(project_detail(q.get('id',[''])[0])); return
        if u.path=='/project/report': self.send_html(project_report(q.get('id',[''])[0])); return
        if u.path=='/project/edit':
            p=next((x for x in projects() if x['id']==q.get('id',[''])[0]),None); self.send_html(project_form(p)); return
        if u.path=='/task/edit':
            t=next((x for x in tasks() if x['id']==q.get('id',[''])[0]),None); self.send_html(task_form(t)); return
        if u.path=='/responsible/edit':
            r=next((x for x in responsibles() if x['id']==q.get('id',[''])[0]),None); self.send_html(responsible_form(r)); return
        self.send_html(layout('No encontrado','<h1>Página no encontrada</h1>'),404)
    def do_POST(self):
        f=self.form()
        if self.path=='/responsible/save':
            people=responsibles(); rid=str(f.get('id','') or uid('rsp')); old=next((x for x in people if x.get('id')==rid),{})
            person={**old,'id':rid,'name':str(f.get('name','')).strip(),'email':str(f.get('email','')).strip(),'created':old.get('created',now()),'updated':now()}
            people=[person if x.get('id')==rid else x for x in people] if old else people+[person]; write_json(RESPONSIBLES,people); self.redirect('/responsibles'); return
        if self.path=='/responsible/delete':
            rid=str(f.get('id','')); write_json(RESPONSIBLES,[r for r in responsibles() if r.get('id')!=rid])
            ps=projects(); ts=tasks()
            for item in ps+ts:
                ids=selected_responsibles(item); item['responsible_ids']=[x for x in ids if x!=rid]; item['owner']=''
            write_json(PROJECTS,ps); write_json(TASKS,ts); self.redirect('/responsibles'); return
        if self.path=='/project/save':
            ps=projects(); pid=f.get('id') or uid('prj'); old=next((x for x in ps if x['id']==pid),{})
            p={**old,'id':pid,'name':f.get('name','').strip(),'description':f.get('description','').strip(),'responsible_ids':field_values(f,'responsible_ids'),'owner':'','status':f.get('status','Planificado'),'priority':f.get('priority','Media'),'progress':max(0,min(100,int(f.get('progress','0') or 0))),'start_date':f.get('start_date',''),'end_date':f.get('end_date',''),'history':old.get('history',[]),'created':old.get('created',now()),'updated':now()}
            ps=[p if x['id']==pid else x for x in ps] if old else ps+[p]; write_json(PROJECTS,ps); self.redirect('/project?id='+pid); return
        if self.path=='/project/delete':
            pid=f.get('id'); doomed_projects=[p for p in projects() if p['id']==pid]; doomed_tasks=[t for t in tasks() if t.get('project_id')==pid]
            for p in doomed_projects:
                for h in p.get('history',[]): delete_uploads(h.get('attachments',[]))
            for t in doomed_tasks: delete_uploads(t.get('attachments',[]))
            write_json(PROJECTS,[p for p in projects() if p['id']!=pid]); write_json(TASKS,[t for t in tasks() if t.get('project_id')!=pid]); self.redirect('/projects'); return
        if self.path=='/project/note':
            ps=projects(); pid=f.get('id'); text=f.get('text','').strip()
            for p in ps:
                if p['id']==pid and text: p.setdefault('history',[]).append({'date':datetime.now().strftime('%Y-%m-%d %H:%M'),'text':text,'links':parse_links(f.get('links','')),'attachments':f.get('_uploads',[])}); p['updated']=now()
            write_json(PROJECTS,ps); self.redirect('/project?id='+pid); return
        if self.path=='/task/save':
            ts=tasks(); tid=f.get('id') or uid('tsk'); old=next((x for x in ts if x['id']==tid),{})
            new_uploads=f.get('_uploads',[])
            if f.get('replace_assets')=='1':
                delete_uploads(old.get('attachments',[])); attachments=new_uploads
            else:
                attachments=old.get('attachments',[])+new_uploads
            t={**old,'id':tid,'title':f.get('title','').strip(),'description':f.get('description','').strip(),'project_id':f.get('project_id',''),'responsible_ids':field_values(f,'responsible_ids'),'owner':'','status':f.get('status','Pendiente'),'priority':f.get('priority','Media'),'start_date':f.get('start_date',''),'due_date':f.get('due_date',''),'comments':f.get('comments','').strip(),'links':parse_links(f.get('links','')),'attachments':attachments,'created':old.get('created',now()),'updated':now()}
            ts=[t if x['id']==tid else x for x in ts] if old else ts+[t]; write_json(TASKS,ts); self.redirect('/tasks'); return
        if self.path=='/task/delete':
            tid=f.get('id'); doomed=next((t for t in tasks() if t['id']==tid),None)
            if doomed: delete_uploads(doomed.get('attachments',[]))
            write_json(TASKS,[t for t in tasks() if t['id']!=tid]); self.redirect('/tasks'); return
        self.redirect('/')
    def log_message(self,*args): pass

if __name__=='__main__':
    port=int(os.environ.get('GESTOR_PORT','8080')); print(f'Gestor disponible en http://127.0.0.1:{port}'); ThreadingHTTPServer(('127.0.0.1',port),Handler).serve_forever()
