from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote, quote
from pathlib import Path
from datetime import datetime
import html
import hashlib
import json
import mimetypes
import os
import re
import socket
import subprocess
import tempfile
import shutil
import uuid
import zipfile
import sys

from docx_export import generate as generate_docx, safe_filename as safe_docx_name

CORPORATE_THEME_CSS = r""":root {
  --santander-red:#EC0000;
  --santander-red-dark:#C00000;
  --santander-red-deep:#990000;
  --santander-red-soft:#FDECEC;
  --santander-coral:#FF5A5F;
  --santander-orange:#F57C00;
  --santander-black:#111111;
  --santander-text:#2D2D2D;
  --santander-grey-700:#5B5B5B;
  --santander-grey-500:#8A8A8A;
  --santander-grey-300:#C9C9C9;
  --santander-grey-200:#E5E5E5;
  --santander-grey-100:#F2F2F2;
  --santander-bg:#F7F7F7;
  --santander-white:#FFFFFF;
  --brand-font:"Santander Headline","Segoe UI",Arial,sans-serif;
  --body-font:"Santander Headline","Segoe UI",Arial,sans-serif;
}
*{box-sizing:border-box}
html,body{font-family:var(--body-font)!important}
body{background:var(--santander-bg)!important;color:var(--santander-text)!important}
header{
  background:linear-gradient(105deg,var(--santander-red-dark),var(--santander-red))!important;
  color:#fff!important;border-bottom:0!important;box-shadow:0 3px 12px rgba(80,0,0,.18)!important;
}
.brand{font-family:var(--brand-font)!important;font-weight:600!important;letter-spacing:.1px!important;display:flex!important;align-items:center!important;gap:12px!important}
.brand::before{
  content:"";display:inline-block;width:36px;height:34px;flex:0 0 36px;
  background-image:url("/corporate-logo.png");
  background-size:contain;background-position:center;background-repeat:no-repeat;
  filter:brightness(0) invert(1);
}
.shell aside,aside{background:#fff!important;border-right:1px solid var(--santander-grey-200)!important}
aside nav a,nav a{color:#3c3c3c!important;border-radius:6px!important;transition:.15s ease!important}
aside nav a:hover,nav a:hover{background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important}
aside nav a.active,nav a.active{
  background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important;
  border-left:4px solid var(--santander-red)!important;font-weight:700!important;
}
main h1,main h2,.page-title{font-family:var(--brand-font)!important;color:var(--santander-red-dark)!important}
main h3{font-family:var(--brand-font)!important;color:var(--santander-black)!important}
a{color:var(--santander-red-dark)}
a:hover{color:var(--santander-red)}
.btn,.button,button,input[type=submit],input[type=button]{
  font-family:var(--body-font)!important;border-radius:6px!important;box-shadow:none!important;
}
.btn.primary,.btn-primary,.button-primary,button.primary,input[type=submit]{
  background:var(--santander-red)!important;border-color:var(--santander-red)!important;color:#fff!important;
}
.btn.primary:hover,.btn-primary:hover,button.primary:hover,input[type=submit]:hover{
  background:var(--santander-red-dark)!important;border-color:var(--santander-red-dark)!important;
}
.btn:not(.primary),button:not(.primary){
  background:#fff!important;border-color:var(--santander-grey-300)!important;color:var(--santander-text)!important;
}
.card,.panel,.widget,.stat,.tile,.project-card,.task-card,.wiki-card,.bau-card{
  background:#fff!important;border:1px solid var(--santander-grey-200)!important;
  border-radius:10px!important;box-shadow:0 2px 8px rgba(0,0,0,.045)!important;
}
table{background:#fff!important;border-color:var(--santander-grey-200)!important}
thead th,table th{background:var(--santander-red-dark)!important;color:#fff!important;border-color:var(--santander-red-dark)!important}
tbody tr:nth-child(even){background:#FAFAFA!important}
input,select,textarea{
  font-family:var(--body-font)!important;border:1px solid var(--santander-grey-300)!important;border-radius:6px!important;
}
input:focus,select:focus,textarea:focus{
  border-color:var(--santander-red)!important;outline:0!important;box-shadow:0 0 0 3px rgba(236,0,0,.12)!important;
}
.badge,.chip,.tag{border-radius:999px!important}
.badge.en-curso,.badge.alta,.badge.critica,.badge.crítica{background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important}
.notice,.alert,.callout{border-left:6px solid var(--santander-red)!important;background:#fff!important}
pre,code,.code-block{background:#F2F2F2!important;border-color:#D5D5D5!important}
footer{border-top:1px solid var(--santander-grey-200)!important;color:var(--santander-grey-700)!important}
@media print {
  header,aside,.header-actions,.actions,.toolbar,footer{display:none!important}
  body,main{background:#fff!important;color:#111!important}
  main{width:100%!important;max-width:none!important;margin:0!important;padding:0!important}
  h1,h2{color:var(--santander-red-dark)!important}
  table th{background:var(--santander-red-dark)!important;color:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .notice,.alert,.callout{border-left-color:var(--santander-red)!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
}
/* V25.2 — Cabecera corporativa: símbolo rojo íntegro sobre fondo blanco */
header{
  min-height:68px!important;
  height:auto!important;
  padding:10px 22px!important;
  background:#FFFFFF!important;
  color:#222222!important;
  border-bottom:4px solid #EC0000!important;
  box-shadow:0 2px 10px rgba(0,0,0,.08)!important;
  overflow:visible!important;
}
.brand{
  min-width:0!important;
  color:#222222!important;
  font-family:var(--brand-font,"Santander Headline","Segoe UI",Arial,sans-serif)!important;
  font-size:20px!important;
  line-height:1.15!important;
  font-weight:600!important;
  display:flex!important;
  align-items:center!important;
  gap:13px!important;
  white-space:nowrap!important;
  overflow:visible!important;
}
.brand::before{
  content:""!important;
  display:block!important;
  width:46px!important;
  height:46px!important;
  min-width:46px!important;
  max-width:46px!important;
  flex:0 0 46px!important;
  background-color:#FFFFFF!important;
  background-repeat:no-repeat!important;
  background-position:center!important;
  background-size:contain!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
}
@media(max-width:700px){
  header{min-height:60px!important;padding:8px 14px!important}
  .brand{font-size:17px!important;gap:10px!important}
  .brand::before{width:38px!important;height:38px!important;min-width:38px!important;max-width:38px!important;flex-basis:38px!important}
}

/* V25.3 — Auditoría de legibilidad y contraste */
:root{
  --accessible-text:#202124;
  --accessible-muted:#5F6368;
  --accessible-border:#AEB4BA;
  --accessible-link:#B30000;
  --accessible-focus:#8A0000;
  --code-bg:#1F2328;
  --code-head:#2D333B;
  --code-text:#F0F3F6;
  --code-muted:#B7C0CA;
  --code-keyword:#FF9A91;
  --code-string:#B6D7FF;
  --code-number:#91CBFF;
  --code-comment:#B7C0CA;
  --code-variable:#FFC07A;
  --code-builtin:#DFB6FF;
  --code-pipe:#FFD866;
}
body{color:var(--accessible-text)!important}
a{color:var(--accessible-link)!important}
a:hover,a:focus{text-decoration:underline!important;color:#8A0000!important}
small,.muted,.meta,.aside-note,.page-head p,.stats span,.stat span,.card-meta{
  color:var(--accessible-muted)!important;
  opacity:1!important;
}
button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
  outline:3px solid var(--accessible-focus)!important;
  outline-offset:2px!important;
}
input,select,textarea{
  color:#202124!important;
  background:#FFFFFF!important;
  border-color:#8A9097!important;
  opacity:1!important;
}
input::placeholder,textarea::placeholder{color:#656B72!important;opacity:1!important}
button:disabled,.btn:disabled{opacity:.65!important;color:#3C4043!important}

/* Código: contraste alto y sin transparencias */
.code-wrap,.code-block,.code-container,.editor-code{
  background:var(--code-bg)!important;
  border-color:#59636E!important;
  opacity:1!important;
}
.code-head,.code-header,.code-title{
  background:var(--code-head)!important;
  color:#FFFFFF!important;
  border-color:#59636E!important;
  opacity:1!important;
}
.code-box,.code-box code,pre,pre code,.content pre,.content pre code{
  background:var(--code-bg)!important;
  color:var(--code-text)!important;
  font-family:Consolas,"Courier New",monospace!important;
  font-size:14px!important;
  line-height:1.65!important;
  opacity:1!important;
  text-shadow:none!important;
  filter:none!important;
}
.code-box *,pre *,pre code *{
  opacity:1!important;
  text-shadow:none!important;
  filter:none!important;
}
.tok-keyword{color:var(--code-keyword)!important;font-weight:700!important}
.tok-string{color:var(--code-string)!important}
.tok-comment{color:var(--code-comment)!important;font-style:italic!important}
.tok-number{color:var(--code-number)!important}
.tok-builtin{color:var(--code-builtin)!important}
.tok-variable{color:var(--code-variable)!important}
.tok-operator{color:#FF9A91!important;font-weight:700!important}
.tok-pipe{color:var(--code-pipe)!important;font-weight:800!important}
.tok-key,.tok-tag{color:#9BE9A8!important}
.copy-code,.code-head button,.code-header button{
  background:#FFFFFF!important;
  color:#8A0000!important;
  border:1px solid #FFFFFF!important;
  font-weight:700!important;
}

/* Avisos: texto oscuro y fondos claros */
.admonition,.notice,.alert{
  color:#202124!important;
  opacity:1!important;
}
.admonition *,.notice *,.alert *{opacity:1!important}
.admonition.advertencia,.warning{
  background:#FFF4E5!important;
  border-color:#C54800!important;
  color:#3B2500!important;
}
.admonition.informacion,.admonition.nota,.info{
  background:#F3F6F9!important;
  border-color:#B30000!important;
  color:#202124!important;
}
.admonition.importante{
  background:#FDECEC!important;
  border-color:#B30000!important;
  color:#4A0000!important;
}
.admonition.error,.error{
  background:#FCE8E6!important;
  border-color:#A50E0E!important;
  color:#5F0000!important;
}

/* Tablas, tarjetas, etiquetas y estados */
th{background:#ECEFF1!important;color:#30343B!important}
td{color:#202124!important}
.card,section,.stat,.project-card,.info-card{
  color:#202124!important;
}
.badge,.tag{
  color:#30343B!important;
  opacity:1!important;
}
.status-en-curso,.badge.en-curso{background:#FFE1E1!important;color:#8A0000!important}
.status-finalizado,.status-completada,.badge.resuelta,.badge.cerrada{
  background:#DFF1E5!important;color:#1F5D36!important;
}
.status-bloqueada,.status-cancelado,.priority-critica,.badge.priority.critica{
  background:#F8D7DA!important;color:#721C24!important;
}
.primary,.btn.primary{
  background:#EC0000!important;color:#FFFFFF!important;border-color:#B30000!important;
}
.primary:hover,.btn.primary:hover{background:#B30000!important;color:#FFFFFF!important}

/* V25.4 — Selecciones legibles y zona de información ampliada */
html,body{width:100%;min-width:0}
.shell{
  width:calc(100% - 24px)!important;
  max-width:1920px!important;
  margin:0 auto!important;
  grid-template-columns:230px minmax(0,1fr)!important;
}
main{
  width:100%!important;
  max-width:none!important;
  min-width:0!important;
  margin:0!important;
  padding:20px 24px 36px!important;
}
main > *,article,.content,.page-content,.dashboard-grid{
  max-width:none!important;
}
article{width:100%!important}
.card,section,.hero,.panel{
  max-width:none!important;
}
.form-card,.editor,.github-editor,.info-card{
  max-width:none!important;
  width:100%!important;
}
.table-wrap,.pending-card,.pending-table{
  width:100%!important;
  max-width:none!important;
}
table{width:100%!important}

/* Filtros y pestañas: estados claramente visibles */
.pending-filters,.search-filters,.module-tabs{
  display:flex!important;
  flex-wrap:wrap!important;
  gap:8px!important;
  align-items:center!important;
}
.pending-filter,.search-filters a,.module-tabs a{
  display:inline-flex!important;
  align-items:center!important;
  justify-content:center!important;
  min-height:36px!important;
  padding:8px 14px!important;
  border:1px solid #B8BEC5!important;
  border-radius:999px!important;
  background:#FFFFFF!important;
  color:#9B0000!important;
  font-size:13px!important;
  line-height:1.2!important;
  font-weight:600!important;
  text-decoration:none!important;
  opacity:1!important;
  white-space:nowrap!important;
}
.pending-filter:hover,.search-filters a:hover,.module-tabs a:hover{
  background:#FDECEC!important;
  border-color:#EC0000!important;
  color:#780000!important;
  text-decoration:none!important;
}
.pending-filter.active,.search-filters a.active,.module-tabs a.active{
  background:#EC0000!important;
  border-color:#B30000!important;
  color:#FFFFFF!important;
  font-weight:700!important;
  box-shadow:0 0 0 1px #EC0000!important;
}
.pending-filter.active *,
.search-filters a.active *,
.module-tabs a.active *{
  color:#FFFFFF!important;
}

/* Tarjetas resumen */
.pending-summary{
  grid-template-columns:repeat(4,minmax(180px,1fr))!important;
  gap:12px!important;
}
.pending-chip{
  min-height:72px!important;
  padding:14px 16px!important;
  background:#FFFFFF!important;
  color:#30343B!important;
  border:1px solid #C7CDD3!important;
}
.pending-chip:hover{
  background:#FFF5F5!important;
  border-color:#EC0000!important;
  text-decoration:none!important;
}
.pending-chip strong{font-size:24px!important;color:#202124!important}

/* Ventanas y cuadros de información más amplios */
.import-dialog,.modal-dialog,.dialog,.popup,.detail-dialog{
  width:min(1100px,calc(100vw - 40px))!important;
  max-width:1100px!important;
  max-height:92vh!important;
}
.import-dialog-body,.modal-body,.dialog-body{
  padding:22px 24px!important;
}
.project-grid{
  grid-template-columns:repeat(auto-fit,minmax(280px,1fr))!important;
}
.detail-grid{
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
}
.editor-row{
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
}

@media(min-width:1600px){
  .shell{width:calc(100% - 32px)!important;max-width:2200px!important}
  main{padding:22px 30px 42px!important}
}
@media(max-width:1050px){
  .pending-summary{grid-template-columns:repeat(2,minmax(160px,1fr))!important}
  .detail-grid,.editor-row{grid-template-columns:1fr!important}
}
@media(max-width:850px){
  .shell{display:block!important;width:100%!important}
  main{padding:16px!important}
  .pending-summary{grid-template-columns:1fr!important}
  .pending-filter,.search-filters a,.module-tabs a{font-size:12px!important;padding:8px 12px!important}
}

/* V25.5 — Tipografía exacta para PDF */
@media print {
  html,body,main,article,.content,.page-content{
    font-size:12px!important;
    line-height:1.45!important;
  }

  p,li,dd,dt,td,th,span,div,label{
    font-size:12px!important;
  }

  h1,h2,h3,h4,h5,h6,
  .page-title,.section-title,.card-title{
    font-size:14px!important;
    line-height:1.25!important;
  }

  .email-example,
  .email-example *,
  .communication-email,
  .communication-email *,
  .communication-case,
  .communication-case *,
  .communication-response,
  .communication-response *,
  .case-field,
  .case-field *,
  .admonition,
  .admonition *,
  .notice,
  .notice *,
  .alert,
  .alert *,
  .callout,
  .callout *,
  .code-wrap,
  .code-wrap *,
  .code-box,
  .code-box *,
  .code-head,
  .code-head *,
  pre,
  pre *,
  code,
  code *{
    font-size:9px!important;
    line-height:1.4!important;
  }

  .email-example-title,
  .communication-title,
  .admonition-title,
  .code-head{
    font-size:9px!important;
    font-weight:700!important;
  }

  .email-example,
  .communication-email,
  .communication-case,
  .communication-response,
  .admonition,
  .notice,
  .alert,
  .callout,
  .code-wrap,
  pre{
    break-inside:avoid!important;
    page-break-inside:avoid!important;
  }
}
"""

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
PAGES = DATA / "pages"
LEGACY_UPLOADS = DATA / "uploads"
UPLOADS = BASE.parent.parent / "imagenes"
ATTACHMENTS = DATA / "attachments"
STATIC = BASE / "static"
CATEGORIES_FILE = DATA / "categories.json"
TAGS_FILE = DATA / "tags.json"
FAVORITES_FILE = DATA / "favorites.json"
RECENTS_FILE = DATA / "recents.json"
TEMPLATES_FILE = DATA / "templates.json"
APP_VERSION = "25.1"
PROJECT_ROOT = BASE.parent.parent
WORD_TEMPLATES = PROJECT_ROOT / "templates_word"
WORD_EXPORTS = PROJECT_ROOT / "exports" / "docx"
DEFAULT_WORD_TEMPLATE = WORD_TEMPLATES / "Plantilla_procedimientos.docx"
WORD_TEMPLATE_CONFIG = WORD_TEMPLATES / "config.json"
GESTOR_DATA = BASE.parent / "gestor" / "data" / "projects.json"
GESTOR_RESPONSIBLES = BASE.parent / "gestor" / "data" / "responsibles.json"
PORTAL_URL = os.environ.get("PORTAL_URL", "http://127.0.0.1:8079")
GESTOR_URL = os.environ.get("GESTOR_URL", "http://127.0.0.1:8081")
BAU_URL = os.environ.get("BAU_URL", "http://127.0.0.1:8082")
BITACORA_URL = os.environ.get("BITACORA_URL", "http://127.0.0.1:8083")
BIBLIOTECA_URL = os.environ.get("BIBLIOTECA_URL", "http://127.0.0.1:8084")
CAMBIOS_URL = os.environ.get("CAMBIOS_URL", "http://127.0.0.1:8085")
DEFAULT_CATEGORIES = ["General", "Documentación", "Splunk"]

for folder in (DATA, PAGES, LEGACY_UPLOADS, UPLOADS, ATTACHMENTS, STATIC, WORD_TEMPLATES, WORD_EXPORTS):
    folder.mkdir(parents=True, exist_ok=True)

# Conserva imágenes de versiones anteriores en la carpeta unificada del proyecto.
for old_image in LEGACY_UPLOADS.iterdir():
    if old_image.is_file() and not (UPLOADS / old_image.name).exists():
        try:
            shutil.copy2(old_image, UPLOADS / old_image.name)
        except OSError:
            pass



def word_template_config():
    try:
        data=json.loads(WORD_TEMPLATE_CONFIG.read_text(encoding='utf-8')) if WORD_TEMPLATE_CONFIG.exists() else {}
        return data if isinstance(data,dict) else {}
    except Exception:
        return {}


def available_word_templates():
    WORD_TEMPLATES.mkdir(parents=True,exist_ok=True)
    return sorted(WORD_TEMPLATES.glob('*.docx'),key=lambda x:x.name.casefold())


def configured_default_word_template():
    files=available_word_templates()
    cfg=word_template_config()
    configured=Path(str(cfg.get('default',''))).name
    if configured:
        candidate=WORD_TEMPLATES/configured
        if candidate.is_file():
            return candidate
    if DEFAULT_WORD_TEMPLATE.is_file():
        return DEFAULT_WORD_TEMPLATE
    return files[0] if files else DEFAULT_WORD_TEMPLATE


def selected_word_template(name=''):
    safe=Path(str(name or '')).name
    if safe:
        candidate=WORD_TEMPLATES/safe
        if candidate.is_file() and candidate.suffix.lower()=='.docx':
            return candidate
    return None


def word_template_display_name(path):
    stem=Path(path).stem
    stem=re.sub(r'(?i)^plantilla[_\-\s]*','',stem)
    stem=re.sub(r'[_\-]+',' ',stem)
    stem=re.sub(r'\s+',' ',stem).strip()
    return stem[:1].upper()+stem[1:] if stem else Path(path).stem


def export_template_selection_page(page,files,export_type='docx'):
    export_type='pdf' if export_type=='pdf' else 'docx'
    default_template=configured_default_word_template()
    default_name=default_template.name if default_template and default_template.is_file() else ''
    action='/export-pdf/' if export_type=='pdf' else '/export-docx/'
    button_text='Generar PDF' if export_type=='pdf' else 'Generar Word'
    title='Seleccionar formato para PDF' if export_type=='pdf' else 'Seleccionar plantilla Word'
    description=(
        'El PDF se genera directamente con el formato predeterminado de la aplicación.'
        if export_type=='pdf'
        else 'Seleccione la plantilla Word que desea utilizar.'
    )

    options=[]
    if export_type=='pdf':
        options.append(
            '<label class="word-template-option default-template-option">'
            '<input type="radio" name="template" value="__legacy__" checked>'
            '<span><strong>Formato PDF predeterminado</strong>'
            '<small>Diseño generado directamente desde la vista Wiki.</small></span></label>'
        )

    for file in files:
        is_default=file.name==default_name
        checked='checked' if export_type=='docx' and is_default else ''
        display=word_template_display_name(file)
        marker=' <em>Predeterminada</em>' if is_default else ''
        options.append(
            '<label class="word-template-option '+('default-template-option' if is_default else '')+'">'
            '<input type="radio" name="template" value="'+html.escape(file.name,quote=True)+'" '+checked+'>'
            '<span><strong>'+html.escape(display)+marker+'</strong>'
            '<small>'+html.escape(file.name)+'</small></span></label>'
        )

    if export_type=='docx' and files and not any(' checked' in option for option in options):
        options[0]=options[0].replace('>', ' checked>', 1)

    body=(
        '<div class="page-head export-picker-head"><div><h1>'+title+'</h1>'
        '<p>'+description+'</p></div></div>'
        '<section class="card word-template-picker">'
        '<form id="export-template-form" method="get" action="'+action+quote(page['slug'])+'">'
        '<div class="word-template-options">'+''.join(options)+'</div>'
        '<div id="export-progress" class="export-progress" hidden>'
        '<strong>Generando el documento…</strong>'
        '<span>Espere mientras se prepara la descarga.</span>'
        '</div>'
        '<div id="export-error" class="export-inline-error" hidden></div>'
        '<div class="actions export-picker-actions">'
        '<button class="primary" type="submit">'+button_text+'</button>'
        '<a class="btn" href="/wiki/'+quote(page['slug'])+'">Cancelar</a>'
        '</div></form></section>'
        '<style>'
        '.export-picker-head{margin-bottom:10px}.word-template-options{display:grid;gap:10px;margin-bottom:16px}'
        '.word-template-option{display:flex!important;align-items:center!important;gap:10px!important;padding:12px!important;border:1px solid #ccd2d8;border-radius:8px;cursor:pointer;margin:0!important}'
        '.word-template-option:hover{background:#fdecec}.word-template-option input{width:auto!important}'
        '.word-template-option span{display:flex;flex-direction:column;min-width:0}.word-template-option small{color:#666;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}'
        '.word-template-option em{font-style:normal;font-size:11px;margin-left:6px;padding:2px 6px;border-radius:999px;background:#fdecec;color:#9b0000}'
        '.default-template-option{border-color:#ec0000;background:#fff7f7}.export-picker-actions{display:flex!important;align-items:center!important;gap:8px!important}'
        '.export-progress{margin:0 0 14px;padding:12px 14px;border:1px solid #e3b400;border-radius:8px;background:#fff9dc}'
        '.export-progress strong,.export-progress span{display:block}.export-progress span{margin-top:3px;font-size:12px;color:#555}'
        '.export-inline-error{margin:0 0 14px;padding:12px 14px;border:1px solid #b30000;border-radius:8px;background:#fdecec;color:#650000;white-space:pre-wrap;overflow-wrap:anywhere}'
        '</style>'
        '<script>'
        '(function(){'
        'const form=document.getElementById("export-template-form");if(!form)return;'
        'const progress=document.getElementById("export-progress");'
        'const errorBox=document.getElementById("export-error");'
        'const button=form.querySelector("button[type=submit]");'
        'function downloadName(response){'
        'const value=response.headers.get("Content-Disposition")||"";'
        'const utfMarker="filename*=UTF-8"+String.fromCharCode(39)+String.fromCharCode(39);'
        'const utfPos=value.toLowerCase().indexOf(utfMarker.toLowerCase());'
        'if(utfPos>=0){const raw=value.slice(utfPos+utfMarker.length).split(";")[0].trim();try{return decodeURIComponent(raw)}catch(e){return raw}}'
        'const simple=value.match(/filename="?([^";]+)"?/i);return simple?simple[1]:"documento";'
        '}'
        'form.addEventListener("submit",async function(event){'
        'event.preventDefault();'
        'const selected=form.querySelector(\'input[name="template"]:checked\');'
        'if(!selected){alert("Seleccione una plantilla.");return;}'
        'if(errorBox){errorBox.hidden=true;errorBox.textContent="";}'
        'if(progress)progress.hidden=false;'
        'if(button){button.disabled=true;button.textContent="Generando…";}'
        'try{'
        'const params=new URLSearchParams();params.set("template",selected.value);params.set("_",Date.now().toString());'
        'const response=await fetch(form.action+"?"+params.toString(),{method:"GET",cache:"no-store",headers:{"X-Requested-With":"XMLHttpRequest"}});'
        'if(!response.ok){const detail=(await response.text()).trim();throw new Error(detail||("Error HTTP "+response.status));}'
        'const blob=await response.blob();if(!blob.size)throw new Error("El servidor devolvió un documento vacío.");'
        'const url=URL.createObjectURL(blob);const link=document.createElement("a");'
        'link.href=url;link.download=downloadName(response);document.body.appendChild(link);link.click();link.remove();'
        'setTimeout(function(){URL.revokeObjectURL(url)},1500);'
        '}catch(error){if(errorBox){errorBox.textContent=error.message||String(error);errorBox.hidden=false;}else alert(error.message||error);}'
        'finally{if(progress)progress.hidden=true;if(button){button.disabled=false;button.textContent='+json.dumps(button_text)+';}}'
        '});})();'
        '</script>'
    )
    return layout(title,body)



def _document_cache_key(page, template):
    payload={
        'slug':str(page.get('slug','')),
        'updated':str(page.get('updated','')),
        'title':str(page.get('title','')),
        'content':str(page.get('content','')),
        'template':Path(template).name,
        'template_mtime':Path(template).stat().st_mtime_ns if Path(template).is_file() else 0,
        'engine':'2.6',
    }
    raw=json.dumps(payload,ensure_ascii=False,sort_keys=True).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()[:24]


def generate_word_document(page, template):
    """Genera una única copia DOCX reutilizada por Word y PDF.

    La escritura es atómica y el archivo se valida después de cerrar por completo
    el paquete OOXML. Ambas exportaciones consumen exactamente este mismo archivo.
    """
    template=Path(template).resolve()
    if not template.is_file():
        raise FileNotFoundError(f'No se encuentra la plantilla Word: {template}')

    cache_dir=WORD_EXPORTS/'generated'
    cache_dir.mkdir(parents=True,exist_ok=True)
    key=_document_cache_key(page,template)
    final_path=cache_dir/f'{key}.docx'

    if final_path.is_file() and final_path.stat().st_size>100:
        try:
            with zipfile.ZipFile(final_path,'r') as check:
                if check.testzip() is None and 'word/document.xml' in check.namelist():
                    return final_path
        except Exception:
            final_path.unlink(missing_ok=True)

    temp_path=cache_dir/f'.{key}.{uuid.uuid4().hex}.tmp'
    try:
        generate_docx(template,temp_path,page)
        if not temp_path.is_file() or temp_path.stat().st_size<100:
            raise RuntimeError('La generación terminó sin crear un documento Word válido.')

        # generate_docx() ya devuelve el archivo completamente cerrado.
        # En Windows, fsync() sobre un descriptor abierto en solo lectura puede
        # producir [Errno 9] Bad file descriptor, por lo que se valida directamente.
        with zipfile.ZipFile(temp_path,'r') as check:
            bad=check.testzip()
            if bad:
                raise RuntimeError(f'El DOCX generado contiene una entrada dañada: {bad}')
            required={'[Content_Types].xml','_rels/.rels','word/document.xml','word/_rels/document.xml.rels'}
            missing=sorted(required-set(check.namelist()))
            if missing:
                raise RuntimeError('El DOCX generado no contiene: '+', '.join(missing))

        os.replace(temp_path,final_path)
        return final_path
    finally:
        temp_path.unlink(missing_ok=True)


def find_soffice():
    candidates=[]
    for name in ('soffice','libreoffice'):
        found=shutil.which(name)
        if found:
            candidates.append(Path(found))
    if os.name=='nt':
        for root in filter(None,[os.environ.get('PROGRAMFILES'),os.environ.get('PROGRAMFILES(X86)'),os.environ.get('LOCALAPPDATA')]):
            candidates.extend([
                Path(root)/'LibreOffice'/'program'/'soffice.exe',
                Path(root)/'LibreOffice 7'/'program'/'soffice.exe',
            ])
    return next((x for x in candidates if x.is_file()),None)


def convert_word_to_pdf(docx_path,pdf_path):
    """Convierte un DOCX a PDF usando primero Microsoft Word y después LibreOffice.

    La conversión se realiza con nombres ASCII fijos dentro de una carpeta temporal
    para evitar fallos de Windows PowerShell/COM con títulos que contienen tildes,
    eñes u otros caracteres Unicode.
    """
    docx_path=Path(docx_path).resolve()
    pdf_path=Path(pdf_path).resolve()
    pdf_path.parent.mkdir(parents=True,exist_ok=True)
    if not docx_path.is_file():
        raise FileNotFoundError(f'No se encuentra el documento Word generado: {docx_path}')

    errors=[]
    WORD_EXPORTS.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='sms_pdf_') as td:
        td=Path(td)
        ascii_pdf=td/'output.pdf'

        if os.name=='nt':
            powershell=shutil.which('powershell.exe') or shutil.which('powershell') or shutil.which('pwsh')
            if powershell:
                script=td/'convert.ps1'
                def ps_quote(value):
                    return str(value).replace("'","''")
                script_text=(
                    "$ErrorActionPreference='Stop'\r\n"
                    "$word=$null\r\n"
                    "$doc=$null\r\n"
                    f"$source='{ps_quote(docx_path)}'\r\n"
                    "$openPath=$source\r\n"
                    "try {\r\n"
                    "  $fso=New-Object -ComObject Scripting.FileSystemObject\r\n"
                    "  $short=$fso.GetFile($source).ShortPath\r\n"
                    "  if ($short) { $openPath=$short }\r\n"
                    "} catch {}\r\n"
                    "try {\r\n"
                    "  $word=New-Object -ComObject Word.Application\r\n"
                    "  $word.Visible=$false\r\n"
                    "  $word.DisplayAlerts=0\r\n"
                    "  try {\r\n"
                    "    $doc=$word.Documents.Open($openPath,$false,$true)\r\n"
                    "  } catch {\r\n"
                    "    try {\r\n"
                    "      $doc=$word.Documents.Open($source,$false,$true)\r\n"
                    "    } catch {\r\n"
                    "      if ($word -ne $null) { try { $word.Quit() } catch {} }\r\n"
                    "      $word=$null\r\n"
                    "      $doc=$null\r\n"
                    "      $winword=$null\r\n"
                    "      try { $winword=(Get-Command WINWORD.EXE -ErrorAction Stop).Source } catch {}\r\n"
                    "      if (-not $winword) {\r\n"
                    "        $paths=@(\r\n"
                    "          \"$env:ProgramFiles\\Microsoft Office\\root\\Office16\\WINWORD.EXE\",\r\n"
                    "          \"${env:ProgramFiles(x86)}\\Microsoft Office\\root\\Office16\\WINWORD.EXE\",\r\n"
                    "          \"$env:ProgramFiles\\Microsoft Office\\Office16\\WINWORD.EXE\",\r\n"
                    "          \"${env:ProgramFiles(x86)}\\Microsoft Office\\Office16\\WINWORD.EXE\"\r\n"
                    "        )\r\n"
                    "        $winword=$paths | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1\r\n"
                    "      }\r\n"
                    "      if (-not $winword) { throw 'No se encontró WINWORD.EXE.' }\r\n"
                    "      Start-Process -FilePath $winword -ArgumentList @('/q','/n',('"'+$source+'"')) | Out-Null\r\n"
                    "      $limit=(Get-Date).AddSeconds(45)\r\n"
                    "      while ((Get-Date) -lt $limit -and $doc -eq $null) {\r\n"
                    "        Start-Sleep -Milliseconds 500\r\n"
                    "        try { $word=[Runtime.InteropServices.Marshal]::GetActiveObject('Word.Application') } catch { continue }\r\n"
                    "        $word.Visible=$false\r\n"
                    "        $word.DisplayAlerts=0\r\n"
                    "        try {\r\n"
                    "          if ($word.Documents.Count -gt 0) { $doc=$word.ActiveDocument }\r\n"
                    "          elseif ($word.ProtectedViewWindows.Count -gt 0) { $doc=$word.ProtectedViewWindows.Item(1).Edit() }\r\n"
                    "        } catch {}\r\n"
                    "      }\r\n"
                    "      if ($doc -eq $null) { throw 'Word se abrió, pero no cargó el documento.' }\r\n"
                    "    }\r\n"
                    "  }\r\n"
                    "  try {\r\n"
                    f"    $doc.ExportAsFixedFormat('{ps_quote(ascii_pdf)}',17)\r\n"
                    "  } catch {\r\n"
                    "    try {\r\n"
                    f"      $doc.SaveAs2('{ps_quote(ascii_pdf)}',17)\r\n"
                    "    } catch {\r\n"
                    f"      $pdfPath='{ps_quote(ascii_pdf)}'\r\n"
                    "      $format=17\r\n"
                    "      $doc.SaveAs([ref]$pdfPath,[ref]$format)\r\n"
                    "    }\r\n"
                    "  }\r\n"
                    f"  if (-not (Test-Path -LiteralPath '{ps_quote(ascii_pdf)}')) {{ throw 'Microsoft Word no creó el archivo PDF.' }}\r\n"
                    "  $doc.Close($false)\r\n"
                    "} finally {\r\n"
                    "  if ($doc -ne $null) { try { $doc.Close($false) } catch {} }\r\n"
                    "  if ($word -ne $null) { try { $word.Quit() } catch {} }\r\n"
                    "}\r\n"
                )
                # Windows PowerShell 5 interpreta correctamente UTF-8 cuando lleva BOM.
                script.write_text('\ufeff'+script_text,encoding='utf-8')
                try:
                    result=subprocess.run(
                        [powershell,'-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',str(script)],
                        stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120
                    )
                    if result.returncode==0 and ascii_pdf.is_file() and ascii_pdf.stat().st_size>100:
                        shutil.copy2(ascii_pdf,pdf_path)
                        return pdf_path
                    stdout=result.stdout.decode('utf-8',errors='replace')[-1000:]
                    stderr=result.stderr.decode('utf-8',errors='replace')[-1600:]
                    errors.append(('Microsoft Word: '+stderr+' '+stdout).strip())
                except Exception as exc:
                    errors.append('Microsoft Word: '+str(exc))

        soffice=find_soffice()
        if soffice:
            try:
                lo_profile=td/'lo_profile'
                lo_profile.mkdir(parents=True,exist_ok=True)
                profile_uri=lo_profile.resolve().as_uri()
                env=os.environ.copy()
                env['HOME']=str(td)
                env['XDG_CONFIG_HOME']=str(td/'xdg_config')
                env['XDG_CACHE_HOME']=str(td/'xdg_cache')
                env['XDG_RUNTIME_DIR']=str(td/'xdg_runtime')
                for key in ('XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_RUNTIME_DIR'):
                    Path(env[key]).mkdir(parents=True,exist_ok=True)
                result=subprocess.run(
                    [
                        str(soffice),
                        f'-env:UserInstallation={profile_uri}',
                        '--headless','--nologo','--nodefault','--nolockcheck','--nofirststartwizard',
                        '--convert-to','pdf','--outdir','.',str(docx_path)
                    ],
                    stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120,env=env,cwd=str(td)
                )
                produced=td/(docx_path.stem+'.pdf')
                if result.returncode==0 and produced.is_file() and produced.stat().st_size>100:
                    shutil.copy2(produced,pdf_path)
                    return pdf_path
                stdout=result.stdout.decode('utf-8',errors='replace')[-1000:]
                stderr=result.stderr.decode('utf-8',errors='replace')[-1600:]
                errors.append(('LibreOffice: '+stderr+' '+stdout).strip())
            except Exception as exc:
                errors.append('LibreOffice: '+str(exc))

    detail=' | '.join(x for x in errors if x)
    raise RuntimeError(
        'No se pudo convertir el Word a PDF. Word no pudo abrir el documento mediante automatización directa ni mediante apertura normal de WINWORD.EXE, y LibreOffice no pudo completar la conversión.'
        +((' Detalle: '+detail) if detail else '')
    )



def find_pdf_browser():
    """Localiza un navegador Chromium compatible con exportación PDF."""
    candidates = []
    if os.name == "nt":
        roots = [
            os.environ.get("PROGRAMFILES", ""),
            os.environ.get("PROGRAMFILES(X86)", ""),
            os.environ.get("LOCALAPPDATA", ""),
        ]
        for root in roots:
            if root:
                candidates.extend([
                    Path(root) / "Google/Chrome/Application/chrome.exe",
                    Path(root) / "Microsoft/Edge/Application/msedge.exe",
                ])
    else:
        for name in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "microsoft-edge", "microsoft-edge-stable"):
            found = shutil.which(name)
            if found:
                candidates.append(Path(found))
    return next((str(path) for path in candidates if Path(path).is_file()), None)


def safe_pdf_name(title: str) -> str:
    clean = re.sub(r'[\\/:*?"<>|]+', "-", title).strip().strip(".")
    return (clean or "documento") + ".pdf"

def slugify(text: str) -> str:
    text = str(text).strip().lower()
    for a, b in {"á":"a","é":"e","í":"i","ó":"o","ú":"u","ü":"u","ñ":"n"}.items():
        text = text.replace(a, b)
    return re.sub(r"[^a-z0-9_-]+", "-", text).strip("-") or "pagina"


def read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else default
    except (OSError, json.JSONDecodeError):
        return default


def write_json(path: Path, value) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def page_file(slug: str) -> Path:
    return PAGES / f"{slugify(slug)}.json"


def load_page(slug: str):
    data = read_json(page_file(slug), None)
    return data if isinstance(data, dict) else None


def all_pages():
    pages = []
    for path in PAGES.glob("*.json"):
        page = load_page(path.stem)
        if page:
            pages.append(page)
    return sorted(pages, key=lambda p: p.get("title", "").casefold())


def page_number(page: dict) -> str:
    """Obtiene el número documental desde la primera línea del contenido."""
    content = str(page.get("content", "")).replace("\r\n", "\n")
    first_non_empty = next((line.strip() for line in content.split("\n") if line.strip()), "")
    match = re.match(r"(?i)^(?:number|n[uú]mero)\s*:\s*(.+?)\s*$", first_non_empty)
    return match.group(1).strip() if match else "—"


HEADER_LABELS = {
    "numero": "Number", "número": "Number", "number": "Number",
    "titulo": "Title", "título": "Title", "title": "Title",
    "version": "Version", "versión": "Version",
    "fecha": "Date", "date": "Date",
    "autor": "Author", "author": "Author",
    "estado": "Status", "status": "Status",
    "clasificacion": "Classification", "clasificación": "Classification", "classification": "Classification",
}

def normalize_document_header(content: str, title: str = "") -> str:
    """Normaliza el encabezado técnico al inglés y sincroniza el título del cuerpo."""
    lines = str(content or "").replace("\r\n", "\n").split("\n")
    seen_title = False
    for i, line in enumerate(lines):
        match = re.match(r"^(\s*)([^:]{2,20})\s*:\s*(.*)$", line)
        if not match:
            continue
        key = match.group(2).strip().casefold()
        english = HEADER_LABELS.get(key)
        if not english:
            continue
        value = match.group(3).strip()
        if english == "Title":
            seen_title = True
            value = f"**{title.strip()}**" if title.strip() else value
        lines[i] = f"{match.group(1)}{english}: {value}".rstrip()
    if title.strip() and not seen_title:
        insert_at = 1 if lines and re.match(r"(?i)^\s*(?:number|n[uú]mero)\s*:", lines[0]) else 0
        lines.insert(insert_at, f"Title: **{title.strip()}**")
    return "\n".join(lines)

def gestor_responsibles():
    rows=read_json(GESTOR_RESPONSIBLES, [])
    if not isinstance(rows,list):
        rows=[]
    return sorted(
        rows,
        key=lambda x:(
            0 if str(x.get("name","")).strip().casefold() in ("emailsecurity","mailsecurity") else 1,
            str(x.get("name","")).strip().casefold()
        )
    )

def page_responsible_ids(page):
    values=page.get("responsible_ids",[])
    if isinstance(values,str):
        values=[x.strip() for x in values.split(",") if x.strip()]
    return [str(x) for x in values if str(x).strip()]

def author_names_from_content(content):
    match=re.search(r"(?im)^\s*(?:Author|Autor)\s*:\s*(.*?)\s*$",str(content or ""))
    if not match:
        return []
    raw=re.sub(r"[*_`]+","",match.group(1))
    return [x.strip() for x in re.split(r"[,;·|]+",raw) if x.strip()]

def selected_author_ids(page):
    selected=page_responsible_ids(page)
    if selected:
        return selected
    existing={x.casefold() for x in author_names_from_content(page.get("content",""))}
    return [
        str(person.get("id"))
        for person in gestor_responsibles()
        if str(person.get("name","")).strip().casefold() in existing
    ]

def author_names_from_ids(ids):
    chosen={str(x) for x in ids}
    return [
        str(person.get("name","")).strip()
        for person in gestor_responsibles()
        if str(person.get("id")) in chosen and str(person.get("name","")).strip()
    ]

def update_document_authors(content, names):
    text=str(content or "").replace("\r\n","\n")
    value=", ".join(names) if names else "A. Garcia"
    line=f"Author: {value}"
    if re.search(r"(?im)^\s*(?:Author|Autor)\s*:",text):
        return re.sub(r"(?im)^\s*(?:Author|Autor)\s*:.*$",line,text,count=1)
    lines=text.split("\n")
    insert_at=1 if lines and re.match(r"(?i)^\s*(?:Number|N[uú]mero)\s*:",lines[0]) else 0
    lines.insert(insert_at,line)
    return "\n".join(lines)


def save_page(title: str, category: str, content: str, tags: str = "", template: str = "", project_id: str = "", responsible_ids=None):
    title = title.strip()
    slug = slugify(title)
    old = load_page(slug) or {}
    now = datetime.now().isoformat(timespec="seconds")
    tag_list = sorted({x.strip() for x in tags.split(",") if x.strip()}, key=str.casefold)
    responsible_ids=[str(x).strip() for x in (responsible_ids or []) if str(x).strip()]
    author_names=author_names_from_ids(responsible_ids)
    normalized_content=normalize_document_header(update_document_authors(content,author_names), title)
    data = {
        "slug": slug,
        "title": title,
        "category": category.strip() or "General",
        "tags": tag_list,
        "template": template.strip(),
        "project_id": project_id.strip(),
        "content": normalized_content,
        "responsible_ids": responsible_ids,
        "created": old.get("created", now),
        "updated": now,
        "views": int(old.get("views", 0)),
        "attachments": old.get("attachments", []) if isinstance(old.get("attachments", []), list) else [],
    }
    write_json(page_file(slug), data)
    ensure_category(data["category"])
    ensure_tags(tag_list)
    return data




def delete_page(slug: str) -> bool:
    slug = slugify(slug)
    path = page_file(slug)
    if not path.exists():
        return False
    try:
        path.unlink()
    except OSError:
        return False

    save_favorites([x for x in load_favorites() if x != slug])
    recents = read_json(RECENTS_FILE, [])
    if isinstance(recents, list):
        write_json(RECENTS_FILE, [x for x in recents if slugify(x) != slug])
    return True


def load_categories():
    categories = read_json(CATEGORIES_FILE, [])
    values = {str(x).strip() for x in categories if str(x).strip()} if isinstance(categories, list) else set()
    values.update(DEFAULT_CATEGORIES)
    values.update(p.get("category", "").strip() for p in all_pages() if p.get("category", "").strip())
    clean = sorted(values, key=str.casefold)
    write_json(CATEGORIES_FILE, clean)
    return clean


def save_categories(values):
    clean = sorted({str(x).strip() for x in values if str(x).strip()}, key=str.casefold)
    write_json(CATEGORIES_FILE, clean)


def ensure_category(category: str):
    category = category.strip()
    if not category:
        return
    categories = load_categories()
    if category.casefold() not in {x.casefold() for x in categories}:
        categories.append(category)
        save_categories(categories)


def load_tags():
    stored = read_json(TAGS_FILE, [])
    values = {str(x).strip() for x in stored if str(x).strip()} if isinstance(stored, list) else set()
    for page in all_pages():
        values.update(str(x).strip() for x in page.get("tags", []) if str(x).strip())
    clean = sorted(values, key=str.casefold)
    write_json(TAGS_FILE, clean)
    return clean


def save_tags(values):
    clean = sorted({str(x).strip() for x in values if str(x).strip()}, key=str.casefold)
    write_json(TAGS_FILE, clean)


def ensure_tags(values):
    current = load_tags()
    known = {x.casefold() for x in current}
    for value in values:
        value = str(value).strip()
        if value and value.casefold() not in known:
            current.append(value); known.add(value.casefold())
    save_tags(current)


def load_favorites():
    values = read_json(FAVORITES_FILE, [])
    return [slugify(x) for x in values] if isinstance(values, list) else []


def save_favorites(values):
    write_json(FAVORITES_FILE, sorted(set(values)))


def add_recent(slug: str):
    values = read_json(RECENTS_FILE, [])
    if not isinstance(values, list):
        values = []
    slug = slugify(slug)
    values = [x for x in values if x != slug]
    values.insert(0, slug)
    write_json(RECENTS_FILE, values[:12])


def recent_pages(limit=6):
    slugs = read_json(RECENTS_FILE, [])
    result = []
    for slug in slugs if isinstance(slugs, list) else []:
        page = load_page(slug)
        if page:
            result.append(page)
        if len(result) >= limit:
            break
    return result


def escape_inline(text: str) -> str:
    text = html.escape(text)
    text = re.sub(
        r"\[\[imagen:([^\]|]+)(?:\|([^\]]+))?\]\]",
        lambda m: (
            f'<figure class="wiki-image"><img src="/uploads/{html.escape(Path(m.group(1).strip()).name, quote=True)}" '
            f'alt="{html.escape((m.group(2) or m.group(1)).strip(), quote=True)}" loading="lazy">'
            f'<figcaption>{html.escape((m.group(2) or "").strip())}</figcaption></figure>'
        ), text, flags=re.I,
    )
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"''(.+?)''", r"<em>\1</em>", text)
    text = re.sub(r"~~(.+?)~~", r"<del>\1</del>", text)
    text = re.sub(r"\[u\](.+?)\[/u\]", r"<u>\1</u>", text, flags=re.I)
    text = re.sub(r"\[azul\](.+?)\[/azul\]", r'<span class="text-blue">\1</span>', text, flags=re.I)
    text = re.sub(r"\[rojo\](.+?)\[/rojo\]", r'<span class="text-red">\1</span>', text, flags=re.I)
    text = re.sub(r"\[amarillo\](.+?)\[/amarillo\]", r'<mark class="highlight-yellow">\1</mark>', text, flags=re.I)
    text = re.sub(r"`([^`]+)`", r"<code class=\"inline-code\">\1</code>", text)
    text = re.sub(r"\[\[([^\]|]+)\|([^\]]+)\]\]", lambda m: f'<a href="/wiki/{slugify(html.unescape(m.group(1)))}">{m.group(2)}</a>', text)
    text = re.sub(r"\[\[([^\]]+)\]\]", lambda m: f'<a href="/wiki/{slugify(html.unescape(m.group(1)))}">{m.group(1)}</a>', text)
    text = re.sub(r"\[(https?://[^\s\]]+)\s+([^\]]+)\]", r'<a href="\1" target="_blank" rel="noopener">\2</a>', text)
    return text


def highlight_code(source: str, language: str) -> str:
    lang = (language or "text").lower()
    escaped = html.escape(source)
    tokens = []

    def protect(pattern, css_class, text, flags=0):
        def repl(match):
            token = chr(0xE000 + len(tokens))
            tokens.append(f'<span class="tok-{css_class}">{match.group(0)}</span>')
            return token
        return re.sub(pattern, repl, text, flags=flags)

    if lang == "json":
        escaped = protect(r'&quot;(?:\\.|[^&])*?&quot;(?=\s*:)', "key", escaped)
        escaped = protect(r'&quot;(?:\\.|[^&])*?&quot;', "string", escaped)
        escaped = protect(r'\b(?:true|false|null)\b', "keyword", escaped, re.I)
        escaped = protect(r'(?<![\w])[-+]?\d+(?:\.\d+)?', "number", escaped)
    elif lang in ("python", "py"):
        escaped = protect(r'&quot;(?:\\.|[^&])*?&quot;|&#x27;(?:\\.|[^&])*?&#x27;', "string", escaped)
        escaped = protect(r'(?m)#.*$', "comment", escaped)
        escaped = protect(r'\b(?:False|None|True|and|as|assert|async|await|break|class|continue|def|del|elif|else|except|finally|for|from|global|if|import|in|is|lambda|nonlocal|not|or|pass|raise|return|try|while|with|yield)\b', "keyword", escaped)
        escaped = protect(r'\b(?:print|len|range|str|int|float|list|dict|set|tuple|open|super|self)\b', "builtin", escaped)
        escaped = protect(r'(?<![\w])\d+(?:\.\d+)?', "number", escaped)
    elif lang in ("spl", "splunk"):
        escaped = protect(r'(?m)#.*$', "comment", escaped)
        escaped = protect(r'&quot;.*?&quot;|&#x27;.*?&#x27;', "string", escaped)
        escaped = protect(r'\|', "pipe", escaped)
        escaped = protect(r'\b(?:search|where|eval|stats|chart|timechart|table|fields|rename|sort|dedup|rex|regex|spath|lookup|inputlookup|outputlookup|eventstats|streamstats|transaction|bin|bucket|makeresults|append|appendcols|join|fillnull|addtotals|xyseries|mvexpand|mvjoin|mvcount|coalesce|count|sum|avg|min|max|dc|values|list|by|as|from)\b', "keyword", escaped, re.I)
        escaped = protect(r'\b(?:AND|OR|NOT|IN)\b', "operator", escaped)
        escaped = protect(r'(?<![\w])\d+(?:\.\d+)?', "number", escaped)
    elif lang in ("cql", "logscale", "crowdstrike", "falcon"):
        # CrowdStrike Next-Gen SIEM / Falcon LogScale query language.
        escaped = protect(r'(?m)//.*$|#.*$', "comment", escaped)
        escaped = protect(r'&quot;(?:\.|[^&])*?&quot;|&#x27;(?:\.|[^&])*?&#x27;', "string", escaped)
        escaped = protect(r'\|', "pipe", escaped)
        escaped = protect(r'\b(?:case|caseSensitive|cidr|collect|concat|count|defineTable|drop|end|eventSize|fieldstats|format|groupBy|head|in|join|match|parseCsv|parseJson|parseRegex|parseTimestamp|rename|replace|select|selfJoin|sort|splitString|start|stats|table|tail|test|timeChart|top|transpose|where|wildcard|writeJson|as|by|function)\b', "keyword", escaped, re.I)
        escaped = protect(r'\b(?:and|or|not|true|false|null)\b', "operator", escaped, re.I)
        escaped = protect(r'(?<![\w])[-+]?\d+(?:\.\d+)?', "number", escaped)
    elif lang == "sql":
        escaped = protect(r'--.*$', "comment", escaped, re.M)
        escaped = protect(r'&quot;.*?&quot;|&#x27;.*?&#x27;', "string", escaped)
        escaped = protect(r'\b(?:SELECT|FROM|WHERE|JOIN|LEFT|RIGHT|INNER|OUTER|ON|GROUP|BY|ORDER|HAVING|INSERT|INTO|UPDATE|DELETE|CREATE|ALTER|DROP|TABLE|VIEW|AS|AND|OR|NOT|NULL|IS|IN|LIKE|DISTINCT|COUNT|SUM|AVG|MIN|MAX|CASE|WHEN|THEN|ELSE|END|LIMIT)\b', "keyword", escaped, re.I)
        escaped = protect(r'(?<![\w])\d+(?:\.\d+)?', "number", escaped)
    elif lang in ("powershell", "ps1"):
        escaped = protect(r'(?m)#.*$', "comment", escaped)
        escaped = protect(r'&quot;.*?&quot;|&#x27;.*?&#x27;', "string", escaped)
        escaped = protect(r'\$[A-Za-z_][\w:]*', "variable", escaped)
        escaped = protect(r'\b(?:function|param|if|elseif|else|foreach|for|while|switch|return|try|catch|finally|throw|class|filter|begin|process|end)\b', "keyword", escaped, re.I)
        escaped = protect(r'\b[A-Za-z]+-[A-Za-z]+\b', "builtin", escaped)
    elif lang in ("html", "xml"):
        escaped = protect(r'&lt;!--.*?--&gt;', "comment", escaped, re.S)
        escaped = protect(r'&lt;/?[A-Za-z][^&]*?&gt;', "tag", escaped)
    elif lang in ("bash", "shell", "sh"):
        escaped = protect(r'(?m)#.*$', "comment", escaped)
        escaped = protect(r'&quot;.*?&quot;|&#x27;.*?&#x27;', "string", escaped)
        escaped = protect(r'\$\{?\w+\}?', "variable", escaped)
        escaped = protect(r'\b(?:if|then|else|elif|fi|for|while|do|done|case|esac|function|in|echo|export|source|cd|pwd|read)\b', "keyword", escaped)

    for i, value in enumerate(tokens):
        escaped = escaped.replace(chr(0xE000 + i), value)
    return escaped


def render_leading_indent(raw_line: str, formatted_text: str) -> str:
    """Conserva tabuladores y espacios iniciales en HTML, vista previa y PDF."""
    expanded = raw_line.expandtabs(4)
    leading = len(expanded) - len(expanded.lstrip(" "))
    if not leading:
        return formatted_text
    return '<span class="text-indent">' + ('&#160;' * leading) + '</span>' + formatted_text


def render(src: str) -> str:
    out, para, code = [], [], []
    in_code, language, list_tag = False, "", None

    def flush_para():
        nonlocal para
        if para:
            rendered_lines = []
            for raw_line in para:
                content_line = raw_line.rstrip()
                clean_line = content_line.lstrip()
                field_match = re.match(r"(?i)^([^:]{2,20})\s*:\s*(.*)$", clean_line)
                field_key = field_match.group(1).strip().casefold() if field_match else ""
                field_label = HEADER_LABELS.get(field_key)
                if field_match and field_label == "Number":
                    rendered_lines.append(
                        '<span class="document-number-line"><span class="document-number-label">Number:</span> '
                        + '<span class="document-number-value">' + escape_inline(field_match.group(2).strip()) + '</span>'
                        + '</span>'
                    )
                elif field_match and field_label:
                    value_html = escape_inline(field_match.group(2).strip())
                    if field_label == "Title":
                        value_html = '<strong>' + re.sub(r"^<strong>|</strong>$", "", value_html) + '</strong>'
                    rendered_lines.append(
                        '<span class="document-header-line"><span class="document-header-label">'
                        + field_label + ':</span> <span class="document-header-value">' + value_html + '</span></span>'
                    )
                else:
                    rendered_lines.append(render_leading_indent(content_line, escape_inline(clean_line)))
            out.append("<p>" + "<br>".join(rendered_lines) + "</p>")
            para = []

    def close_list():
        nonlocal list_tag
        if list_tag:
            out.append(f"</{list_tag}>")
            list_tag = None

    lines = src.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if in_code:
            if line.strip() == "```":
                highlighted = highlight_code("\n".join(code), language)
                raw = html.escape("\n".join(code), quote=True)
                normalized_language = (language or "text").lower()
                is_crowdstrike = normalized_language in ("cql", "logscale", "crowdstrike", "falcon")
                code_label = "CrowdStrike Next-Gen SIEM · CQL" if is_crowdstrike else (language or "código")
                extra_class = " code-wrap-crowdstrike" if is_crowdstrike else ""
                out.append(
                    f'<div class="code-wrap{extra_class}"><div class="code-head"><span>{html.escape(code_label)}</span>'
                    f'<span class="code-actions"><button type="button" class="toggle-code">Contraer</button>'
                    f'<button type="button" class="copy-code" data-code="{raw}">Copiar</button></span></div>'
                    f'<pre class="code-box language-{html.escape(normalized_language)}"><code>{highlighted}</code></pre></div>'
                )
                in_code, language, code = False, "", []
            else:
                code.append(line)
            i += 1
            continue

        stripped = line.strip()

        communication_match = re.fullmatch(r":::\s*(email|correo|example|ejemplo|caso|respuesta)(?:\s+(.+))?", stripped, re.I)
        if communication_match:
            flush_para(); close_list()
            kind = communication_match.group(1).casefold()
            kind = {"email":"correo", "example":"correo", "ejemplo":"correo"}.get(kind, kind)
            default_title = {"correo":"Correo", "caso":"Caso", "respuesta":"Respuesta"}[kind]
            title = (communication_match.group(2) or default_title).strip()
            block=[]; j=i+1
            end_pattern = rf":::\s*end(?:{re.escape(kind)}|email|correo|example|ejemplo|caso|respuesta)\s*"
            while j < len(lines) and not re.fullmatch(end_pattern, lines[j].strip(), re.I):
                block.append(lines[j]); j += 1

            if kind == "correo":
                fields = {"para":"", "cc":"", "cco":"", "asunto":""}
                body_lines=[]; in_body=False
                for item in block:
                    match = re.match(r"^\s*(Para|To|CC|CCO|BCC|Asunto|Subject)\s*:\s*(.*)$", item, re.I)
                    if match and not in_body:
                        key=match.group(1).casefold()
                        key={"to":"para","bcc":"cco","subject":"asunto"}.get(key,key)
                        fields[key]=match.group(2)
                    else:
                        if item.strip() or body_lines: in_body=True
                        body_lines.append(item)
                meta=''.join(f'<div class="email-field"><strong>{label}:</strong><span>{escape_inline(fields[key])}</span></div>' for key,label in (("para","Para"),("cc","CC"),("cco","CCO"),("asunto","Asunto")))
                content="<br>".join(escape_inline(x) for x in body_lines).strip()
                out.append(f'<div class="email-example communication-correo"><div class="email-example-title">{html.escape(title)}</div><div class="email-example-meta">{meta}</div><div class="email-example-body">{content}</div></div>')
            elif kind == "caso":
                case_title=""; body_lines=[]
                for item in block:
                    m=re.match(r"^\s*(Título|Titulo|Title)\s*:\s*(.*)$", item, re.I)
                    if m and not case_title and not body_lines: case_title=m.group(2)
                    else: body_lines.append(item)
                content="<br>".join(escape_inline(x) for x in body_lines).strip()
                out.append(f'<div class="email-example communication-case"><div class="email-example-title">{html.escape(title)}</div><div class="case-field"><strong>Título:</strong><span>{escape_inline(case_title)}</span></div><div class="email-example-body">{content}</div></div>')
            else:
                content="<br>".join(escape_inline(x) for x in block).strip()
                out.append(f'<div class="email-example communication-response"><div class="email-example-title">{html.escape(title)}</div><div class="email-example-body">{content}</div></div>')
            i = j + 1 if j < len(lines) else j
            continue

        # Bloques de diseño en columnas. Sintaxis:
        # ::: columns 50/50
        # ::: column
        # Contenido izquierdo
        # ::: column
        # Contenido derecho
        # ::: endcolumns
        columns_match = re.fullmatch(r":::\s*columns(?:\s+([0-9]{1,2})\s*[/\-]\s*([0-9]{1,2})|\s+(3))?\s*", stripped, re.I)
        if columns_match:
            flush_para(); close_list()
            if columns_match.group(3):
                expected_columns = 3
                layout_class = "columns-3"
            else:
                left = int(columns_match.group(1) or 50)
                right = int(columns_match.group(2) or (100 - left))
                if left + right != 100 or left < 20 or right < 20:
                    left, right = 50, 50
                expected_columns = 2
                layout_class = f"columns-{left}-{right}"

            j = i + 1
            column_parts = []
            current = []
            found_end = False
            while j < len(lines):
                marker = lines[j].strip().casefold()
                if marker == "::: endcolumns":
                    if current or not column_parts:
                        column_parts.append(current)
                    found_end = True
                    j += 1
                    break
                if marker in ("::: column", "::: left", "::: right"):
                    if current:
                        column_parts.append(current)
                        current = []
                    j += 1
                    continue
                current.append(lines[j])
                j += 1

            if not found_end:
                # Si falta el cierre, no se pierde contenido: el bloque llega hasta el final.
                if current or not column_parts:
                    column_parts.append(current)

            column_parts = [part for part in column_parts if any(x.strip() for x in part)]
            while len(column_parts) < expected_columns:
                column_parts.append([])
            if len(column_parts) > expected_columns:
                merged = column_parts[:expected_columns - 1]
                tail = []
                for part in column_parts[expected_columns - 1:]:
                    if tail:
                        tail.append("")
                    tail.extend(part)
                column_parts = merged + [tail]

            cells = []
            for part in column_parts[:expected_columns]:
                cells.append('<div class="doc-column">' + render("\n".join(part)) + '</div>')
            unclosed = ' columns-unclosed' if not found_end else ''
            out.append(f'<div class="doc-columns {layout_class}{unclosed}">' + "".join(cells) + '</div>')
            i = j
            continue

        if stripped.startswith("```"):
            flush_para(); close_list(); in_code = True; language = stripped[3:].strip(); i += 1; continue
        labelled_separator = re.fullmatch(r"-{3,}\s*\[([^]\n]+)\]\s*-{3,}", stripped)
        if labelled_separator:
            flush_para(); close_list()
            out.append('<div class="doc-separator separator-labelled"><span>' + escape_inline(labelled_separator.group(1).strip()) + '</span></div>')
            i += 1; continue
        if re.fullmatch(r"={4,}", stripped):
            flush_para(); close_list(); out.append('<hr class="doc-separator separator-thick">'); i += 1; continue
        if re.fullmatch(r"(?:-\s+){3,}-?", stripped):
            flush_para(); close_list(); out.append('<hr class="doc-separator separator-dashed">'); i += 1; continue
        if re.fullmatch(r"-{4,}", stripped):
            flush_para(); close_list(); out.append('<hr class="doc-separator separator-thin">'); i += 1; continue
        heading = re.match(r"^(={2,6})\s*(.*?)\s*\1$", stripped)
        if heading:
            flush_para(); close_list(); level = min(len(heading.group(1)), 6); title = heading.group(2)
            out.append(f'<h{level} id="{slugify(title)}">{escape_inline(title)}</h{level}>'); i += 1; continue

        notice = re.match(r"^!!!\s+([^\s:]+)\s*(:)?\s*(.*)$", stripped, re.I)
        if notice:
            flush_para(); close_list()
            raw_kind = notice.group(1).casefold()
            has_colon = bool(notice.group(2))
            inline_text = notice.group(3).strip()
            kind_map = {
                'advertencia': ('advertencia', 'Advertencia'), 'warning': ('advertencia', 'Advertencia'),
                'nota': ('nota', 'Nota'), 'note': ('nota', 'Nota'),
                'informacion': ('informacion', 'Información'), 'información': ('informacion', 'Información'),
                'information': ('informacion', 'Información')
            }
            kind, label = kind_map.get(raw_kind, (slugify(raw_kind), raw_kind.title()))
            body_lines = []
            if has_colon:
                if inline_text:
                    body_lines.append(inline_text)
                j = i + 1
                explicit_close = None
                while j < len(lines):
                    if lines[j].strip() == "!!!":
                        explicit_close = j
                        break
                    j += 1

                if explicit_close is not None:
                    body_lines.extend(lines[i + 1:explicit_close])
                    j = explicit_close + 1
                else:
                    # Compatibilidad con documentos antiguos: si no existe cierre
                    # explícito, termina al encontrar el siguiente bloque estructural.
                    j = i + 1
                    while j < len(lines):
                        probe = lines[j].strip()
                        boundary = (
                            probe.startswith('!!! ') or
                            bool(re.match(r"^(={2,6})\s*(.*?)\s*\1$", probe)) or
                            bool(re.fullmatch(r"-{3,}\s*\[([^]\n]+)\]\s*-{3,}", probe)) or
                            bool(re.fullmatch(r"={4,}", probe)) or
                            bool(re.fullmatch(r"(?:-\s+){3,}-?", probe)) or
                            bool(re.fullmatch(r"-{4,}", probe))
                        )
                        if boundary and any(x.strip() for x in body_lines):
                            break
                        body_lines.append(lines[j])
                        j += 1

                while body_lines and not body_lines[-1].strip():
                    body_lines.pop()
                body_html = render("\n".join(body_lines)) if body_lines else ''
                missing_class = ' admonition-unclosed' if explicit_close is None else ''
                out.append(f'<div class="admonition {kind}{missing_class}"><div class="admonition-title">{escape_inline(label)}</div><div class="admonition-body">{body_html}</div></div>')
                i = j
                continue
            # Compatibilidad con el formato antiguo de una sola línea.
            title = inline_text or label
            out.append(f'<div class="admonition {kind}"><div class="admonition-title">{escape_inline(title)}</div></div>')
            i += 1
            continue

        # Tablas con sintaxis de barras verticales. Ejemplo:
        # | Columna 1 | Columna 2 |
        # | --- | --- |
        # | Dato 1 | Dato 2 |
        if stripped.startswith("|") and stripped.endswith("|") and i + 1 < len(lines):
            separator = lines[i + 1].strip()
            if separator.startswith("|") and separator.endswith("|"):
                sep_cells = [cell.strip() for cell in separator.strip("|").split("|")]
                if sep_cells and all(re.fullmatch(r":?-{3,}:?", cell) for cell in sep_cells):
                    flush_para(); close_list()
                    headers = [cell.strip() for cell in stripped.strip("|").split("|")]
                    rows = []
                    j = i + 2
                    while j < len(lines):
                        row_line = lines[j].strip()
                        if not (row_line.startswith("|") and row_line.endswith("|")):
                            break
                        cells = [cell.strip() for cell in row_line.strip("|").split("|")]
                        rows.append(cells)
                        j += 1
                    head_html = "".join("<th>" + escape_inline(cell) + "</th>" for cell in headers)
                    row_html = []
                    for cells in rows:
                        padded = cells + [""] * max(0, len(headers) - len(cells))
                        row_html.append("<tr>" + "".join("<td>" + escape_inline(cell) + "</td>" for cell in padded[:len(headers)]) + "</tr>")
                    out.append('<div class="table-scroll"><table class="wiki-table"><thead><tr>' + head_html + '</tr></thead><tbody>' + "".join(row_html) + '</tbody></table></div>')
                    i = j
                    continue

        if re.match(r"^\s*[-*]\s+", line):
            flush_para()
            if list_tag != "ul": close_list(); list_tag = "ul"; out.append("<ul>")
            out.append("<li>" + escape_inline(re.sub(r"^\s*[-*]\s+", "", line)) + "</li>"); i += 1; continue
        if re.match(r"^\s*\d+\.\s+", line):
            flush_para()
            if list_tag != "ol": close_list(); list_tag = "ol"; out.append("<ol>")
            out.append("<li>" + escape_inline(re.sub(r"^\s*\d+\.\s+", "", line)) + "</li>"); i += 1; continue
        if stripped.startswith(">"):
            flush_para(); close_list(); out.append("<blockquote>" + escape_inline(stripped[1:].strip()) + "</blockquote>"); i += 1; continue
        if not stripped:
            flush_para(); close_list(); i += 1; continue
        para.append(line)
        i += 1

    flush_para(); close_list()
    if in_code:
        highlighted = highlight_code("\n".join(code), language)
        out.append(f'<pre class="code-box"><code>{highlighted}</code></pre>')
    return "\n".join(out)


DEFAULT_TEMPLATES = [
  {
    "id": "procedimiento",
    "name": "Procedimiento técnico",
    "code": "PROC",
    "content": "Number: PROC-\nTitle: \nVersion: \nDate: \nAuthor: \nStatus: \nClassification: \n\n------------------------\n== Objetivo ==\n\n\n\n== Requisitos ==\n\n\n\n== Pasos ==\n\n\n\n== Código o comandos ==\n\n\n\n== Resultado esperado ==\n\n\n\n== Errores frecuentes ==\n\n!!! advertencia Precaución\n\n\n== Rollback ==\n\n\n"
  },
  {
    "id": "tareas",
    "name": "Tareas",
    "code": "TAR",
    "content": "Number: TAR-\nTitle: \nVersion: \nDate: \nAuthor: \nStatus: \nClassification: \n\n------------------------\n== Objetivo ==\n\n\n\n== Requisitos ==\n\n\n\n== Pasos ==\n\n\n\n== Código o comandos ==\n\n\n\n== Resultado esperado ==\n\n\n\n== Errores frecuentes ==\n\n!!! advertencia Precaución\n\n\n== Rollback ==\n\n\n"
  },
  {
    "id": "ces",
    "name": "Procedimiento CES",
    "code": "CES",
    "content": "Number: CES-\nTitle: \nVersion: \nDate: \nAuthor: \nStatus: \nClassification: \n\n------------------------\n== Objetivo ==\n\nDescribe qué se quiere conseguir.\n\n== Requisitos ==\n\n- Acceso necesario\n- Permisos necesarios\n\n== Pasos ==\n\n1. Primer paso\n2. Segundo paso\n\n== Código o comandos ==\n\n```text\nComando o consulta\n```\n\n== Resultado esperado ==\n\nDescribe el resultado correcto.\n\n== Errores frecuentes ==\n\n!!! advertencia Precaución\nAñade aquí los riesgos o errores conocidos.\n\n== Rollback ==\n\nExplica cómo deshacer el cambio.\n"
  },
  {
    "id": "proofpoint",
    "name": "Procedimiento ProofPoint",
    "code": "PRF",
    "content": "Number: PRF-\nTitle: \nVersion: \nDate: \nAuthor: \nStatus: \nClassification: \n\n------------------------\n== Objetivo ==\n\nDescribe qué se quiere conseguir.\n\n== Requisitos ==\n\n- Acceso necesario\n- Permisos necesarios\n\n== Pasos ==\n\n1. Primer paso\n2. Segundo paso\n\n== Código o comandos ==\n\n```text\nComando o consulta\n```\n\n== Resultado esperado ==\n\nDescribe el resultado correcto.\n\n== Errores frecuentes ==\n\n!!! advertencia Precaución\nAñade aquí los riesgos o errores conocidos.\n\n== Rollback ==\n\nExplica cómo deshacer el cambio.\n"
  },
  {
    "id": "correos",
    "name": "Respuestas correos",
    "code": "COR",
    "content": "Number: COR-\nTitle: \nVersion: \nDate: \nAuthor: \nStatus: \nClassification: \n\n------------------------\n== Objetivo ==\n\n\n\n== Requisitos ==\n\n\n\n== Pasos ==\n\n\n\n== Código o comandos ==\n\n\n\n== Resultado esperado ==\n\n\n\n== Errores frecuentes ==\n\n!!! advertencia Precaución\n\n\n== Rollback ==\n\n\n"
  },
  {
    "id": "snow",
    "name": "Peticiones SNOW",
    "code": "SNW",
    "content": "Number: SNW-\nTitle: \nVersion: \nDate: \nAuthor: \nStatus: \nClassification: \n\n------------------------\n== Objetivo ==\n\n\n\n== Requisitos ==\n\n\n\n== Pasos ==\n\n\n\n== Código o comandos ==\n\n\n\n== Resultado esperado ==\n\n\n\n== Errores frecuentes ==\n\n!!! advertencia Precaución\n\n\n== Rollback ==\n\n\n"
  },
  {
    "id": "splunk",
    "name": "Búsqueda Splunk",
    "code": "SPL",
    "content": "Number: SPL-\nTitle: \nVersion: \nDate: \nAuthor: \nStatus: \nClassification: \n\n------------------------\n== Objetivo de la búsqueda ==\n\n== Origen de datos ==\n\n- Índice:\n- Sourcetype:\n\n== Consulta SPL ==\n\n```spl\nindex=ejemplo\n| stats count by host\n| sort - count\n```\n\n== Campos de salida ==\n\n== Interpretación ==\n"
  },
  {
    "id": "falcon",
    "name": "Búsqueda Falcon",
    "code": "CSF",
    "content": "Number: CSF-\nTitle: \nVersion: \nDate: \nAuthor: \nStatus: \nClassification: \n\n------------------------\n== Objetivo ==\n\nDescribe qué se quiere conseguir.\n\n== Requisitos ==\n\n- Acceso necesario\n- Permisos necesarios\n\n== Pasos ==\n\n1. Primer paso\n2. Segundo paso\n\n== Código o comandos ==\n\n```text\nComando o consulta\n```\n\n== Resultado esperado ==\n\nDescribe el resultado correcto.\n\n== Errores frecuentes ==\n\n!!! advertencia Precaución\nAñade aquí los riesgos o errores conocidos.\n\n== Rollback ==\n\nExplica cómo deshacer el cambio.\n"
  },
  {
    "id": "incidencia",
    "name": "Informe de incidencia",
    "code": "INC",
    "content": "Number: INC-\nTitle: \nVersion: \nDate: \nAuthor: \nStatus: \nClassification: \n\n------------------------\n== Resumen ==\n\n== Impacto ==\n\n== Línea temporal ==\n\n== Diagnóstico ==\n\n== Acciones realizadas ==\n\n== Solución ==\n\n== Prevención ==\n"
  }
]

def load_templates():
    data = read_json(TEMPLATES_FILE, None)
    if not isinstance(data, list):
        data = DEFAULT_TEMPLATES
        write_json(TEMPLATES_FILE, data)
    clean=[]
    for item in data:
        if not isinstance(item, dict):
            continue
        tid=slugify(item.get("id") or item.get("name") or "plantilla")
        clean.append({"id":tid,"name":str(item.get("name") or tid).strip(),"code":re.sub(r"[^A-Za-z0-9]","",str(item.get("code") or "DOC")).upper()[:12] or "DOC","content":str(item.get("content") or "")})
    return clean

def save_templates(items):
    write_json(TEMPLATES_FILE, items)

def template_by_id(name):
    key=slugify(name)
    return next((x for x in load_templates() if x.get("id")==key),None)

def next_document_number(code):
    code=re.sub(r"[^A-Za-z0-9]","",str(code)).upper() or "DOC"
    date_part=datetime.now().strftime("%y%m%d")
    prefix=f"{code}-{date_part}"
    used=set(); pattern=re.compile(rf"(?i)^(?:number|n[uú]mero)\s*:\s*{re.escape(prefix)}(\d{{2}})\s*$")
    for page in all_pages():
        for line in str(page.get("content","")).replace("\r\n","\n").split("\n")[:8]:
            m=pattern.match(line.strip())
            if m:
                used.add(int(m.group(1))); break
    for seq in range(1,100):
        if seq not in used:
            return f"{prefix}{seq:02d}"
    return f"{prefix}99"

def apply_template_number(content, code):
    number=next_document_number(code)
    lines=str(content).replace("\r\n","\n").split("\n")
    for i,line in enumerate(lines):
        if re.match(r"(?i)^\s*(?:number|n[uú]mero)\s*:",line):
            lines[i]=f"Number: {number}"; return "\n".join(lines)
        if line.strip():
            break
    return f"Number: {number}\n"+"\n".join(lines)

def apply_template_defaults(content, code, autonumber=True):
    """Completa los metadatos de una plantilla al crear un documento nuevo."""
    text = apply_template_number(content, code) if autonumber else str(content or "")
    today = datetime.now().strftime("%Y-%m-%d")
    replacements = {
        "version": "Version: 1.0",
        "date": f"Date: {today}",
        "author": "Author: A. Garcia",
    }
    lines = text.replace("\r\n", "\n").split("\n")
    found = set()
    for index, line in enumerate(lines):
        match = re.match(r"(?i)^\s*(version|date|author)\s*:\s*(.*)$", line)
        if match:
            key = match.group(1).casefold()
            found.add(key)
            # En documentos nuevos se aplican siempre los valores corporativos solicitados.
            lines[index] = replacements[key]
    insert_at = 1 if lines and re.match(r"(?i)^\s*(?:number|n[uú]mero)\s*:", lines[0]) else 0
    for key in ("version", "date", "author"):
        if key not in found:
            lines.insert(insert_at, replacements[key])
            insert_at += 1
    return "\n".join(lines)


def template_content(name, autonumber=True):
    item=template_by_id(name)
    if not item:
        return ""
    return apply_template_defaults(item.get("content", ""), item.get("code", "DOC"), autonumber)


def sidebar(active=""):
    categories = load_categories()
    favorites = [load_page(x) for x in load_favorites()]
    favorites = [x for x in favorites if x]
    recents = recent_pages(5)
    main_links=[('Inicio',PORTAL_URL),('Wiki','/'),('Proyectos y tareas',GESTOR_URL),('BAU',BAU_URL),('Bitácora',BITACORA_URL),('Biblioteca',BIBLIOTECA_URL),('Plantillas',CAMBIOS_URL)]
    main_nav=''.join(f'<a class="{"active" if n=="Wiki" else ""}" href="{html.escape(u,quote=True)}">{html.escape(n)}</a>' for n,u in main_links)
    cat_links = "".join(f'<a class="category-link" href="/category/{quote(c)}">{html.escape(c)}</a>' for c in categories)
    tag_links = "".join(f'<a class="tag-filter-link" href="/tags?tag={quote(t)}">#{html.escape(t)}</a>' for t in load_tags()[:12])
    fav_links = "".join(f'<a href="/wiki/{p["slug"]}">★ {html.escape(p["title"])}</a>' for p in favorites) or '<span class="empty-menu">Sin favoritos</span>'
    recent_links = "".join(f'<a href="/wiki/{p["slug"]}">{html.escape(p["title"])}</a>' for p in recents) or '<span class="empty-menu">Sin páginas recientes</span>'
    return f'''<aside><nav>{main_nav}<div class="menu-title">Wiki</div><a href="/new">＋ Nueva página</a><a href="/import-word">⇩ Importar Word</a><a href="/help">? Ayuda</a><div class="menu-title">Categorías</div><div class="category-menu">{cat_links}</div><a class="manage-link" href="/manage-categories">⚙ Gestionar categorías</a><div class="menu-title">Etiquetas</div><div class="tag-menu">{tag_links or '<span class="empty-menu">Sin etiquetas</span>'}</div><a class="manage-link" href="/tags">🔎 Filtrar por etiquetas</a><a class="manage-link" href="/manage-tags">⚙ Gestionar etiquetas</a><a class="manage-link" href="/manage-templates">📝 Gestionar plantillas</a><div class="menu-title">Favoritos</div>{fav_links}<div class="menu-title">Recientes</div>{recent_links}</nav><div class="aside-note">Aplicación local<br>Sin usuarios<br>Datos en JSON</div></aside>'''


def layout(title: str, body: str, active=""):
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)} · Wiki Procedimientos</title><link rel="stylesheet" href="/static/style.css?v={APP_VERSION}"><style>{CORPORATE_THEME_CSS}</style>
<style>
/* V27.3 · Logotipo adaptable al espacio disponible */
header{{
  min-height:72px!important;
  height:auto!important;
  overflow:visible!important;
}}
.brand{{
  min-height:56px!important;
  max-width:min(70vw,760px)!important;
  display:flex!important;
  align-items:center!important;
  gap:14px!important;
  overflow:visible!important;
}}
.brand::before{{
  display:none!important;
  content:none!important;
  background-image:none!important;
}}
.brand .brand-logo{{
  display:block!important;
  width:auto!important;
  height:auto!important;
  min-width:0!important;
  min-height:0!important;
  max-width:210px!important;
  max-height:56px!important;
  flex:0 1 auto!important;
  object-fit:contain!important;
  object-position:left center!important;
  background:transparent!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
}}
.brand>span{{
  display:block!important;
  min-width:0!important;
  overflow:hidden!important;
  text-overflow:ellipsis!important;
}}
@media(max-width:760px){{
  header{{min-height:64px!important;padding:8px 14px!important}}
  .brand{{min-height:46px!important;gap:10px!important;max-width:76vw!important}}
  .brand .brand-logo{{
    width:auto!important;
    height:auto!important;
    max-width:145px!important;
    max-height:46px!important;
  }}
}}
@media(max-width:480px){{
  .brand .brand-logo{{max-width:105px!important;max-height:42px!important}}
  .brand>span{{font-size:15px!important}}
}}
</style>

<style>
/* V27.7 · Editor Wiki compacto */
header{{min-height:58px!important;padding:6px 16px!important}}
.brand{{min-height:44px!important;max-width:min(62vw,680px)!important;gap:10px!important}}
.brand .brand-logo{{max-width:150px!important;max-height:40px!important;width:auto!important;height:auto!important;object-fit:contain!important}}
main{{padding-top:12px!important}}
main>h1{{margin:0 0 10px!important;font-size:25px!important}}
.editor{{gap:8px!important}}
.editor-meta-row{{display:grid!important;grid-template-columns:minmax(320px,2fr) minmax(160px,.65fr) minmax(240px,1fr)!important;gap:10px 12px!important;align-items:end!important;margin-bottom:8px!important}}
.editor-meta-row label{{margin:0!important}}
.editor-project-authors-row{{display:grid!important;grid-template-columns:minmax(260px,1fr) minmax(320px,1.2fr)!important;gap:12px!important;margin:0 0 8px!important}}
.editor textarea,.editor input,.editor select{{padding:8px!important}}
.editor-toolbar{{margin-top:6px!important}}
.editor-shell,.editor-area{{margin-top:4px!important}}
@media(max-width:900px){{.editor-meta-row,.editor-project-authors-row{{grid-template-columns:1fr!important}}.brand .brand-logo{{max-width:115px!important}}
</style>

<style>
/* V27.11 · Metadatos Wiki compactos y selector múltiple de autores */
.editor-meta-top{{
  display:grid!important;
  grid-template-columns:minmax(420px,2.15fr) minmax(210px,.7fr) minmax(300px,1fr)!important;
  gap:10px 12px!important;
  align-items:start!important;
  margin:0 0 10px!important;
}}
.editor-project-authors-row{{
  display:grid!important;
  grid-template-columns:minmax(360px,1fr) minmax(420px,1.25fr)!important;
  gap:12px!important;
  align-items:start!important;
  margin:0 0 10px!important;
}}
.editor-project-field,.editor-authors-field{{margin:0!important;min-width:0}}
.field-label{{display:block;font-weight:600;margin-bottom:5px}}
.author-multiselect{{position:relative;width:100%}}
.author-multiselect summary{{
  min-height:38px;display:flex;align-items:center;justify-content:space-between;
  gap:10px;padding:8px 11px;border:1px solid #8a9097;border-radius:6px;
  background:#fff;cursor:pointer;list-style:none;
}}
.author-multiselect summary::-webkit-details-marker{{display:none}}
#author-summary{{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}}
.author-arrow{{flex:0 0 auto}}
.author-options{{
  position:absolute;z-index:100;top:calc(100% + 4px);left:0;right:0;
  max-height:260px;overflow:auto;padding:7px;background:#fff;
  border:1px solid #b8bec5;border-radius:7px;box-shadow:0 8px 24px rgba(0,0,0,.16);
}}
.author-check{{
  display:flex!important;align-items:center!important;gap:8px!important;
  padding:7px 8px!important;margin:0!important;border-radius:5px;cursor:pointer;
}}
.author-check:hover{{background:#fdecec}}
.author-check input{{width:16px!important;height:16px!important;flex:0 0 16px;margin:0!important}}
.author-check span{{display:inline!important;line-height:1.2}}
.editor-authors-field small{{display:block;margin-top:4px;color:#666}}
@media(max-width:1050px){{
  .editor-meta-top{{grid-template-columns:1fr 240px!important}}
  .editor-tags-field{{grid-column:1/-1}}
}}
@media(max-width:800px){{
  .editor-meta-top,.editor-project-authors-row{{grid-template-columns:1fr!important}}
  .author-options{{position:static;margin-top:5px}}
}}
</style>
</head>
<body><header><div class="brand"><img class="brand-logo" src="/logo.png?v=27112" alt="Logo Santander" onerror="this.style.display=\'none\'"><span>Santander Mail Security · Wiki <small style="font-size:10px;opacity:.8">V2.6</small></span></div><div class="header-actions"><a class="btn" href="/">← Atrás</a><a class="btn" href="{html.escape(PORTAL_URL, quote=True)}">Inicio común</a><a class="btn primary" href="/new">+ Nueva página</a></div></header>
<div class="shell">{sidebar(active)}<main>{body}</main></div><footer>Wiki local · Versión {APP_VERSION} · Python sin dependencias externas</footer>
<script src="/static/editor.js?v={APP_VERSION}"></script><script src="/static/preview.js?v={APP_VERSION}"></script>
<script>
document.addEventListener('DOMContentLoaded',function(){{
  const details=document.getElementById('author-multiselect');
  const hidden=document.getElementById('responsible-ids-field');
  const summary=document.getElementById('author-summary');
  const checks=Array.from(document.querySelectorAll('.author-checkbox'));
  function updateAuthors(){{
    const selected=checks.filter(x=>x.checked);
    if(hidden)hidden.value=selected.map(x=>x.value).join(',');
    if(summary)summary.textContent=selected.length
      ? selected.map(x=>x.dataset.authorName||'').filter(Boolean).join(', ')
      : 'Seleccionar autores';
  }}
  checks.forEach(x=>x.addEventListener('change',updateAuthors));
  updateAuthors();
  document.addEventListener('click',function(event){{
    if(details&&details.open&&!details.contains(event.target))details.open=false;
  }});
}});
</script>
</body></html>'''




def corporate_logo_path():
    """Devuelve siempre el logo corporativo de la carpeta raíz del proyecto."""
    source=Path(__file__).resolve()
    try:
        app_root=source.parents[2]
    except IndexError:
        app_root=source.parent
    candidates=[
        app_root/"configuracion"/"logo"/"logo.png",
        source.parent/"logo.png",
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None

def serve_corporate_logo(handler):
    path = corporate_logo_path()
    if path is None:
        handler.send_response(404)
        handler.end_headers()
        return
    data = path.read_bytes()
    handler.send_response(200)
    handler.send_header("Content-Type", "image/png")
    handler.send_header("Content-Length", str(len(data)))
    handler.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
    handler.end_headers()
    handler.wfile.write(data)

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print(f"[{datetime.now():%H:%M:%S}] {fmt % args}")

    def send_html(self, content, status=200):
        data = content.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers(); self.wfile.write(data)

    def send_json(self, payload, status=200):
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers(); self.wfile.write(data)

    def redirect(self, path):
        self.send_response(303); self.send_header("Location", path); self.end_headers()

    def read_form(self):
        length = int(self.headers.get("Content-Length", "0") or 0)
        raw = self.rfile.read(length).decode("utf-8", errors="replace")
        return {k: v[-1] for k, v in parse_qs(raw, keep_blank_values=True).items()}

    def serve_file(self, path: Path):
        if not path.is_file():
            return self.send_error(404)
        data = path.read_bytes(); mime, _ = mimetypes.guess_type(str(path))
        self.send_response(200); self.send_header("Content-Type", mime or "application/octet-stream")
        self.send_header("Content-Length", str(len(data))); self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff"); self.end_headers(); self.wfile.write(data)

    def do_GET(self):
        parsed = urlparse(self.path); path = unquote(parsed.path); query = parse_qs(parsed.query)
        if path in {"/logo.png", "/corporate-logo.png"}: return serve_corporate_logo(self)
        if path.startswith("/static/"):
            return self.serve_file(STATIC / Path(path[8:]).name)
        if path.startswith("/uploads/"):
            return self.serve_file(UPLOADS / Path(path[9:]).name)
        if path.startswith("/attachments/"):
            return self.serve_file(ATTACHMENTS / Path(path[13:]).name)
        if path == "/open-attachment":
            return self.open_attachment(query.get("slug", [""])[0], query.get("id", [""])[0])
        if path == "/open-external":
            return self.open_external(query.get("slug", [""])[0], query.get("id", [""])[0])
        if path == "/": return self.dashboard()
        if path == "/new": return self.editor(None, query.get("template", [""])[0])
        if path == "/import-word": return self.import_word_form()
        if path == "/help": return self.help_page()
        if path == "/search": return self.search(query.get("q", [""])[0])
        if path == "/manage-categories": return self.manage_categories()
        if path == "/manage-tags": return self.manage_tags()
        if path == "/tags": return self.tags_page(query)
        if path == "/manage-templates": return self.manage_templates(query.get("edit", [""])[0])
        if path.startswith("/category/"): return self.category_page(path.split("/category/",1)[1])
        if path.startswith("/pdf-view/"): return self.pdf_view(path.split("/pdf-view/",1)[1])
        if path.startswith("/export-pdf/"): return self.export_pdf_default_from_slug(path.split("/export-pdf/",1)[1])
        if path.startswith("/export-docx/"): return self.export_docx(path.split("/export-docx/",1)[1], query.get("template",[""])[0])
        if path.startswith("/wiki/"): return self.show_page(path.split("/wiki/",1)[1])
        if path.startswith("/edit/"): return self.editor(load_page(path.split("/edit/",1)[1]))
        self.send_html(layout("No encontrado", "<h1>Página no encontrada</h1>"), 404)

    def do_POST(self):
        path = urlparse(self.path).path
        if path == "/upload-image": return self.handle_image_upload()
        if path == "/import-word": return self.handle_word_import()
        if path == "/attachment/upload": return self.handle_attachment_upload()
        if path == "/preview": return self.handle_preview()
        if path == "/save": return self.handle_save_with_attachments()
        form = self.read_form()
        if path == "/attachment/link": return self.add_external_attachment(form)
        if path == "/attachment/delete": return self.delete_attachment(form)
        if path == "/delete-page":
            delete_page(form.get("slug", ""))
            return self.redirect("/")
        if path == "/toggle-favorite":
            slug = slugify(form.get("slug", "")); values = load_favorites()
            values = [x for x in values if x != slug] if slug in values else values + [slug]
            save_favorites(values); return self.redirect(f"/wiki/{slug}")
        if path == "/save-template": return self.save_template(form)
        if path == "/delete-template": return self.delete_template(form)
        if path == "/reset-templates":
            save_templates(DEFAULT_TEMPLATES); return self.redirect("/manage-templates")
        if path == "/add-category":
            ensure_category(form.get("name", "")); return self.redirect("/manage-categories")
        if path == "/add-tag":
            ensure_tags([form.get("name", "")]); return self.redirect("/manage-tags")
        if path == "/rename-tag":
            old, new = form.get("old", "").strip(), form.get("new", "").strip()
            if old and new:
                for page in all_pages():
                    tags = [new if str(t).casefold() == old.casefold() else t for t in page.get("tags", [])]
                    if tags != page.get("tags", []):
                        save_page(page["title"], page.get("category", "General"), page.get("content", ""), ",".join(tags), page.get("template", ""), page.get("project_id", ""), page_responsible_ids(page))
                save_tags([new if x.casefold() == old.casefold() else x for x in load_tags()])
            return self.redirect("/manage-tags")
        if path == "/delete-tag":
            name = form.get("name", "").strip()
            if name:
                for page in all_pages():
                    tags = [t for t in page.get("tags", []) if str(t).casefold() != name.casefold()]
                    if len(tags) != len(page.get("tags", [])):
                        save_page(page["title"], page.get("category", "General"), page.get("content", ""), ",".join(tags), page.get("template", ""), page.get("project_id", ""), page_responsible_ids(page))
                save_tags([x for x in load_tags() if x.casefold() != name.casefold()])
            return self.redirect("/manage-tags")
        if path == "/rename-category":
            old, new = form.get("old", "").strip(), form.get("new", "").strip()
            if old and new:
                cats = [new if x.casefold() == old.casefold() else x for x in load_categories()]
                save_categories(cats)
                for page in all_pages():
                    if page.get("category", "").casefold() == old.casefold():
                        save_page(page["title"], new, page.get("content", ""), ",".join(page.get("tags", [])), page.get("template", ""), page.get("project_id", ""), page_responsible_ids(page))
            return self.redirect("/manage-categories")
        if path == "/delete-category":
            name, target = form.get("name", "").strip(), form.get("target", "General").strip() or "General"
            for page in all_pages():
                if page.get("category", "").casefold() == name.casefold():
                    save_page(page["title"], target, page.get("content", ""), ",".join(page.get("tags", [])), page.get("template", ""), page.get("project_id", ""), page_responsible_ids(page))
            save_categories([x for x in load_categories() if x.casefold() != name.casefold()]); ensure_category(target)
            return self.redirect("/manage-categories")
        self.send_error(404)

    def _save_page_record(self, page):
        page["updated"] = datetime.now().isoformat(timespec="seconds")
        write_json(page_file(page.get("slug", "")), page)

    def _multipart_fields(self, max_size=60 * 1024 * 1024):
        content_type = self.headers.get("Content-Type", "")
        match = re.search(r'boundary="?([^";]+)', content_type)
        try: length = int(self.headers.get("Content-Length", "0"))
        except ValueError: length = 0
        if not match or length <= 0 or length > max_size:
            return {}, None, None
        raw = self.rfile.read(length); boundary = ("--" + match.group(1)).encode()
        fields, filename, filedata = {}, None, None
        for part in raw.split(boundary):
            if b"\r\n\r\n" not in part: continue
            head, body = part.split(b"\r\n\r\n", 1); body = body.rstrip(b"\r\n-")
            name_m = re.search(br'name="([^"]+)"', head)
            if not name_m: continue
            name = name_m.group(1).decode("utf-8", "replace")
            file_m = re.search(br'filename="([^"]*)"', head)
            if file_m:
                filename = Path(file_m.group(1).decode("utf-8", "replace")).name
                filedata = body
            else:
                fields[name] = body.decode("utf-8", "replace")
        return fields, filename, filedata

    def _multipart_all(self, max_size=200 * 1024 * 1024):
        """Lee campos y varios archivos de un formulario multipart sin librerías externas."""
        content_type = self.headers.get("Content-Type", "")
        match = re.search(r'boundary="?([^";]+)', content_type)
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if not match or length <= 0 or length > max_size:
            return {}, []
        raw = self.rfile.read(length)
        boundary = ("--" + match.group(1)).encode()
        fields, files = {}, []
        for part in raw.split(boundary):
            if b"\r\n\r\n" not in part:
                continue
            head, body = part.split(b"\r\n\r\n", 1)
            body = body.rstrip(b"\r\n-")
            name_m = re.search(br'name="([^"]+)"', head)
            if not name_m:
                continue
            name = name_m.group(1).decode("utf-8", "replace")
            file_m = re.search(br'filename="([^"]*)"', head)
            if file_m:
                filename = Path(file_m.group(1).decode("utf-8", "replace")).name
                if filename:
                    files.append({"field": name, "filename": filename, "data": body})
            else:
                fields[name] = body.decode("utf-8", "replace")
        return fields, files

    def _store_attachment(self, page, filename, data):
        safe = re.sub(r"[^A-Za-z0-9._-]+", "_", filename).strip("._") or "archivo"
        stored = f"{page['slug']}_{uuid.uuid4().hex[:8]}_{safe}"
        (ATTACHMENTS / stored).write_bytes(data)
        page.setdefault("attachments", []).append({
            "id": uuid.uuid4().hex[:10], "type": "copy", "name": filename,
            "stored": stored, "size": len(data),
            "added": datetime.now().isoformat(timespec="seconds")
        })

    def handle_save_with_attachments(self):
        content_type = self.headers.get("Content-Type", "")
        if "multipart/form-data" in content_type:
            form, files = self._multipart_all()
        else:
            form, files = self.read_form(), []
        title = form.get("title", "").strip()
        if not title:
            return self.send_html(layout("Editor", "<h1>El título es obligatorio</h1><p>Vuelva atrás y escriba un título.</p>"), 400)
        responsible_ids=[x.strip() for x in form.get("responsible_ids","").split(",") if x.strip()]
        page = save_page(title, form.get("category", "General"), form.get("content", ""),
                         form.get("tags", ""), form.get("template", ""), form.get("project_id", ""), responsible_ids)
        for item in files:
            if item.get("field") == "attachments" and item.get("data") is not None:
                self._store_attachment(page, item["filename"], item["data"])
        target = form.get("external_target", "").strip()
        if target:
            name = form.get("external_name", "").strip() or Path(target.rstrip("/\\")).name or target
            page.setdefault("attachments", []).append({
                "id": uuid.uuid4().hex[:10], "type": "external", "name": name,
                "target": target, "added": datetime.now().isoformat(timespec="seconds")
            })
        self._save_page_record(page)
        return self.redirect(f'/wiki/{page["slug"]}#adjuntos')

    def handle_attachment_upload(self):
        fields, filename, data = self._multipart_fields()
        slug = slugify(fields.get("slug", "")); page = load_page(slug)
        if not page or not filename or data is None:
            return self.send_html(layout("Adjunto", "<h1>No se pudo adjuntar el archivo</h1>"), 400)
        self._store_attachment(page, filename, data)
        self._save_page_record(page)
        return self.redirect(f"/wiki/{slug}?attachment=added#adjuntos")

    def add_external_attachment(self, form):
        slug=slugify(form.get("slug", "")); page=load_page(slug); target=form.get("target", "").strip()
        if page and target:
            name=form.get("name", "").strip() or Path(target.rstrip("/\\")).name or target
            page.setdefault("attachments", []).append({"id":uuid.uuid4().hex[:10],"type":"external","name":name,"target":target,"added":datetime.now().isoformat(timespec="seconds")})
            self._save_page_record(page)
        return self.redirect(f"/wiki/{slug}?attachment=linked#adjuntos")

    def delete_attachment(self, form):
        slug=slugify(form.get("slug", "")); aid=form.get("id", ""); page=load_page(slug)
        if page:
            kept=[]
            for item in page.get("attachments", []):
                if item.get("id") == aid:
                    if item.get("type") == "copy":
                        try: (ATTACHMENTS / Path(item.get("stored", "")).name).unlink(missing_ok=True)
                        except OSError: pass
                else: kept.append(item)
            page["attachments"] = kept; self._save_page_record(page)
        return self.redirect(f"/wiki/{slug}#adjuntos")

    def open_attachment(self, slug, aid):
        page=load_page(slugify(slug)); item=next((x for x in (page or {}).get("attachments", []) if x.get("id")==aid and x.get("type")=="copy"), None)
        if not item: return self.send_error(404)
        stored=Path(item.get("stored","")).name
        path=(ATTACHMENTS/stored).resolve()
        if ATTACHMENTS.resolve() not in path.parents or not path.is_file():
            return self.send_error(404)
        try:
            if os.name=="nt": os.startfile(str(path))
            elif sys.platform=="darwin": subprocess.Popen(["open",str(path)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            else:
                opener=shutil.which("xdg-open")
                if not opener: raise RuntimeError("No se encontró una aplicación para abrir el archivo.")
                subprocess.Popen([opener,str(path)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        except Exception as exc:
            return self.send_html(layout("No se pudo abrir", f'<h1>No se pudo abrir el adjunto</h1><p>{html.escape(str(exc))}</p>'),500)
        return self.redirect(f"/wiki/{slugify(slug)}#adjuntos")

    def open_external(self, slug, aid):
        page=load_page(slugify(slug)); item=next((x for x in (page or {}).get("attachments", []) if x.get("id")==aid), None)
        if not item: return self.send_error(404)
        target=item.get("target", "").strip()
        if re.match(r"^https?://", target, re.I): return self.redirect(target)
        try:
            if os.name == "nt": os.startfile(target)
            elif sys.platform == "darwin": subprocess.Popen(["open", target])
            else: subprocess.Popen(["xdg-open", target])
        except Exception:
            return self.send_html(layout("No se pudo abrir", f'<h1>No se pudo abrir el recurso</h1><p class="path-value">{html.escape(target)}</p><p>Compruebe que la ruta existe y es accesible desde este equipo.</p>'), 400)
        return self.redirect(f"/wiki/{slugify(slug)}#adjuntos")

    def handle_preview(self):
        form = self.read_form()
        title = form.get("title", "").strip() or "Vista previa del documento"
        category = form.get("category", "").strip()
        tags = form.get("tags", "").strip()
        content = form.get("content", "")

        meta = []
        if category:
            meta.append(f'<span><strong>Categoría:</strong> {html.escape(category)}</span>')
        if tags:
            meta.append(f'<span><strong>Etiquetas:</strong> {html.escape(tags)}</span>')

        document = (
            '<article class="document-preview">'
            f'<h1>{html.escape(title)}</h1>'
            f'<div class="preview-meta">{"".join(meta)}</div>'
            f'<div class="wiki-content">{render(normalize_document_header(content, title))}</div>'
            '</article>'
        )

        preview_html = f"""<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Vista previa</title>
<link rel="stylesheet" href="/static/style.css?v={APP_VERSION}">
<style>
html, body {{
  margin: 0;
  padding: 0;
  background: #fff;
}}
body {{
  min-height: 100vh;
}}
</style>
<style>{CORPORATE_THEME_CSS}</style></head>
<body>
{document}
</body>
</html>"""
        self.send_html(preview_html)

    def pdf_view(self, slug):
        page = load_page(slug)
        if not page:
            return self.send_html("<h1>Documento no encontrado</h1>", 404)
        tags = ", ".join(page.get("tags", []))
        meta = [f"Categoría: {html.escape(page.get('category', 'General'))}"]
        if tags:
            meta.append(f"Etiquetas: {html.escape(tags)}")
        updated = html.escape(page.get("updated", "").replace("T", " "))
        raw_content = page.get("content", "")
        number_match = re.search(r"(?im)^\s*(?:number|n[uú]mero|numero)\s*:\s*(.+?)\s*$", raw_content)
        document_number = number_match.group(1).strip() if number_match else ""
        rendered_content = render(normalize_document_header(raw_content, page.get("title", "")))

        document = f"""<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>{html.escape(page['title'])}</title>
<link rel="stylesheet" href="/static/style.css?v={APP_VERSION}">
<style>
@page {{ size: A4 portrait; margin: 0; }}
.code-actions, .toggle-code, .copy-code {{ display: none !important; }}
* {{ box-sizing: border-box; }}
html, body {{ margin: 0; padding: 0; background: #fff !important; color: #202124; }}
body {{ font-family: Arial, sans-serif; font-size: 11px; line-height: 1.4; }}
#pdf-source {{
  display: block;
  width: 210mm;
  min-height: 297mm;
  margin: 0;
  padding: 8mm 12mm 9mm;
  background: #fff;
}}
#pdf-pages {{ display: none; margin: 0; padding: 0; }}
html[data-pdf-ready="1"] #pdf-source {{ display: none !important; }}
html[data-pdf-ready="1"] #pdf-pages {{ display: block !important; }}
.pdf-sheet {{
  position: relative;
  width: 210mm;
  height: 297mm;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background: #fff;
  page-break-after: always;
  break-after: page;
}}
.pdf-sheet:last-child {{ page-break-after: auto; break-after: auto; }}
.pdf-page-header {{
  position: absolute;
  top: 10mm;
  left: 12mm;
  right: 12mm;
  height: 8mm;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12mm;
  padding: 0 0 1.5mm;
  border-bottom: 0.25mm solid #a2a9b1;
  color: #202124;
  background: transparent;
  font-family: Arial, sans-serif;
  font-size: 8pt;
  line-height: 1.15;
}}
.pdf-page-header .number {{
  flex: 0 0 auto;
  font-weight: 700;
  white-space: nowrap;
}}
.pdf-page-header .title {{
  flex: 1 1 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  text-align: right;
  white-space: nowrap;
}}
.pdf-page-body {{
  position: absolute;
  top: 21mm;
  left: 12mm;
  right: 12mm;
  bottom: 22mm;
  overflow: hidden;
}}
.pdf-page-footer {{
  position: absolute;
  left: 12mm;
  right: 12mm;
  bottom: 10mm;
  height: 8mm;
  padding-top: 1.8mm;
  border-top: 0.25mm solid #a2a9b1;
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  align-items: start;
  color: #57606a;
  background: transparent;
  font-family: Arial, sans-serif;
  font-size: 8pt;
  line-height: 1.15;
}}
.pdf-page-footer .footer-left {{ justify-self: start; }}
.pdf-page-footer .footer-page {{
  justify-self: center;
  color: #202124;
  font-weight: 600;
}}
.pdf-page-footer .footer-date {{ justify-self: end; }}
.pdf-first-title {{
  margin: 0 0 8px;
  padding-bottom: 4px;
  border-bottom: 1px solid #a2a9b1;
  color: #EC0000;
  font-family: Arial, sans-serif;
  font-size: 14px;
  font-weight: 700;
  line-height: 1.3;
}}
.pdf-meta {{ margin: 0 0 14px; padding-bottom: 7px; border-bottom: 1px solid #d8dee4; color: #57606a; font-size: 8px; }}
.pdf-page-body article {{ max-width: none; font-size: 10px; line-height: 1.4; }}
.pdf-page-body article h1 {{ color: #EC0000; font-size: 13px; font-weight: 700; line-height: 1.3; }}
.pdf-page-body article h2 {{ font-size: 12px; font-weight: 700; line-height: 1.3; }}
.pdf-page-body article h3 {{ font-size: 11px; font-weight: 700; line-height: 1.3; }}
.pdf-page-body article h4 {{ font-size: 10px; font-weight: 700; font-style: italic; line-height: 1.3; }}
.pdf-page-body article p, .pdf-page-body article li, .pdf-page-body article td, .pdf-page-body article th {{ font-size: 10px; line-height: 1.4; }}
.document-number-line {{ color: #202124; font-size: 11px; font-weight: 400; }}
.document-number-label {{ color: #202124; font-weight: 400; }}
.document-number-value {{ color: #EC0000; font-weight: 700; }}
pre, table, figure {{ page-break-inside: avoid; break-inside: avoid; }}
pre, pre code, .code-box, .code-box code, .code-block, .hljs {{
  white-space: pre-wrap !important; word-break: break-word; overflow-wrap: anywhere;
  overflow: hidden !important; max-width: 100% !important; font-size: 7pt !important;
  line-height: 1.3; box-sizing: border-box;
}}
.copy-btn, .copy-code, button {{ display:none !important; }}
figure, p:has(> img), a:has(> img) {{ page-break-inside: avoid; break-inside: avoid; }}
img {{ display:block; max-width:100% !important; max-height:270mm !important; width:auto !important; height:auto !important; object-fit:contain; margin:10px auto; }}
p {{ orphans: 3; widows: 3; }}
table {{ width:100%; border-collapse:collapse; }}
thead {{ display:table-header-group; }}
tr {{ break-inside:avoid; page-break-inside:avoid; }}
@media screen {{ body {{ background:#e9edf1 !important; }} .pdf-sheet {{ margin:8px auto; box-shadow:0 1px 7px #0004; }} }}
</style>
<style>{CORPORATE_THEME_CSS}
/* V26.1: logotipo configurable desde configuracion/logo/logo.png */
.brand::before{{display:none!important;content:none!important;background-image:none!important}}
.brand .brand-logo{{
  display:block!important;width:46px!important;height:46px!important;
  min-width:46px!important;max-width:46px!important;flex:0 0 46px!important;
  object-fit:contain!important;object-position:center!important;
  background:transparent!important;border:0!important;border-radius:0!important;
  box-shadow:none!important
}}
.brand>span{{display:block!important}}
@media(max-width:760px){{
  .brand .brand-logo{{width:38px!important;height:38px!important;min-width:38px!important;max-width:38px!important;flex-basis:38px!important}}
}}
</style></head>
<body>
<div id="pdf-source">
  <h1 class="pdf-first-title">{html.escape(page['title'])}</h1>
  <div class="pdf-meta">{' · '.join(meta)} · Actualizado: {updated}</div>
  <article>{rendered_content}</article>
</div>
<div id="pdf-pages"></div>
<script>
(function() {{
  const docNumber = {json.dumps(document_number, ensure_ascii=False)};
  const docTitle = {json.dumps(page.get('title', ''), ensure_ascii=False)};
  const source = document.getElementById('pdf-source');
  const pagesRoot = document.getElementById('pdf-pages');

  function makePage(first) {{
    const sheet = document.createElement('section');
    sheet.className = 'pdf-sheet';

    const header = document.createElement('div');
    header.className = 'pdf-page-header';
    header.innerHTML = '<span class="number"></span><span class="title"></span>';
    header.querySelector('.number').textContent = docNumber || 'Santander Mail Security';
    header.querySelector('.title').textContent = docTitle;
    sheet.appendChild(header);

    const body = document.createElement('div');
    body.className = 'pdf-page-body';
    const article = document.createElement('article');
    body.appendChild(article);
    sheet.appendChild(body);

    const footer = document.createElement('div');
    footer.className = 'pdf-page-footer';
    footer.innerHTML = '<span class="footer-left"></span><span class="footer-page"></span><span class="footer-date"></span>';
    footer.querySelector('.footer-left').textContent = docNumber || 'Santander Mail Security';
    const generated = new Date();
    footer.querySelector('.footer-date').textContent =
      generated.toLocaleDateString('es-ES') + ' ' +
      generated.toLocaleTimeString('es-ES', {{hour: '2-digit', minute: '2-digit'}});
    sheet.appendChild(footer);

    pagesRoot.appendChild(sheet);
    return {{sheet, body, article, footer}};
  }}

  function overflows(page) {{
    return page.article.getBoundingClientRect().bottom > page.body.getBoundingClientRect().bottom + 0.5;
  }}

  function addNode(page, node) {{
    page.article.appendChild(node);
    return !overflows(page);
  }}

  function splitPlainTextNode(node, page) {{
    const text = (node.textContent || '').trim();
    if (!text || !/^(P|DIV|BLOCKQUOTE)$/i.test(node.tagName || '')) return null;
    const words = text.split(/\\s+/);
    if (words.length < 8) return null;
    let lo = 1, hi = words.length, best = 0;
    while (lo <= hi) {{
      const mid = Math.floor((lo + hi) / 2);
      const probe = node.cloneNode(false);
      probe.textContent = words.slice(0, mid).join(' ');
      page.article.appendChild(probe);
      const fits = !overflows(page);
      probe.remove();
      if (fits) {{ best = mid; lo = mid + 1; }} else {{ hi = mid - 1; }}
    }}
    if (best < 1 || best >= words.length) return null;
    const first = node.cloneNode(false);
    first.textContent = words.slice(0, best).join(' ');
    const rest = node.cloneNode(false);
    rest.textContent = words.slice(best).join(' ');
    return [first, rest];
  }}

  function paginate() {{
    pagesRoot.innerHTML = '';
    const title = source.querySelector('.pdf-first-title').cloneNode(true);
    const meta = source.querySelector('.pdf-meta').cloneNode(true);
    const nodes = Array.from(source.querySelector('article').children).map(n => n.cloneNode(true));
    let page = makePage(true);
    page.body.insertBefore(meta, page.article);
    page.body.insertBefore(title, meta);

    const queue = nodes.slice();
    while (queue.length) {{
      const node = queue.shift();
      page.article.appendChild(node);
      if (!overflows(page)) continue;
      node.remove();

      const split = splitPlainTextNode(node, page);
      if (split) {{
        page.article.appendChild(split[0]);
        page = makePage(false);
        queue.unshift(split[1]);
        continue;
      }}

      page = makePage(false);
      page.article.appendChild(node);
      if (overflows(page)) {{
        node.style.breakInside = 'auto';
        node.style.pageBreakInside = 'auto';
        node.style.maxHeight = 'none';
      }}
    }}
    if (pagesRoot.children.length) {{
      const total = pagesRoot.children.length;
      Array.from(pagesRoot.children).forEach((sheet, index) => {{
        const target = sheet.querySelector('.footer-page');
        if (target) target.textContent = 'Página ' + (index + 1) + ' de ' + total;
      }});
      document.documentElement.setAttribute('data-pdf-ready', '1');
      window.status = 'pdf-ready';
    }}
  }}

  function ready() {{
    const images = Array.from(source.querySelectorAll('img'));
    const imageWait = Promise.all(images.map(img => {{
      if (img.complete) return Promise.resolve();
      return new Promise(resolve => {{
        img.addEventListener('load', resolve, {{once:true}});
        img.addEventListener('error', resolve, {{once:true}});
      }});
    }}));
    const fontWait = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve();
    Promise.all([imageWait, fontWait]).then(() => {{
      try {{
        paginate();
        setTimeout(() => {{ try {{ paginate(); }} catch (e) {{ console.error(e); }} }}, 80);
      }} catch (e) {{
        console.error('PDF pagination fallback:', e);
        document.documentElement.removeAttribute('data-pdf-ready');
        window.status = 'pdf-fallback';
      }}
    }});
  }}
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready, {{once:true}}); else ready();
}})();
</script>
</body>
</html>"""
        self.send_html(document)

    def export_pdf_default(self,page):
        """Genera el PDF con el formato predeterminado anterior mediante Chrome/Edge."""
        browser=find_pdf_browser()
        if not browser:
            message=(
                '<div class="export-error"><h1>No se pudo exportar el PDF predeterminado</h1>'
                '<p>Esta opción necesita Google Chrome o Microsoft Edge instalado en el equipo.</p>'
                f'<div class="actions"><a class="btn primary" href="/export-pdf/{quote(page["slug"])}">Reintentar PDF</a>'
                f'<a class="btn" href="/wiki/{quote(page["slug"])}">Volver al documento</a></div></div>'
            )
            return self.send_html(layout('Exportación PDF',message),503)

        url=f'http://127.0.0.1:{self.server.server_port}/pdf-view/{quote(page["slug"])}'
        try:
            with tempfile.TemporaryDirectory(prefix='wiki_pdf_default_',dir=str(WORD_EXPORTS)) as tmp:
                tmp=Path(tmp)
                output=tmp/'documento.pdf'
                command=[
                    browser,
                    '--headless',
                    '--disable-gpu',
                    '--no-sandbox',
                    '--disable-extensions',
                    '--hide-scrollbars',
                    f'--user-data-dir={tmp/"browser-profile"}',
                    '--run-all-compositor-stages-before-draw',
                    '--virtual-time-budget=8000',
                    '--no-pdf-header-footer',
                    '--print-to-pdf-no-header',
                    f'--print-to-pdf={output}',
                    url,
                ]
                result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
                if result.returncode!=0 or not output.is_file() or output.stat().st_size<100:
                    error=result.stderr.decode('utf-8',errors='replace')[-1400:]
                    raise RuntimeError(error or 'El navegador no creó el archivo PDF.')
                data=output.read_bytes()
        except Exception as exc:
            message=(
                '<div class="export-error"><h1>No se pudo exportar el PDF predeterminado</h1>'
                '<p>Chrome o Edge no pudo generar el archivo.</p>'
                '<p class="export-error-detail">'+html.escape(str(exc))+'</p>'
                f'<div class="actions"><a class="btn primary" href="/export-pdf/{quote(page["slug"])}">Reintentar PDF</a>'
                f'<a class="btn" href="/wiki/{quote(page["slug"])}">Volver al documento</a></div></div>'
            )
            print(f'Error exportando PDF predeterminado: {exc}')
            return self.send_html(layout('Exportación PDF',message),500)

        filename=safe_pdf_name(page.get('title','documento'))
        self.send_response(200)
        self.send_header('Content-Type','application/pdf')
        self.send_header('Content-Disposition',f"attachment; filename*=UTF-8''{quote(filename)}")
        self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store')
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError,ConnectionAbortedError,ConnectionResetError):
            return

    def export_pdf_default_from_slug(self,slug):
        page=load_page(slug)
        if not page:
            return self.send_html(layout('No encontrado','<h1>Documento no encontrado</h1>'),404)
        return self.export_pdf_default(page)

    def export_pdf_legacy_word_templates(self, slug, template_name=''):
        page=load_page(slug)
        if not page:
            return self.send_html(layout('No encontrado','<h1>Documento no encontrado</h1>'),404)

        files=available_word_templates()
        if not template_name:
            return self.send_html(export_template_selection_page(page,files,'pdf'))
        if template_name=='__legacy__':
            return self.export_pdf_default(page)

        template=configured_default_word_template() if template_name=='__default__' else selected_word_template(template_name)
        if not template or not template.is_file():
            return self.send_html(
                layout(
                    'Exportación PDF',
                    '<div class="export-error"><h1>No se encuentra la plantilla Word seleccionada</h1>'
                    '<p>Vuelva al documento y seleccione otra plantilla.</p>'
                    f'<p><a href="/wiki/{quote(page["slug"])}">Volver al documento</a></p></div>'
                ),
                404
            )

        diagnostic_docx=None
        try:
            # Exactamente el mismo DOCX que utiliza «Generar Word».
            docx_file=generate_word_document(page,template)
            with tempfile.TemporaryDirectory(prefix='sms_wordpdf_') as tmp:
                tmp=Path(tmp)
                pdf_file=tmp/'documento.pdf'
                convert_word_to_pdf(docx_file,pdf_file)
                if not pdf_file.is_file() or pdf_file.stat().st_size<100:
                    raise RuntimeError('La conversión terminó sin generar un PDF válido.')
                data=pdf_file.read_bytes()
        except Exception as exc:
            try:
                diagnostic_docx=WORD_EXPORTS/(safe_docx_name(page.get('title','documento')).replace('.docx','')+'_ERROR.docx')
                if 'docx_file' in locals() and Path(docx_file).is_file():
                    shutil.copy2(docx_file,diagnostic_docx)
            except Exception:
                diagnostic_docx=None
            short_error=html.escape(str(exc))
            diagnostic_html=(
                '<p><strong>Documento Word de diagnóstico conservado en:</strong><br><code>'
                +html.escape(str(diagnostic_docx))+'</code></p>'
                if diagnostic_docx and diagnostic_docx.is_file() else ''
            )
            message=(
                '<div class="export-error">'
                '<h1>No se pudo exportar el PDF</h1>'
                '<p>El documento Word se generó correctamente, pero no se pudo completar la conversión a PDF.</p>'
                '<p class="export-error-detail">'+short_error+'</p>'+diagnostic_html
                +f'<div class="actions"><a class="btn primary" href="/export-pdf/{quote(page["slug"])}">Reintentar PDF</a>'
                f'<a class="btn" href="/wiki/{quote(page["slug"])}">Volver al documento</a></div>'
                '</div>'
                '<style>.export-error h1,.export-error p{margin-top:0}.export-error-detail{white-space:normal;overflow-wrap:anywhere;line-height:1.45}'
                '.export-error .actions{display:flex!important;align-items:center!important;gap:8px!important;flex-wrap:wrap}</style>'
            )
            print(f'Error exportando PDF desde Word: {exc}')
            if self.headers.get('X-Requested-With')=='XMLHttpRequest':
                data=(
                    'No se pudo exportar el PDF desde la plantilla Word.\n\n'
                    +str(exc)
                    +(('\n\nDOCX de diagnóstico: '+str(diagnostic_docx)) if diagnostic_docx and diagnostic_docx.is_file() else '')
                ).encode('utf-8','replace')
                self.send_response(500)
                self.send_header('Content-Type','text/plain; charset=utf-8')
                self.send_header('Content-Length',str(len(data)))
                self.send_header('Cache-Control','no-store')
                self.end_headers()
                try:
                    self.wfile.write(data)
                except (BrokenPipeError,ConnectionAbortedError,ConnectionResetError):
                    pass
                return
            return self.send_html(layout('Exportación PDF',message),500)

        filename=safe_pdf_name(page.get('title','documento'))
        self.send_response(200)
        self.send_header('Content-Type','application/pdf')
        self.send_header('Content-Disposition',f"attachment; filename*=UTF-8''{quote(filename)}")
        self.send_header('X-Template-Used',quote(template.name))
        self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store')
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError,ConnectionAbortedError,ConnectionResetError):
            return

    def export_docx(self, slug, template_name=''):
        page=load_page(slug)
        if not page:
            return self.send_html(layout('No encontrado','<h1>Página no encontrada</h1>'),404)

        files=available_word_templates()
        if not template_name:
            return self.send_html(export_template_selection_page(page,files,'docx'))

        chosen=configured_default_word_template() if template_name=='__default__' else selected_word_template(template_name)
        if not chosen or not chosen.is_file():
            return self.send_html(
                layout(
                    'Exportación Word',
                    '<h1>No se encuentra la plantilla Word seleccionada</h1>'
                    f'<p><a href="/wiki/{quote(page["slug"])}">Volver al documento</a></p>'
                ),
                404
            )

        try:
            filename=safe_docx_name(page.get('title','procedimiento'))
            output=generate_word_document(page,chosen)
            data=output.read_bytes()
        except Exception as exc:
            message=(
                '<h1>No se pudo generar el procedimiento Word</h1>'
                f'<p>{html.escape(str(exc))}</p>'
                '<p>Compruebe que la plantilla DOCX conserva los marcadores necesarios.</p>'
                f'<p><a href="/wiki/{quote(page["slug"])}">Volver al documento</a></p>'
            )
            print(f'Error exportando DOCX: {exc}')
            return self.send_html(layout('Exportación Word',message),500)

        self.send_response(200)
        self.send_header('Content-Type','application/vnd.openxmlformats-officedocument.wordprocessingml.document')
        self.send_header('Content-Disposition',f"attachment; filename*=UTF-8''{quote(filename)}")
        self.send_header('X-Template-Used',quote(chosen.name))
        self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store')
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError,ConnectionAbortedError,ConnectionResetError):
            return

    def dashboard(self):
        pages = all_pages(); categories = load_categories(); favorites = load_favorites()
        updated = sorted(pages, key=lambda p: p.get("updated", ""), reverse=True)[:8]
        cards = f'''<div class="stats"><div><strong>{len(pages)}</strong><span>Procedimientos</span></div><div><strong>{len(categories)}</strong><span>Categorías</span></div><div><strong>{len(favorites)}</strong><span>Favoritos</span></div><div><strong>{sum(int(p.get("views",0)) for p in pages)}</strong><span>Consultas</span></div></div>'''
        template_cards = "".join(f'<div class="template-card"><a href="/new?template={quote(item["id"])}">📋 {html.escape(item["name"])}</a><small>{html.escape(item["code"])}-YYMMDDNN</small></div>' for item in load_templates())
        templates = f'<section><div class="section-title-row"><h2>Crear desde plantilla</h2><a class="manage-templates-button" href="/manage-templates">Editar plantillas</a></div><div class="template-grid">{template_cards}<div class="template-card"><a href="/new">📄 Página en blanco</a><small>Sin numeración automática</small></div></div></section>'
        recent = "".join(f'<li><a href="/wiki/{p["slug"]}">{html.escape(p["title"])}</a><small>{html.escape(p.get("category",""))} · {html.escape(p.get("updated","").replace("T"," "))}</small></li>' for p in updated) or "<li>No hay páginas todavía.</li>"
        body = f'<h1>Panel principal</h1>{cards}{templates}<section><h2>Últimas modificaciones</h2><ul class="dashboard-list">{recent}</ul></section>'
        self.send_html(layout("Panel principal", body))

    def show_page(self, slug):
        page = load_page(slug)
        if not page: return self.send_html(layout("No encontrado", "<h1>Página no encontrada</h1>"), 404)
        page["views"] = int(page.get("views", 0)) + 1; write_json(page_file(page["slug"]), page); add_recent(page["slug"])
        favorite = page["slug"] in load_favorites()
        tags = "".join(f'<span class="tag">{html.escape(t)}</span>' for t in page.get("tags", []))
        related = [p for p in all_pages() if p["slug"] != page["slug"] and (p.get("category") == page.get("category") or set(p.get("tags", [])) & set(page.get("tags", [])))][:5]
        related_html = "".join(f'<li><a href="/wiki/{p["slug"]}">{html.escape(p["title"])}</a></li>' for p in related)
        linked_project = next((p for p in read_json(GESTOR_DATA, []) if p.get('id') == page.get('project_id')), None)
        project_box = f'<div class="linked-project"><strong>Proyecto relacionado:</strong> <a href="{html.escape(GESTOR_URL)}/project?id={html.escape(linked_project.get("id", ""))}">{html.escape(linked_project.get("name", ""))}</a></div>' if linked_project else ''
        attachment_rows=[]
        for item in page.get("attachments", []):
            name=html.escape(item.get("name", "Adjunto")); aid=html.escape(item.get("id", ""), quote=True)
            if item.get("type") == "copy":
                stored=quote(Path(item.get("stored", "")).name)
                open_href=f'/open-attachment?slug={quote(page["slug"])}&id={quote(item.get("id", ""))}'
                download_href=f'/attachments/{stored}'
                kind='Archivo copiado'; detail=f'{int(item.get("size",0))/1024:.1f} KB'
                actions=f'<a class="btn small" href="{open_href}">Abrir</a><a class="btn small secondary" href="{download_href}" download="{name}">Descargar</a>'
            else:
                open_href=f'/open-external?slug={quote(page["slug"])}&id={quote(item.get("id", ""))}'
                kind='Enlace externo'; detail=html.escape(item.get("target", ""))
                actions=f'<a class="btn small" href="{open_href}">Abrir</a>'
            attachment_rows.append(f'''<div class="attachment-item"><div class="attachment-icon">📎</div><div class="attachment-info"><strong>{name}</strong><span class="attachment-kind">{kind}</span><small title="{detail}">{detail}</small><div class="actions">{actions}</div></div><form method="post" action="/attachment/delete" onsubmit="return confirm('¿Eliminar este adjunto?')"><input type="hidden" name="slug" value="{html.escape(page['slug'], quote=True)}"><input type="hidden" name="id" value="{aid}"><button class="attachment-delete" title="Eliminar vínculo">×</button></form></div>''')
        attachments_html=''.join(attachment_rows) or '<p class="empty-attachments">No hay archivos ni enlaces adjuntos.</p>'
        attachments_box=f'''<section id="adjuntos" class="attachments-section">
<div class="section-title-row"><div><h2>📎 Adjuntos</h2><p>Añada una copia al Workspace o guarde un vínculo a una ruta, carpeta, red o SharePoint.</p></div></div>
<div class="attachments-list">{attachments_html}</div>
<div class="attachment-forms">
<form class="attachment-form attachment-copy" method="post" action="/attachment/upload" enctype="multipart/form-data">
<input type="hidden" name="slug" value="{html.escape(page['slug'], quote=True)}">
<h3>Adjuntar una copia</h3><p>Pulse <strong>Seleccionar archivo</strong>, elija el documento y después pulse <strong>Adjuntar archivo</strong>.</p>
<label class="file-picker-label">Archivo del equipo<input type="file" name="file" required></label>
<button type="submit">📎 Adjuntar archivo</button>
<small>La copia se guardará dentro de <code>wiki/data/attachments</code>.</small>
</form>
<form class="attachment-form external" method="post" action="/attachment/link">
<input type="hidden" name="slug" value="{html.escape(page['slug'], quote=True)}">
<h3>Guardar un vínculo externo</h3><p>Para archivos locales o carpetas, pegue la ruta. Para SharePoint, pegue el enlace web.</p>
<label>Nombre visible<input name="name" placeholder="Ej.: Diagrama de arquitectura"></label>
<label>Ruta o enlace externo<input name="target" required placeholder="C:\\Documentos\\archivo.pdf, \\\\servidor\\carpeta o https://..."></label>
<button type="submit">🔗 Guardar vínculo</button>
<small>Por seguridad, el navegador no puede obtener automáticamente la ruta completa de un archivo local; debe pegarla aquí.</small>
</form></div></section>'''
        body = f'''<div class="page-actions"><a href="/edit/{page['slug']}">Editar</a><a href="/export-docx/{page['slug']}">📝 Generar Word</a><a href="/export-pdf/{page['slug']}">📄 Exportar PDF</a><form method="post" action="/toggle-favorite"><input type="hidden" name="slug" value="{page['slug']}"><button>{'★ Quitar favorito' if favorite else '☆ Añadir favorito'}</button></form><form method="post" action="/delete-page" onsubmit="return confirm('¿Desea eliminar definitivamente este documento? Esta acción no se puede deshacer.');"><input type="hidden" name="slug" value="{page['slug']}"><button class="danger" type="submit">🗑 Eliminar</button></form></div>
<h1>{html.escape(page['title'])}</h1><div class="meta">Categoría: <a href="/category/{quote(page.get('category','General'))}">{html.escape(page.get('category','General'))}</a> · Autores: {html.escape(", ".join(author_names_from_ids(page_responsible_ids(page))) or ", ".join(author_names_from_content(page.get("content",""))) or "Sin asignar")} · Actualizado: {html.escape(page.get('updated','').replace('T',' '))} · Visitas: {page['views']}</div><div class="tags">{tags}</div>
{project_box}<article>{render(page.get('content',''))}</article>{attachments_box}
{f'<section class="related"><h2>También puede interesarte</h2><ul>{related_html}</ul></section>' if related_html else ''}'''
        self.send_html(layout(page["title"], body))

    def manage_templates(self, edit_id=""):
        items=load_templates()
        selected=next((x for x in items if x.get("id")==slugify(edit_id)),None) if edit_id else None
        if selected is None:
            selected={"id":"","name":"","code":"DOC","content":"Number: DOC-\nTitle: \nVersion: \nDate: \nAuthor: \nStatus: \nClassification: \n\n------------------------\n== Objetivo ==\n\n"}
        rows=[]
        for item in items:
            iid=html.escape(item["id"],quote=True); name=html.escape(item["name"]); code=html.escape(item["code"])
            rows.append('<tr><td><strong>'+name+'</strong><small>'+iid+'</small></td><td><code>'+code+'-YYMMDDNN</code></td><td><a href="/new?template='+quote(item["id"])+'">Usar</a> <a href="/manage-templates?edit='+quote(item["id"])+'">Editar</a><form class="inline-delete" method="post" action="/delete-template" onsubmit="return confirm(\'¿Eliminar esta plantilla?\')"><input type="hidden" name="id" value="'+iid+'"><button class="danger">Eliminar</button></form></td></tr>')
        rows_html=''.join(rows) or '<tr><td colspan="3">No hay plantillas.</td></tr>'
        title='Editar plantilla' if selected.get('id') else 'Nueva plantilla'
        preview=html.escape(selected.get('code','DOC'))+'-'+datetime.now().strftime('%y%m%d')+'01'
        body='<h1>Gestionar plantillas</h1><p>La línea <code>Number:</code> se completa al crear el documento con el formato <strong>CÓDIGO-YYMMDDNN</strong>.</p>'
        body+='<div class="template-management"><section><h2>Plantillas disponibles</h2><table class="category-table"><thead><tr><th>Plantilla</th><th>Numeración</th><th>Acciones</th></tr></thead><tbody>'+rows_html+'</tbody></table><form method="post" action="/reset-templates" onsubmit="return confirm(\'¿Restaurar las plantillas originales?\')"><button class="danger">Restaurar originales</button></form></section>'
        body+='<section class="template-editor-panel"><h2>'+title+'</h2><form class="editor template-editor" method="post" action="/save-template"><input type="hidden" name="original_id" value="'+html.escape(selected.get('id',''),quote=True)+'"><label>Nombre visible<input name="name" required value="'+html.escape(selected.get('name',''),quote=True)+'"></label><label>Identificador interno<input name="id" required value="'+html.escape(selected.get('id',''),quote=True)+'"></label><label>Código<input name="code" maxlength="12" required value="'+html.escape(selected.get('code','DOC'),quote=True)+'"></label><p class="number-preview">Ejemplo: <strong>'+preview+'</strong></p><label>Contenido</label><div class="editor-toolbar template-toolbar" role="toolbar"><button type="button" data-insert="== Título ==\n">H1</button><button type="button" data-insert="=== Subtítulo ===\n">H2</button><button type="button" data-insert="==== Apartado ====\n">H3</button><button type="button" data-insert="===== Subapartado =====\n">H4</button><button type="button" data-wrap="**">Negrita</button><button type="button" data-wrap="''">Cursiva</button><button type="button" data-wrap-open="[u]" data-wrap-close="[/u]">Subrayado</button><details class="separator-menu communication-menu"><summary title="Insertar bloque de comunicación">✉ Comunicación</summary><div class="separator-options"><span class="separator-options-title">Tipo de bloque</span><button type="button" data-communication="correo">✉ Correo</button><button type="button" data-communication="caso">▣ Caso</button><button type="button" data-communication="respuesta">↩ Respuesta</button></div></details><details class="separator-menu"><summary title="Insertar separador">─ Separador</summary><div class="separator-options"><button type="button" data-insert="\n\n----\n\n">──────── Línea fina</button><button type="button" data-insert="\n\n====\n\n">════════ Línea gruesa</button><button type="button" data-insert="\n\n- - - - - -\n\n">- - - - Línea discontinua</button><span class="separator-options-title">Con texto centrado</span><button type="button" data-separator-text="Procedure">──────── Procedure ────────</button><button type="button" data-separator-text="Configuration">──────── Configuration ────────</button><button type="button" data-separator-text="Validation">──────── Validation ────────</button><button type="button" data-custom-separator>Texto personalizado…</button></div></details><details class="separator-menu notice-menu"><summary title="Insertar aviso">⚠ Avisos</summary><div class="separator-options"><span class="separator-options-title">Tipo de aviso</span><button type="button" data-notice="advertencia">⚠ Advertencia</button><button type="button" data-notice="nota">ℹ Nota</button><button type="button" data-notice="informacion">ⓘ Información</button></div></details><details class="separator-menu table-menu"><summary title="Insertar tabla">▦ Tabla</summary><div class="separator-options"><span class="separator-options-title">Formato de tabla</span><button type="button" data-table="simple">Tabla simple</button><button type="button" data-table="header">Tabla con encabezado</button><button type="button" data-table="checklist">Tabla de checklist</button><button type="button" data-table="double">Tabla de doble columna</button><button type="button" data-table="compare">Tabla comparativa</button><button type="button" data-table="custom">Tabla personalizada…</button></div></details><details class="separator-menu layout-menu"><summary title="Insertar zona en columnas">▥ Diseño</summary><div class="separator-options"><span class="separator-options-title">Distribución de columnas</span><button type="button" data-columns="50/50">2 columnas · 50/50</button><button type="button" data-columns="30/70">2 columnas · 30/70</button><button type="button" data-columns="70/30">2 columnas · 70/30</button><button type="button" data-columns="3">3 columnas</button></div></details><details class="separator-menu code-menu"><summary title="Insertar bloque de código">⌨ Código</summary><div class="separator-options"><span class="separator-options-title">Lenguaje</span><button type="button" data-code="text">Texto / comandos</button><button type="button" data-code="spl">Splunk SPL</button><button type="button" data-code="cql">CrowdStrike NG SIEM (CQL)</button><button type="button" data-code="python">Python</button><button type="button" data-code="powershell">PowerShell</button><button type="button" data-code="bash">Bash / Shell</button><button type="button" data-code="sql">SQL</button><button type="button" data-code="kql">KQL</button><button type="button" data-code="json">JSON</button><button type="button" data-code="xml">XML</button><button type="button" data-code="regex">Regex</button></div></details></div><textarea id="template-content-editor" name="content" wrap="soft" required>'+html.escape(selected.get('content',''))+'</textarea><div class="template-format-help"><strong>Formato:</strong> H1 14 px azul · H2 13 px · H3 12 px · H4 11 px cursiva · texto 11 px · código 10 px (7 pt en PDF).</div><section class="template-preview-panel"><h3>Vista previa de la plantilla</h3><article>'+render(selected.get('content',''))+'</article></section><div class="editor-footer"><button class="primary">Guardar plantilla</button><a href="/manage-templates">Nueva plantilla</a></div></form></section></div>'
        self.send_html(layout("Gestionar plantillas",body))

    def save_template(self, form):
        original=slugify(form.get("original_id","")) if form.get("original_id","").strip() else ""
        tid=slugify(form.get("id","")); name=form.get("name","").strip(); code=re.sub(r"[^A-Za-z0-9]","",form.get("code","")).upper()[:12]; content=form.get("content","").replace("\r\n","\n")
        if not tid or not name or not code or not content.strip():
            return self.send_html(layout("Plantillas","<h1>Faltan datos obligatorios</h1>"),400)
        items=[x for x in load_templates() if x.get("id")!=original]
        if any(x.get("id")==tid for x in items):
            return self.send_html(layout("Plantillas","<h1>Identificador duplicado</h1>"),400)
        items.append({"id":tid,"name":name,"code":code,"content":content}); save_templates(items)
        return self.redirect('/manage-templates?edit='+quote(tid))

    def delete_template(self, form):
        tid=slugify(form.get("id","")); save_templates([x for x in load_templates() if x.get("id")!=tid]); return self.redirect('/manage-templates')

    def editor(self, page=None, template=""):
        if page is None:
            page = {"title":"", "category":"General", "content":template_content(template), "tags":[], "template":template, "attachments":[]}
        options = "".join(
            f'<option value="{html.escape(c, quote=True)}" {"selected" if c == page.get("category") else ""}>{html.escape(c)}</option>'
            for c in load_categories()
        )
        tags = ", ".join(page.get("tags", []))
        selected_tags = {str(x).casefold() for x in page.get("tags", [])}
        tag_suggestions = "".join('<button type="button" class="tag-choice%s" data-tag-choice="%s">#%s</button>' % (" selected" if t.casefold() in selected_tags else "", html.escape(t, quote=True), html.escape(t)) for t in load_tags())
        project_options = '<option value="">Sin proyecto vinculado</option>'
        for prj in read_json(GESTOR_DATA, []):
            selected = "selected" if prj.get("id") == page.get("project_id", "") else ""
            project_options += f'<option value="{html.escape(prj.get("id", ""), quote=True)}" {selected}>{html.escape(prj.get("name", ""))}</option>'
        author_ids=selected_author_ids(page)
        author_people=gestor_responsibles()
        author_names=author_names_from_ids(author_ids)
        author_summary=", ".join(author_names) if author_names else "Seleccionar autores"
        author_checks="".join(
            '<label class="author-check"><input type="checkbox" class="author-checkbox" value="'
            +html.escape(str(person.get("id","")),quote=True)+'" data-author-name="'
            +html.escape(str(person.get("name","")),quote=True)+'" '
            +("checked" if str(person.get("id")) in set(author_ids) else "")
            +'><span>'+html.escape(str(person.get("name","")))+'</span></label>'
            for person in author_people
        ) or '<div class="author-empty">No hay responsables creados.</div>'
        body = f"""<h1>{'Editar página' if page.get('title') else 'Crear página'}</h1>
<form class="editor" method="post" action="/save" enctype="multipart/form-data">
<input type="hidden" name="template" value="{html.escape(page.get('template',''), quote=True)}">

<div class="editor-meta-row editor-meta-top">
<label class="editor-title-field">Título
<input id="editor-title" name="title" value="{html.escape(page.get('title',''), quote=True)}" required>
</label>
<label class="editor-category-field">Categoría
<select id="editor-category" name="category">{options}</select>
</label>
<label class="editor-tags-field">Etiquetas
<input id="editor-tags" name="tags" value="{html.escape(tags, quote=True)}" placeholder="splunk, correo, producción" autocomplete="off">
<div class="tag-choice-list">{tag_suggestions or '<small>Aún no hay etiquetas. Escríbalas separadas por comas.</small>'}</div>
</label>
</div>
<div class="editor-project-authors-row">
<label class="editor-project-field">Proyecto relacionado
<select name="project_id">{project_options}</select>
</label>
<div class="editor-authors-field">
<span class="field-label">Autor o autores</span>
<details class="author-multiselect" id="author-multiselect">
<summary><span id="author-summary">{html.escape(author_summary)}</span><span class="author-arrow">▾</span></summary>
<div class="author-options">{author_checks}</div>
</details>
<input type="hidden" id="responsible-ids-field" name="responsible_ids" value="{html.escape(','.join(author_ids),quote=True)}">
<small>Seleccione uno o varios responsables.</small>
</div>
</div>

<div class="github-editor">
<div class="github-editor-tabs" role="tablist" aria-label="Modo del editor">
<button type="button" id="edit-tab" class="github-tab active" role="tab" aria-selected="true">Editar</button>
<button type="button" id="preview-tab" class="github-tab" role="tab" aria-selected="false">Vista previa</button>
</div>

<div id="edit-view" class="editor-tab-content active">
<div class="editor-toolbar" role="toolbar">
<button type="button" data-heading="2">Título</button>
<button type="button" data-wrap="**">Negrita</button>
<button type="button" data-wrap="''">Cursiva</button><button type="button" data-wrap-open="[u]" data-wrap-close="[/u]">Subrayado</button><details class="separator-menu communication-menu"><summary title="Insertar bloque de comunicación">✉ Comunicación</summary><div class="separator-options"><span class="separator-options-title">Tipo de bloque</span><button type="button" data-communication="correo">✉ Correo</button><button type="button" data-communication="caso">▣ Caso</button><button type="button" data-communication="respuesta">↩ Respuesta</button></div></details>
<button type="button" data-wrap-open="[azul]" data-wrap-close="[/azul]">Azul</button>
<button type="button" data-wrap-open="[rojo]" data-wrap-close="[/rojo]">Rojo</button>
<button type="button" data-wrap-open="[amarillo]" data-wrap-close="[/amarillo]">Resaltar</button>
<button type="button" data-insert="- ">Lista</button>
<details class="separator-menu"><summary title="Insertar separador">─ Separador</summary><div class="separator-options"><button type="button" data-insert="\n\n----\n\n">──────── Línea fina</button><button type="button" data-insert="\n\n====\n\n">════════ Línea gruesa</button><button type="button" data-insert="\n\n- - - - - -\n\n">- - - - Línea discontinua</button><span class="separator-options-title">Con texto centrado</span><button type="button" data-separator-text="Procedure">──────── Procedure ────────</button><button type="button" data-separator-text="Configuration">──────── Configuration ────────</button><button type="button" data-separator-text="Validation">──────── Validation ────────</button><button type="button" data-custom-separator>Texto personalizado…</button></div></details>
<span class="toolbar-separator" aria-hidden="true"></span>
<button type="button" id="indent-button" title="Añadir 4 espacios (Tab)">→ Tab +4</button>
<button type="button" id="outdent-button" title="Quitar hasta 4 espacios o una tabulación (Mayús+Tab)">← Quitar tab</button>
<details class="separator-menu notice-menu"><summary title="Insertar aviso">⚠ Avisos</summary><div class="separator-options"><span class="separator-options-title">Tipo de aviso</span><button type="button" data-notice="advertencia">⚠ Advertencia</button><button type="button" data-notice="nota">ℹ Nota</button><button type="button" data-notice="informacion">ⓘ Información</button></div></details><details class="separator-menu table-menu"><summary title="Insertar tabla">▦ Tabla</summary><div class="separator-options"><span class="separator-options-title">Formato de tabla</span><button type="button" data-table="simple">Tabla simple</button><button type="button" data-table="header">Tabla con encabezado</button><button type="button" data-table="checklist">Tabla de checklist</button><button type="button" data-table="double">Tabla de doble columna</button><button type="button" data-table="custom">Tabla personalizada…</button></div></details><details class="separator-menu layout-menu"><summary title="Insertar zona en columnas">▥ Diseño</summary><div class="separator-options"><span class="separator-options-title">Distribución de columnas</span><button type="button" data-columns="50/50">2 columnas · 50/50</button><button type="button" data-columns="30/70">2 columnas · 30/70</button><button type="button" data-columns="70/30">2 columnas · 70/30</button><button type="button" data-columns="3">3 columnas</button></div></details><details class="separator-menu code-menu"><summary title="Insertar bloque de código">⌨ Código</summary><div class="separator-options"><span class="separator-options-title">Lenguaje</span><button type="button" data-code="text">Texto / comandos</button><button type="button" data-code="spl">Splunk SPL</button><button type="button" data-code="cql">CrowdStrike NG SIEM (CQL)</button><button type="button" data-code="python">Python</button><button type="button" data-code="powershell">PowerShell</button><button type="button" data-code="bash">Bash / Shell</button><button type="button" data-code="sql">SQL</button><button type="button" data-code="kql">KQL</button><button type="button" data-code="json">JSON</button><button type="button" data-code="xml">XML</button><button type="button" data-code="regex">Regex</button></div></details>
<button type="button" id="insert-image-button">🖼 Imagen</button>
<input id="image-file" type="file" accept=".png,.jpg,.jpeg,.gif,.webp,image/*" hidden>
<span class="toolbar-separator" aria-hidden="true"></span>
<button type="button" id="find-button" title="Buscar en el documento">🔎 Buscar</button>
<button type="button" id="replace-button" title="Buscar y reemplazar">⇄ Reemplazar</button>
<button type="button" id="goto-line-button" title="Ir a una línea concreta"># Línea</button>
<span id="image-upload-status" class="upload-status"></span>
</div>
<div class="editor-code-area">
  <pre id="editor-line-numbers" class="editor-line-numbers" aria-hidden="true">1</pre>
  <textarea id="content-editor" name="content" wrap="soft" spellcheck="false" required>{html.escape(page.get('content',''))}</textarea>
</div>
<div class="editor-statusbar">
  <span id="editor-save-state">Sin cambios</span>
  <span id="editor-position">Línea 1, columna 1</span>
  <span id="editor-counts">0 palabras · 0 caracteres</span>
</div>
</div>

<div id="preview-view" class="editor-tab-content" hidden>
<div id="preview-loading" class="preview-loading" hidden>Actualizando vista previa…</div>
<iframe id="preview-frame" title="Vista previa del documento"></iframe>
</div>
</div>

<section class="editor-attachments" aria-labelledby="editor-attachments-title">
<div class="editor-attachments-heading">
<div><h2 id="editor-attachments-title">📎 Adjuntos</h2><p>Los archivos seleccionados se copiarán al Workspace al guardar la página.</p></div>
</div>
<label id="attachment-dropzone" class="attachment-dropzone">
<input id="attachment-files" type="file" name="attachments" multiple>
<span class="dropzone-icon">📂</span>
<strong>Seleccionar archivos o arrastrarlos aquí</strong>
<small>Puede elegir varios archivos. Tamaño conjunto máximo: 200 MB.</small>
</label>
<div id="selected-attachments" class="selected-attachments">Ningún archivo seleccionado.</div>
<div class="external-editor-link">
<h3>🔗 Añadir ruta o enlace externo</h3>
<div class="external-link-grid">
<label>Nombre visible<input name="external_name" placeholder="Ej.: Carpeta del proyecto"></label>
<label>Ruta o enlace<input name="external_target" placeholder="C:\\Documentos\\archivo.pdf, \\\\servidor\\carpeta o https://..."></label>
</div>
<small>El vínculo se guarda sin copiar el archivo. Puede ser una ruta local, de red o SharePoint.</small>
</div>
</section>

<div class="editor-footer">
<button class="primary">Guardar página</button>
<a href="/help" target="_blank">Ver ayuda de formato</a>
</div>
</form>"""
        self.send_html(layout("Editor", body))

    def search(self, query):
        q = query.strip().casefold(); results = []
        for p in all_pages():
            haystack = " ".join([p.get("title",""), p.get("category",""), p.get("content",""), " ".join(p.get("tags",[]))]).casefold()
            if q and q in haystack: results.append(p)
        items = "".join(f'<li><a href="/wiki/{p["slug"]}">{html.escape(p["title"])}</a><small>{html.escape(p.get("category",""))}</small><p>{html.escape(re.sub(r"\s+", " ", p.get("content", ""))[:180])}…</p></li>' for p in results)
        self.send_html(layout("Búsqueda", f'<h1>Resultados para “{html.escape(query)}”</h1><p>{len(results)} resultado(s).</p><ul class="search-results">{items or "<li>No se encontraron coincidencias.</li>"}</ul>'))

    def category_page(self, category):
        pages = [p for p in all_pages() if p.get("category", "").casefold() == category.casefold()]
        rows = "".join(
            f'<tr><td class="doc-number">{html.escape(page_number(p))}</td>'
            f'<td><a href="/wiki/{p["slug"]}">{html.escape(p["title"])}</a></td>'
            f'<td class="doc-updated">{html.escape(p.get("updated", "").replace("T", " "))}</td></tr>'
            for p in pages
        )
        if rows:
            content = (
                '<table class="document-list"><thead><tr>'
                '<th>Número</th><th>Nombre</th><th>Actualizado</th>'
                f'</tr></thead><tbody>{rows}</tbody></table>'
            )
        else:
            content = '<p>No hay páginas en esta categoría.</p>'
        self.send_html(layout(category, f'<h1>Categoría: {html.escape(category)}</h1>{content}'))

    def tags_page(self, query):
        selected = [x.strip() for raw in query.get("tag", []) for x in raw.split(",") if x.strip()]
        mode = (query.get("mode", ["any"])[0] or "any").lower()
        selected_cf = {x.casefold() for x in selected}
        pages = []
        for page in all_pages():
            page_tags = {str(x).casefold() for x in page.get("tags", [])}
            if not selected_cf or (selected_cf <= page_tags if mode == "all" else bool(selected_cf & page_tags)):
                pages.append(page)
        checks = "".join('<label class="tag-filter-option"><input type="checkbox" name="tag" value="%s" %s><span>#%s</span></label>' % (html.escape(t, quote=True), "checked" if t.casefold() in selected_cf else "", html.escape(t)) for t in load_tags())
        rows = []
        for page in pages:
            tag_html = "".join('<span class="tag">#%s</span>' % html.escape(t) for t in page.get("tags", []))
            rows.append('<tr><td><a href="/wiki/%s">%s</a></td><td>%s</td><td><div class="tags">%s</div></td><td>%s</td></tr>' % (page["slug"], html.escape(page["title"]), html.escape(page.get("category", "General")), tag_html, html.escape(page.get("updated", "").replace("T", " "))))
        body = '<h1>Filtrar documentos por etiquetas</h1><form class="tag-filter-panel" method="get" action="/tags"><div class="tag-filter-options">%s</div><div class="tag-filter-actions"><label>Coincidencia <select name="mode"><option value="any" %s>Cualquiera</option><option value="all" %s>Todas</option></select></label><button class="primary">Aplicar filtro</button><a class="btn" href="/tags">Limpiar</a></div></form><p><strong>%s</strong> documento(s).</p><table class="document-list tag-results"><thead><tr><th>Documento</th><th>Categoría</th><th>Etiquetas</th><th>Actualizado</th></tr></thead><tbody>%s</tbody></table>' % (checks or '<p>No hay etiquetas disponibles.</p>', "selected" if mode == "any" else "", "selected" if mode == "all" else "", len(pages), "".join(rows) or '<tr><td colspan="4">No hay coincidencias.</td></tr>')
        self.send_html(layout("Etiquetas", body))

    def manage_tags(self):
        rows = []
        for tag in load_tags():
            count = sum(1 for page in all_pages() if tag.casefold() in {str(x).casefold() for x in page.get("tags", [])})
            rows.append('<tr><td><strong>#%s</strong><br><small>%s documento(s)</small></td><td><form class="inline-form" method="post" action="/rename-tag"><input type="hidden" name="old" value="%s"><input name="new" value="%s" required><button>Renombrar</button></form></td><td><form method="post" action="/delete-tag"><input type="hidden" name="name" value="%s"><button class="danger">Eliminar</button></form></td></tr>' % (html.escape(tag), count, html.escape(tag, quote=True), html.escape(tag, quote=True), html.escape(tag, quote=True)))
        body = '<h1>Gestionar etiquetas</h1><p>Cree, renombre o elimine etiquetas reutilizables.</p><form class="add-category" method="post" action="/add-tag"><input name="name" placeholder="Nueva etiqueta" required><button>Crear etiqueta</button></form><table class="category-table"><thead><tr><th>Etiqueta</th><th>Renombrar</th><th>Eliminar</th></tr></thead><tbody>%s</tbody></table>' % ("".join(rows) or '<tr><td colspan="3">No hay etiquetas creadas.</td></tr>')
        self.send_html(layout("Gestionar etiquetas", body))

    def manage_categories(self):
        categories = load_categories(); rows = []
        for c in categories:
            count = sum(1 for p in all_pages() if p.get("category","").casefold() == c.casefold())
            options = "".join(f'<option value="{html.escape(x, quote=True)}">{html.escape(x)}</option>' for x in categories if x.casefold() != c.casefold())
            rows.append(f'''<tr><td><strong>{html.escape(c)}</strong><br><small>{count} página(s)</small></td><td><form class="inline-form" method="post" action="/rename-category"><input type="hidden" name="old" value="{html.escape(c, quote=True)}"><input name="new" value="{html.escape(c, quote=True)}"><button>Renombrar</button></form></td><td><form class="inline-form" method="post" action="/delete-category"><input type="hidden" name="name" value="{html.escape(c, quote=True)}"><select name="target">{options or '<option value="General">General</option>'}</select><button class="danger">Eliminar y mover</button></form></td></tr>''')
        body = f'''<h1>Gestionar categorías</h1><form class="add-category" method="post" action="/add-category"><input name="name" placeholder="Nueva categoría" required><button>Crear categoría</button></form><table class="category-table"><thead><tr><th>Categoría</th><th>Renombrar</th><th>Eliminar</th></tr></thead><tbody>{''.join(rows)}</tbody></table>'''
        self.send_html(layout("Categorías", body))


    def import_word_form(self):
        body = """<h1>Importar Word a Wiki</h1><section class="card"><p>Importa texto, títulos, imágenes e hipervínculos desde un archivo DOCX.</p><form method="post" action="/import-word" enctype="multipart/form-data"><label>Documento Word<input type="file" name="word" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required></label><label>Categoría<select name="category">""" + "".join(f'<option>{html.escape(c)}</option>' for c in load_categories()) + """</select></label><div class="editor-footer"><button class="primary">Importar y crear Wiki</button><a href="/">Cancelar</a></div></form></section>"""
        return self.send_html(layout("Importar Word", body))

    def handle_word_import(self):
        fields, files = self._multipart_all(max_size=100 * 1024 * 1024)
        item = next((x for x in files if x.get("field") == "word"), None)
        if not item or not item.get("data"):
            return self.send_html(layout("Importar Word", "<h1>No se ha recibido ningún DOCX.</h1>"), 400)
        try:
            from docx_import import import_docx
            result = import_docx(item["data"], UPLOADS)
            page = save_page(result.get("title") or Path(item.get("filename") or "Documento").stem, fields.get("category", "General"), result.get("content", ""), "importado-word", "", "")
            return self.redirect(f'/edit/{page["slug"]}')
        except Exception as exc:
            return self.send_html(layout("Error al importar", f"<h1>No se pudo importar el Word</h1><pre>{html.escape(str(exc))}</pre>"), 400)

    def help_page(self):
        body = '''<h1>Ayuda de edición</h1><h2>Títulos</h2><pre class="help-example"><code>== Título ==\n=== Subtítulo ===</code></pre><h2>Texto</h2><pre class="help-example"><code>**Negrita**\n''Cursiva''\n`código corto`
[azul]Texto azul[/azul]
[rojo]Texto rojo[/rojo]
[amarillo]Texto resaltado[/amarillo]</code></pre><h2>Código coloreado</h2><pre class="help-example"><code>```spl\nindex=correo\n| stats count by sender\n```</code></pre><p>Lenguajes: cql (CrowdStrike Next-Gen SIEM), spl, python, powershell, sql, json, html, xml y bash.</p><h2>Imágenes dentro del cuerpo</h2><p>Coloque el cursor en el editor y pulse <strong>Imagen</strong>. También puede pegar una captura con Ctrl+V o arrastrarla sobre el editor.</p><pre class="help-example"><code>[[imagen:captura.png|Descripción]]</code></pre><h2>Separadores</h2><pre class="help-example"><code>----                 Línea fina\n====                 Línea gruesa\n- - - - - -          Línea discontinua\n---[Procedure]---     Separador con texto</code></pre><h2>Avisos</h2><pre class="help-example"><code>!!! nota:\n\nInformación importante\n\n!!!\n!!! advertencia Precaución</code></pre><h2>Zonas en columnas</h2><pre class="help-example"><code>::: columns 50/50\n::: column\nContenido izquierdo\n::: column\nContenido derecho\n::: endcolumns</code></pre><p>Distribuciones disponibles: 50/50, 30/70, 70/30 y tres columnas. Cada columna admite texto, títulos, listas, avisos, tablas, imágenes y código.</p><h2>Enlaces</h2><pre class="help-example"><code>[[Otra página]]\n[[Otra página|Texto visible]]\n[https://ejemplo.com Sitio externo]</code></pre>'''
        self.send_html(layout("Ayuda", body))

    def handle_image_upload(self):
        content_type = self.headers.get("Content-Type", "")
        match = re.search(r'boundary="?([^";]+)', content_type)
        try: length = int(self.headers.get("Content-Length", "0"))
        except ValueError: length = 0
        if not match or length <= 0 or length > 9 * 1024 * 1024:
            return self.send_json({"ok":False,"error":"Carga no válida o demasiado grande."}, 400)
        raw = self.rfile.read(length); boundary = ("--" + match.group(1)).encode(); filename = ""; data = b""
        for part in raw.split(boundary):
            if b"\r\n\r\n" not in part: continue
            head, body = part.split(b"\r\n\r\n", 1)
            found = re.search(br'filename="([^"]*)"', head)
            if found:
                filename = Path(found.group(1).decode("utf-8", "replace")).name; data = body.rstrip(b"\r\n-"); break
        ext = Path(filename).suffix.lower(); allowed = {".png",".jpg",".jpeg",".gif",".webp"}
        if not filename or ext not in allowed or not data or len(data) > 8 * 1024 * 1024:
            return self.send_json({"ok":False,"error":"Use PNG, JPG, GIF o WEBP de hasta 8 MB."}, 400)
        signatures = {".png":b"\x89PNG", ".jpg":b"\xff\xd8\xff", ".jpeg":b"\xff\xd8\xff", ".gif":b"GIF8", ".webp":b"RIFF"}
        if not data.startswith(signatures[ext]):
            return self.send_json({"ok":False,"error":"El archivo no parece una imagen válida."}, 400)
        stored = f"{slugify(Path(filename).stem)[:60]}-{uuid.uuid4().hex[:8]}{ext}"; (UPLOADS / stored).write_bytes(data)
        self.send_json({"ok":True,"filename":stored})


def seed_examples():
    if not any(PAGES.glob("*.json")):
        save_page("Bienvenida", "General", "== Bienvenido ==\n\nEsta wiki funciona de forma local sin instalar librerías.\n\n- Cree categorías.\n- Use plantillas.\n- Inserte imágenes y código coloreado.", "inicio, ayuda")
        save_page("Ejemplo de consulta Splunk", "Splunk", "== Consulta ==\n\n```spl\nindex=correo action_final!=incomplete\n| stats count by suborg\n| sort - count\n```", "splunk, ejemplo")


def find_port(start=8080, end=8099):
    for port in range(start, end + 1):
        with socket.socket() as sock:
            try: sock.bind(("127.0.0.1", port)); return port
            except OSError: continue
    raise RuntimeError("No hay puertos libres entre 8080 y 8099")


if __name__ == "__main__":
    seed_examples(); load_categories()
    requested_port = os.environ.get("WIKI_PORT", "").strip()
    port = int(requested_port) if requested_port.isdigit() else find_port()
    url = f"http://127.0.0.1:{port}"
    print("=" * 60); print(f"Wiki Procedimientos {APP_VERSION}"); print(f"Abrir: {url}"); print("Para detener: Ctrl+C"); print("=" * 60, flush=True)
    ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
