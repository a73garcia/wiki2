from __future__ import annotations

from copy import deepcopy
from datetime import datetime
from pathlib import Path
from xml.etree import ElementTree as ET
import html as html_lib
import re
import shutil
import zipfile

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
XML = 'http://www.w3.org/XML/1998/namespace'
ET.register_namespace('w', W)


def q(name: str) -> str:
    return f'{{{W}}}{name}'


def safe_filename(text: str) -> str:
    clean = re.sub(r'[\\/:*?"<>|]+', '-', str(text)).strip().strip('.')
    return (clean or 'procedimiento') + '.docx'


def metadata(content: str, page: dict) -> dict:
    values = {
        'TITLE': page.get('title', 'Procedimiento'),
        'VERSION': '1.0',
        'DATE': datetime.now().strftime('%d/%m/%Y'),
        'AUTHOR': 'A. Garcia',
        'REVISION_DESCRIPTION': 'Versión inicial',
    }
    aliases = {
        'title': 'TITLE', 'título': 'TITLE', 'titulo': 'TITLE',
        'version': 'VERSION', 'versión': 'VERSION',
        'date': 'DATE', 'fecha': 'DATE',
        'author': 'AUTHOR', 'autor': 'AUTHOR',
    }
    for line in str(content).splitlines()[:15]:
        m = re.match(r'^\s*([^:]{2,24})\s*:\s*(.*?)\s*$', line)
        if not m: continue
        key = aliases.get(m.group(1).strip().casefold())
        if key and m.group(2).strip():
            values[key] = re.sub(r'^\*\*(.*?)\*\*$', r'\1', m.group(2).strip())
    return values


def strip_header(content: str) -> str:
    aliases = {'number','número','numero','title','título','titulo','version','versión','date','fecha','author','autor','status','estado','classification','clasificación','clasificacion'}
    lines = str(content).replace('\r\n','\n').split('\n')
    while lines:
        line = lines[0].strip()
        m = re.match(r'^([^:]{2,24})\s*:', line)
        if not line or (m and m.group(1).strip().casefold() in aliases):
            lines.pop(0)
        else:
            break
    return '\n'.join(lines).strip()


def parse_blocks(content: str):
    lines = strip_header(content).splitlines()
    blocks=[]; i=0; in_code=False; code_lang=''; code=[]
    while i < len(lines):
        line=lines[i]
        if line.strip().startswith('```'):
            if not in_code:
                in_code=True; code_lang=line.strip()[3:].strip(); code=[]
            else:
                blocks.append(('code', code_lang, '\n'.join(code))); in_code=False
            i+=1; continue
        if in_code:
            code.append(line); i+=1; continue
        s=line.strip()
        if not s: blocks.append(('blank','')); i+=1; continue
        hm=re.match(r'^(={2,5})\s*(.*?)\s*\1$', s)
        mm=re.match(r'^(#{1,4})\s+(.*)$', s)
        if hm:
            blocks.append(('heading',len(hm.group(1))-1,hm.group(2))); i+=1; continue
        if mm:
            blocks.append(('heading',len(mm.group(1)),mm.group(2))); i+=1; continue
        if s.startswith('|') and s.endswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|') and lines[i].strip().endswith('|'):
                cells=[x.strip() for x in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r':?-{3,}:?',x or '') for x in cells): rows.append(cells)
                i+=1
            if rows: blocks.append(('table',rows))
            continue
        bm=re.match(r'^[-*•]\s+(.*)$',s)
        nm=re.match(r'^\d+[.)]\s+(.*)$',s)
        if bm: blocks.append(('bullet',bm.group(1))); i+=1; continue
        if nm: blocks.append(('number',nm.group(1))); i+=1; continue
        blocks.append(('paragraph',line)); i+=1
    if in_code: blocks.append(('code',code_lang,'\n'.join(code)))
    return blocks


def run(text: str, *, bold=False, italic=False, font='Courier New', size=20, color=None):
    r=ET.Element(q('r')); rpr=ET.SubElement(r,q('rPr'))
    fonts=ET.SubElement(rpr,q('rFonts')); fonts.set(q('ascii'),font); fonts.set(q('hAnsi'),font)
    sz=ET.SubElement(rpr,q('sz')); sz.set(q('val'),str(size)); ET.SubElement(rpr,q('szCs')).set(q('val'),str(size))
    if bold: ET.SubElement(rpr,q('b'))
    if italic: ET.SubElement(rpr,q('i'))
    if color: ET.SubElement(rpr,q('color')).set(q('val'),color)
    t=ET.SubElement(r,q('t')); t.set(f'{{{XML}}}space','preserve'); t.text=text
    return r


def paragraph(text='', *, level=None, bullet=False, number=False, code=False):
    p=ET.Element(q('p')); ppr=ET.SubElement(p,q('pPr'))
    spacing=ET.SubElement(ppr,q('spacing')); spacing.set(q('after'),'80'); spacing.set(q('line'),'240'); spacing.set(q('lineRule'),'auto')
    if level:
        spacing.set(q('before'),'180')
    if bullet or number:
        ind=ET.SubElement(ppr,q('ind')); ind.set(q('left'),'420'); ind.set(q('hanging'),'240')
    if code:
        shd=ET.SubElement(ppr,q('shd')); shd.set(q('fill'),'F2F2F2')
        ind=ET.SubElement(ppr,q('ind')); ind.set(q('left'),'240'); ind.set(q('right'),'240')
    prefix='• ' if bullet else ('1. ' if number else '')
    if level:
        size={1:28,2:24,3:20,4:18}.get(level,20)
        p.append(run(text,bold=True,font='Courier New',size=size,color='1F4E79'))
    else:
        p.append(run(prefix+text,font='Courier New',size=18 if code else 20))
    return p


def table(rows):
    tbl=ET.Element(q('tbl')); pr=ET.SubElement(tbl,q('tblPr'))
    ET.SubElement(pr,q('tblW'),{q('w'):'0',q('type'):'auto'})
    borders=ET.SubElement(pr,q('tblBorders'))
    for edge in ('top','left','bottom','right','insideH','insideV'):
        ET.SubElement(borders,q(edge),{q('val'):'single',q('sz'):'4',q('color'):'B7B7B7'})
    cols=max(len(r) for r in rows)
    for ri,row in enumerate(rows):
        tr=ET.SubElement(tbl,q('tr'))
        for ci in range(cols):
            tc=ET.SubElement(tr,q('tc')); ET.SubElement(tc,q('tcPr'))
            p=ET.SubElement(tc,q('p')); ppr=ET.SubElement(p,q('pPr')); ET.SubElement(ppr,q('spacing'),{q('after'):'40'})
            p.append(run(row[ci] if ci<len(row) else '',bold=ri==0,font='Courier New',size=18,color='FFFFFF' if ri==0 else None))
            if ri==0: ET.SubElement(tc.find(q('tcPr')),q('shd')).set(q('fill'),'1F4E79')
    return tbl


def body_elements(content: str):
    result=[]
    for b in parse_blocks(content):
        if b[0]=='blank': continue
        if b[0]=='heading': result.append(paragraph(b[2],level=min(4,b[1])))
        elif b[0]=='bullet': result.append(paragraph(b[1],bullet=True))
        elif b[0]=='number': result.append(paragraph(b[1],number=True))
        elif b[0]=='code': result.append(paragraph(b[2],code=True))
        elif b[0]=='table': result.append(table(b[1]))
        else: result.append(paragraph(b[1]))
    return result or [paragraph('')]


def index_elements(content: str):
    els=[]
    count=[0,0,0,0]
    for b in parse_blocks(content):
        if b[0]!='heading': continue
        level=max(1,min(4,b[1])); count[level-1]+=1
        for j in range(level,4): count[j]=0
        number='.'.join(str(x) for x in count[:level] if x)
        p=paragraph(f'{number}. {b[2]}')
        p.find(q('pPr')).append(ET.Element(q('ind'),{q('left'):str((level-1)*260)}))
        els.append(p)
    return els or [paragraph('El documento no contiene títulos para generar el índice.')]


def replace_text(root, replacements):
    for t in root.iter(q('t')):
        if not t.text: continue
        for key,val in replacements.items(): t.text=t.text.replace('{{'+key+'}}',str(val))


def replace_marker(root, marker: str, elements):
    parent_map={c:p for p in root.iter() for c in p}
    for p in list(root.iter(q('p'))):
        text=''.join(t.text or '' for t in p.iter(q('t')))
        if marker not in text: continue
        parent=parent_map.get(p)
        if parent is None: continue
        idx=list(parent).index(p)
        parent.remove(p)
        for offset,el in enumerate(elements): parent.insert(idx+offset,el)
        return True
    return False


def generate(template: Path, output: Path, page: dict) -> Path:
    if not template.is_file(): raise FileNotFoundError(f'No se encuentra la plantilla: {template}')
    output.parent.mkdir(parents=True,exist_ok=True)
    content=page.get('content',''); meta=metadata(content,page)
    with zipfile.ZipFile(template,'r') as zin, zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data=zin.read(item.filename)
            if item.filename=='word/document.xml':
                root=ET.fromstring(data)
                replace_marker(root,'{{WIKI_INDEX}}',index_elements(content))
                replace_marker(root,'{{WIKI_CONTENT}}',body_elements(content))
                replace_text(root,meta)
                data=ET.tostring(root,encoding='utf-8',xml_declaration=True)
            elif item.filename in ('docProps/core.xml','docProps/custom.xml'):
                try:
                    root=ET.fromstring(data); replace_text(root,meta); data=ET.tostring(root,encoding='utf-8',xml_declaration=True)
                except ET.ParseError: pass
            zout.writestr(item,data)
    return output
