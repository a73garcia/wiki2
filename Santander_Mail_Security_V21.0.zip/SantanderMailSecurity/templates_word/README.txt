PLANTILLAS WORD
================

La Wiki usa por defecto:
  Plantilla_procedimientos.docx

La plantilla se puede modificar o sustituir sin cambiar el código, manteniendo el mismo nombre.
Debe conservar estos marcadores:

  {{TITLE}}
  {{VERSION}}
  {{DATE}}
  {{AUTHOR}}
  {{REVISION_DESCRIPTION}}
  {{WIKI_INDEX}}
  {{WIKI_CONTENT}}

{{WIKI_INDEX}} y {{WIKI_CONTENT}} deben estar en párrafos independientes.
Los documentos generados se guardan también en exports/docx y se descargan como DOCX editable.
