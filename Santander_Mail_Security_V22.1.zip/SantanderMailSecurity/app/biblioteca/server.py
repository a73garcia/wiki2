from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path
from datetime import datetime
import os, json, html, uuid

BASE = Path(__file__).resolve().parent
DB = BASE / 'data' / 'snippets.json'
PORTAL_URL = os.environ.get('PORTAL_URL', 'http://127.0.0.1:8079')
WIKI_URL = os.environ.get('WIKI_URL', 'http://127.0.0.1:8080')
GESTOR_URL = os.environ.get('GESTOR_URL', 'http://127.0.0.1:8081')
BAU_URL = os.environ.get('BAU_URL', 'http://127.0.0.1:8082')
BITACORA_URL = os.environ.get('BITACORA_URL', 'http://127.0.0.1:8083')
CATEGORIES = ['CrowdStrike NG SIEM','Splunk','Python','PowerShell','Bash','SQL','KQL','JSON','XML','Regex','Cisco CES','Proofpoint','Microsoft 365','Power Automate','Snow','Otros']

def esc(value):
    return html.escape(str(value or ''), quote=True)

def load():
    try:
        return json.loads(DB.read_text(encoding='utf-8')) if DB.exists() else []
    except Exception:
        return []

def save(rows):
    DB.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')

def now():
    return datetime.now().isoformat(timespec='seconds')

def get_one(item_id):
    return next((x for x in load() if x.get('id') == item_id), None)

def options(current=''):
    return ''.join(f'<option value="{esc(x)}" {"selected" if x == current else ""}>{esc(x)}</option>' for x in CATEGORIES)

def layout(title, body):
    links=[('Inicio',PORTAL_URL),('Wiki',WIKI_URL),('Proyectos y tareas',GESTOR_URL),('BAU',BAU_URL),('Bitácora',BITACORA_URL),('Biblioteca','/')]
    nav=''.join(f'<a class="{"active" if n=="Biblioteca" else ""}" href="{esc(u)}">{esc(n)}</a>' for n,u in links)
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)} · Biblioteca</title><style>{CSS}
/* V19.5 · Word wrap visual en cajas de edición */
textarea{{white-space:pre-wrap!important;overflow-wrap:anywhere;word-break:normal;overflow-x:hidden}}
.form textarea.code{{white-space:pre-wrap!important;overflow-wrap:anywhere;word-break:normal;overflow-x:hidden}}
</style></head><body><header><div class="brand">Santander Mail Security · Biblioteca</div><div class="header-actions"><a class="btn" href="{esc(PORTAL_URL)}">Inicio común</a><a class="btn primary" href="/new">+ Nuevo fragmento</a></div></header><div class="shell"><aside><nav>{nav}</nav><div class="aside-note">Aplicación local<br>Sin usuarios<br>Datos en JSON</div></aside><main>{body}</main></div></body></html>'''

def home(qs):
    rows = load()
    query = qs.get('q', [''])[0].strip().casefold()
    category = qs.get('category', [''])[0]
    favorites = qs.get('fav', [''])[0]
    filtered = []
    for row in rows:
        haystack = ' '.join(str(row.get(k, '')) for k in ('title','category','tags','description','code','notes')).casefold()
        if query and query not in haystack:
            continue
        if category and row.get('category') != category:
            continue
        if favorites and not row.get('favorite'):
            continue
        filtered.append(row)
    filtered.sort(key=lambda r: (not r.get('favorite', False), r.get('title', '').casefold()))
    cards = ''.join(
        f'''<article class="card"><div class="row"><span class="badge">{esc(r.get('category'))}</span><span>{'★' if r.get('favorite') else '☆'}</span></div><h2><a href="/view?id={esc(r['id'])}">{esc(r.get('title'))}</a></h2><p>{esc(r.get('description'))}</p><small>{esc(r.get('tags'))}</small><pre class="{'crowdstrike-code' if r.get('category') == 'CrowdStrike NG SIEM' else ''}"><code>{esc(r.get('code'))}</code></pre><div><button onclick="navigator.clipboard.writeText(this.closest('article').querySelector('code').innerText)">Copiar</button> <a class="btn" href="/edit?id={esc(r['id'])}">Editar</a></div></article>'''
        for r in filtered
    ) or '<div class="card">No hay fragmentos.</div>'
    body = f'''<div class="head"><div><h1>Biblioteca Técnica</h1><p>Consultas, scripts, expresiones y fragmentos reutilizables.</p></div></div><form class="filters"><input name="q" value="{esc(qs.get('q',[''])[0])}" placeholder="Buscar por título, código, etiquetas o notas"><select name="category"><option value="">Todas las categorías</option>{options(category)}</select><label><input type="checkbox" name="fav" value="1" {'checked' if favorites else ''}> Solo favoritos</label><button>Buscar</button></form><div class="grid">{cards}</div>'''
    return layout('Biblioteca', body)

def form_page(row=None):
    row = row or {}
    return layout('Editar fragmento', f'''<h1>{'Editar' if row else 'Nuevo'} fragmento</h1><form class="card form" method="post" action="/save"><input type="hidden" name="id" value="{esc(row.get('id'))}"><label>Título<input name="title" required value="{esc(row.get('title'))}"></label><label>Categoría<select name="category">{options(row.get('category','Splunk'))}</select></label><label>Etiquetas<input name="tags" value="{esc(row.get('tags'))}" placeholder="correo, búsqueda, auditoría"></label><label>Descripción<textarea wrap="soft" name="description" rows="3">{esc(row.get('description'))}</textarea></label><label>Código<textarea wrap="soft" class="code" name="code" rows="18" required>{esc(row.get('code'))}</textarea></label><label>Notas<textarea wrap="soft" name="notes" rows="5">{esc(row.get('notes'))}</textarea></label><label><input type="checkbox" name="favorite" value="1" {'checked' if row.get('favorite') else ''}> Favorito</label><button class="primary">Guardar</button> <a class="btn" href="/">Cancelar</a></form>''')

def view_page(row):
    notes = esc(row.get('notes')).replace('\n', '<br>')
    return layout(row.get('title','Fragmento'), f'''<div class="head"><div><span class="badge">{esc(row.get('category'))}</span><h1>{esc(row.get('title'))} {'★' if row.get('favorite') else ''}</h1><p>{esc(row.get('description'))}</p></div><div><a class="btn" href="/edit?id={esc(row['id'])}">Editar</a></div></div><section class="card"><button onclick="navigator.clipboard.writeText(document.getElementById('code').innerText)">Copiar código</button><pre class="{'crowdstrike-code' if row.get('category') == 'CrowdStrike NG SIEM' else ''}"><code id="code">{esc(row.get('code'))}</code></pre></section><section class="card"><h2>Notas</h2><p class="notes">{notes}</p><p><b>Etiquetas:</b> {esc(row.get('tags'))}</p><form method="post" action="/delete" onsubmit="return confirm('¿Eliminar este fragmento?')"><input type="hidden" name="id" value="{esc(row['id'])}"><button class="danger">Eliminar</button></form></section>''')

class Handler(BaseHTTPRequestHandler):
    def send_html(self, text):
        data = text.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def redirect(self, url):
        self.send_response(303)
        self.send_header('Location', url)
        self.end_headers()

    def read_form(self):
        size = int(self.headers.get('Content-Length','0') or 0)
        return {k: v[-1] for k, v in parse_qs(self.rfile.read(size).decode('utf-8','replace'), keep_blank_values=True).items()}

    def do_GET(self):
        parsed = urlparse(self.path)
        qs = parse_qs(parsed.query)
        if parsed.path == '/':
            return self.send_html(home(qs))
        if parsed.path == '/new':
            return self.send_html(form_page())
        if parsed.path in ('/view','/edit'):
            row = get_one(qs.get('id',[''])[0])
            if not row:
                return self.send_error(404)
            return self.send_html(form_page(row) if parsed.path == '/edit' else view_page(row))
        self.send_error(404)

    def do_POST(self):
        form = self.read_form()
        if self.path == '/save':
            rows = load()
            item_id = form.get('id') or uuid.uuid4().hex
            old = next((x for x in rows if x.get('id') == item_id), {})
            row = {**old, **{k: form.get(k,'').strip() for k in ('title','category','tags','description','code','notes')}}
            row.update(id=item_id, favorite=form.get('favorite') == '1', created=old.get('created') or now(), updated=now())
            save([x for x in rows if x.get('id') != item_id] + [row])
            return self.redirect('/view?id=' + item_id)
        if self.path == '/delete':
            save([x for x in load() if x.get('id') != form.get('id')])
            return self.redirect('/')
        self.send_error(404)

    def log_message(self, *args):
        pass

CSS = '''*{box-sizing:border-box}body{margin:0;font:14px Arial,sans-serif;color:#26384a;background:#f3f6f9}header{height:62px;background:#25364a;color:#fff;padding:0 24px;display:flex;justify-content:space-between;align-items:center}.brand{font-size:19px;font-weight:bold}.header-actions{display:flex;gap:8px}.shell{display:grid;grid-template-columns:210px minmax(0,1fr);min-height:calc(100vh - 62px)}aside{background:#fff;border-right:1px solid #d9e1e8;padding:20px 14px}nav a{display:block;padding:10px 12px;color:#38516b;text-decoration:none;border-radius:5px;margin-bottom: 5px}nav a.active,nav a:hover{background:#FFF0F0;color:#B30000;font-weight:bold}.aside-note{margin:25px 10px;color:#7b8996;font-size:12px;line-height:1.6}main{padding:24px;max-width:1450px;width:100%;margin:0 auto}h1{margin-top:0}.head,.row{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}.filters{background:white;border:1px solid #d7e0e8;padding:14px;border-radius:8px;display:grid;grid-template-columns:1fr 220px auto auto;gap:9px;margin-bottom:16px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(310px,1fr));gap:15px}.card{background:white;border:1px solid #d7e0e8;border-radius:8px;padding:17px;box-shadow:0 1px 4px #0001}.card h2 a{text-decoration:none;color:#B30000}.btn,button{display:inline-block;border:1px solid #bdcad5;background:white;color:#31516e;padding:9px 13px;border-radius:5px;text-decoration:none;cursor:pointer;font:inherit}.crowdstrike-code{border:1px solid #EC0000!important;box-shadow:inset 0 3px 0 #EC0000}.primary{background:#EC0000!important;color:white!important;border-color:#EC0000!important}.danger{background:#a53b3b;color:white}.badge{background:#e7eef5;color:#B30000;border-radius:12px;padding:4px 8px;font-size:11px}input,select,textarea{width:100%;padding:10px;border:1px solid #bdcad5;border-radius:5px;font:inherit}.form label{display:block;font-weight:bold;margin-bottom:13px}.form label input,.form label select,.form label textarea{margin-top:6px;font-weight:normal}.code,pre{font-family:Consolas,monospace}pre{background:#17222d;color:#eaf2f8;padding:14px;border-radius:5px;overflow:auto;white-space:pre-wrap;word-break:break-word}.notes{line-height:1.6}@media(max-width:850px){.shell{grid-template-columns:1fr}aside{display:none}.filters{grid-template-columns:1fr}.head{display:block}}

/* V15.5 · Tipografía del editor unificada con Wiki */
.form label{font-size:12px;line-height:1.3}
.form input,.form select,.form textarea{
  font-size:12px;
  line-height:1.42;
}
.form textarea{
  padding:10px 12px;
  font-family:Arial,sans-serif;
  font-size:13px;
  line-height:1.42;
  resize:vertical;
}
.form textarea.code{
  min-height:430px;
  font-family:Consolas,"Courier New",monospace;
  font-size:13px;
  line-height:20px;
  tab-size:4;
  white-space:pre;
}

/* V16.0 · Tipografía común de Biblioteca */
:root{
  --doc-text-size:12px;
  --doc-h4-size:12px;
  --doc-h3-size:13px;
  --doc-h2-size:14px;
  --doc-h1-size:15px;
  --doc-h1-color:#EC0000;
}
main p,.notes,.card p{font-size:var(--doc-text-size);line-height:1.6}
main h1{font-size:var(--doc-h1-size);color:var(--doc-h1-color);font-weight:700;line-height:1.3}
main h2{font-size:var(--doc-h2-size);font-weight:700;line-height:1.3}
main h3{font-size:var(--doc-h3-size);font-weight:700;line-height:1.3}
main h4{font-size:var(--doc-h4-size);font-weight:700;font-style:italic;line-height:1.3}

.text-indent{white-space:pre;display:inline}

'''

if __name__ == '__main__':
    ThreadingHTTPServer(('127.0.0.1', int(os.environ.get('BIBLIOTECA_PORT','8084'))), Handler).serve_forever()
