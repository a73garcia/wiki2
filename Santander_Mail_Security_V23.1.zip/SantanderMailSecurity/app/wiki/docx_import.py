"""Importador DOCX -> Wiki sin dependencias externas.
Conserva títulos, texto, negrita/cursiva/subrayado, hipervínculos e imágenes.
"""
from __future__ import annotations
from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
from xml.etree import ElementTree as ET
import mimetypes, re, uuid

W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
A='http://schemas.openxmlformats.org/drawingml/2006/main'
PR='http://schemas.openxmlformats.org/package/2006/relationships'
NS={'w':W,'r':R,'a':A,'pr':PR}

def q(ns, name): return f'{{{ns}}}{name}'

def safe_ext(name, content_type=''):
    ext=Path(name).suffix.lower()
    if ext in {'.png','.jpg','.jpeg','.gif','.webp','.bmp','.tif','.tiff'}: return ext
    guessed=mimetypes.guess_extension(content_type or '')
    return guessed or '.png'

def rels_map(z: ZipFile):
    result={}
    path='word/_rels/document.xml.rels'
    if path not in z.namelist(): return result
    root=ET.fromstring(z.read(path))
    for rel in root:
        rid=rel.attrib.get('Id',''); target=rel.attrib.get('Target',''); typ=rel.attrib.get('Type','')
        result[rid]={'target':target,'type':typ,'external':rel.attrib.get('TargetMode')=='External'}
    return result

def style_headings(z: ZipFile):
    result={}
    if 'word/styles.xml' not in z.namelist(): return result
    root=ET.fromstring(z.read('word/styles.xml'))
    for st in root.findall('w:style',NS):
        sid=st.attrib.get(q(W,'styleId'),'')
        name=st.find('w:name',NS)
        label=(name.attrib.get(q(W,'val'),'') if name is not None else '').lower()
        text=(sid+' '+label).lower().replace('í','i')
        m=re.search(r'(?:heading|titulo|title)\s*([1-3])',text)
        if m: result[sid]=int(m.group(1))
    return result

def run_markup(run):
    text=''.join((n.text or '') for n in run.findall('.//w:t',NS))
    tabs=len(run.findall('.//w:tab',NS)); breaks=len(run.findall('.//w:br',NS))
    text=('\t'*tabs)+text+('\n'*breaks)
    if not text: return ''
    rp=run.find('w:rPr',NS)
    if rp is not None:
        if rp.find('w:b',NS) is not None: text=f'**{text}**'
        if rp.find('w:i',NS) is not None: text=f"''{text}''"
        if rp.find('w:u',NS) is not None: text=f'[u]{text}[/u]'
    return text

def extract_image(z, rel, uploads: Path, index: int):
    target=rel.get('target','').replace('\\','/')
    while target.startswith('../'): target=target[3:]
    member=target if target.startswith('word/') else 'word/'+target.lstrip('/')
    if member not in z.namelist(): return None
    ext=safe_ext(member)
    filename=f'word_import_{uuid.uuid4().hex[:12]}_{index:03d}{ext}'
    uploads.mkdir(parents=True,exist_ok=True)
    (uploads/filename).write_bytes(z.read(member))
    return filename

def paragraph_to_wiki(p, z, rels, headings, uploads, image_counter):
    ppr=p.find('w:pPr',NS); style=''
    if ppr is not None:
        ps=ppr.find('w:pStyle',NS)
        if ps is not None: style=ps.attrib.get(q(W,'val'),'')
    heading=headings.get(style)
    chunks=[]
    for child in list(p):
        if child.tag==q(W,'r'):
            chunks.append(run_markup(child))
            for blip in child.findall('.//a:blip',NS):
                rid=blip.attrib.get(q(R,'embed'))
                if rid and rid in rels:
                    image_counter[0]+=1
                    fn=extract_image(z,rels[rid],uploads,image_counter[0])
                    if fn: chunks.append(f'\n[[imagen:{fn}|Imagen importada de Word]]\n')
        elif child.tag==q(W,'hyperlink'):
            label=''.join(run_markup(r) for r in child.findall('.//w:r',NS))
            rid=child.attrib.get(q(R,'id'))
            url=rels.get(rid,{}).get('target','') if rid else ''
            chunks.append(f'[{url} {label}]' if url else label)
    text=''.join(chunks).strip()
    if not text: return ''
    if heading:
        marks='='*(heading+1)
        return f'{marks} {text} {marks}'
    return text

def import_docx(raw: bytes, uploads: Path):
    with ZipFile(BytesIO(raw),'r') as z:
        if 'word/document.xml' not in z.namelist(): raise ValueError('El archivo no contiene un documento Word válido.')
        rels=rels_map(z); headings=style_headings(z)
        root=ET.fromstring(z.read('word/document.xml'))
        body=root.find('w:body',NS)
        blocks=[]; image_counter=[0]; first_heading=''
        for child in list(body or []):
            if child.tag==q(W,'p'):
                text=paragraph_to_wiki(child,z,rels,headings,uploads,image_counter)
                if text:
                    if not first_heading and re.match(r'^==\s+',text):
                        first_heading=re.sub(r'^==\s*|\s*==$','',text).strip()
                    blocks.append(text)
            elif child.tag==q(W,'tbl'):
                rows=[]
                for tr in child.findall('w:tr',NS):
                    cells=[]
                    for tc in tr.findall('w:tc',NS):
                        parts=[]
                        for p in tc.findall('w:p',NS):
                            v=paragraph_to_wiki(p,z,rels,headings,uploads,image_counter)
                            if v: parts.append(v)
                        cells.append(' '.join(parts).replace('|','\\|'))
                    if cells: rows.append(cells)
                if rows:
                    width=max(len(r) for r in rows)
                    rows=[r+['']*(width-len(r)) for r in rows]
                    blocks.append('| '+' | '.join(rows[0])+' |\n| '+' | '.join(['---']*width)+' |\n'+'\n'.join('| '+' | '.join(r)+' |' for r in rows[1:]))
        title=first_heading or 'Documento importado'
        return {'title':title,'content':'\n\n'.join(blocks).strip(),'images':image_counter[0]}
