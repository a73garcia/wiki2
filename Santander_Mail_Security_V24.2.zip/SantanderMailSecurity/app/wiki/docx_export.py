from __future__ import annotations

from datetime import datetime
from pathlib import Path
from xml.etree import ElementTree as ET
import re
import zipfile
import mimetypes
import struct

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
PKG_REL = 'http://schemas.openxmlformats.org/package/2006/relationships'
WP = 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing'
A = 'http://schemas.openxmlformats.org/drawingml/2006/main'
PIC = 'http://schemas.openxmlformats.org/drawingml/2006/picture'
XML = 'http://www.w3.org/XML/1998/namespace'
ET.register_namespace('w', W)
ET.register_namespace('r', R)
ET.register_namespace('wp', WP)
ET.register_namespace('a', A)
ET.register_namespace('pic', PIC)

BLUE = '2F5597'
BODY_FONT = 'Aptos'
DISPLAY_FONT = 'Aptos Display'
MONO_FONT = 'Cascadia Mono'
CODE_FONT = 'Arial'
CODE_SIZE = 12  # 6 pt expressed in Word half-points


def q(name: str) -> str:
    return f'{{{W}}}{name}'


def rq(name: str) -> str:
    return f'{{{R}}}{name}'


def safe_filename(text: str) -> str:
    clean = re.sub(r'[\\/:*?"<>|]+', '-', str(text)).strip().strip('.')
    return (clean or 'procedimiento') + '.docx'


def metadata(content: str, page: dict) -> dict:
    values = {
        'TITLE': page.get('title', 'Procedimiento'),
        'VERSION': '1.0',
        'DATE': datetime.now().strftime('%d/%m/%Y'),
        'AUTHOR': 'A. Garcia',
        'REVISION_DESCRIPTION': 'Versión inicial',
    }
    aliases = {
        'title': 'TITLE', 'título': 'TITLE', 'titulo': 'TITLE',
        'version': 'VERSION', 'versión': 'VERSION',
        'date': 'DATE', 'fecha': 'DATE',
        'author': 'AUTHOR', 'autor': 'AUTHOR',
        'revision': 'REVISION_DESCRIPTION', 'revisión': 'REVISION_DESCRIPTION',
        'descripcion revision': 'REVISION_DESCRIPTION',
        'descripción revisión': 'REVISION_DESCRIPTION',
    }
    for line in str(content).splitlines()[:20]:
        m = re.match(r'^\s*([^:]{2,32})\s*:\s*(.*?)\s*$', line)
        if not m:
            continue
        key = aliases.get(m.group(1).strip().casefold())
        if key and m.group(2).strip():
            values[key] = re.sub(r'^\*\*(.*?)\*\*$', r'\1', m.group(2).strip())
    return values


def strip_header(content: str) -> str:
    aliases = {
        'number', 'número', 'numero', 'title', 'título', 'titulo', 'version', 'versión',
        'date', 'fecha', 'author', 'autor', 'status', 'estado', 'classification',
        'clasificación', 'clasificacion', 'revision', 'revisión', 'descripcion revision',
        'descripción revisión'
    }
    lines = str(content).replace('\r\n', '\n').replace('\r', '\n').split('\n')
    while lines:
        line = lines[0].strip()
        m = re.match(r'^([^:]{2,32})\s*:', line)
        if not line or (m and m.group(1).strip().casefold() in aliases):
            lines.pop(0)
        else:
            break
    return '\n'.join(lines).strip()


def parse_blocks(content: str):
    lines = strip_header(content).splitlines()
    blocks = []
    i = 0
    while i < len(lines):
        raw = lines[i]
        stripped = raw.strip()
        if not stripped:
            i += 1
            continue

        communication_box = re.match(r'^:::\s*(email|correo|example|ejemplo|caso|respuesta)(?:\s+(.+))?$', stripped, re.I)
        if communication_box:
            kind = communication_box.group(1).casefold()
            kind = {'email':'correo','example':'correo','ejemplo':'correo'}.get(kind,kind)
            title = (communication_box.group(2) or {'correo':'Correo','caso':'Caso','respuesta':'Respuesta'}[kind]).strip()
            content_lines=[]; i += 1
            while i < len(lines) and not re.match(r'^:::\s*end(?:email|correo|example|ejemplo|caso|respuesta)\s*$', lines[i].strip(), re.I):
                content_lines.append(lines[i]); i += 1
            if i < len(lines): i += 1
            blocks.append(('communication_box', kind, title, '\n'.join(content_lines)))
            continue

        notice = re.match(r'^!!!\s+(advertencia|warning|nota|note|informaci[oó]n|information|importante|important|error)(?:\s*:)?(?:\s+(.+))?$', stripped, re.I)
        if notice:
            notice_kind = notice.group(1).casefold()
            notice_kind = {
                'warning':'advertencia', 'note':'nota', 'information':'informacion',
                'información':'informacion', 'important':'importante'
            }.get(notice_kind, notice_kind)
            notice_title = (notice.group(2) or {
                'advertencia':'Advertencia', 'nota':'Nota', 'informacion':'Información',
                'importante':'Importante', 'error':'Error'
            }.get(notice_kind, 'Aviso')).strip()
            content_lines=[]; i += 1
            while i < len(lines) and lines[i].strip() != '!!!':
                content_lines.append(lines[i]); i += 1
            if i < len(lines): i += 1
            blocks.append(('notice_box', notice_kind, notice_title, '\n'.join(content_lines).strip()))
            continue

        fence = re.match(r'^\s*```\s*([^`]*)$', raw)
        if fence:
            language = fence.group(1).strip().lower()
            code = []
            i += 1
            while i < len(lines) and not re.match(r'^\s*```\s*$', lines[i]):
                code.append(lines[i])
                i += 1
            if i < len(lines):
                i += 1
            blocks.append(('email' if language in {'email', 'correo', 'mail'} else 'code', language, '\n'.join(code)))
            continue

        heading = re.match(r'^(#{1,6})\s+(.*?)\s*#*$', stripped)
        old_heading = re.match(r'^(={2,5})\s*(.*?)\s*\1$', stripped)
        if heading:
            blocks.append(('heading', min(3, len(heading.group(1))), heading.group(2)))
            i += 1
            continue
        if old_heading:
            blocks.append(('heading', min(3, len(old_heading.group(1)) - 1), old_heading.group(2)))
            i += 1
            continue

        if re.fullmatch(r'\s*(?:---+|___+|\*\*\*+)\s*', raw):
            blocks.append(('rule',))
            i += 1
            continue

        if stripped.startswith('|') and stripped.endswith('|'):
            rows = []
            while i < len(lines):
                candidate = lines[i].strip()
                if not (candidate.startswith('|') and candidate.endswith('|')):
                    break
                cells = [x.strip() for x in candidate.strip('|').split('|')]
                if not all(re.fullmatch(r':?-{3,}:?', x or '') for x in cells):
                    rows.append(cells)
                i += 1
            if rows:
                blocks.append(('table', rows))
            continue

        quote = re.match(r'^\s*>\s?(.*)$', raw)
        if quote:
            pieces = [quote.group(1)]
            i += 1
            while i < len(lines):
                qmatch = re.match(r'^\s*>\s?(.*)$', lines[i])
                if not qmatch:
                    break
                pieces.append(qmatch.group(1))
                i += 1
            blocks.append(('quote', '\n'.join(pieces)))
            continue

        item = re.match(r'^(\s*)([-*+] |\d+[.)]\s+)(.*)$', raw)
        if item:
            indent = len(item.group(1).replace('\t', '    '))
            level = min(8, indent // 2)
            kind = 'number' if re.match(r'\d', item.group(2)) else 'bullet'
            blocks.append((kind, level, item.group(3)))
            i += 1
            continue

        # Paragraphs can span consecutive normal lines. A forced Markdown line break is preserved.
        paragraph_lines = [raw.rstrip()]
        i += 1
        while i < len(lines):
            nxt = lines[i]
            ns = nxt.strip()
            if not ns:
                break
            if (re.match(r'^\s*```', nxt) or re.match(r'^#{1,6}\s+', ns) or
                    re.match(r'^(={2,5})\s*.*\s*\1$', ns) or
                    (ns.startswith('|') and ns.endswith('|')) or
                    re.match(r'^\s*>', nxt) or
                    re.match(r'^(\s*)([-*+] |\d+[.)]\s+)', nxt) or
                    re.fullmatch(r'\s*(?:---+|___+|\*\*\*+)\s*', nxt)):
                break
            paragraph_lines.append(nxt.rstrip())
            i += 1
        blocks.append(('paragraph', '\n'.join(paragraph_lines)))
    return blocks


class Renderer:
    def __init__(self, rels_root: ET.Element, image_dir: Path | None = None):
        self.rels_root = rels_root
        self.image_dir = image_dir
        self.media = {}
        self.next_image = 1
        ids = []
        for rel in rels_root:
            rid = rel.attrib.get('Id', '')
            m = re.fullmatch(r'rId(\d+)', rid)
            if m:
                ids.append(int(m.group(1)))
        self.next_rel = max(ids or [0]) + 1

    def relationship(self, url: str) -> str:
        rid = f'rId{self.next_rel}'
        self.next_rel += 1
        ET.SubElement(self.rels_root, f'{{{PKG_REL}}}Relationship', {
            'Id': rid,
            'Type': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink',
            'Target': url,
            'TargetMode': 'External',
        })
        return rid

    @staticmethod
    def run(text: str, *, bold=False, italic=False, strike=False, font=BODY_FONT,
            size=20, color=None, underline=False, preserve=True):
        r = ET.Element(q('r'))
        rpr = ET.SubElement(r, q('rPr'))
        fonts = ET.SubElement(rpr, q('rFonts'))
        for attr in ('ascii', 'hAnsi', 'cs'):
            fonts.set(q(attr), font)
        ET.SubElement(rpr, q('sz')).set(q('val'), str(size))
        ET.SubElement(rpr, q('szCs')).set(q('val'), str(size))
        if bold:
            ET.SubElement(rpr, q('b'))
        if italic:
            ET.SubElement(rpr, q('i'))
        if strike:
            ET.SubElement(rpr, q('strike'))
        if underline:
            ET.SubElement(rpr, q('u')).set(q('val'), 'single')
        if color:
            ET.SubElement(rpr, q('color')).set(q('val'), color)
        # Tabs and newlines become genuine Word elements.
        parts = re.split(r'(\t|\n)', text)
        for part in parts:
            if part == '\t':
                ET.SubElement(r, q('tab'))
            elif part == '\n':
                ET.SubElement(r, q('br'))
            elif part:
                t = ET.SubElement(r, q('t'))
                if preserve:
                    t.set(f'{{{XML}}}space', 'preserve')
                t.text = part
        return r

    @staticmethod
    def _image_size(data: bytes, suffix: str):
        """Return image width/height in pixels using only the Python standard library."""
        suffix = suffix.lower()
        try:
            if suffix == '.png' and data[:8] == b'\x89PNG\r\n\x1a\n':
                return struct.unpack('>II', data[16:24])
            if suffix in {'.gif'} and data[:3] == b'GIF':
                return struct.unpack('<HH', data[6:10])
            if suffix in {'.jpg', '.jpeg'} and data[:2] == b'\xff\xd8':
                pos = 2
                while pos + 9 < len(data):
                    if data[pos] != 0xFF:
                        pos += 1
                        continue
                    marker = data[pos + 1]
                    pos += 2
                    if marker in (0xD8, 0xD9):
                        continue
                    length = int.from_bytes(data[pos:pos + 2], 'big')
                    if marker in {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}:
                        height = int.from_bytes(data[pos + 3:pos + 5], 'big')
                        width = int.from_bytes(data[pos + 5:pos + 7], 'big')
                        return width, height
                    pos += max(length, 2)
        except (ValueError, struct.error, IndexError):
            pass
        return 1200, 675

    def _find_image(self, target: str):
        if not self.image_dir:
            return None
        raw = target.strip().replace('\\', '/')
        if raw.startswith('/uploads/'):
            raw = raw[len('/uploads/'):]
        raw = raw.split('?', 1)[0].split('#', 1)[0]
        name = Path(raw).name
        candidate = self.image_dir / name
        if candidate.is_file():
            return candidate
        # Case-insensitive fallback for Windows-created files.
        folded = name.casefold()
        try:
            return next((x for x in self.image_dir.iterdir() if x.is_file() and x.name.casefold() == folded), None)
        except OSError:
            return None

    def image_paragraph(self, target: str, caption: str = ''):
        source = self._find_image(target)
        if not source:
            p = self.paragraph(f'[Imagen no encontrada: {Path(target).name}]')
            return [p]
        data = source.read_bytes()
        suffix = source.suffix.lower() or '.png'
        if suffix == '.jpeg':
            suffix = '.jpg'
        media_name = f'image{self.next_image}{suffix}'
        self.next_image += 1
        self.media[media_name] = data
        rid = f'rId{self.next_rel}'
        self.next_rel += 1
        ET.SubElement(self.rels_root, f'{{{PKG_REL}}}Relationship', {
            'Id': rid,
            'Type': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/image',
            'Target': f'media/{media_name}',
        })
        width_px, height_px = self._image_size(data, suffix)
        max_cx = 5_900_000  # about 6.45 inches, safe for A4 portrait margins
        cx = min(max_cx, max(900_000, int(width_px * 9525)))
        cy = max(500_000, int(cx * height_px / max(width_px, 1)))

        p = ET.Element(q('p'))
        ppr = ET.SubElement(p, q('pPr'))
        ET.SubElement(ppr, q('jc')).set(q('val'), 'center')
        ET.SubElement(ppr, q('spacing'), {q('before'): '80', q('after'): '80'})
        run = ET.SubElement(p, q('r'))
        drawing = ET.SubElement(run, q('drawing'))
        inline = ET.SubElement(drawing, f'{{{WP}}}inline', {'distT':'0','distB':'0','distL':'0','distR':'0'})
        ET.SubElement(inline, f'{{{WP}}}extent', {'cx':str(cx), 'cy':str(cy)})
        ET.SubElement(inline, f'{{{WP}}}effectExtent', {'l':'0','t':'0','r':'0','b':'0'})
        ET.SubElement(inline, f'{{{WP}}}docPr', {'id':str(self.next_image + 100), 'name':source.name, 'descr':caption or source.name})
        cNv = ET.SubElement(inline, f'{{{WP}}}cNvGraphicFramePr')
        ET.SubElement(cNv, f'{{{A}}}graphicFrameLocks', {'noChangeAspect':'1'})
        graphic = ET.SubElement(inline, f'{{{A}}}graphic')
        gd = ET.SubElement(graphic, f'{{{A}}}graphicData', {'uri':PIC})
        pic = ET.SubElement(gd, f'{{{PIC}}}pic')
        nv = ET.SubElement(pic, f'{{{PIC}}}nvPicPr')
        ET.SubElement(nv, f'{{{PIC}}}cNvPr', {'id':'0', 'name':source.name, 'descr':caption or source.name})
        ET.SubElement(nv, f'{{{PIC}}}cNvPicPr')
        bf = ET.SubElement(pic, f'{{{PIC}}}blipFill')
        ET.SubElement(bf, f'{{{A}}}blip', {rq('embed'):rid})
        stretch = ET.SubElement(bf, f'{{{A}}}stretch')
        ET.SubElement(stretch, f'{{{A}}}fillRect')
        sp = ET.SubElement(pic, f'{{{PIC}}}spPr')
        xfrm = ET.SubElement(sp, f'{{{A}}}xfrm')
        ET.SubElement(xfrm, f'{{{A}}}off', {'x':'0','y':'0'})
        ET.SubElement(xfrm, f'{{{A}}}ext', {'cx':str(cx),'cy':str(cy)})
        geom = ET.SubElement(sp, f'{{{A}}}prstGeom', {'prst':'rect'})
        ET.SubElement(geom, f'{{{A}}}avLst')
        result = [p]
        if caption:
            cp = ET.Element(q('p'))
            cppr = ET.SubElement(cp, q('pPr'))
            ET.SubElement(cppr, q('jc')).set(q('val'), 'center')
            ET.SubElement(cppr, q('spacing'), {q('after'):'100'})
            cp.append(self.run(caption, italic=True, size=18, color='666666'))
            result.append(cp)
        return result

    def hyperlink(self, label: str, url: str):
        h = ET.Element(q('hyperlink'))
        h.set(rq('id'), self.relationship(url))
        h.append(self.run(label, color='0563C1', underline=True))
        return h

    def inline(self, text: str, *, email=False):
        nodes = []
        # Ordered alternatives avoid emitting Markdown delimiters in the document.
        token = re.compile(
            r'(!?\[[^\]]+\]\([^\s)]+(?:\s+"[^"]*")?\)|'
            r'`[^`]+`|\*\*[^*]+\*\*|__[^_]+__|~~[^~]+~~|\[u\].+?\[/u\]|'
            r'\[(?:rojo|azul|verde|amarillo|gris)\].+?\[/(?:rojo|azul|verde|amarillo|gris)\]|'
            r'(?<!\*)\*[^*\n]+\*(?!\*)|(?<!_)_[^_\n]+_(?!_))'
        )
        pos = 0
        for m in token.finditer(text):
            if m.start() > pos:
                nodes.append(self.run(text[pos:m.start()], italic=email, size=18 if email else 20))
            value = m.group(0)
            link = re.fullmatch(r'\[([^\]]+)\]\(([^\s)]+)(?:\s+"[^"]*")?\)', value)
            image = re.fullmatch(r'!\[([^\]]*)\]\(([^\s)]+)(?:\s+"[^"]*")?\)', value)
            if image:
                label = image.group(1) or 'Imagen'
                nodes.append(self.run(label, italic=True, color='666666'))
            elif link:
                nodes.append(self.hyperlink(link.group(1), link.group(2)))
            elif value.startswith('`'):
                nodes.append(self.run(value[1:-1], font=MONO_FONT, size=18, color='9C0006'))
            elif value.startswith(('**', '__')):
                nodes.append(self.run(value[2:-2], bold=True, italic=email, size=18 if email else 20))
            elif value.startswith('~~'):
                nodes.append(self.run(value[2:-2], strike=True, italic=email, size=18 if email else 20))
            elif value.lower().startswith('[u]'):
                nodes.append(self.run(value[3:-4], underline=True, italic=email, size=18 if email else 20))
            elif re.match(r'^\[(rojo|azul|verde|amarillo|gris)\]', value, re.I):
                cm = re.match(r'^\[(rojo|azul|verde|amarillo|gris)\](.*?)\[/\1\]$', value, re.I | re.S)
                colors = {'rojo':'C00000','azul':'2F5597','verde':'008000','amarillo':'9C6500','gris':'666666'}
                if cm:
                    nodes.append(self.run(cm.group(2), color=colors.get(cm.group(1).casefold()), italic=email, size=18 if email else 20))
            else:
                nodes.append(self.run(value[1:-1], italic=True, size=18 if email else 20))
            pos = m.end()
        if pos < len(text):
            nodes.append(self.run(text[pos:], italic=email, size=18 if email else 20))
        return nodes

    def paragraph(self, text='', *, level=None, list_kind=None, list_level=0,
                  code=False, email=False, quote=False):
        p = ET.Element(q('p'))
        ppr = ET.SubElement(p, q('pPr'))
        spacing = ET.SubElement(ppr, q('spacing'))
        spacing.set(q('after'), '80' if not level else '100')
        spacing.set(q('line'), '240')
        spacing.set(q('lineRule'), 'auto')

        if level:
            spacing.set(q('before'), '180')
            style_id = {1: 'Heading1', 2: 'Heading2', 3: 'Heading3'}[level]
            ET.SubElement(ppr, q('pStyle')).set(q('val'), style_id)
            font = DISPLAY_FONT if level in (1, 2) else BODY_FONT
            size = {1: 28, 2: 24, 3: 24}[level]
            p.append(self.run(text, bold=True, font=font, size=size, color=BLUE))
            return p

        if list_kind:
            left = 420 + list_level * 360
            ind = ET.SubElement(ppr, q('ind'))
            ind.set(q('left'), str(left))
            ind.set(q('hanging'), '240')
            marker = '• ' if list_kind == 'bullet' else '1. '
            p.append(self.run(marker, size=20))
        elif quote:
            ind = ET.SubElement(ppr, q('ind'))
            ind.set(q('left'), '420')
            ET.SubElement(ppr, q('pBdr'))
            ppr.find(q('pBdr')).append(ET.Element(q('left'), {
                q('val'): 'single', q('sz'): '12', q('space'): '8', q('color'): BLUE
            }))
        elif code:
            shd = ET.SubElement(ppr, q('shd'))
            shd.set(q('fill'), 'F3F4F6')
            ind = ET.SubElement(ppr, q('ind'))
            ind.set(q('left'), '240')
            ind.set(q('right'), '240')
            borders = ET.SubElement(ppr, q('pBdr'))
            for edge in ('top', 'left', 'bottom', 'right'):
                ET.SubElement(borders, q(edge), {
                    q('val'): 'single', q('sz'): '4', q('space'): '3', q('color'): 'D9D9D9'
                })
        elif email:
            ET.SubElement(ppr, q('jc')).set(q('val'), 'left')
            ET.SubElement(ppr, q('shd')).set(q('fill'), 'F7F9FB')
            ind = ET.SubElement(ppr, q('ind')); ind.set(q('left'),'240'); ind.set(q('right'),'240')
            borders = ET.SubElement(ppr, q('pBdr'))
            for edge in ('top','left','bottom','right'):
                ET.SubElement(borders, q(edge), {q('val'):'single', q('sz'):'4', q('space'):'4', q('color'):'CBD5DF'})
        else:
            ET.SubElement(ppr, q('jc')).set(q('val'), 'both')

        for node in self.inline(text, email=email):
            p.append(node)
        return p

    def syntax_runs(self, code: str, language: str):
        # Lightweight, dependency-free highlighting. It preserves every character.
        language = (language or '').lower()
        keywords = {
            'python': r'\b(?:and|as|assert|async|await|break|class|continue|def|del|elif|else|except|False|finally|for|from|global|if|import|in|is|lambda|None|nonlocal|not|or|pass|raise|return|True|try|while|with|yield)\b',
            'powershell': r'(?i:\b(?:function|param|if|elseif|else|foreach|for|while|switch|return|try|catch|finally|throw|write-host|write-output|select-object|where-object)\b)',
            'sql': r'(?i:\b(?:select|from|where|join|left|right|inner|outer|on|group|by|order|having|as|and|or|not|null|insert|update|delete|create|table|case|when|then|else|end|distinct|limit)\b)',
            'spl': r'(?i:\b(?:index|search|stats|eval|where|table|fields|rename|rex|spath|timechart|chart|dedup|sort|lookup|append|join|transaction|eventstats|streamstats|bin|bucket|makeresults)\b)',
            'cql': r'(?i:\b(?:select|from|where|group|by|order|limit|let|case|when|then|else|end|and|or|not|in|contains)\b)',
            'javascript': r'\b(?:const|let|var|function|return|if|else|for|while|class|new|true|false|null|undefined|async|await|try|catch|throw|import|export|from)\b',
        }
        key = 'javascript' if language in {'js', 'javascript'} else language
        kw = keywords.get(key)
        parts = []
        combined = []
        if kw:
            combined.append(f'(?P<kw>{kw})')
        combined += [
            r'(?P<comment>#[^\n]*|//[^\n]*|/\*[\s\S]*?\*/|--[^\n]*)',
            r'(?P<string>"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\')',
            r'(?P<number>\b\d+(?:\.\d+)?\b)',
            r'(?P<operator>\|>|\||==|!=|>=|<=|=>|[-+*/%=<>])',
        ]
        pattern = re.compile('|'.join(combined))
        pos = 0
        colors = {'kw': '0000FF', 'comment': '608B4E', 'string': 'A31515', 'number': '098658', 'operator': '7F6000'}
        for m in pattern.finditer(code):
            if m.start() > pos:
                parts.append(self.run(code[pos:m.start()], font=CODE_FONT, size=CODE_SIZE))
            kind = m.lastgroup or ''
            parts.append(self.run(m.group(0), font=CODE_FONT, size=CODE_SIZE, color=colors.get(kind)))
            pos = m.end()
        if pos < len(code):
            parts.append(self.run(code[pos:], font=CODE_FONT, size=CODE_SIZE))
        return parts

    def code_paragraph(self, code: str, language: str):
        p = self.paragraph('', code=True)
        # Remove the empty run generated by paragraph().
        for child in list(p):
            if child.tag == q('r'):
                p.remove(child)
        if language:
            p.append(self.run(language.upper() + '\n', bold=True, font=CODE_FONT, size=CODE_SIZE, color='666666'))
        for r in self.syntax_runs(code, language):
            p.append(r)
        return p

    def rule(self):
        p = ET.Element(q('p'))
        ppr = ET.SubElement(p, q('pPr'))
        bdr = ET.SubElement(ppr, q('pBdr'))
        ET.SubElement(bdr, q('bottom'), {q('val'): 'single', q('sz'): '6', q('space'): '1', q('color'): 'B4C6E7'})
        return p

    def table(self, rows):
        tbl = ET.Element(q('tbl'))
        pr = ET.SubElement(tbl, q('tblPr'))
        ET.SubElement(pr, q('tblW'), {q('w'): '0', q('type'): 'auto'})
        ET.SubElement(pr, q('tblLayout'), {q('type'): 'autofit'})
        borders = ET.SubElement(pr, q('tblBorders'))
        for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
            ET.SubElement(borders, q(edge), {q('val'): 'single', q('sz'): '4', q('color'): 'B7B7B7'})
        cols = max(len(r) for r in rows)
        for ri, row in enumerate(rows):
            tr = ET.SubElement(tbl, q('tr'))
            for ci in range(cols):
                tc = ET.SubElement(tr, q('tc'))
                tcpr = ET.SubElement(tc, q('tcPr'))
                if ri == 0:
                    ET.SubElement(tcpr, q('shd')).set(q('fill'), BLUE)
                p = ET.SubElement(tc, q('p'))
                ppr = ET.SubElement(p, q('pPr'))
                ET.SubElement(ppr, q('spacing'), {q('after'): '40'})
                text = row[ci] if ci < len(row) else ''
                for node in self.inline(text):
                    # Header runs need white/bold formatting, so rebuild text for reliability.
                    if ri == 0 and node.tag == q('r'):
                        rendered = ''.join(t.text or '' for t in node.iter(q('t')))
                        p.append(self.run(rendered, bold=True, size=18, color='FFFFFF'))
                    else:
                        p.append(node)
        return tbl

    def _cell(self, text='', *, fill=None, width=None, bold=False, color=None, email=False, border_color='CBD5DF'):
        tc = ET.Element(q('tc'))
        tcpr = ET.SubElement(tc, q('tcPr'))
        if width:
            ET.SubElement(tcpr, q('tcW'), {q('w'): str(width), q('type'): 'dxa'})
        if fill:
            ET.SubElement(tcpr, q('shd')).set(q('fill'), fill)
        mar = ET.SubElement(tcpr, q('tcMar'))
        for side in ('top','left','bottom','right'):
            ET.SubElement(mar, q(side), {q('w'):'90', q('type'):'dxa'})
        borders = ET.SubElement(tcpr, q('tcBorders'))
        for edge in ('top','left','bottom','right'):
            ET.SubElement(borders, q(edge), {q('val'):'single', q('sz'):'4', q('color'):border_color})
        p = ET.SubElement(tc, q('p'))
        ppr = ET.SubElement(p, q('pPr'))
        ET.SubElement(ppr, q('spacing'), {q('after'):'20', q('line'):'220'})
        for node in self.inline(text, email=email):
            if bold and node.tag == q('r'):
                rpr=node.find(q('rPr'))
                if rpr is None: rpr=ET.SubElement(node,q('rPr'))
                ET.SubElement(rpr,q('b'))
            if color and node.tag == q('r'):
                rpr=node.find(q('rPr'))
                if rpr is None: rpr=ET.SubElement(node,q('rPr'))
                ET.SubElement(rpr,q('color')).set(q('val'),color)
            p.append(node)
        return tc

    def communication_table(self, subtype: str, title: str, raw: str):
        tbl=ET.Element(q('tbl'))
        pr=ET.SubElement(tbl,q('tblPr'))
        ET.SubElement(pr,q('tblW'),{q('w'):'0',q('type'):'auto'})
        ET.SubElement(pr,q('tblLayout'),{q('type'):'autofit'})
        borders=ET.SubElement(pr,q('tblBorders'))
        for edge in ('top','left','bottom','right','insideH','insideV'):
            ET.SubElement(borders,q(edge),{q('val'):'single',q('sz'):'4',q('color'):'CBD5DF'})
        header=ET.SubElement(tbl,q('tr'))
        hc=self._cell(title,fill='EAF0F7',bold=True,color=BLUE,border_color='9FB3C8')
        tcpr=hc.find(q('tcPr')); ET.SubElement(tcpr,q('gridSpan')).set(q('val'),'2')
        header.append(hc)
        if subtype=='correo':
            fields={'para':'','cc':'','cco':'','asunto':''}; body=[]; in_body=False
            for line in raw.splitlines():
                m=re.match(r'^\s*(Para|To|CC|CCO|BCC|Asunto|Subject)\s*:\s*(.*)$',line,re.I)
                if m and not in_body:
                    key=m.group(1).casefold(); key={'to':'para','bcc':'cco','subject':'asunto'}.get(key,key)
                    fields[key]=m.group(2)
                else:
                    if line.strip() or body: in_body=True
                    body.append(line)
            for label,key in [('Para','para'),('CC','cc'),('CCO','cco'),('Asunto','asunto')]:
                tr=ET.SubElement(tbl,q('tr'))
                tr.append(self._cell(label,fill='F3F6F9',width=1300,bold=True,color='34495E'))
                tr.append(self._cell(fields[key],width=8200))
            body_text='\n'.join(body).strip()
        elif subtype=='caso':
            case_title=''; body=[]
            for line in raw.splitlines():
                m=re.match(r'^\s*(Título|Titulo|Title)\s*:\s*(.*)$',line,re.I)
                if m and not case_title and not body: case_title=m.group(2)
                else: body.append(line)
            tr=ET.SubElement(tbl,q('tr'))
            tr.append(self._cell('Título',fill='F3F6F9',width=1300,bold=True,color='34495E'))
            tr.append(self._cell(case_title,width=8200))
            body_text='\n'.join(body).strip()
        else:
            body_text=raw.strip()
        if body_text:
            tr=ET.SubElement(tbl,q('tr'))
            bc=self._cell(body_text,fill='F9FBFC',email=True,border_color='CBD5DF')
            tcpr=bc.find(q('tcPr')); ET.SubElement(tcpr,q('gridSpan')).set(q('val'),'2')
            tr.append(bc)
        return tbl

    def notice_table(self, kind: str, title: str, body: str):
        palette={
            'advertencia':('FFF4DB','B86B00'),
            'nota':('EEF5FF','2F5597'),
            'informacion':('EAF4FF','1D70B8'),
            'importante':('FFF0F0','B32424'),
            'error':('FFF0F0','B32424'),
        }
        fill,accent=palette.get(kind,('F3F4F6','666666'))
        tbl=ET.Element(q('tbl')); pr=ET.SubElement(tbl,q('tblPr'))
        # 5000 = 100 % del ancho disponible en Word.
        ET.SubElement(pr,q('tblW'),{q('w'):'5000',q('type'):'pct'})
        ET.SubElement(pr,q('tblLayout'),{q('type'):'fixed'})
        ET.SubElement(pr,q('jc'),{q('val'):'left'})
        grid=ET.SubElement(tbl,q('tblGrid'))
        ET.SubElement(grid,q('gridCol'),{q('w'):'9000'})
        borders=ET.SubElement(pr,q('tblBorders'))
        for edge in ('top','bottom','right'):
            ET.SubElement(borders,q(edge),{q('val'):'single',q('sz'):'4',q('color'):accent})
        ET.SubElement(borders,q('left'),{q('val'):'single',q('sz'):'18',q('color'):accent})
        tr=ET.SubElement(tbl,q('tr')); tc=ET.SubElement(tr,q('tc'))
        tcpr=ET.SubElement(tc,q('tcPr'))
        ET.SubElement(tcpr,q('tcW'),{q('w'):'5000',q('type'):'pct'})
        ET.SubElement(tcpr,q('shd')).set(q('fill'),fill)
        mar=ET.SubElement(tcpr,q('tcMar'))
        for side in ('top','left','bottom','right'):
            ET.SubElement(mar,q(side),{q('w'):'120',q('type'):'dxa'})
        p=ET.SubElement(tc,q('p')); ppr=ET.SubElement(p,q('pPr')); ET.SubElement(ppr,q('spacing'),{q('after'):'70'})
        p.append(self.run(title,bold=True,color=accent,size=20))
        if body:
            for line in body.splitlines() or ['']:
                bp=ET.SubElement(tc,q('p')); bppr=ET.SubElement(bp,q('pPr')); ET.SubElement(bppr,q('spacing'),{q('after'):'30'})
                for node in self.inline(line): bp.append(node)
        return tbl

    def body_elements(self, content: str):
        result = []
        for block in parse_blocks(content):
            kind = block[0]
            if kind == 'heading':
                result.append(self.paragraph(block[2], level=block[1]))
            elif kind in {'bullet', 'number'}:
                result.append(self.paragraph(block[2], list_kind=kind, list_level=block[1]))
            elif kind == 'code':
                result.append(self.code_paragraph(block[2], block[1]))
            elif kind == 'email':
                result.append(self.paragraph(block[2], email=True))
            elif kind == 'communication_box':
                result.append(self.communication_table(block[1], block[2], block[3]))
            elif kind == 'notice_box':
                result.append(self.notice_table(block[1], block[2], block[3]))
                # Separación visual entre el aviso y el bloque siguiente (10 pt aprox.).
                spacer=ET.Element(q('p'))
                spacer_pr=ET.SubElement(spacer,q('pPr'))
                ET.SubElement(spacer_pr,q('spacing'),{
                    q('before'):'80', q('after'):'120',
                    q('line'):'40', q('lineRule'):'exact'
                })
                result.append(spacer)
            elif kind == 'table':
                result.append(self.table(block[1]))
            elif kind == 'quote':
                result.append(self.paragraph(block[1], quote=True))
            elif kind == 'rule':
                result.append(self.rule())
            else:
                text = block[1]
                image_pattern = re.compile(
                    r'\[\[imagen:([^\]|]+)(?:\|([^\]]+))?\]\]|!\[([^\]]*)\]\(([^\s)]+)(?:\s+"[^"]*")?\)',
                    re.I,
                )
                pos = 0
                found = False
                for match in image_pattern.finditer(text):
                    found = True
                    before = text[pos:match.start()].strip()
                    if before:
                        result.append(self.paragraph(before))
                    target = match.group(1) or match.group(4) or ''
                    caption = (match.group(2) if match.group(1) else match.group(3)) or ''
                    result.extend(self.image_paragraph(target, caption.strip()))
                    pos = match.end()
                after = text[pos:].strip()
                if found:
                    if after:
                        result.append(self.paragraph(after))
                else:
                    result.append(self.paragraph(text))
        return result or [self.paragraph('')]

    def index_elements(self, content: str):
        elements = []
        count = [0, 0, 0]
        for block in parse_blocks(content):
            if block[0] != 'heading':
                continue
            level = max(1, min(3, block[1]))
            count[level - 1] += 1
            for pos in range(level, 3):
                count[pos] = 0
            number = '.'.join(str(x) for x in count[:level] if x)
            p = self.paragraph(f'{number}. {block[2]}')
            p.find(q('pPr')).append(ET.Element(q('ind'), {q('left'): str((level - 1) * 260)}))
            elements.append(p)
        return elements or [self.paragraph('El documento no contiene títulos para generar el índice.')]


def replace_text(root, replacements):
    # Supports markers split across runs by rebuilding only paragraphs that contain them.
    for p in root.iter(q('p')):
        texts = list(p.iter(q('t')))
        if not texts:
            continue
        merged = ''.join(t.text or '' for t in texts)
        changed = merged
        for key, value in replacements.items():
            changed = changed.replace('{{' + key + '}}', str(value))
        if changed != merged:
            texts[0].text = changed
            for t in texts[1:]:
                t.text = ''


def replace_marker(root, marker: str, elements):
    parent_map = {child: parent for parent in root.iter() for child in parent}
    for p in list(root.iter(q('p'))):
        text = ''.join(t.text or '' for t in p.iter(q('t')))
        if marker not in text:
            continue
        parent = parent_map.get(p)
        if parent is None:
            continue
        index = list(parent).index(p)
        parent.remove(p)
        for offset, element in enumerate(elements):
            parent.insert(index + offset, element)
        return True
    return False


def generate(template: Path, output: Path, page: dict) -> Path:
    if not template.is_file():
        raise FileNotFoundError(f'No se encuentra la plantilla: {template}')
    output.parent.mkdir(parents=True, exist_ok=True)
    content = page.get('content', '')
    meta = metadata(content, page)

    with zipfile.ZipFile(template, 'r') as zin:
        document_xml = ET.fromstring(zin.read('word/document.xml'))
        rels_xml = ET.fromstring(zin.read('word/_rels/document.xml.rels'))
        image_dir = template.parent.parent / 'imagenes'
        renderer = Renderer(rels_xml, image_dir=image_dir)
        replace_marker(document_xml, '{{WIKI_INDEX}}', renderer.index_elements(content))
        replace_marker(document_xml, '{{WIKI_CONTENT}}', renderer.body_elements(content))
        replace_text(document_xml, meta)

        with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                data = zin.read(item.filename)
                if item.filename == 'word/document.xml':
                    data = ET.tostring(document_xml, encoding='utf-8', xml_declaration=True)
                elif item.filename == 'word/_rels/document.xml.rels':
                    data = ET.tostring(rels_xml, encoding='utf-8', xml_declaration=True)
                elif item.filename == '[Content_Types].xml':
                    try:
                        root = ET.fromstring(data)
                        existing = {x.attrib.get('Extension', '').lower() for x in root}
                        content_types = {'.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.gif':'image/gif', '.webp':'image/webp'}
                        ns = 'http://schemas.openxmlformats.org/package/2006/content-types'
                        for media_name in renderer.media:
                            ext = Path(media_name).suffix.lower().lstrip('.')
                            if ext and ext not in existing:
                                ET.SubElement(root, f'{{{ns}}}Default', {'Extension':ext, 'ContentType':content_types.get('.'+ext, mimetypes.guess_type(media_name)[0] or 'application/octet-stream')})
                                existing.add(ext)
                        data = ET.tostring(root, encoding='utf-8', xml_declaration=True)
                    except ET.ParseError:
                        pass
                elif item.filename in ('docProps/core.xml', 'docProps/custom.xml'):
                    try:
                        root = ET.fromstring(data)
                        replace_text(root, meta)
                        data = ET.tostring(root, encoding='utf-8', xml_declaration=True)
                    except ET.ParseError:
                        pass
                zout.writestr(item, data)
            for media_name, media_data in renderer.media.items():
                zout.writestr(f'word/media/{media_name}', media_data)
    return output
