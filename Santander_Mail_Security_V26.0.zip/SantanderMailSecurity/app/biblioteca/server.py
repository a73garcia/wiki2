from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path
from datetime import datetime
import os, json, html, uuid

CORPORATE_THEME_CSS = r""":root {
  --santander-red:#EC0000;
  --santander-red-dark:#C00000;
  --santander-red-deep:#990000;
  --santander-red-soft:#FDECEC;
  --santander-coral:#FF5A5F;
  --santander-orange:#F57C00;
  --santander-black:#111111;
  --santander-text:#2D2D2D;
  --santander-grey-700:#5B5B5B;
  --santander-grey-500:#8A8A8A;
  --santander-grey-300:#C9C9C9;
  --santander-grey-200:#E5E5E5;
  --santander-grey-100:#F2F2F2;
  --santander-bg:#F7F7F7;
  --santander-white:#FFFFFF;
  --brand-font:"Santander Headline","Segoe UI",Arial,sans-serif;
  --body-font:"Santander Headline","Segoe UI",Arial,sans-serif;
}
*{box-sizing:border-box}
html,body{font-family:var(--body-font)!important}
body{background:var(--santander-bg)!important;color:var(--santander-text)!important}
header{
  background:linear-gradient(105deg,var(--santander-red-dark),var(--santander-red))!important;
  color:#fff!important;border-bottom:0!important;box-shadow:0 3px 12px rgba(80,0,0,.18)!important;
}
.brand{font-family:var(--brand-font)!important;font-weight:600!important;letter-spacing:.1px!important;display:flex!important;align-items:center!important;gap:12px!important}
.brand::before{
  content:"";display:inline-block;width:36px;height:34px;flex:0 0 36px;
  background-image:url("/corporate-logo.png");
  background-size:contain;background-position:center;background-repeat:no-repeat;
  filter:brightness(0) invert(1);
}
.shell aside,aside{background:#fff!important;border-right:1px solid var(--santander-grey-200)!important}
aside nav a,nav a{color:#3c3c3c!important;border-radius:6px!important;transition:.15s ease!important}
aside nav a:hover,nav a:hover{background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important}
aside nav a.active,nav a.active{
  background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important;
  border-left:4px solid var(--santander-red)!important;font-weight:700!important;
}
main h1,main h2,.page-title{font-family:var(--brand-font)!important;color:var(--santander-red-dark)!important}
main h3{font-family:var(--brand-font)!important;color:var(--santander-black)!important}
a{color:var(--santander-red-dark)}
a:hover{color:var(--santander-red)}
.btn,.button,button,input[type=submit],input[type=button]{
  font-family:var(--body-font)!important;border-radius:6px!important;box-shadow:none!important;
}
.btn.primary,.btn-primary,.button-primary,button.primary,input[type=submit]{
  background:var(--santander-red)!important;border-color:var(--santander-red)!important;color:#fff!important;
}
.btn.primary:hover,.btn-primary:hover,button.primary:hover,input[type=submit]:hover{
  background:var(--santander-red-dark)!important;border-color:var(--santander-red-dark)!important;
}
.btn:not(.primary),button:not(.primary){
  background:#fff!important;border-color:var(--santander-grey-300)!important;color:var(--santander-text)!important;
}
.card,.panel,.widget,.stat,.tile,.project-card,.task-card,.wiki-card,.bau-card{
  background:#fff!important;border:1px solid var(--santander-grey-200)!important;
  border-radius:10px!important;box-shadow:0 2px 8px rgba(0,0,0,.045)!important;
}
table{background:#fff!important;border-color:var(--santander-grey-200)!important}
thead th,table th{background:var(--santander-red-dark)!important;color:#fff!important;border-color:var(--santander-red-dark)!important}
tbody tr:nth-child(even){background:#FAFAFA!important}
input,select,textarea{
  font-family:var(--body-font)!important;border:1px solid var(--santander-grey-300)!important;border-radius:6px!important;
}
input:focus,select:focus,textarea:focus{
  border-color:var(--santander-red)!important;outline:0!important;box-shadow:0 0 0 3px rgba(236,0,0,.12)!important;
}
.badge,.chip,.tag{border-radius:999px!important}
.badge.en-curso,.badge.alta,.badge.critica,.badge.crítica{background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important}
.notice,.alert,.callout{border-left:6px solid var(--santander-red)!important;background:#fff!important}
pre,code,.code-block{background:#F2F2F2!important;border-color:#D5D5D5!important}
footer{border-top:1px solid var(--santander-grey-200)!important;color:var(--santander-grey-700)!important}
@media print {
  header,aside,.header-actions,.actions,.toolbar,footer{display:none!important}
  body,main{background:#fff!important;color:#111!important}
  main{width:100%!important;max-width:none!important;margin:0!important;padding:0!important}
  h1,h2{color:var(--santander-red-dark)!important}
  table th{background:var(--santander-red-dark)!important;color:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .notice,.alert,.callout{border-left-color:var(--santander-red)!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
}
/* V25.2 — Cabecera corporativa: símbolo rojo íntegro sobre fondo blanco */
header{
  min-height:68px!important;
  height:auto!important;
  padding:10px 22px!important;
  background:#FFFFFF!important;
  color:#222222!important;
  border-bottom:4px solid #EC0000!important;
  box-shadow:0 2px 10px rgba(0,0,0,.08)!important;
  overflow:visible!important;
}
.brand{
  min-width:0!important;
  color:#222222!important;
  font-family:var(--brand-font,"Santander Headline","Segoe UI",Arial,sans-serif)!important;
  font-size:20px!important;
  line-height:1.15!important;
  font-weight:600!important;
  display:flex!important;
  align-items:center!important;
  gap:13px!important;
  white-space:nowrap!important;
  overflow:visible!important;
}
.brand::before{
  content:""!important;
  display:block!important;
  width:46px!important;
  height:46px!important;
  min-width:46px!important;
  max-width:46px!important;
  flex:0 0 46px!important;
  background-color:#FFFFFF!important;
  background-repeat:no-repeat!important;
  background-position:center!important;
  background-size:contain!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
}
@media(max-width:700px){
  header{min-height:60px!important;padding:8px 14px!important}
  .brand{font-size:17px!important;gap:10px!important}
  .brand::before{width:38px!important;height:38px!important;min-width:38px!important;max-width:38px!important;flex-basis:38px!important}
}

/* V25.3 — Auditoría de legibilidad y contraste */
:root{
  --accessible-text:#202124;
  --accessible-muted:#5F6368;
  --accessible-border:#AEB4BA;
  --accessible-link:#B30000;
  --accessible-focus:#8A0000;
  --code-bg:#1F2328;
  --code-head:#2D333B;
  --code-text:#F0F3F6;
  --code-muted:#B7C0CA;
  --code-keyword:#FF9A91;
  --code-string:#B6D7FF;
  --code-number:#91CBFF;
  --code-comment:#B7C0CA;
  --code-variable:#FFC07A;
  --code-builtin:#DFB6FF;
  --code-pipe:#FFD866;
}
body{color:var(--accessible-text)!important}
a{color:var(--accessible-link)!important}
a:hover,a:focus{text-decoration:underline!important;color:#8A0000!important}
small,.muted,.meta,.aside-note,.page-head p,.stats span,.stat span,.card-meta{
  color:var(--accessible-muted)!important;
  opacity:1!important;
}
button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
  outline:3px solid var(--accessible-focus)!important;
  outline-offset:2px!important;
}
input,select,textarea{
  color:#202124!important;
  background:#FFFFFF!important;
  border-color:#8A9097!important;
  opacity:1!important;
}
input::placeholder,textarea::placeholder{color:#656B72!important;opacity:1!important}
button:disabled,.btn:disabled{opacity:.65!important;color:#3C4043!important}

/* Código: contraste alto y sin transparencias */
.code-wrap,.code-block,.code-container,.editor-code{
  background:var(--code-bg)!important;
  border-color:#59636E!important;
  opacity:1!important;
}
.code-head,.code-header,.code-title{
  background:var(--code-head)!important;
  color:#FFFFFF!important;
  border-color:#59636E!important;
  opacity:1!important;
}
.code-box,.code-box code,pre,pre code,.content pre,.content pre code{
  background:var(--code-bg)!important;
  color:var(--code-text)!important;
  font-family:Consolas,"Courier New",monospace!important;
  font-size:14px!important;
  line-height:1.65!important;
  opacity:1!important;
  text-shadow:none!important;
  filter:none!important;
}
.code-box *,pre *,pre code *{
  opacity:1!important;
  text-shadow:none!important;
  filter:none!important;
}
.tok-keyword{color:var(--code-keyword)!important;font-weight:700!important}
.tok-string{color:var(--code-string)!important}
.tok-comment{color:var(--code-comment)!important;font-style:italic!important}
.tok-number{color:var(--code-number)!important}
.tok-builtin{color:var(--code-builtin)!important}
.tok-variable{color:var(--code-variable)!important}
.tok-operator{color:#FF9A91!important;font-weight:700!important}
.tok-pipe{color:var(--code-pipe)!important;font-weight:800!important}
.tok-key,.tok-tag{color:#9BE9A8!important}
.copy-code,.code-head button,.code-header button{
  background:#FFFFFF!important;
  color:#8A0000!important;
  border:1px solid #FFFFFF!important;
  font-weight:700!important;
}

/* Avisos: texto oscuro y fondos claros */
.admonition,.notice,.alert{
  color:#202124!important;
  opacity:1!important;
}
.admonition *,.notice *,.alert *{opacity:1!important}
.admonition.advertencia,.warning{
  background:#FFF4E5!important;
  border-color:#C54800!important;
  color:#3B2500!important;
}
.admonition.informacion,.admonition.nota,.info{
  background:#F3F6F9!important;
  border-color:#B30000!important;
  color:#202124!important;
}
.admonition.importante{
  background:#FDECEC!important;
  border-color:#B30000!important;
  color:#4A0000!important;
}
.admonition.error,.error{
  background:#FCE8E6!important;
  border-color:#A50E0E!important;
  color:#5F0000!important;
}

/* Tablas, tarjetas, etiquetas y estados */
th{background:#ECEFF1!important;color:#30343B!important}
td{color:#202124!important}
.card,section,.stat,.project-card,.info-card{
  color:#202124!important;
}
.badge,.tag{
  color:#30343B!important;
  opacity:1!important;
}
.status-en-curso,.badge.en-curso{background:#FFE1E1!important;color:#8A0000!important}
.status-finalizado,.status-completada,.badge.resuelta,.badge.cerrada{
  background:#DFF1E5!important;color:#1F5D36!important;
}
.status-bloqueada,.status-cancelado,.priority-critica,.badge.priority.critica{
  background:#F8D7DA!important;color:#721C24!important;
}
.primary,.btn.primary{
  background:#EC0000!important;color:#FFFFFF!important;border-color:#B30000!important;
}
.primary:hover,.btn.primary:hover{background:#B30000!important;color:#FFFFFF!important}

/* V25.4 — Selecciones legibles y zona de información ampliada */
html,body{width:100%;min-width:0}
.shell{
  width:calc(100% - 24px)!important;
  max-width:1920px!important;
  margin:0 auto!important;
  grid-template-columns:230px minmax(0,1fr)!important;
}
main{
  width:100%!important;
  max-width:none!important;
  min-width:0!important;
  margin:0!important;
  padding:20px 24px 36px!important;
}
main > *,article,.content,.page-content,.dashboard-grid{
  max-width:none!important;
}
article{width:100%!important}
.card,section,.hero,.panel{
  max-width:none!important;
}
.form-card,.editor,.github-editor,.info-card{
  max-width:none!important;
  width:100%!important;
}
.table-wrap,.pending-card,.pending-table{
  width:100%!important;
  max-width:none!important;
}
table{width:100%!important}

/* Filtros y pestañas: estados claramente visibles */
.pending-filters,.search-filters,.module-tabs{
  display:flex!important;
  flex-wrap:wrap!important;
  gap:8px!important;
  align-items:center!important;
}
.pending-filter,.search-filters a,.module-tabs a{
  display:inline-flex!important;
  align-items:center!important;
  justify-content:center!important;
  min-height:36px!important;
  padding:8px 14px!important;
  border:1px solid #B8BEC5!important;
  border-radius:999px!important;
  background:#FFFFFF!important;
  color:#9B0000!important;
  font-size:13px!important;
  line-height:1.2!important;
  font-weight:600!important;
  text-decoration:none!important;
  opacity:1!important;
  white-space:nowrap!important;
}
.pending-filter:hover,.search-filters a:hover,.module-tabs a:hover{
  background:#FDECEC!important;
  border-color:#EC0000!important;
  color:#780000!important;
  text-decoration:none!important;
}
.pending-filter.active,.search-filters a.active,.module-tabs a.active{
  background:#EC0000!important;
  border-color:#B30000!important;
  color:#FFFFFF!important;
  font-weight:700!important;
  box-shadow:0 0 0 1px #EC0000!important;
}
.pending-filter.active *,
.search-filters a.active *,
.module-tabs a.active *{
  color:#FFFFFF!important;
}

/* Tarjetas resumen */
.pending-summary{
  grid-template-columns:repeat(4,minmax(180px,1fr))!important;
  gap:12px!important;
}
.pending-chip{
  min-height:72px!important;
  padding:14px 16px!important;
  background:#FFFFFF!important;
  color:#30343B!important;
  border:1px solid #C7CDD3!important;
}
.pending-chip:hover{
  background:#FFF5F5!important;
  border-color:#EC0000!important;
  text-decoration:none!important;
}
.pending-chip strong{font-size:24px!important;color:#202124!important}

/* Ventanas y cuadros de información más amplios */
.import-dialog,.modal-dialog,.dialog,.popup,.detail-dialog{
  width:min(1100px,calc(100vw - 40px))!important;
  max-width:1100px!important;
  max-height:92vh!important;
}
.import-dialog-body,.modal-body,.dialog-body{
  padding:22px 24px!important;
}
.project-grid{
  grid-template-columns:repeat(auto-fit,minmax(280px,1fr))!important;
}
.detail-grid{
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
}
.editor-row{
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
}

@media(min-width:1600px){
  .shell{width:calc(100% - 32px)!important;max-width:2200px!important}
  main{padding:22px 30px 42px!important}
}
@media(max-width:1050px){
  .pending-summary{grid-template-columns:repeat(2,minmax(160px,1fr))!important}
  .detail-grid,.editor-row{grid-template-columns:1fr!important}
}
@media(max-width:850px){
  .shell{display:block!important;width:100%!important}
  main{padding:16px!important}
  .pending-summary{grid-template-columns:1fr!important}
  .pending-filter,.search-filters a,.module-tabs a{font-size:12px!important;padding:8px 12px!important}
}

/* V25.5 — Tipografía exacta para PDF */
@media print {
  html,body,main,article,.content,.page-content{
    font-size:12px!important;
    line-height:1.45!important;
  }

  p,li,dd,dt,td,th,span,div,label{
    font-size:12px!important;
  }

  h1,h2,h3,h4,h5,h6,
  .page-title,.section-title,.card-title{
    font-size:14px!important;
    line-height:1.25!important;
  }

  .email-example,
  .email-example *,
  .communication-email,
  .communication-email *,
  .communication-case,
  .communication-case *,
  .communication-response,
  .communication-response *,
  .case-field,
  .case-field *,
  .admonition,
  .admonition *,
  .notice,
  .notice *,
  .alert,
  .alert *,
  .callout,
  .callout *,
  .code-wrap,
  .code-wrap *,
  .code-box,
  .code-box *,
  .code-head,
  .code-head *,
  pre,
  pre *,
  code,
  code *{
    font-size:9px!important;
    line-height:1.4!important;
  }

  .email-example-title,
  .communication-title,
  .admonition-title,
  .code-head{
    font-size:9px!important;
    font-weight:700!important;
  }

  .email-example,
  .communication-email,
  .communication-case,
  .communication-response,
  .admonition,
  .notice,
  .alert,
  .callout,
  .code-wrap,
  pre{
    break-inside:avoid!important;
    page-break-inside:avoid!important;
  }
}
"""

BASE = Path(__file__).resolve().parent
DB = BASE / 'data' / 'snippets.json'
PORTAL_URL = os.environ.get('PORTAL_URL', 'http://127.0.0.1:8079')
WIKI_URL = os.environ.get('WIKI_URL', 'http://127.0.0.1:8080')
GESTOR_URL = os.environ.get('GESTOR_URL', 'http://127.0.0.1:8081')
BAU_URL = os.environ.get('BAU_URL', 'http://127.0.0.1:8082')
BITACORA_URL = os.environ.get('BITACORA_URL', 'http://127.0.0.1:8083')
CATEGORIES = ['CrowdStrike NG SIEM','Splunk','Python','PowerShell','Bash','SQL','KQL','JSON','XML','Regex','Cisco CES','Proofpoint','Microsoft 365','Power Automate','Snow','Otros']

def esc(value):
    return html.escape(str(value or ''), quote=True)

def load():
    try:
        return json.loads(DB.read_text(encoding='utf-8')) if DB.exists() else []
    except Exception:
        return []

def save(rows):
    DB.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')

def now():
    return datetime.now().isoformat(timespec='seconds')

def get_one(item_id):
    return next((x for x in load() if x.get('id') == item_id), None)

def options(current=''):
    return ''.join(f'<option value="{esc(x)}" {"selected" if x == current else ""}>{esc(x)}</option>' for x in CATEGORIES)

def layout(title, body):
    links=[('Inicio',PORTAL_URL),('Wiki',WIKI_URL),('Proyectos y tareas',GESTOR_URL),('BAU',BAU_URL),('Bitácora',BITACORA_URL),('Biblioteca','/')]
    nav=''.join(f'<a class="{"active" if n=="Biblioteca" else ""}" href="{esc(u)}">{esc(n)}</a>' for n,u in links)
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)} · Biblioteca</title><style>{CSS}
/* V19.5 · Word wrap visual en cajas de edición */
textarea{{white-space:pre-wrap!important;overflow-wrap:anywhere;word-break:normal;overflow-x:hidden}}
.form textarea.code{{white-space:pre-wrap!important;overflow-wrap:anywhere;word-break:normal;overflow-x:hidden}}
</style><style>{CORPORATE_THEME_CSS}</style></head><body><header><div class="brand">Santander Mail Security · Biblioteca</div><div class="header-actions"><a class="btn" href="{esc(PORTAL_URL)}">Inicio común</a><a class="btn primary" href="/new">+ Nuevo fragmento</a></div></header><div class="shell"><aside><nav>{nav}</nav><div class="aside-note">Aplicación local<br>Sin usuarios<br>Datos en JSON</div></aside><main>{body}</main></div></body></html>'''

def home(qs):
    rows = load()
    query = qs.get('q', [''])[0].strip().casefold()
    category = qs.get('category', [''])[0]
    favorites = qs.get('fav', [''])[0]
    filtered = []
    for row in rows:
        haystack = ' '.join(str(row.get(k, '')) for k in ('title','category','tags','description','code','notes')).casefold()
        if query and query not in haystack:
            continue
        if category and row.get('category') != category:
            continue
        if favorites and not row.get('favorite'):
            continue
        filtered.append(row)
    filtered.sort(key=lambda r: (not r.get('favorite', False), r.get('title', '').casefold()))
    cards = ''.join(
        f'''<article class="card"><div class="row"><span class="badge">{esc(r.get('category'))}</span><span>{'★' if r.get('favorite') else '☆'}</span></div><h2><a href="/view?id={esc(r['id'])}">{esc(r.get('title'))}</a></h2><p>{esc(r.get('description'))}</p><small>{esc(r.get('tags'))}</small><pre class="{'crowdstrike-code' if r.get('category') == 'CrowdStrike NG SIEM' else ''}"><code>{esc(r.get('code'))}</code></pre><div><button onclick="navigator.clipboard.writeText(this.closest('article').querySelector('code').innerText)">Copiar</button> <a class="btn" href="/edit?id={esc(r['id'])}">Editar</a></div></article>'''
        for r in filtered
    ) or '<div class="card">No hay fragmentos.</div>'
    body = f'''<div class="head"><div><h1>Biblioteca Técnica</h1><p>Consultas, scripts, expresiones y fragmentos reutilizables.</p></div></div><form class="filters"><input name="q" value="{esc(qs.get('q',[''])[0])}" placeholder="Buscar por título, código, etiquetas o notas"><select name="category"><option value="">Todas las categorías</option>{options(category)}</select><label><input type="checkbox" name="fav" value="1" {'checked' if favorites else ''}> Solo favoritos</label><button>Buscar</button></form><div class="grid">{cards}</div>'''
    return layout('Biblioteca', body)

def form_page(row=None):
    row = row or {}
    return layout('Editar fragmento', f'''<h1>{'Editar' if row else 'Nuevo'} fragmento</h1><form class="card form" method="post" action="/save"><input type="hidden" name="id" value="{esc(row.get('id'))}"><label>Título<input name="title" required value="{esc(row.get('title'))}"></label><label>Categoría<select name="category">{options(row.get('category','Splunk'))}</select></label><label>Etiquetas<input name="tags" value="{esc(row.get('tags'))}" placeholder="correo, búsqueda, auditoría"></label><label>Descripción<textarea wrap="soft" name="description" rows="3">{esc(row.get('description'))}</textarea></label><label>Código<textarea wrap="soft" class="code" name="code" rows="18" required>{esc(row.get('code'))}</textarea></label><label>Notas<textarea wrap="soft" name="notes" rows="5">{esc(row.get('notes'))}</textarea></label><label><input type="checkbox" name="favorite" value="1" {'checked' if row.get('favorite') else ''}> Favorito</label><button class="primary">Guardar</button> <a class="btn" href="/">Cancelar</a></form>''')

def view_page(row):
    notes = esc(row.get('notes')).replace('\n', '<br>')
    return layout(row.get('title','Fragmento'), f'''<div class="head"><div><span class="badge">{esc(row.get('category'))}</span><h1>{esc(row.get('title'))} {'★' if row.get('favorite') else ''}</h1><p>{esc(row.get('description'))}</p></div><div><a class="btn" href="/edit?id={esc(row['id'])}">Editar</a></div></div><section class="card"><button onclick="navigator.clipboard.writeText(document.getElementById('code').innerText)">Copiar código</button><pre class="{'crowdstrike-code' if row.get('category') == 'CrowdStrike NG SIEM' else ''}"><code id="code">{esc(row.get('code'))}</code></pre></section><section class="card"><h2>Notas</h2><p class="notes">{notes}</p><p><b>Etiquetas:</b> {esc(row.get('tags'))}</p><form method="post" action="/delete" onsubmit="return confirm('¿Eliminar este fragmento?')"><input type="hidden" name="id" value="{esc(row['id'])}"><button class="danger">Eliminar</button></form></section>''')



def corporate_logo_path():
    """Return the preferred corporate PNG from imagenes/logo, regardless of filename."""
    logo_dir = Path(__file__).resolve().parent.parent / "imagenes" if Path(__file__).resolve().parent.name == "app" else Path(__file__).resolve().parent.parent.parent / "imagenes"
    logo_dir = logo_dir / "logo"
    logo_dir.mkdir(parents=True, exist_ok=True)
    pngs = sorted((p for p in logo_dir.iterdir() if p.is_file() and p.suffix.lower() == ".png"), key=lambda p: p.name.lower())
    if not pngs:
        return None
    preferred = next((p for p in pngs if p.name.lower() == "logo.png"), None)
    return preferred or pngs[0]

def serve_corporate_logo(handler):
    path = corporate_logo_path()
    if path is None:
        handler.send_response(404)
        handler.end_headers()
        return
    data = path.read_bytes()
    handler.send_response(200)
    handler.send_header("Content-Type", "image/png")
    handler.send_header("Content-Length", str(len(data)))
    handler.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
    handler.end_headers()
    handler.wfile.write(data)

class Handler(BaseHTTPRequestHandler):
    def send_html(self, text):
        data = text.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def redirect(self, url):
        self.send_response(303)
        self.send_header('Location', url)
        self.end_headers()

    def read_form(self):
        size = int(self.headers.get('Content-Length','0') or 0)
        return {k: v[-1] for k, v in parse_qs(self.rfile.read(size).decode('utf-8','replace'), keep_blank_values=True).items()}

    def do_GET(self):
        parsed = urlparse(self.path)
        qs = parse_qs(parsed.query)
        if parsed.path == "/corporate-logo.png": return serve_corporate_logo(self)
        if parsed.path == '/':
            return self.send_html(home(qs))
        if parsed.path == '/new':
            return self.send_html(form_page())
        if parsed.path in ('/view','/edit'):
            row = get_one(qs.get('id',[''])[0])
            if not row:
                return self.send_error(404)
            return self.send_html(form_page(row) if parsed.path == '/edit' else view_page(row))
        self.send_error(404)

    def do_POST(self):
        form = self.read_form()
        if self.path == '/save':
            rows = load()
            item_id = form.get('id') or uuid.uuid4().hex
            old = next((x for x in rows if x.get('id') == item_id), {})
            row = {**old, **{k: form.get(k,'').strip() for k in ('title','category','tags','description','code','notes')}}
            row.update(id=item_id, favorite=form.get('favorite') == '1', created=old.get('created') or now(), updated=now())
            save([x for x in rows if x.get('id') != item_id] + [row])
            return self.redirect('/view?id=' + item_id)
        if self.path == '/delete':
            save([x for x in load() if x.get('id') != form.get('id')])
            return self.redirect('/')
        self.send_error(404)

    def log_message(self, *args):
        pass

CSS = '''*{box-sizing:border-box}body{margin:0;font:14px Arial,sans-serif;color:#26384a;background:#f3f6f9}header{height:62px;background:#25364a;color:#fff;padding:0 24px;display:flex;justify-content:space-between;align-items:center}.brand{font-size:19px;font-weight:bold}.header-actions{display:flex;gap:8px}.shell{display:grid;grid-template-columns:210px minmax(0,1fr);min-height:calc(100vh - 62px)}aside{background:#fff;border-right:1px solid #d9e1e8;padding:20px 14px}nav a{display:block;padding:10px 12px;color:#38516b;text-decoration:none;border-radius:5px;margin-bottom: 5px}nav a.active,nav a:hover{background:#FFF0F0;color:#B30000;font-weight:bold}.aside-note{margin:25px 10px;color:#7b8996;font-size:12px;line-height:1.6}main{padding:24px;max-width:1450px;width:100%;margin:0 auto}h1{margin-top:0}.head,.row{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}.filters{background:white;border:1px solid #d7e0e8;padding:14px;border-radius:8px;display:grid;grid-template-columns:1fr 220px auto auto;gap:9px;margin-bottom:16px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(310px,1fr));gap:15px}.card{background:white;border:1px solid #d7e0e8;border-radius:8px;padding:17px;box-shadow:0 1px 4px #0001}.card h2 a{text-decoration:none;color:#B30000}.btn,button{display:inline-block;border:1px solid #bdcad5;background:white;color:#31516e;padding:9px 13px;border-radius:5px;text-decoration:none;cursor:pointer;font:inherit}.crowdstrike-code{border:1px solid #EC0000!important;box-shadow:inset 0 3px 0 #EC0000}.primary{background:#EC0000!important;color:white!important;border-color:#EC0000!important}.danger{background:#a53b3b;color:white}.badge{background:#e7eef5;color:#B30000;border-radius:12px;padding:4px 8px;font-size:11px}input,select,textarea{width:100%;padding:10px;border:1px solid #bdcad5;border-radius:5px;font:inherit}.form label{display:block;font-weight:bold;margin-bottom:13px}.form label input,.form label select,.form label textarea{margin-top:6px;font-weight:normal}.code,pre{font-family:Consolas,monospace}pre{background:#17222d;color:#eaf2f8;padding:14px;border-radius:5px;overflow:auto;white-space:pre-wrap;word-break:break-word}.notes{line-height:1.6}@media(max-width:850px){.shell{grid-template-columns:1fr}aside{display:none}.filters{grid-template-columns:1fr}.head{display:block}}

/* V15.5 · Tipografía del editor unificada con Wiki */
.form label{font-size:12px;line-height:1.3}
.form input,.form select,.form textarea{
  font-size:12px;
  line-height:1.42;
}
.form textarea{
  padding:10px 12px;
  font-family:Arial,sans-serif;
  font-size:13px;
  line-height:1.42;
  resize:vertical;
}
.form textarea.code{
  min-height:430px;
  font-family:Consolas,"Courier New",monospace;
  font-size:13px;
  line-height:20px;
  tab-size:4;
  white-space:pre;
}

/* V16.0 · Tipografía común de Biblioteca */
:root{
  --doc-text-size:12px;
  --doc-h4-size:12px;
  --doc-h3-size:13px;
  --doc-h2-size:14px;
  --doc-h1-size:15px;
  --doc-h1-color:#EC0000;
}
main p,.notes,.card p{font-size:var(--doc-text-size);line-height:1.6}
main h1{font-size:var(--doc-h1-size);color:var(--doc-h1-color);font-weight:700;line-height:1.3}
main h2{font-size:var(--doc-h2-size);font-weight:700;line-height:1.3}
main h3{font-size:var(--doc-h3-size);font-weight:700;line-height:1.3}
main h4{font-size:var(--doc-h4-size);font-weight:700;font-style:italic;line-height:1.3}

.text-indent{white-space:pre;display:inline}

'''

if __name__ == '__main__':
    ThreadingHTTPServer(('127.0.0.1', int(os.environ.get('BIBLIOTECA_PORT','8084'))), Handler).serve_forever()
