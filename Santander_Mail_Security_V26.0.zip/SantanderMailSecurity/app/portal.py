from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path
from datetime import datetime, date, timedelta
import html, io, json, os, shutil, tempfile, zipfile

CORPORATE_THEME_CSS = r""":root {
  --santander-red:#EC0000;
  --santander-red-dark:#C00000;
  --santander-red-deep:#990000;
  --santander-red-soft:#FDECEC;
  --santander-coral:#FF5A5F;
  --santander-orange:#F57C00;
  --santander-black:#111111;
  --santander-text:#2D2D2D;
  --santander-grey-700:#5B5B5B;
  --santander-grey-500:#8A8A8A;
  --santander-grey-300:#C9C9C9;
  --santander-grey-200:#E5E5E5;
  --santander-grey-100:#F2F2F2;
  --santander-bg:#F7F7F7;
  --santander-white:#FFFFFF;
  --brand-font:"Santander Headline","Segoe UI",Arial,sans-serif;
  --body-font:"Santander Headline","Segoe UI",Arial,sans-serif;
}
*{box-sizing:border-box}
html,body{font-family:var(--body-font)!important}
body{background:var(--santander-bg)!important;color:var(--santander-text)!important}
header{
  background:linear-gradient(105deg,var(--santander-red-dark),var(--santander-red))!important;
  color:#fff!important;border-bottom:0!important;box-shadow:0 3px 12px rgba(80,0,0,.18)!important;
}
.brand{font-family:var(--brand-font)!important;font-weight:600!important;letter-spacing:.1px!important;display:flex!important;align-items:center!important;gap:12px!important}
.brand::before{
  content:"";display:inline-block;width:36px;height:34px;flex:0 0 36px;
  background-image:url("/corporate-logo.png");
  background-size:contain;background-position:center;background-repeat:no-repeat;
  filter:brightness(0) invert(1);
}
.shell aside,aside{background:#fff!important;border-right:1px solid var(--santander-grey-200)!important}
aside nav a,nav a{color:#3c3c3c!important;border-radius:6px!important;transition:.15s ease!important}
aside nav a:hover,nav a:hover{background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important}
aside nav a.active,nav a.active{
  background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important;
  border-left:4px solid var(--santander-red)!important;font-weight:700!important;
}
main h1,main h2,.page-title{font-family:var(--brand-font)!important;color:var(--santander-red-dark)!important}
main h3{font-family:var(--brand-font)!important;color:var(--santander-black)!important}
a{color:var(--santander-red-dark)}
a:hover{color:var(--santander-red)}
.btn,.button,button,input[type=submit],input[type=button]{
  font-family:var(--body-font)!important;border-radius:6px!important;box-shadow:none!important;
}
.btn.primary,.btn-primary,.button-primary,button.primary,input[type=submit]{
  background:var(--santander-red)!important;border-color:var(--santander-red)!important;color:#fff!important;
}
.btn.primary:hover,.btn-primary:hover,button.primary:hover,input[type=submit]:hover{
  background:var(--santander-red-dark)!important;border-color:var(--santander-red-dark)!important;
}
.btn:not(.primary),button:not(.primary){
  background:#fff!important;border-color:var(--santander-grey-300)!important;color:var(--santander-text)!important;
}
.card,.panel,.widget,.stat,.tile,.project-card,.task-card,.wiki-card,.bau-card{
  background:#fff!important;border:1px solid var(--santander-grey-200)!important;
  border-radius:10px!important;box-shadow:0 2px 8px rgba(0,0,0,.045)!important;
}
table{background:#fff!important;border-color:var(--santander-grey-200)!important}
thead th,table th{background:var(--santander-red-dark)!important;color:#fff!important;border-color:var(--santander-red-dark)!important}
tbody tr:nth-child(even){background:#FAFAFA!important}
input,select,textarea{
  font-family:var(--body-font)!important;border:1px solid var(--santander-grey-300)!important;border-radius:6px!important;
}
input:focus,select:focus,textarea:focus{
  border-color:var(--santander-red)!important;outline:0!important;box-shadow:0 0 0 3px rgba(236,0,0,.12)!important;
}
.badge,.chip,.tag{border-radius:999px!important}
.badge.en-curso,.badge.alta,.badge.critica,.badge.crítica{background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important}
.notice,.alert,.callout{border-left:6px solid var(--santander-red)!important;background:#fff!important}
pre,code,.code-block{background:#F2F2F2!important;border-color:#D5D5D5!important}
footer{border-top:1px solid var(--santander-grey-200)!important;color:var(--santander-grey-700)!important}
@media print {
  header,aside,.header-actions,.actions,.toolbar,footer{display:none!important}
  body,main{background:#fff!important;color:#111!important}
  main{width:100%!important;max-width:none!important;margin:0!important;padding:0!important}
  h1,h2{color:var(--santander-red-dark)!important}
  table th{background:var(--santander-red-dark)!important;color:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .notice,.alert,.callout{border-left-color:var(--santander-red)!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
}
/* V25.2 — Cabecera corporativa: símbolo rojo íntegro sobre fondo blanco */
header{
  min-height:68px!important;
  height:auto!important;
  padding:10px 22px!important;
  background:#FFFFFF!important;
  color:#222222!important;
  border-bottom:4px solid #EC0000!important;
  box-shadow:0 2px 10px rgba(0,0,0,.08)!important;
  overflow:visible!important;
}
.brand{
  min-width:0!important;
  color:#222222!important;
  font-family:var(--brand-font,"Santander Headline","Segoe UI",Arial,sans-serif)!important;
  font-size:20px!important;
  line-height:1.15!important;
  font-weight:600!important;
  display:flex!important;
  align-items:center!important;
  gap:13px!important;
  white-space:nowrap!important;
  overflow:visible!important;
}
.brand::before{
  content:""!important;
  display:block!important;
  width:46px!important;
  height:46px!important;
  min-width:46px!important;
  max-width:46px!important;
  flex:0 0 46px!important;
  background-color:#FFFFFF!important;
  background-repeat:no-repeat!important;
  background-position:center!important;
  background-size:contain!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
}
@media(max-width:700px){
  header{min-height:60px!important;padding:8px 14px!important}
  .brand{font-size:17px!important;gap:10px!important}
  .brand::before{width:38px!important;height:38px!important;min-width:38px!important;max-width:38px!important;flex-basis:38px!important}
}

/* V25.3 — Auditoría de legibilidad y contraste */
:root{
  --accessible-text:#202124;
  --accessible-muted:#5F6368;
  --accessible-border:#AEB4BA;
  --accessible-link:#B30000;
  --accessible-focus:#8A0000;
  --code-bg:#1F2328;
  --code-head:#2D333B;
  --code-text:#F0F3F6;
  --code-muted:#B7C0CA;
  --code-keyword:#FF9A91;
  --code-string:#B6D7FF;
  --code-number:#91CBFF;
  --code-comment:#B7C0CA;
  --code-variable:#FFC07A;
  --code-builtin:#DFB6FF;
  --code-pipe:#FFD866;
}
body{color:var(--accessible-text)!important}
a{color:var(--accessible-link)!important}
a:hover,a:focus{text-decoration:underline!important;color:#8A0000!important}
small,.muted,.meta,.aside-note,.page-head p,.stats span,.stat span,.card-meta{
  color:var(--accessible-muted)!important;
  opacity:1!important;
}
button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
  outline:3px solid var(--accessible-focus)!important;
  outline-offset:2px!important;
}
input,select,textarea{
  color:#202124!important;
  background:#FFFFFF!important;
  border-color:#8A9097!important;
  opacity:1!important;
}
input::placeholder,textarea::placeholder{color:#656B72!important;opacity:1!important}
button:disabled,.btn:disabled{opacity:.65!important;color:#3C4043!important}

/* Código: contraste alto y sin transparencias */
.code-wrap,.code-block,.code-container,.editor-code{
  background:var(--code-bg)!important;
  border-color:#59636E!important;
  opacity:1!important;
}
.code-head,.code-header,.code-title{
  background:var(--code-head)!important;
  color:#FFFFFF!important;
  border-color:#59636E!important;
  opacity:1!important;
}
.code-box,.code-box code,pre,pre code,.content pre,.content pre code{
  background:var(--code-bg)!important;
  color:var(--code-text)!important;
  font-family:Consolas,"Courier New",monospace!important;
  font-size:14px!important;
  line-height:1.65!important;
  opacity:1!important;
  text-shadow:none!important;
  filter:none!important;
}
.code-box *,pre *,pre code *{
  opacity:1!important;
  text-shadow:none!important;
  filter:none!important;
}
.tok-keyword{color:var(--code-keyword)!important;font-weight:700!important}
.tok-string{color:var(--code-string)!important}
.tok-comment{color:var(--code-comment)!important;font-style:italic!important}
.tok-number{color:var(--code-number)!important}
.tok-builtin{color:var(--code-builtin)!important}
.tok-variable{color:var(--code-variable)!important}
.tok-operator{color:#FF9A91!important;font-weight:700!important}
.tok-pipe{color:var(--code-pipe)!important;font-weight:800!important}
.tok-key,.tok-tag{color:#9BE9A8!important}
.copy-code,.code-head button,.code-header button{
  background:#FFFFFF!important;
  color:#8A0000!important;
  border:1px solid #FFFFFF!important;
  font-weight:700!important;
}

/* Avisos: texto oscuro y fondos claros */
.admonition,.notice,.alert{
  color:#202124!important;
  opacity:1!important;
}
.admonition *,.notice *,.alert *{opacity:1!important}
.admonition.advertencia,.warning{
  background:#FFF4E5!important;
  border-color:#C54800!important;
  color:#3B2500!important;
}
.admonition.informacion,.admonition.nota,.info{
  background:#F3F6F9!important;
  border-color:#B30000!important;
  color:#202124!important;
}
.admonition.importante{
  background:#FDECEC!important;
  border-color:#B30000!important;
  color:#4A0000!important;
}
.admonition.error,.error{
  background:#FCE8E6!important;
  border-color:#A50E0E!important;
  color:#5F0000!important;
}

/* Tablas, tarjetas, etiquetas y estados */
th{background:#ECEFF1!important;color:#30343B!important}
td{color:#202124!important}
.card,section,.stat,.project-card,.info-card{
  color:#202124!important;
}
.badge,.tag{
  color:#30343B!important;
  opacity:1!important;
}
.status-en-curso,.badge.en-curso{background:#FFE1E1!important;color:#8A0000!important}
.status-finalizado,.status-completada,.badge.resuelta,.badge.cerrada{
  background:#DFF1E5!important;color:#1F5D36!important;
}
.status-bloqueada,.status-cancelado,.priority-critica,.badge.priority.critica{
  background:#F8D7DA!important;color:#721C24!important;
}
.primary,.btn.primary{
  background:#EC0000!important;color:#FFFFFF!important;border-color:#B30000!important;
}
.primary:hover,.btn.primary:hover{background:#B30000!important;color:#FFFFFF!important}

/* V25.4 — Selecciones legibles y zona de información ampliada */
html,body{width:100%;min-width:0}
.shell{
  width:calc(100% - 24px)!important;
  max-width:1920px!important;
  margin:0 auto!important;
  grid-template-columns:230px minmax(0,1fr)!important;
}
main{
  width:100%!important;
  max-width:none!important;
  min-width:0!important;
  margin:0!important;
  padding:20px 24px 36px!important;
}
main > *,article,.content,.page-content,.dashboard-grid{
  max-width:none!important;
}
article{width:100%!important}
.card,section,.hero,.panel{
  max-width:none!important;
}
.form-card,.editor,.github-editor,.info-card{
  max-width:none!important;
  width:100%!important;
}
.table-wrap,.pending-card,.pending-table{
  width:100%!important;
  max-width:none!important;
}
table{width:100%!important}

/* Filtros y pestañas: estados claramente visibles */
.pending-filters,.search-filters,.module-tabs{
  display:flex!important;
  flex-wrap:wrap!important;
  gap:8px!important;
  align-items:center!important;
}
.pending-filter,.search-filters a,.module-tabs a{
  display:inline-flex!important;
  align-items:center!important;
  justify-content:center!important;
  min-height:36px!important;
  padding:8px 14px!important;
  border:1px solid #B8BEC5!important;
  border-radius:999px!important;
  background:#FFFFFF!important;
  color:#9B0000!important;
  font-size:13px!important;
  line-height:1.2!important;
  font-weight:600!important;
  text-decoration:none!important;
  opacity:1!important;
  white-space:nowrap!important;
}
.pending-filter:hover,.search-filters a:hover,.module-tabs a:hover{
  background:#FDECEC!important;
  border-color:#EC0000!important;
  color:#780000!important;
  text-decoration:none!important;
}
.pending-filter.active,.search-filters a.active,.module-tabs a.active{
  background:#EC0000!important;
  border-color:#B30000!important;
  color:#FFFFFF!important;
  font-weight:700!important;
  box-shadow:0 0 0 1px #EC0000!important;
}
.pending-filter.active *,
.search-filters a.active *,
.module-tabs a.active *{
  color:#FFFFFF!important;
}

/* Tarjetas resumen */
.pending-summary{
  grid-template-columns:repeat(4,minmax(180px,1fr))!important;
  gap:12px!important;
}
.pending-chip{
  min-height:72px!important;
  padding:14px 16px!important;
  background:#FFFFFF!important;
  color:#30343B!important;
  border:1px solid #C7CDD3!important;
}
.pending-chip:hover{
  background:#FFF5F5!important;
  border-color:#EC0000!important;
  text-decoration:none!important;
}
.pending-chip strong{font-size:24px!important;color:#202124!important}

/* Ventanas y cuadros de información más amplios */
.import-dialog,.modal-dialog,.dialog,.popup,.detail-dialog{
  width:min(1100px,calc(100vw - 40px))!important;
  max-width:1100px!important;
  max-height:92vh!important;
}
.import-dialog-body,.modal-body,.dialog-body{
  padding:22px 24px!important;
}
.project-grid{
  grid-template-columns:repeat(auto-fit,minmax(280px,1fr))!important;
}
.detail-grid{
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
}
.editor-row{
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
}

@media(min-width:1600px){
  .shell{width:calc(100% - 32px)!important;max-width:2200px!important}
  main{padding:22px 30px 42px!important}
}
@media(max-width:1050px){
  .pending-summary{grid-template-columns:repeat(2,minmax(160px,1fr))!important}
  .detail-grid,.editor-row{grid-template-columns:1fr!important}
}
@media(max-width:850px){
  .shell{display:block!important;width:100%!important}
  main{padding:16px!important}
  .pending-summary{grid-template-columns:1fr!important}
  .pending-filter,.search-filters a,.module-tabs a{font-size:12px!important;padding:8px 12px!important}
}

/* V25.5 — Tipografía exacta para PDF */
@media print {
  html,body,main,article,.content,.page-content{
    font-size:12px!important;
    line-height:1.45!important;
  }

  p,li,dd,dt,td,th,span,div,label{
    font-size:12px!important;
  }

  h1,h2,h3,h4,h5,h6,
  .page-title,.section-title,.card-title{
    font-size:14px!important;
    line-height:1.25!important;
  }

  .email-example,
  .email-example *,
  .communication-email,
  .communication-email *,
  .communication-case,
  .communication-case *,
  .communication-response,
  .communication-response *,
  .case-field,
  .case-field *,
  .admonition,
  .admonition *,
  .notice,
  .notice *,
  .alert,
  .alert *,
  .callout,
  .callout *,
  .code-wrap,
  .code-wrap *,
  .code-box,
  .code-box *,
  .code-head,
  .code-head *,
  pre,
  pre *,
  code,
  code *{
    font-size:9px!important;
    line-height:1.4!important;
  }

  .email-example-title,
  .communication-title,
  .admonition-title,
  .code-head{
    font-size:9px!important;
    font-weight:700!important;
  }

  .email-example,
  .communication-email,
  .communication-case,
  .communication-response,
  .admonition,
  .notice,
  .alert,
  .callout,
  .code-wrap,
  pre{
    break-inside:avoid!important;
    page-break-inside:avoid!important;
  }
}
"""

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent
BACKUPS = ROOT / 'backups'
WIKI_PAGES = BASE/'wiki'/'data'/'pages'
PROJECTS = BASE/'gestor'/'data'/'projects.json'
TASKS = BASE/'gestor'/'data'/'tasks.json'
BAU = BASE/'bau'/'data'/'requests.json'
BITACORA = BASE/'bitacora'/'data'/'entries.json'
BIBLIOTECA = BASE/'biblioteca'/'data'/'snippets.json'
WIKI_URL=os.environ.get('WIKI_URL','http://127.0.0.1:8080'); GESTOR_URL=os.environ.get('GESTOR_URL','http://127.0.0.1:8081'); BAU_URL=os.environ.get('BAU_URL','http://127.0.0.1:8082'); BITACORA_URL=os.environ.get('BITACORA_URL','http://127.0.0.1:8083'); BIBLIOTECA_URL=os.environ.get('BIBLIOTECA_URL','http://127.0.0.1:8084')
TARGETS=[Path('app/wiki/data'),Path('app/gestor/data'),Path('app/bau/data'),Path('app/bitacora/data'),Path('app/biblioteca/data'),Path('imagenes'),Path('templates_word')]
# Los adjuntos locales de Wiki/Proyectos/BAU/Bitácora/Biblioteca viven dentro de sus carpetas data;
# se incluyen completos junto con imágenes y plantillas Word.
TEMPLATES_WORD = ROOT / 'templates_word'
TEMPLATE_CONFIG = TEMPLATES_WORD / 'config.json'

def read(path, default):
    try: return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default
    except Exception: return default

def pages():
    return [d for p in (WIKI_PAGES.glob('*.json') if WIKI_PAGES.exists() else []) if (d:=read(p,{}))]

def backup_bytes():
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('backup_manifest.json',json.dumps({'format':'Santander Mail Security Backup','version':3,'application_version':'25.1','includes':['data','attachments','imagenes','templates_word'],'created':datetime.now().isoformat(timespec='seconds')},ensure_ascii=False,indent=2))
        for rel in TARGETS:
            base=ROOT/rel
            if base.exists():
                for f in base.rglob('*'):
                    if f.is_file() and '__pycache__' not in f.parts: z.write(f,f.relative_to(ROOT).as_posix())
    return buf.getvalue()

def valid_rel(name):
    rel=Path(name.replace('\\','/'))
    if rel.is_absolute() or '..' in rel.parts or not rel.parts: return None
    if rel.as_posix()=='backup_manifest.json': return rel
    return rel if any(rel==t or t in rel.parents for t in TARGETS) else None

def merge_json(src,dst):
    try: incoming=json.loads(src.read_text(encoding='utf-8'))
    except Exception: return
    if not dst.exists(): dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst); return
    try: current=json.loads(dst.read_text(encoding='utf-8'))
    except Exception: current=None
    if isinstance(current,list) and isinstance(incoming,list):
        def key(x):
            if isinstance(x,dict):
                for f in ('id','slug','number','title'):
                    if x.get(f) not in (None,''): return (f,str(x.get(f)))
            return ('raw',json.dumps(x,ensure_ascii=False,sort_keys=True))
        have={key(x) for x in current}; current.extend(x for x in incoming if key(x) not in have)
        dst.write_text(json.dumps(current,ensure_ascii=False,indent=2),encoding='utf-8')
    elif isinstance(current,dict) and isinstance(incoming,dict):
        merged=dict(incoming); merged.update(current); dst.write_text(json.dumps(merged,ensure_ascii=False,indent=2),encoding='utf-8')

def _backup_summary(z, files):
    summary={
        'Documentos Wiki':0,'Proyectos':0,'Tareas':0,'Seguimientos':0,
        'Imágenes':0,'Adjuntos':0,'Plantillas Word':0,'Categorías':0,
        'Etiquetas':0,'Responsables':0,'Configuración':0,'Archivos totales':len(files)
    }
    def load_json(name, default):
        try: return json.loads(z.read(name).decode('utf-8'))
        except Exception: return default
    for name,_ in files:
        low=name.lower()
        if low.startswith('app/wiki/data/pages/') and low.endswith('.json'): summary['Documentos Wiki']+=1
        if '/attachments/' in low or '/uploads/' in low: summary['Adjuntos']+=1
        if low.startswith('imagenes/') and not low.endswith('leeme.txt'): summary['Imágenes']+=1
        if low.startswith('templates_word/') and low.endswith('.docx'): summary['Plantillas Word']+=1
        if low.endswith('categories.json'):
            data=load_json(name,[]); summary['Categorías']=len(data) if isinstance(data,list) else len(data or {})
        elif low.endswith('tags.json'):
            data=load_json(name,[]); summary['Etiquetas']=len(data) if isinstance(data,list) else len(data or {})
        elif low.endswith('responsibles.json'):
            data=load_json(name,[]); summary['Responsables']=len(data) if isinstance(data,list) else len(data or {})
        elif low.endswith('projects.json'):
            data=load_json(name,[]); summary['Proyectos']=len(data) if isinstance(data,list) else 0
            if isinstance(data,list):
                summary['Seguimientos']+=sum(len(x.get('followups',[]) or x.get('tracking',[]) or []) for x in data if isinstance(x,dict))
        elif low.endswith('tasks.json'):
            data=load_json(name,[]); summary['Tareas']=len(data) if isinstance(data,list) else 0
            if isinstance(data,list):
                summary['Seguimientos']+=sum(len(x.get('followups',[]) or x.get('tracking',[]) or []) for x in data if isinstance(x,dict))
        elif low.endswith('config.json') or low.endswith('favorites.json') or low.endswith('recents.json'):
            summary['Configuración']+=1
    return summary

def import_backup(raw,mode):
    started=datetime.now()
    if mode not in ('merge','replace'): return False,{'error':'Modo de importación no válido.'}
    try: z=zipfile.ZipFile(io.BytesIO(raw),'r')
    except Exception: return False,{'error':'El archivo seleccionado no es un ZIP válido.'}
    if 'backup_manifest.json' not in z.namelist(): return False,{'error':'El ZIP no es una copia exportada por Santander Mail Security.'}
    files=[]
    for name in z.namelist():
        rel=valid_rel(name)
        if rel is None: return False,{'error':f'Ruta no permitida en la copia: {name}'}
        if name!='backup_manifest.json' and not name.endswith('/'): files.append((name,rel))
    summary=_backup_summary(z,files)
    summary.update({'Modo':'Combinar' if mode=='merge' else 'Reemplazar','Duplicados/Omitidos':0,'Errores':0})
    BACKUPS.mkdir(exist_ok=True)
    safety=BACKUPS/f'Santander_Mail_Security_Antes_Importar_{datetime.now():%Y-%m-%d_%H%M%S}.zip'
    safety.write_bytes(backup_bytes())
    details=[]
    with tempfile.TemporaryDirectory(prefix='tw_import_') as tmp:
        td=Path(tmp)
        for name,rel in files:
            out=td/rel; out.parent.mkdir(parents=True,exist_ok=True)
            with z.open(name) as a,out.open('wb') as b: shutil.copyfileobj(a,b)
        if mode=='replace':
            for rel in TARGETS:
                base=ROOT/rel
                if base.exists():
                    for child in base.iterdir():
                        if child.name=='LEEME.txt': continue
                        shutil.rmtree(child) if child.is_dir() else child.unlink()
        for name,rel in files:
            src,dst=td/rel,ROOT/rel; dst.parent.mkdir(parents=True,exist_ok=True)
            try:
                if mode=='merge' and dst.exists():
                    if dst.suffix.lower()=='.json':
                        before=dst.read_bytes()
                        merge_json(src,dst)
                        if dst.read_bytes()==before:
                            summary['Duplicados/Omitidos']+=1
                            details.append(f'Omitido sin cambios: {rel.as_posix()}')
                        else:
                            details.append(f'Combinado: {rel.as_posix()}')
                    else:
                        summary['Duplicados/Omitidos']+=1
                        details.append(f'Conservado existente: {rel.as_posix()}')
                    continue
                shutil.copy2(src,dst); details.append(f'Restaurado: {rel.as_posix()}')
            except Exception as exc:
                summary['Errores']+=1; details.append(f'ERROR {rel.as_posix()}: {exc}')
    summary['Duración']=f'{(datetime.now()-started).total_seconds():.1f} s'
    summary['Copia previa']=safety.name
    log_dir=ROOT/'logs'; log_dir.mkdir(exist_ok=True)
    log_file=log_dir/f'importacion_{datetime.now():%Y%m%d_%H%M%S}.log'
    log_file.write_text(
        'IMPORTACIÓN DE BACKUP\n' + '\n'.join(f'{k}: {v}' for k,v in summary.items()) +
        '\n\nDETALLE\n' + '\n'.join(details), encoding='utf-8'
    )
    summary['Registro']=log_file.relative_to(ROOT).as_posix()
    summary['details']=details
    return True,summary

def layout(body):
    links=[('Inicio','/'),('Wiki',WIKI_URL),('Proyectos y tareas',GESTOR_URL),('BAU',BAU_URL),('Bitácora',BITACORA_URL),('Biblioteca',BIBLIOTECA_URL),('Plantillas Word','/templates')]
    nav=''.join(f'<a class="{"active" if n=="Inicio" else ""}" href="{html.escape(u,quote=True)}">{html.escape(n)}</a>' for n,u in links)
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Santander Mail Security v24.1</title><style>
*{{box-sizing:border-box}}body{{margin:0;font:14px Arial,sans-serif;color:#26384a;background:#f3f6f9}}header{{height:62px;background:#25364a;color:#fff;padding:0 24px;display:flex;justify-content:space-between;align-items:center}}.brand{{font-size:19px;font-weight:bold}}.shell{{display:grid;grid-template-columns:210px minmax(0,1fr);min-height:calc(100vh - 62px)}}aside{{background:#fff;border-right:1px solid #d9e1e8;padding:20px 14px}}aside nav a{{display:block;padding:10px 12px;color:#38516b;text-decoration:none;border-radius:5px;margin-bottom: 5px}}aside nav a.active,aside nav a:hover{{background:#FFF0F0;color:#B30000;font-weight:bold}}.aside-note{{margin:25px 10px;color:#7b8996;font-size:12px;line-height:1.6}}main{{padding:24px;max-width:1450px;width:100%;margin:0 auto}}.hero,.card{{background:white;border:1px solid #d9e1e8;border-radius:8px;padding:18px;box-shadow:0 1px 4px #0001}}.hero{{margin-bottom:16px}}.search{{display:flex;gap:8px}}input{{flex:1;padding:10px;border:1px solid #bfcbd6;border-radius:5px}}button,.btn{{padding:9px 13px;border:1px solid #bdcad5;border-radius:5px;background:#EC0000;color:white;text-decoration:none;cursor:pointer}}.secondary{{background:#596b7c}}.stats,.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px;margin:16px 0}}.stat strong{{font-size:28px;display:block}}.stat span,small,p{{color:#607080}}h2{{margin-top:0}}.result{{border-top:1px solid #e3e8ed;padding:14px 0}}.tag{{font-size:11px;background:#e8eef4;padding:3px 6px;border-radius:10px}}.backup{{margin-top:16px}}.actions{{display:flex;gap:10px;flex-wrap:wrap}}.notice{{padding:11px;margin:12px 0;background:#e9f6ec;border:1px solid #aed8b8;border-radius:5px;color:#245c31}}.pending-card{{margin:16px 0}}.pending-head{{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap}}.pending-head h2{{margin:0 0 4px}}.pending-summary{{display:grid;grid-template-columns:repeat(4,minmax(120px,1fr));gap:10px;margin:14px 0}}.pending-chip{{display:block;text-decoration:none;border:1px solid #d7e0e8;border-radius:7px;padding:10px;background:#f8fafc;color:#38516b}}.pending-chip strong{{font-size:20px;display:block;color:#24384d}}.pending-chip.overdue strong{{color:#b42318}}.pending-chip.today strong{{color:#b54708}}.pending-chip.week strong{{color:#9a6700}}.pending-filters{{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0 14px}}.pending-filter{{padding:6px 10px;border:1px solid #c7d2dc;border-radius:16px;text-decoration:none;color:#38516b;background:#fff;font-size:12px}}.pending-filter.active{{background:#EC0000;color:#fff;border-color:#EC0000}}.pending-table{{width:100%;border-collapse:collapse}}.pending-table th,.pending-table td{{padding:9px 8px;border-top:1px solid #e5ebf0;text-align:left;vertical-align:top}}.pending-table th{{font-size:12px;color:#607080;background:#f8fafc}}.pending-table a{{color:#B30000;text-decoration:none}}.pending-table .late{{color:#b42318;font-weight:bold}}.pending-table .today-label{{color:#b54708;font-weight:bold}}.pending-empty{{padding:18px;text-align:center;color:#607080}}.import-modal{{position:fixed;inset:0;z-index:1000;display:flex;align-items:center;justify-content:center;padding:20px;background:#16253599}}.import-modal[hidden]{{display:none}}.import-dialog{{width:min(620px,100%);max-height:90vh;overflow:auto;background:#fff;border:1px solid #b9c5cf;border-radius:10px;box-shadow:0 18px 55px #0005}}.import-dialog-head{{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:16px 18px;border-bottom:1px solid #dce3e9}}.import-dialog-head h2{{margin:0}}.import-close{{padding:4px 9px;background:#fff;color:#43586c;font-size:20px;line-height:1}}.import-dialog-body{{padding:18px}}.import-file-label{{display:block;font-weight:bold;color:#26384a}}.import-file-label input{{display:block;width:100%;margin-top:7px;background:#fff}}.import-mode-title{{display:block;margin:18px 0 8px;color:#26384a}}.import-option{{display:grid;grid-template-columns:auto 1fr;gap:10px;padding:12px;margin:8px 0;border:1px solid #ccd6df;border-radius:7px;background:#f9fbfc;cursor:pointer}}.import-option:has(input:checked){{border-color:#EC0000;background:#edf4fb}}.import-option input{{margin-top:3px}}.import-option strong{{display:block;color:#26384a;margin-bottom:3px}}.import-option small{{display:block;color:#607080;line-height:1.45}}.import-warning{{margin-top:10px;padding:9px 11px;border-left:4px solid #b54708;background:#fff5e8;color:#7a3b00}}.import-dialog-actions{{display:flex;justify-content:flex-end;gap:9px;padding:14px 18px;border-top:1px solid #dce3e9;background:#f8fafc}}.import-summary{{display:none;margin-top:14px}}.import-summary.show{{display:block}}.summary-grid{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}}.summary-row{{display:flex;justify-content:space-between;gap:15px;padding:8px 10px;background:#f7f9fb;border:1px solid #dde5ec;border-radius:5px}}.summary-row strong{{color:#24384d}}.summary-details{{margin-top:12px;max-height:190px;overflow:auto;background:#f7f9fb;border:1px solid #dde5ec;padding:9px;font:12px Consolas,monospace;white-space:pre-wrap}}.import-dialog-actions .cancel{{background:#fff;color:#38516b}}body.modal-open{{overflow:hidden}}.welcome{{display:flex;justify-content:space-between;align-items:flex-start;gap:18px;flex-wrap:wrap}}.welcome h1{{margin:0 0 6px;font-size:24px;color:#203449}}.welcome p{{margin:0}}.quick-actions{{display:flex;gap:8px;flex-wrap:wrap}}.quick-actions a{{display:inline-flex;align-items:center;gap:6px}}.dashboard-grid{{display:grid;grid-template-columns:minmax(0,1.45fr) minmax(300px,.75fr);gap:16px;margin:16px 0}}.activity-list{{list-style:none;padding:0;margin:0}}.activity-item{{display:grid;grid-template-columns:auto 1fr auto;gap:10px;align-items:start;padding:11px 0;border-top:1px solid #e5ebf0}}.activity-item:first-child{{border-top:0}}.activity-icon{{width:30px;height:30px;border-radius:50%;background:#fff0f0;color:#b30000;display:grid;place-items:center;font-weight:bold}}.activity-item a{{color:#b30000;text-decoration:none}}.activity-time{{white-space:nowrap;color:#7b8996;font-size:12px}}.health-list{{display:grid;gap:10px}}.health-row{{display:grid;grid-template-columns:1fr auto;gap:12px;padding:10px;border:1px solid #e0e7ed;border-radius:7px;background:#fafcfd}}.health-row strong{{color:#24384d}}.health-value{{font-size:18px;font-weight:bold}}.bar{{height:7px;background:#e7edf2;border-radius:10px;overflow:hidden;margin-top:7px}}.bar span{{display:block;height:100%;background:#ec0000}}.section-head{{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:8px}}.section-head h2{{margin:0}}.search-filters{{display:flex;gap:7px;flex-wrap:wrap;margin-top:10px}}.search-filters a{{padding:5px 9px;border:1px solid #d0dae3;border-radius:14px;color:#455d73;text-decoration:none;font-size:12px;background:#fff}}.search-filters a.active{{background:#ec0000;color:#fff;border-color:#ec0000}}.result-snippet{{margin:6px 0 0;line-height:1.45}}.result-meta{{display:flex;gap:7px;flex-wrap:wrap;margin-top:6px}}.muted{{color:#7b8996}}@media(max-width:1050px){{.dashboard-grid{{grid-template-columns:1fr}}}}@media(max-width:850px){{.shell{{grid-template-columns:1fr}}aside{{display:none}}.search{{display:block}}.search input{{width:100%;margin-bottom:8px}}.pending-summary{{grid-template-columns:repeat(2,1fr)}}.pending-table{{font-size:12px}}}}</style><style>{CORPORATE_THEME_CSS}</style></head><body><header><div class="brand">Santander Mail Security</div></header><div class="shell"><aside><nav>{nav}</nav><div class="aside-note">Aplicación local<br>Sin usuarios<br>Datos en JSON</div></aside><main>{body}</main></div></body></html>'''

def backup_panel(message=''):
    notice=f'<div class="notice">{html.escape(message)}</div>' if message else ''
    return f'''<section class="card backup">
<h2>Copias de seguridad</h2>
<p>Exporta toda la información guardada, incluidos los adjuntos, las imágenes y las plantillas Word, o restaura una copia anterior.</p>
{notice}
<div id="import-status" class="notice" style="display:none"></div>
<div class="actions">
  <a class="btn" href="/backup/export">Exportar información</a>
  <button id="import-button" class="btn secondary" type="button">Importar información</button>
</div>
<p><small>La copia incluye datos, <b>todos los adjuntos</b>, imágenes y la carpeta <b>templates_word</b>. Al importar se restauran también las plantillas DOCX y su configuración.</small></p>
</section>

<div id="import-modal" class="import-modal" hidden aria-hidden="true">
  <section class="import-dialog" role="dialog" aria-modal="true" aria-labelledby="import-modal-title">
    <div class="import-dialog-head">
      <h2 id="import-modal-title">Importar copia de seguridad</h2>
      <button id="import-close" class="import-close" type="button" aria-label="Cerrar">×</button>
    </div>
    <div class="import-dialog-body">
      <label class="import-file-label">Archivo ZIP
        <input id="backup-file" type="file" accept=".zip,application/zip,application/x-zip-compressed">
      </label>
      <strong class="import-mode-title">Tipo de importación</strong>
      <label class="import-option">
        <input type="radio" name="import-mode" value="merge" checked>
        <span><strong>Combinar con los datos actuales</strong><small>Conserva la información existente y añade los registros de la copia que todavía no estén guardados.</small></span>
      </label>
      <label class="import-option">
        <input type="radio" name="import-mode" value="replace">
        <span><strong>Reemplazar todos los datos</strong><small>Elimina los datos actuales y los sustituye por el contenido de la copia importada.</small></span>
      </label>
      <div class="import-warning">Antes de reemplazar se crea automáticamente una copia de seguridad de los datos actuales.</div>
      <div id="modal-import-status" class="notice" style="display:none"></div><div id="import-summary" class="import-summary"><h3>Resumen de la importación</h3><div id="summary-grid" class="summary-grid"></div><details><summary>Ver detalle</summary><div id="summary-details" class="summary-details"></div></details></div>
    </div>
    <div class="import-dialog-actions">
      <button id="import-cancel" class="btn cancel" type="button">Cancelar</button>
      <button id="import-confirm" class="btn" type="button">Importar</button>
    </div>
  </section>
</div>

<script>
(function () {{
  const openButton = document.getElementById('import-button');
  const modal = document.getElementById('import-modal');
  const closeButton = document.getElementById('import-close');
  const cancelButton = document.getElementById('import-cancel');
  const confirmButton = document.getElementById('import-confirm');
  const fileInput = document.getElementById('backup-file');
  const pageStatus = document.getElementById('import-status');
  const modalStatus = document.getElementById('modal-import-status');

  function showStatus(target, message, isError) {{
    if (!target) return;
    target.style.display = 'block';
    target.style.background = isError ? '#fff0f0' : '#e9f6ec';
    target.style.borderColor = isError ? '#e0aaaa' : '#aed8b8';
    target.style.color = isError ? '#8b1e1e' : '#245c31';
    target.textContent = message;
  }}

  function clearModalStatus() {{
    if (!modalStatus) return;
    modalStatus.style.display = 'none';
    modalStatus.textContent = '';
  }}

  function openModal() {{
    clearModalStatus();
    fileInput.value = '';
    const merge = document.querySelector('input[name="import-mode"][value="merge"]');
    if (merge) merge.checked = true;
    modal.hidden = false;
    modal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('modal-open');
    setTimeout(() => fileInput.focus(), 0);
  }}

  function closeModal() {{
    if (confirmButton.disabled) return;
    modal.hidden = true;
    modal.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('modal-open');
    openButton.focus();
  }}

  openButton?.addEventListener('click', openModal);
  closeButton?.addEventListener('click', closeModal);
  cancelButton?.addEventListener('click', closeModal);

  modal?.addEventListener('click', event => {{
    if (event.target === modal) closeModal();
  }});

  document.addEventListener('keydown', event => {{
    if (event.key === 'Escape' && modal && !modal.hidden) closeModal();
  }});

  confirmButton?.addEventListener('click', async function () {{
    const file = fileInput.files && fileInput.files[0];
    if (!file) {{
      showStatus(modalStatus, 'Selecciona primero una copia de seguridad ZIP.', true);
      fileInput.focus();
      return;
    }}
    if (!file.name.toLowerCase().endsWith('.zip')) {{
      showStatus(modalStatus, 'El archivo seleccionado debe tener extensión .zip.', true);
      fileInput.focus();
      return;
    }}

    const selectedMode = document.querySelector('input[name="import-mode"]:checked');
    const mode = selectedMode ? selectedMode.value : 'merge';

    confirmButton.disabled = true;
    closeButton.disabled = true;
    cancelButton.disabled = true;
    showStatus(modalStatus, mode === 'replace'
      ? 'Creando copia previa y reemplazando los datos…'
      : 'Combinando la copia con los datos actuales…', false);

    try {{
      const response = await fetch('/backup/import?mode=' + encodeURIComponent(mode), {{
        method: 'POST',
        headers: {{'Content-Type': 'application/zip'}},
        body: file
      }});
      const data = await response.json();
      if (!response.ok || !data.ok) throw new Error(data.error || 'No se pudo importar la copia.');
      showStatus(modalStatus, 'Importación completada correctamente.', false);
      const summaryBox=document.getElementById('import-summary');
      const summaryGrid=document.getElementById('summary-grid');
      const details=document.getElementById('summary-details');
      summaryGrid.innerHTML='';
      const hiddenKeys=new Set(['details']);
      Object.entries(data.summary || {{}}).forEach(([key,value])=>{{
        if(hiddenKeys.has(key)) return;
        const row=document.createElement('div'); row.className='summary-row';
        const label=document.createElement('span'); label.textContent=key;
        const val=document.createElement('strong'); val.textContent=String(value);
        row.append(label,val); summaryGrid.appendChild(row);
      }});
      details.textContent=(data.summary.details || []).join('\\n') || 'Sin incidencias.';
      summaryBox.classList.add('show');
      confirmButton.textContent='Cerrar';
      confirmButton.disabled=false; closeButton.disabled=false; cancelButton.disabled=false;
      confirmButton.onclick=()=>window.location.reload();
      showStatus(pageStatus, 'Importación completada. Consulte el resumen en la ventana.', false);
    }} catch (error) {{
      showStatus(modalStatus, error && error.message ? error.message : 'Error inesperado durante la importación.', true);
      showStatus(pageStatus, 'La importación no pudo completarse.', true);
      confirmButton.disabled = false;
      closeButton.disabled = false;
      cancelButton.disabled = false;
    }}
  }});
}})();
</script>'''

def template_config():
    TEMPLATES_WORD.mkdir(parents=True, exist_ok=True)
    cfg=read(TEMPLATE_CONFIG,{})
    return cfg if isinstance(cfg,dict) else {}

def save_template_config(cfg):
    TEMPLATES_WORD.mkdir(parents=True, exist_ok=True)
    TEMPLATE_CONFIG.write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')

def safe_template_name(name):
    name=Path(str(name or '')).name.strip()
    if not name.lower().endswith('.docx'): return None
    return name if name not in ('.','..') else None

def templates_page(message=''):
    cfg=template_config(); default=cfg.get('default','Plantilla_procedimientos.docx')
    files=sorted(TEMPLATES_WORD.glob('*.docx'),key=lambda x:x.name.lower())
    rows=[]
    for f in files:
        badge='<span class="tag">Predeterminada</span>' if f.name==default else ''
        rows.append("<tr><td><strong>{}</strong> {}</td><td>{} KB</td><td class=\"actions\"><button type=\"button\" onclick=\"setDefault({})\">Predeterminada</button><button class=\"secondary\" type=\"button\" onclick=\"removeTemplate({})\">Eliminar</button></td></tr>".format(html.escape(f.name),badge,f.stat().st_size//1024,json.dumps(f.name),json.dumps(f.name)))
    table=''.join(rows) or '<tr><td colspan="3">No hay plantillas DOCX.</td></tr>'
    notice=f'<div class="notice">{html.escape(message)}</div>' if message else ''
    body='<section class="card"><h2>Plantillas Word</h2><p>Estas plantillas se incluyen automáticamente en todas las copias de seguridad.</p>'+notice+'<table class="pending-table"><thead><tr><th>Plantilla</th><th>Tamaño</th><th>Acciones</th></tr></thead><tbody>'+table+'</tbody></table><hr style="border:0;border-top:1px solid #e1e7ec;margin:20px 0"><h3>Añadir o sustituir plantilla</h3><p>Al subir un archivo con el mismo nombre se sustituye la plantilla existente.</p><div class="actions"><input id="template-file" type="file" accept=".docx"><button type="button" onclick="uploadTemplate()">Subir plantilla</button></div></section>'
    body += """<script>
async function req(url,opt){const r=await fetch(url,opt);const t=await r.text();if(!r.ok)throw new Error(t.replace(/<[^>]+>/g,' ').trim());location.reload();}
async function uploadTemplate(){const f=document.getElementById('template-file').files[0];if(!f)return alert('Selecciona un archivo DOCX.');try{await req('/templates/upload?name='+encodeURIComponent(f.name),{method:'POST',body:f})}catch(e){alert(e.message)}}
async function setDefault(n){try{await req('/templates/default?name='+encodeURIComponent(n),{method:'POST'})}catch(e){alert(e.message)}}
async function removeTemplate(n){if(!confirm('¿Eliminar la plantilla '+n+'?'))return;try{await req('/templates/delete?name='+encodeURIComponent(n),{method:'POST'})}catch(e){alert(e.message)}}
</script>"""
    return layout(body)

def parse_day(value):
    value=str(value or '').strip()
    if not value:
        return None
    try:
        return date.fromisoformat(value[:10])
    except ValueError:
        return None

def wiki_header(content, key):
    aliases={
        'status':{'status','estado'},
        'title':{'title','titulo','título'},
        'number':{'number','numero','número'},
        'owner':{'owner','responsable','asignado','assigned to'},
    }
    wanted=aliases.get(key,{key.casefold()})
    for line in str(content or '').splitlines()[:20]:
        if ':' not in line:
            continue
        field,value=line.split(':',1)
        if field.strip().casefold() in wanted:
            return value.strip().strip('*')
    return ''

def pending_items():
    today=date.today()
    items=[]
    project_map={str(p.get('id','')):p for p in read(PROJECTS,[])}
    for t in read(TASKS,[]):
        status=str(t.get('status','')).strip()
        if status in ('Completada','Cancelada'):
            continue
        project=project_map.get(str(t.get('project_id','')),{}).get('name','')
        items.append({
            'kind':'Tarea','ref':project,
            'title':t.get('title') or 'Tarea sin título',
            'owner':t.get('owner',''),
            'status':status or 'Pendiente','due':parse_day(t.get('due_date')),
            'url':f'{GESTOR_URL}/task/edit?id={t.get("id","")}'
        })
    for p in read(PROJECTS,[]):
        status=str(p.get('status','')).strip()
        if status in ('Finalizado','Cancelado'):
            continue
        items.append({
            'kind':'Proyecto','ref':'',
            'title':p.get('name') or 'Proyecto sin título',
            'owner':p.get('owner',''),
            'status':status or 'Planificado','due':parse_day(p.get('end_date')),
            'url':f'{GESTOR_URL}/project?id={p.get("id","")}'
        })
    for r in read(BAU,[]):
        status=str(r.get('status','')).strip()
        if status in ('Resuelta','Cerrada'):
            continue
        items.append({
            'kind':'BAU','ref':r.get('number',''),
            'title':r.get('title') or 'BAU sin título',
            'owner':r.get('owner') or r.get('responsible') or r.get('responsable') or r.get('assigned_to') or '',
            'status':status or 'Nueva',
            'due':parse_day(r.get('due_date') or r.get('resolution_date')),
            'url':f'{BAU_URL}/view?id={r.get("id","")}'
        })
    pending_statuses={'draft','borrador','in review','en revisión','en revision','obsolete','obsoleto'}
    shown_status={'draft':'Draft','borrador':'Borrador','in review':'In review','en revisión':'En revisión','en revision':'En revisión','obsolete':'Obsolete','obsoleto':'Obsoleto'}
    for d in pages():
        raw=wiki_header(d.get('content',''),'status').casefold()
        if raw not in pending_statuses:
            continue
        items.append({
            'kind':'Wiki','ref':wiki_header(d.get('content',''),'number'),
            'title':d.get('title') or wiki_header(d.get('content',''),'title') or 'Documento sin título',
            'owner':wiki_header(d.get('content',''),'owner'),
            'status':shown_status.get(raw,raw.title()),'due':None,
            'url':f'{WIKI_URL}/wiki/{d.get("slug","")}'
        })
    def rank(item):
        due=item['due']
        if due is None:
            return (3,date.max,item['kind'],str(item['title']).casefold())
        if due < today:
            return (0,due,item['kind'],str(item['title']).casefold())
        if due == today:
            return (1,due,item['kind'],str(item['title']).casefold())
        return (2,due,item['kind'],str(item['title']).casefold())
    items.sort(key=rank)
    return items

def pending_panel(filter_name='all'):
    today=date.today()
    end_week=today+timedelta(days=7)
    items=pending_items()
    counts={
        'overdue':sum(1 for x in items if x['due'] and x['due']<today),
        'today':sum(1 for x in items if x['due']==today),
        'week':sum(1 for x in items if x['due'] and today<x['due']<=end_week),
        'nodate':sum(1 for x in items if x['due'] is None),
    }
    if filter_name not in {'all','overdue','today','week','nodate'}:
        filter_name='all'
    def matches(item):
        if filter_name=='all': return True
        if filter_name=='overdue': return bool(item['due'] and item['due']<today)
        if filter_name=='today': return item['due']==today
        if filter_name=='week': return bool(item['due'] and today<item['due']<=end_week)
        return item['due'] is None
    shown=[x for x in items if matches(x)]
    labels=[('all','Todos',len(items)),('overdue','Vencidos',counts['overdue']),('today','Hoy',counts['today']),('week','7 días',counts['week']),('nodate','Sin fecha',counts['nodate'])]
    filters=''.join(
        f'<a class="pending-filter {"active" if key==filter_name else ""}" href="/?pending={key}">{html.escape(label)} · {amount}</a>'
        for key,label,amount in labels
    )
    rows=[]
    for item in shown[:20]:
        due=item['due']
        if due is None:
            due_html='Sin fecha'
        elif due<today:
            due_html=f'<span class="late">Vencido · {due.strftime("%d/%m/%Y")}</span>'
        elif due==today:
            due_html='<span class="today-label">Hoy</span>'
        else:
            due_html=due.strftime('%d/%m/%Y')
        reference_html=html.escape(str(item.get("ref") or ""))
        owner_html=html.escape(str(item.get("owner") or ""))
        rows.append(
            f'<tr><td><span class="tag">{html.escape(item["kind"])}</span></td>'
            f'<td>{reference_html}</td>'
            f'<td><a href="{html.escape(item["url"],quote=True)}"><strong>{html.escape(str(item["title"]))}</strong></a></td>'
            f'<td>{owner_html}</td>'
            f'<td>{html.escape(str(item["status"]))}</td><td>{due_html}</td></tr>'
        )
    if rows:
        table='<div style="overflow:auto"><table class="pending-table"><thead><tr><th>Tipo</th><th>Referencia</th><th>Pendiente</th><th>Responsable</th><th>Estado</th><th>Fecha</th></tr></thead><tbody>'+''.join(rows)+'</tbody></table></div>'
    else:
        table='<div class="pending-empty">No hay elementos pendientes en este filtro.</div>'
    extra=f'<p><small>Mostrando los primeros 20 de {len(shown)} pendientes.</small></p>' if len(shown)>20 else ''
    return (
        '<section class="card pending-card">'
        '<div class="pending-head"><div><h2>Pendientes</h2><p>Resumen de elementos que todavía requieren atención.</p></div>'
        f'<strong>{len(items)} en total</strong></div>'
        '<div class="pending-summary">'
        f'<a class="pending-chip overdue" href="/?pending=overdue"><strong>{counts["overdue"]}</strong>Vencidos</a>'
        f'<a class="pending-chip today" href="/?pending=today"><strong>{counts["today"]}</strong>Para hoy</a>'
        f'<a class="pending-chip week" href="/?pending=week"><strong>{counts["week"]}</strong>Próximos 7 días</a>'
        f'<a class="pending-chip" href="/?pending=nodate"><strong>{counts["nodate"]}</strong>Sin fecha</a>'
        f'</div><div class="pending-filters">{filters}</div>{table}{extra}</section>'
    )

def fmt_date(value):
    if not value:
        return None
    text=str(value).strip()
    candidates=[text,text[:19],text[:10]]
    for candidate in candidates:
        for fmt in ('%Y-%m-%dT%H:%M:%S','%Y-%m-%d %H:%M:%S','%Y-%m-%d','%d/%m/%Y'):
            try:
                return datetime.strptime(candidate,fmt)
            except Exception:
                pass
    return None

def recent_activity(limit=10):
    items=[]
    for d in pages():
        when=fmt_date(d.get('updated_at') or d.get('modified') or d.get('date') or wiki_header(d.get('content',''),'date'))
        items.append({'kind':'Wiki','title':d.get('title') or 'Documento sin título','url':f'{WIKI_URL}/wiki/{d.get("slug","")}','when':when,'meta':d.get('category','')})
    for p in read(PROJECTS,[]):
        when=fmt_date(p.get('updated_at') or p.get('modified_at') or p.get('end_date') or p.get('start_date'))
        items.append({'kind':'Proyecto','title':p.get('name') or 'Proyecto sin nombre','url':f'{GESTOR_URL}/project?id={p.get("id","")}','when':when,'meta':p.get('status','')})
    for r in read(BAU,[]):
        when=fmt_date(r.get('updated_at') or r.get('date') or r.get('created_at'))
        items.append({'kind':'BAU','title':f'{r.get("number","")} · {r.get("title","")}'.strip(' ·'),'url':f'{BAU_URL}/view?id={r.get("id","")}','when':when,'meta':r.get('status','')})
    for r in read(BITACORA,[]):
        when=fmt_date(r.get('updated_at') or r.get('date') or r.get('created_at'))
        items.append({'kind':'Bitácora','title':r.get('title') or 'Entrada sin título','url':f'{BITACORA_URL}/view?id={r.get("id","")}','when':when,'meta':r.get('group','')})
    for r in read(BIBLIOTECA,[]):
        when=fmt_date(r.get('updated_at') or r.get('date') or r.get('created_at'))
        items.append({'kind':'Biblioteca','title':r.get('title') or 'Recurso sin título','url':f'{BIBLIOTECA_URL}/view?id={r.get("id","")}','when':when,'meta':r.get('category','')})
    items.sort(key=lambda x:(x['when'] is not None,x['when'] or datetime.min),reverse=True)
    return items[:limit]

def activity_panel():
    rows=[]
    icons={'Wiki':'W','Proyecto':'P','BAU':'B','Bitácora':'N','Biblioteca':'T'}
    for item in recent_activity():
        when=item['when']
        when_text=when.strftime('%d/%m/%Y') if when else 'Sin fecha'
        rows.append(
            f'<li class="activity-item"><span class="activity-icon">{icons.get(item["kind"],"•")}</span>'
            f'<div><a href="{html.escape(item["url"],quote=True)}"><strong>{html.escape(str(item["title"]))}</strong></a>'
            f'<div class="muted">{html.escape(item["kind"])} · {html.escape(str(item.get("meta") or ""))}</div></div>'
            f'<span class="activity-time">{when_text}</span></li>'
        )
    return '<section class="card"><div class="section-head"><h2>Actividad reciente</h2></div><ul class="activity-list">'+(''.join(rows) if rows else '<li class="pending-empty">Sin actividad registrada.</li>')+'</ul></section>'

def project_health_panel(projects,tasks):
    active=[p for p in projects if str(p.get('status','')).casefold() not in {'completado','completada','cerrado','cerrada','cancelado','cancelada'}]
    completed=sum(1 for t in tasks if str(t.get('status','')).casefold() in {'completada','completado','cerrada','cerrado'})
    total=len(tasks)
    progress=round((completed/total)*100) if total else 0
    overdue=sum(1 for x in pending_items() if x.get('due') and x['due']<date.today())
    no_owner=sum(1 for t in tasks if str(t.get('status','')).casefold() not in {'completada','cancelada'} and not (t.get('responsible_ids') or t.get('responsibles') or t.get('owner') or t.get('responsible')))
    rows=[('Proyectos activos',len(active)),('Tareas completadas',f'{completed}/{total}'),('Pendientes vencidos',overdue),('Tareas sin responsable',no_owner)]
    body=''.join(f'<div class="health-row"><span>{html.escape(label)}</span><span class="health-value">{html.escape(str(value))}</span></div>' for label,value in rows)
    body+=f'<div class="health-row"><div><strong>Avance global de tareas</strong><div class="bar"><span style="width:{progress}%"></span></div></div><span class="health-value">{progress}%</span></div>'
    return '<section class="card"><div class="section-head"><h2>Salud del espacio</h2></div><div class="health-list">'+body+'</div></section>'

def home(pending_filter='all'):
    ps=read(PROJECTS,[]); ts=read(TASKS,[]); docs=pages(); bau=read(BAU,[]); bit=read(BITACORA,[]); bib=read(BIBLIOTECA,[])
    pending=[t for t in ts if str(t.get('status','')).casefold() not in ('completada','cancelada','completado','cancelado')]
    hour=datetime.now().hour
    greeting='Buenos días' if hour<14 else ('Buenas tardes' if hour<21 else 'Buenas noches')
    welcome=f"""<div class="hero welcome"><div><h1>{greeting}, A. Garcia</h1><p>Resumen operativo y documental de Santander Mail Security.</p></div><div class="quick-actions"><a class="btn" href="{WIKI_URL}/new">+ Nuevo documento</a><a class="btn secondary" href="{GESTOR_URL}/project/new">+ Nuevo proyecto</a><a class="btn secondary" href="{BAU_URL}/new">+ Nueva BAU</a></div></div>"""
    searchbox='<div class="hero"><h2>Buscador global</h2><form class="search" action="/search"><input name="q" placeholder="Buscar en Wiki, proyectos, tareas, BAU, bitácora y biblioteca"><button>Buscar</button></form></div>'
    active_projects=sum(1 for p in ps if str(p.get('status','')).casefold() not in {'completado','completada','cerrado','cerrada','cancelado','cancelada'})
    stats=f'<div class="stats"><div class="card stat"><strong>{len(docs)}</strong><span>Documentos Wiki</span></div><div class="card stat"><strong>{active_projects}</strong><span>Proyectos activos</span></div><div class="card stat"><strong>{len(pending)}</strong><span>Tareas pendientes</span></div><div class="card stat"><strong>{len(bau)}</strong><span>Registros BAU</span></div><div class="card stat"><strong>{len(bit)}</strong><span>Entradas Bitácora</span></div><div class="card stat"><strong>{len(bib)}</strong><span>Recursos técnicos</span></div></div>'
    dashboard=f'<div class="dashboard-grid">{activity_panel()}{project_health_panel(ps,ts)}</div>'
    return layout(welcome+searchbox+stats+dashboard+pending_panel(pending_filter)+backup_panel())

def compact_text(value,limit=190):
    text=' '.join(str(value or '').replace('\n',' ').split())
    return text if len(text)<=limit else text[:limit-1]+'…'

def search(q,kind='all'):
    term=q.strip().casefold(); results=[]
    def add(k,title,url,meta,content=''):
        haystack=' '.join([str(title or ''),str(meta or ''),str(content or '')]).casefold()
        if term and term in haystack:
            raw=' '.join(str(content or '').replace('\n',' ').split())
            pos=raw.casefold().find(term)
            snippet=raw[max(0,pos-60):pos+150] if raw and pos>=0 else (raw[:190] if raw else str(meta or ''))
            results.append((k,title,url,meta,compact_text(snippet)))
    if term:
        if kind in ('all','wiki'):
            for d in pages(): add('Documento',d.get('title',''),f'{WIKI_URL}/wiki/{d.get("slug","")}',d.get('category',''),' '.join([d.get('content',''),' '.join(d.get('tags',[]))]))
        if kind in ('all','projects'):
            for p in read(PROJECTS,[]): add('Proyecto',p.get('name',''),f'{GESTOR_URL}/project?id={p.get("id","")}',p.get('status',''),json.dumps(p,ensure_ascii=False))
            for t in read(TASKS,[]): add('Tarea',t.get('title',''),f'{GESTOR_URL}/task/edit?id={t.get("id","")}',t.get('status',''),json.dumps(t,ensure_ascii=False))
        if kind in ('all','bau'):
            for r in read(BAU,[]): add('BAU',f'{r.get("number","")} · {r.get("title","")}',f'{BAU_URL}/view?id={r.get("id","")}',r.get('status',''),json.dumps(r,ensure_ascii=False))
        if kind in ('all','notes'):
            for r in read(BITACORA,[]): add('Bitácora',r.get('title',''),f'{BITACORA_URL}/view?id={r.get("id","")}',r.get('group',''),json.dumps(r,ensure_ascii=False))
        if kind in ('all','library'):
            for r in read(BIBLIOTECA,[]): add('Biblioteca',r.get('title',''),f'{BIBLIOTECA_URL}/view?id={r.get("id","")}',r.get('category',''),json.dumps(r,ensure_ascii=False))
    filters=[('all','Todo'),('wiki','Wiki'),('projects','Proyectos y tareas'),('bau','BAU'),('notes','Bitácora'),('library','Biblioteca')]
    filter_html=''.join(f'<a class="{"active" if key==kind else ""}" href="/search?q={html.escape(q,quote=True)}&kind={key}">{label}</a>' for key,label in filters)
    rows=''.join(f'<div class="result"><span class="tag">{html.escape(k)}</span> <a href="{html.escape(u,quote=True)}"><strong>{html.escape(str(title))}</strong></a><div class="result-meta"><span>{html.escape(str(meta))}</span></div><p class="result-snippet">{html.escape(snippet)}</p></div>' for k,title,u,meta,snippet in results) or '<p>No se encontraron coincidencias.</p>'
    return layout(f'<div class="hero"><h2>Resultados para “{html.escape(q)}”</h2><form class="search" action="/search"><input type="hidden" name="kind" value="{html.escape(kind,quote=True)}"><input name="q" value="{html.escape(q,quote=True)}"><button>Buscar</button></form><div class="search-filters">{filter_html}</div></div><section class="card"><div class="section-head"><h2>{len(results)} coincidencias</h2></div>{rows}</section>')



def corporate_logo_path():
    """Return the preferred corporate PNG from imagenes/logo, regardless of filename."""
    logo_dir = Path(__file__).resolve().parent.parent / "imagenes" if Path(__file__).resolve().parent.name == "app" else Path(__file__).resolve().parent.parent.parent / "imagenes"
    logo_dir = logo_dir / "logo"
    logo_dir.mkdir(parents=True, exist_ok=True)
    pngs = sorted((p for p in logo_dir.iterdir() if p.is_file() and p.suffix.lower() == ".png"), key=lambda p: p.name.lower())
    if not pngs:
        return None
    preferred = next((p for p in pngs if p.name.lower() == "logo.png"), None)
    return preferred or pngs[0]

def serve_corporate_logo(handler):
    path = corporate_logo_path()
    if path is None:
        handler.send_response(404)
        handler.end_headers()
        return
    data = path.read_bytes()
    handler.send_response(200)
    handler.send_header("Content-Type", "image/png")
    handler.send_header("Content-Length", str(len(data)))
    handler.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
    handler.end_headers()
    handler.wfile.write(data)

class Handler(BaseHTTPRequestHandler):
    def send_html(self,body,status=200):
        data=body.encode('utf-8'); self.send_response(status); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def send_json(self,payload,status=200):
        data=json.dumps(payload,ensure_ascii=False).encode('utf-8'); self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        u=urlparse(self.path)
        if u.path == "/corporate-logo.png": return serve_corporate_logo(self)
        if u.path=='/templates':
            self.send_html(templates_page()); return
        if u.path=='/backup/export':
            data=backup_bytes(); name=f'Santander_Mail_Security_Backup_{datetime.now():%Y-%m-%d_%H%M}.zip'; self.send_response(200); self.send_header('Content-Type','application/zip'); self.send_header('Content-Disposition',f'attachment; filename="{name}"'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        qs=parse_qs(u.query); q=qs.get('q',[''])[0]; kind=qs.get('kind',['all'])[0]; self.send_html(search(q,kind) if u.path=='/search' else home(qs.get('pending',['all'])[0]))
    def do_POST(self):
        u=urlparse(self.path)
        if u.path.startswith('/templates/'):
            q=parse_qs(u.query); name=safe_template_name(q.get('name',[''])[0])
            if not name: self.send_html(layout('<section class="card"><h2>Nombre de plantilla no válido</h2></section>'),400); return
            target=TEMPLATES_WORD/name; TEMPLATES_WORD.mkdir(parents=True,exist_ok=True)
            if u.path=='/templates/upload':
                try: length=int(self.headers.get('Content-Length','0'))
                except ValueError: length=0
                if length<=0 or length>25*1024*1024: self.send_html(layout('<section class="card"><h2>Archivo vacío o demasiado grande</h2></section>'),400); return
                raw=self.rfile.read(length)
                try:
                    with zipfile.ZipFile(io.BytesIO(raw),'r') as docx:
                        if '[Content_Types].xml' not in docx.namelist() or 'word/document.xml' not in docx.namelist(): raise ValueError
                except Exception: self.send_html(layout('<section class="card"><h2>El archivo no es un DOCX válido</h2></section>'),400); return
                target.write_bytes(raw); self.send_html(templates_page('Plantilla guardada correctamente.')); return
            if u.path=='/templates/default':
                if not target.exists(): self.send_html(layout('<section class="card"><h2>La plantilla no existe</h2></section>'),404); return
                cfg=template_config(); cfg['default']=name; save_template_config(cfg); self.send_html(templates_page('Plantilla predeterminada actualizada.')); return
            if u.path=='/templates/delete':
                if target.exists(): target.unlink()
                cfg=template_config()
                if cfg.get('default')==name: cfg.pop('default',None); save_template_config(cfg)
                self.send_html(templates_page('Plantilla eliminada.')); return
            self.send_html(layout('<section class="card"><h2>Ruta no encontrada</h2></section>'),404); return
        if u.path!='/backup/import': self.send_html(layout('<section class="card"><h2>Ruta no encontrada</h2></section>'),404); return
        try: length=int(self.headers.get('Content-Length','0'))
        except ValueError: length=0
        if length<=0 or length>500*1024*1024: self.send_json({'ok':False,'error':'Archivo vacío o demasiado grande.'},400); return
        ok,result=import_backup(self.rfile.read(length),parse_qs(u.query).get('mode',['merge'])[0])
        if ok: self.send_json({'ok':True,'summary':result},200)
        else: self.send_json({'ok':False,'error':result.get('error','No se pudo importar la copia.')},400)
    def log_message(self,*args): pass

if __name__=='__main__': ThreadingHTTPServer(('127.0.0.1',int(os.environ.get('PORTAL_PORT','8079'))),Handler).serve_forever()
