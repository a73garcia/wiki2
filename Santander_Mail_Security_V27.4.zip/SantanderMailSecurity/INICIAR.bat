@echo off
cd /d "%~dp0"
python workspace.py
if errorlevel 1 pause
