from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from email.parser import BytesParser
from email.policy import default as email_policy
import mimetypes, re
from pathlib import Path
from datetime import date, datetime
import json, os, html, uuid

CORPORATE_THEME_CSS = r""":root {
  --santander-red:#EC0000;
  --santander-red-dark:#C00000;
  --santander-red-deep:#990000;
  --santander-red-soft:#FDECEC;
  --santander-coral:#FF5A5F;
  --santander-orange:#F57C00;
  --santander-black:#111111;
  --santander-text:#2D2D2D;
  --santander-grey-700:#5B5B5B;
  --santander-grey-500:#8A8A8A;
  --santander-grey-300:#C9C9C9;
  --santander-grey-200:#E5E5E5;
  --santander-grey-100:#F2F2F2;
  --santander-bg:#F7F7F7;
  --santander-white:#FFFFFF;
  --brand-font:"Santander Headline","Segoe UI",Arial,sans-serif;
  --body-font:"Santander Headline","Segoe UI",Arial,sans-serif;
}
*{box-sizing:border-box}
html,body{font-family:var(--body-font)!important}
body{background:var(--santander-bg)!important;color:var(--santander-text)!important}
header{
  background:linear-gradient(105deg,var(--santander-red-dark),var(--santander-red))!important;
  color:#fff!important;border-bottom:0!important;box-shadow:0 3px 12px rgba(80,0,0,.18)!important;
}
.brand{font-family:var(--brand-font)!important;font-weight:600!important;letter-spacing:.1px!important;display:flex!important;align-items:center!important;gap:12px!important}
.brand::before{
  content:"";display:inline-block;width:36px;height:34px;flex:0 0 36px;
  background-image:url("/corporate-logo.png");
  background-size:contain;background-position:center;background-repeat:no-repeat;
  filter:brightness(0) invert(1);
}
.shell aside,aside{background:#fff!important;border-right:1px solid var(--santander-grey-200)!important}
aside nav a,nav a{color:#3c3c3c!important;border-radius:6px!important;transition:.15s ease!important}
aside nav a:hover,nav a:hover{background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important}
aside nav a.active,nav a.active{
  background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important;
  border-left:4px solid var(--santander-red)!important;font-weight:700!important;
}
main h1,main h2,.page-title{font-family:var(--brand-font)!important;color:var(--santander-red-dark)!important}
main h3{font-family:var(--brand-font)!important;color:var(--santander-black)!important}
a{color:var(--santander-red-dark)}
a:hover{color:var(--santander-red)}
.btn,.button,button,input[type=submit],input[type=button]{
  font-family:var(--body-font)!important;border-radius:6px!important;box-shadow:none!important;
}
.btn.primary,.btn-primary,.button-primary,button.primary,input[type=submit]{
  background:var(--santander-red)!important;border-color:var(--santander-red)!important;color:#fff!important;
}
.btn.primary:hover,.btn-primary:hover,button.primary:hover,input[type=submit]:hover{
  background:var(--santander-red-dark)!important;border-color:var(--santander-red-dark)!important;
}
.btn:not(.primary),button:not(.primary){
  background:#fff!important;border-color:var(--santander-grey-300)!important;color:var(--santander-text)!important;
}
.card,.panel,.widget,.stat,.tile,.project-card,.task-card,.wiki-card,.bau-card{
  background:#fff!important;border:1px solid var(--santander-grey-200)!important;
  border-radius:10px!important;box-shadow:0 2px 8px rgba(0,0,0,.045)!important;
}
table{background:#fff!important;border-color:var(--santander-grey-200)!important}
thead th,table th{background:var(--santander-red-dark)!important;color:#fff!important;border-color:var(--santander-red-dark)!important}
tbody tr:nth-child(even){background:#FAFAFA!important}
input,select,textarea{
  font-family:var(--body-font)!important;border:1px solid var(--santander-grey-300)!important;border-radius:6px!important;
}
input:focus,select:focus,textarea:focus{
  border-color:var(--santander-red)!important;outline:0!important;box-shadow:0 0 0 3px rgba(236,0,0,.12)!important;
}
.badge,.chip,.tag{border-radius:999px!important}
.badge.en-curso,.badge.alta,.badge.critica,.badge.crítica{background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important}
.notice,.alert,.callout{border-left:6px solid var(--santander-red)!important;background:#fff!important}
pre,code,.code-block{background:#F2F2F2!important;border-color:#D5D5D5!important}
footer{border-top:1px solid var(--santander-grey-200)!important;color:var(--santander-grey-700)!important}
@media print {
  header,aside,.header-actions,.actions,.toolbar,footer{display:none!important}
  body,main{background:#fff!important;color:#111!important}
  main{width:100%!important;max-width:none!important;margin:0!important;padding:0!important}
  h1,h2{color:var(--santander-red-dark)!important}
  table th{background:var(--santander-red-dark)!important;color:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .notice,.alert,.callout{border-left-color:var(--santander-red)!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
}
/* V25.2 — Cabecera corporativa: símbolo rojo íntegro sobre fondo blanco */
header{
  min-height:68px!important;
  height:auto!important;
  padding:10px 22px!important;
  background:#FFFFFF!important;
  color:#222222!important;
  border-bottom:4px solid #EC0000!important;
  box-shadow:0 2px 10px rgba(0,0,0,.08)!important;
  overflow:visible!important;
}
.brand{
  min-width:0!important;
  color:#222222!important;
  font-family:var(--brand-font,"Santander Headline","Segoe UI",Arial,sans-serif)!important;
  font-size:20px!important;
  line-height:1.15!important;
  font-weight:600!important;
  display:flex!important;
  align-items:center!important;
  gap:13px!important;
  white-space:nowrap!important;
  overflow:visible!important;
}
.brand::before{
  content:""!important;
  display:block!important;
  width:46px!important;
  height:46px!important;
  min-width:46px!important;
  max-width:46px!important;
  flex:0 0 46px!important;
  background-color:#FFFFFF!important;
  background-repeat:no-repeat!important;
  background-position:center!important;
  background-size:contain!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
}
@media(max-width:700px){
  header{min-height:60px!important;padding:8px 14px!important}
  .brand{font-size:17px!important;gap:10px!important}
  .brand::before{width:38px!important;height:38px!important;min-width:38px!important;max-width:38px!important;flex-basis:38px!important}
}

/* V25.3 — Auditoría de legibilidad y contraste */
:root{
  --accessible-text:#202124;
  --accessible-muted:#5F6368;
  --accessible-border:#AEB4BA;
  --accessible-link:#B30000;
  --accessible-focus:#8A0000;
  --code-bg:#1F2328;
  --code-head:#2D333B;
  --code-text:#F0F3F6;
  --code-muted:#B7C0CA;
  --code-keyword:#FF9A91;
  --code-string:#B6D7FF;
  --code-number:#91CBFF;
  --code-comment:#B7C0CA;
  --code-variable:#FFC07A;
  --code-builtin:#DFB6FF;
  --code-pipe:#FFD866;
}
body{color:var(--accessible-text)!important}
a{color:var(--accessible-link)!important}
a:hover,a:focus{text-decoration:underline!important;color:#8A0000!important}
small,.muted,.meta,.aside-note,.page-head p,.stats span,.stat span,.card-meta{
  color:var(--accessible-muted)!important;
  opacity:1!important;
}
button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
  outline:3px solid var(--accessible-focus)!important;
  outline-offset:2px!important;
}
input,select,textarea{
  color:#202124!important;
  background:#FFFFFF!important;
  border-color:#8A9097!important;
  opacity:1!important;
}
input::placeholder,textarea::placeholder{color:#656B72!important;opacity:1!important}
button:disabled,.btn:disabled{opacity:.65!important;color:#3C4043!important}

/* Código: contraste alto y sin transparencias */
.code-wrap,.code-block,.code-container,.editor-code{
  background:var(--code-bg)!important;
  border-color:#59636E!important;
  opacity:1!important;
}
.code-head,.code-header,.code-title{
  background:var(--code-head)!important;
  color:#FFFFFF!important;
  border-color:#59636E!important;
  opacity:1!important;
}
.code-box,.code-box code,pre,pre code,.content pre,.content pre code{
  background:var(--code-bg)!important;
  color:var(--code-text)!important;
  font-family:Consolas,"Courier New",monospace!important;
  font-size:14px!important;
  line-height:1.65!important;
  opacity:1!important;
  text-shadow:none!important;
  filter:none!important;
}
.code-box *,pre *,pre code *{
  opacity:1!important;
  text-shadow:none!important;
  filter:none!important;
}
.tok-keyword{color:var(--code-keyword)!important;font-weight:700!important}
.tok-string{color:var(--code-string)!important}
.tok-comment{color:var(--code-comment)!important;font-style:italic!important}
.tok-number{color:var(--code-number)!important}
.tok-builtin{color:var(--code-builtin)!important}
.tok-variable{color:var(--code-variable)!important}
.tok-operator{color:#FF9A91!important;font-weight:700!important}
.tok-pipe{color:var(--code-pipe)!important;font-weight:800!important}
.tok-key,.tok-tag{color:#9BE9A8!important}
.copy-code,.code-head button,.code-header button{
  background:#FFFFFF!important;
  color:#8A0000!important;
  border:1px solid #FFFFFF!important;
  font-weight:700!important;
}

/* Avisos: texto oscuro y fondos claros */
.admonition,.notice,.alert{
  color:#202124!important;
  opacity:1!important;
}
.admonition *,.notice *,.alert *{opacity:1!important}
.admonition.advertencia,.warning{
  background:#FFF4E5!important;
  border-color:#C54800!important;
  color:#3B2500!important;
}
.admonition.informacion,.admonition.nota,.info{
  background:#F3F6F9!important;
  border-color:#B30000!important;
  color:#202124!important;
}
.admonition.importante{
  background:#FDECEC!important;
  border-color:#B30000!important;
  color:#4A0000!important;
}
.admonition.error,.error{
  background:#FCE8E6!important;
  border-color:#A50E0E!important;
  color:#5F0000!important;
}

/* Tablas, tarjetas, etiquetas y estados */
th{background:#ECEFF1!important;color:#30343B!important}
td{color:#202124!important}
.card,section,.stat,.project-card,.info-card{
  color:#202124!important;
}
.badge,.tag{
  color:#30343B!important;
  opacity:1!important;
}
.status-en-curso,.badge.en-curso{background:#FFE1E1!important;color:#8A0000!important}
.status-finalizado,.status-completada,.badge.resuelta,.badge.cerrada{
  background:#DFF1E5!important;color:#1F5D36!important;
}
.status-bloqueada,.status-cancelado,.priority-critica,.badge.priority.critica{
  background:#F8D7DA!important;color:#721C24!important;
}
.primary,.btn.primary{
  background:#EC0000!important;color:#FFFFFF!important;border-color:#B30000!important;
}
.primary:hover,.btn.primary:hover{background:#B30000!important;color:#FFFFFF!important}

/* V25.4 — Selecciones legibles y zona de información ampliada */
html,body{width:100%;min-width:0}
.shell{
  width:calc(100% - 24px)!important;
  max-width:1920px!important;
  margin:0 auto!important;
  grid-template-columns:230px minmax(0,1fr)!important;
}
main{
  width:100%!important;
  max-width:none!important;
  min-width:0!important;
  margin:0!important;
  padding:20px 24px 36px!important;
}
main > *,article,.content,.page-content,.dashboard-grid{
  max-width:none!important;
}
article{width:100%!important}
.card,section,.hero,.panel{
  max-width:none!important;
}
.form-card,.editor,.github-editor,.info-card{
  max-width:none!important;
  width:100%!important;
}
.table-wrap,.pending-card,.pending-table{
  width:100%!important;
  max-width:none!important;
}
table{width:100%!important}

/* Filtros y pestañas: estados claramente visibles */
.pending-filters,.search-filters,.module-tabs{
  display:flex!important;
  flex-wrap:wrap!important;
  gap:8px!important;
  align-items:center!important;
}
.pending-filter,.search-filters a,.module-tabs a{
  display:inline-flex!important;
  align-items:center!important;
  justify-content:center!important;
  min-height:36px!important;
  padding:8px 14px!important;
  border:1px solid #B8BEC5!important;
  border-radius:999px!important;
  background:#FFFFFF!important;
  color:#9B0000!important;
  font-size:13px!important;
  line-height:1.2!important;
  font-weight:600!important;
  text-decoration:none!important;
  opacity:1!important;
  white-space:nowrap!important;
}
.pending-filter:hover,.search-filters a:hover,.module-tabs a:hover{
  background:#FDECEC!important;
  border-color:#EC0000!important;
  color:#780000!important;
  text-decoration:none!important;
}
.pending-filter.active,.search-filters a.active,.module-tabs a.active{
  background:#EC0000!important;
  border-color:#B30000!important;
  color:#FFFFFF!important;
  font-weight:700!important;
  box-shadow:0 0 0 1px #EC0000!important;
}
.pending-filter.active *,
.search-filters a.active *,
.module-tabs a.active *{
  color:#FFFFFF!important;
}

/* Tarjetas resumen */
.pending-summary{
  grid-template-columns:repeat(4,minmax(180px,1fr))!important;
  gap:12px!important;
}
.pending-chip{
  min-height:72px!important;
  padding:14px 16px!important;
  background:#FFFFFF!important;
  color:#30343B!important;
  border:1px solid #C7CDD3!important;
}
.pending-chip:hover{
  background:#FFF5F5!important;
  border-color:#EC0000!important;
  text-decoration:none!important;
}
.pending-chip strong{font-size:24px!important;color:#202124!important}

/* Ventanas y cuadros de información más amplios */
.import-dialog,.modal-dialog,.dialog,.popup,.detail-dialog{
  width:min(1100px,calc(100vw - 40px))!important;
  max-width:1100px!important;
  max-height:92vh!important;
}
.import-dialog-body,.modal-body,.dialog-body{
  padding:22px 24px!important;
}
.project-grid{
  grid-template-columns:repeat(auto-fit,minmax(280px,1fr))!important;
}
.detail-grid{
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
}
.editor-row{
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
}

@media(min-width:1600px){
  .shell{width:calc(100% - 32px)!important;max-width:2200px!important}
  main{padding:22px 30px 42px!important}
}
@media(max-width:1050px){
  .pending-summary{grid-template-columns:repeat(2,minmax(160px,1fr))!important}
  .detail-grid,.editor-row{grid-template-columns:1fr!important}
}
@media(max-width:850px){
  .shell{display:block!important;width:100%!important}
  main{padding:16px!important}
  .pending-summary{grid-template-columns:1fr!important}
  .pending-filter,.search-filters a,.module-tabs a{font-size:12px!important;padding:8px 12px!important}
}

/* V25.5 — Tipografía exacta para PDF */
@media print {
  html,body,main,article,.content,.page-content{
    font-size:12px!important;
    line-height:1.45!important;
  }

  p,li,dd,dt,td,th,span,div,label{
    font-size:12px!important;
  }

  h1,h2,h3,h4,h5,h6,
  .page-title,.section-title,.card-title{
    font-size:14px!important;
    line-height:1.25!important;
  }

  .email-example,
  .email-example *,
  .communication-email,
  .communication-email *,
  .communication-case,
  .communication-case *,
  .communication-response,
  .communication-response *,
  .case-field,
  .case-field *,
  .admonition,
  .admonition *,
  .notice,
  .notice *,
  .alert,
  .alert *,
  .callout,
  .callout *,
  .code-wrap,
  .code-wrap *,
  .code-box,
  .code-box *,
  .code-head,
  .code-head *,
  pre,
  pre *,
  code,
  code *{
    font-size:9px!important;
    line-height:1.4!important;
  }

  .email-example-title,
  .communication-title,
  .admonition-title,
  .code-head{
    font-size:9px!important;
    font-weight:700!important;
  }

  .email-example,
  .communication-email,
  .communication-case,
  .communication-response,
  .admonition,
  .notice,
  .alert,
  .callout,
  .code-wrap,
  pre{
    break-inside:avoid!important;
    page-break-inside:avoid!important;
  }
}
"""

BASE=Path(__file__).resolve().parent
DATA=BASE/'data'; STATIC=BASE/'static'
PROJECTS=DATA/'projects.json'; TASKS=DATA/'tasks.json'; RESPONSIBLES=DATA/'responsibles.json'; ATTACHMENTS=DATA/'attachments'
DATA.mkdir(parents=True,exist_ok=True); STATIC.mkdir(parents=True,exist_ok=True); ATTACHMENTS.mkdir(parents=True,exist_ok=True)
WIKI_URL=os.environ.get('WIKI_URL','http://127.0.0.1:8080')
PORTAL_URL=os.environ.get('PORTAL_URL','http://127.0.0.1:8079')
BAU_URL=os.environ.get('BAU_URL','http://127.0.0.1:8082')
BITACORA_URL=os.environ.get('BITACORA_URL','http://127.0.0.1:8083')
BIBLIOTECA_URL=os.environ.get('BIBLIOTECA_URL','http://127.0.0.1:8084')
CAMBIOS_URL=os.environ.get('CAMBIOS_URL','http://127.0.0.1:8085')
WIKI_PAGES=BASE.parent/'wiki'/'data'/'pages'

def read_json(path, default):
    try: return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default
    except Exception: return default

def write_json(path, value):
    tmp=path.with_suffix('.tmp'); tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(path)

def esc(v): return html.escape(str(v or ''), quote=True)
def now(): return datetime.now().isoformat(timespec='seconds')
def uid(prefix): return prefix+'_'+uuid.uuid4().hex[:10]
def projects(): return read_json(PROJECTS, [])
def tasks(): return read_json(TASKS, [])
def responsibles(): return read_json(RESPONSIBLES, [])

def field_values(form, name):
    value=form.get(name, [])
    if isinstance(value, list): return [str(x) for x in value if str(x).strip()]
    return [str(value)] if str(value or '').strip() else []

def selected_responsibles(item):
    ids=item.get('responsible_ids', [])
    if isinstance(ids, str): ids=[ids] if ids else []
    if not ids and item.get('owner'):
        owner=str(item.get('owner')).strip().lower()
        ids=[r['id'] for r in responsibles() if str(r.get('name','')).strip().lower()==owner]
    return ids

def responsible_names(item):
    selected=set(selected_responsibles(item)); people=responsibles()
    names=[r.get('name','') for r in people if r.get('id') in selected]
    if not names and item.get('owner'): names=[item.get('owner')]
    return [n for n in names if n]

def responsibles_badges(item):
    names=responsible_names(item)
    return ''.join(f'<span class="person-chip">{esc(n)}</span>' for n in names) or '<span class="muted">Sin asignar</span>'

def responsible_options(selected=None):
    chosen=set(selected or [])
    return ''.join(f'<option value="{esc(r.get("id"))}" {"selected" if r.get("id") in chosen else ""}>{esc(r.get("name"))}</option>' for r in sorted(responsibles(),key=lambda x:x.get('name','').lower()))

def responsible_checkboxes(selected=None):
    chosen=set(selected or [])
    people=sorted(responsibles(),key=lambda x:x.get('name','').lower())
    if not people:
        return '<div class="responsible-empty">No hay responsables creados.</div>'
    return ''.join(
        f'<label class="responsible-check"><input type="checkbox" name="responsible_ids" value="{esc(r.get("id"))}" {"checked" if r.get("id") in chosen else ""}><span>{esc(r.get("name"))}</span></label>'
        for r in people
    )


def safe_filename(name):
    name=Path(str(name or 'archivo')).name
    clean=re.sub(r'[^A-Za-z0-9._-]+','_',name).strip('._') or 'archivo'
    return clean[:140]

def save_upload(filename, content):
    ATTACHMENTS.mkdir(parents=True, exist_ok=True)
    original=safe_filename(filename)
    stored=uuid.uuid4().hex[:12]+'_'+original
    target=ATTACHMENTS/stored
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
    return {'name':original,'file':stored}

def delete_uploads(items):
    for item in items or []:
        stored=item.get('file','') if isinstance(item,dict) else ''
        if stored:
            try: (ATTACHMENTS/stored).unlink(missing_ok=True)
            except Exception: pass


def wiki_pages():
    items=[]
    try:
        WIKI_PAGES.mkdir(parents=True, exist_ok=True)
        for path in sorted(WIKI_PAGES.glob('*.json')):
            try:
                page=json.loads(path.read_text(encoding='utf-8'))
                slug=str(page.get('slug') or path.stem)
                title=str(page.get('title') or slug)
                items.append({'slug':slug,'title':title,'category':str(page.get('category') or '')})
            except Exception:
                continue
    except Exception:
        pass
    return items

def selected_wiki_pages(item):
    values=item.get('wiki_pages',[])
    if isinstance(values,str): values=[values] if values else []
    return [str(x) for x in values if str(x).strip()]

def wiki_page_options(selected=None):
    chosen=set(selected or [])
    pages=wiki_pages()
    if not pages:
        return '<option disabled>No hay páginas Wiki disponibles</option>'
    return ''.join(f'<option value="{esc(p["slug"])}" {"selected" if p["slug"] in chosen else ""}>{esc(p["title"])}{(" · "+esc(p["category"])) if p.get("category") else ""}</option>' for p in pages)

def wiki_links_html(item):
    slugs=selected_wiki_pages(item)
    if not slugs: return ''
    by_slug={p['slug']:p for p in wiki_pages()}
    rows=[]
    for slug in slugs:
        page=by_slug.get(slug,{'title':slug})
        rows.append(f'<li><a href="{esc(WIKI_URL)}/view?slug={esc(slug)}" target="_blank" rel="noopener">📘 {esc(page.get("title") or slug)}</a></li>')
    return '<ul class="attachment-list wiki-links">'+''.join(rows)+'</ul>'



def ensure_note_ids(history):
    changed=False
    for note in history or []:
        if not note.get('id'):
            note['id']=uid('note')
            changed=True
        note.setdefault('created', note.get('date') or now())
    return changed

def note_actions(kind, parent_id, note_id):
    return f'''<div class="note-actions"><a class="btn small" href="/{kind}/note/edit?id={esc(parent_id)}&note_id={esc(note_id)}">Editar</a><form class="inline" method="post" action="/{kind}/note/delete" onsubmit="return confirm('¿Eliminar este seguimiento?')"><input type="hidden" name="id" value="{esc(parent_id)}"><input type="hidden" name="note_id" value="{esc(note_id)}"><button class="btn small danger">Eliminar</button></form></div>'''

def note_form(kind, parent_id, note_id):
    collection=projects() if kind=='project' else tasks()
    parent=next((x for x in collection if x.get('id')==parent_id),None)
    if not parent:
        return layout('No encontrado','<h1>Elemento no encontrado</h1>','projects' if kind=='project' else 'tasks')
    history=parent.setdefault('history',[])
    changed=ensure_note_ids(history)
    if changed:
        write_json(PROJECTS if kind=='project' else TASKS,collection)
    note=next((x for x in history if x.get('id')==note_id),None)
    if not note:
        return layout('No encontrado','<h1>Seguimiento no encontrado</h1>','projects' if kind=='project' else 'tasks')
    links='\n'.join((str(x.get('title') or x.get('url') or '')+' | '+str(x.get('url') or '')).strip(' |') for x in note.get('links',[]))
    assets=attachments_html(note.get('attachments',[]))
    back=f'/{kind}?id={esc(parent_id)}'
    title='Editar seguimiento del proyecto' if kind=='project' else 'Editar seguimiento de la tarea'
    assets_block=f'<div class="wide current-assets"><strong>Adjuntos actuales</strong>{assets}<label class="remove-assets"><input type="checkbox" name="remove_attachments" value="1"> Eliminar los adjuntos actuales</label></div>' if assets else ''
    body=f'''<div class="page-head"><div><h1>{title}</h1><p>Corrige el contenido sin crear un registro duplicado.</p></div></div><form class="form-card" method="post" action="/{kind}/note/save" enctype="multipart/form-data"><input type="hidden" name="id" value="{esc(parent_id)}"><input type="hidden" name="note_id" value="{esc(note_id)}"><label>Fecha y hora<input type="datetime-local" name="date" value="{esc(str(note.get('date','')).replace(' ','T'))}"></label><label class="wide">Seguimiento<textarea required name="text" rows="7">{esc(note.get('text',''))}</textarea></label><label class="wide">Enlaces relacionados <span class="field-help">Uno por línea. Formato opcional: Nombre | URL</span><textarea name="links" rows="4">{esc(links)}</textarea></label><label class="wide">Añadir archivos<input type="file" name="files" multiple></label>{assets_block}<div class="form-actions wide"><button class="btn primary">Guardar cambios</button><a class="btn" href="{back}">Cancelar</a></div></form>'''
    return layout(title,body,'projects' if kind=='project' else 'tasks')

def normalize_url(value):
    value=str(value or '').strip()
    if value and not value.lower().startswith(('http://','https://','file://')):
        value='https://'+value
    return value

def parse_links(text):
    links=[]
    for raw in str(text or '').splitlines():
        raw=raw.strip()
        if not raw: continue
        if '|' in raw:
            title,url=[x.strip() for x in raw.split('|',1)]
        else:
            title,url=raw,raw
        url=normalize_url(url)
        if url: links.append({'title':title or url,'url':url})
    return links

def attachments_html(items):
    if not items: return ''
    rows=''.join(f'<li><a href="/attachments/{esc(a.get("file"))}" download="{esc(a.get("name"))}">📎 {esc(a.get("name"))}</a></li>' for a in items)
    return f'<ul class="attachment-list">{rows}</ul>'

def links_html(items):
    if not items: return ''
    rows=''.join(f'<li><a href="{esc(a.get("url"))}" target="_blank" rel="noopener">🔗 {esc(a.get("title") or a.get("url"))}</a></li>' for a in items)
    return f'<ul class="attachment-list">{rows}</ul>'

def layout(title, body, active='dashboard'):
    main_links=[('Inicio',PORTAL_URL),('Wiki',WIKI_URL),('Proyectos y tareas','/'),('BAU',BAU_URL),('Bitácora',BITACORA_URL),('Biblioteca',BIBLIOTECA_URL),('Plantillas Cambios',CAMBIOS_URL)]
    nav=''.join(f'<a class="{"active" if n=="Proyectos y tareas" else ""}" href="{esc(u)}">{esc(n)}</a>' for n,u in main_links)
    tabs=[('dashboard','Resumen','/'),('projects','Proyectos','/projects'),('tasks','Tareas','/tasks'),('responsibles','Responsables','/responsibles'),('calendar','Calendario','/calendar')]
    module_nav='<div class="module-tabs">'+''.join(f'<a class="{"active" if active==k else ""}" href="{u}">{esc(label)}</a>' for k,label,u in tabs)+'</div>'
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)} · Proyectos</title><link rel="stylesheet" href="/static/style.css"><style>{CORPORATE_THEME_CSS}</style>
<style>
/* V27.3 · Logotipo adaptable al espacio disponible */
header{{
  min-height:72px!important;
  height:auto!important;
  overflow:visible!important;
}}
.brand{{
  min-height:56px!important;
  max-width:min(70vw,760px)!important;
  display:flex!important;
  align-items:center!important;
  gap:14px!important;
  overflow:visible!important;
}}
.brand::before{{
  display:none!important;
  content:none!important;
  background-image:none!important;
}}
.brand .brand-logo{{
  display:block!important;
  width:auto!important;
  height:auto!important;
  min-width:0!important;
  min-height:0!important;
  max-width:210px!important;
  max-height:56px!important;
  flex:0 1 auto!important;
  object-fit:contain!important;
  object-position:left center!important;
  background:transparent!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
}}
.brand>span{{
  display:block!important;
  min-width:0!important;
  overflow:hidden!important;
  text-overflow:ellipsis!important;
}}
@media(max-width:760px){{
  header{{min-height:64px!important;padding:8px 14px!important}}
  .brand{{min-height:46px!important;gap:10px!important;max-width:76vw!important}}
  .brand .brand-logo{{
    width:auto!important;
    height:auto!important;
    max-width:145px!important;
    max-height:46px!important;
  }}
}}
@media(max-width:480px){{
  .brand .brand-logo{{max-width:105px!important;max-height:42px!important}}
  .brand>span{{font-size:15px!important}}
}}
</style>
</head><body><header><div class="brand"><img class="brand-logo" src="/logo.png" alt="Logo Santander" onerror="this.style.display=\'none\'"><span>Santander Mail Security · Proyectos</span></div><div class="header-actions"><a class="btn" href="/">↑ Nivel superior</a><a class="btn" href="{esc(PORTAL_URL)}">Inicio común</a><a class="btn primary" href="/project/new">+ Nuevo proyecto</a><a class="btn" href="/task/new">+ Nueva tarea</a></div></header><div class="shell"><aside><nav>{nav}</nav><div class="aside-note">Aplicación local<br>Sin usuarios<br>Datos en JSON</div></aside><main>{module_nav}{body}</main></div><script src="/static/app.js"></script></body></html>'''

def badge(value, kind='status'):
    key=str(value or '').lower().replace(' ','-').replace('ó','o').replace('í','i')
    return f'<span class="badge {kind}-{esc(key)}">{esc(value)}</span>'

def dashboard():
    ps=projects(); ts=tasks(); today=date.today().isoformat()
    # El panel principal solo muestra proyectos abiertos. Los proyectos cerrados
    # siguen disponibles en el listado general de Proyectos y mediante sus filtros.
    closed_statuses={'cerrado','cerrada','finalizado','finalizada','cancelado','cancelada'}
    active=[p for p in ps if str(p.get('status','')).strip().lower() not in closed_statuses]
    pending=[t for t in ts if t.get('status') not in ('Completada','Cancelada')]
    overdue=[t for t in pending if t.get('due_date') and t['due_date']<today]
    done=len([t for t in ts if t.get('status')=='Completada'])
    cards=f'''<div class="stats"><div><strong>{len(active)}</strong><span>Proyectos activos</span></div><div><strong>{len(pending)}</strong><span>Tareas pendientes</span></div><div><strong>{len(overdue)}</strong><span>Tareas vencidas</span></div><div><strong>{done}</strong><span>Tareas completadas</span></div></div>'''
    recent=sorted(active,key=lambda x:x.get('updated',''),reverse=True)[:6]
    plist=''.join(project_card(p, compact=True) for p in recent) or '<p class="empty">No hay proyectos abiertos.</p>'
    upcoming=sorted([t for t in pending if t.get('due_date')],key=lambda x:x['due_date'])[:8]
    rows=''.join(task_row(t,ps) for t in upcoming) or '<tr><td colspan="6" class="empty">No hay tareas próximas.</td></tr>'
    body=f'''<div class="page-head"><div><h1>Panel principal</h1><p>Resumen general del trabajo pendiente y los proyectos en curso.</p></div></div>{cards}<section><div class="section-head"><h2>Proyectos recientes</h2><a href="/projects">Ver todos</a></div><div class="project-grid">{plist}</div></section><section><div class="section-head"><h2>Próximas tareas</h2><a href="/tasks">Ver todas</a></div><div class="table-wrap"><table><thead><tr><th>Tarea</th><th>Proyecto</th><th>Responsables</th><th>Estado</th><th>Prioridad</th><th>Vence</th></tr></thead><tbody>{rows}</tbody></table></div></section>'''
    return layout('Inicio',body)

def project_card(p, compact=False):
    progress=int(p.get('progress',0) or 0)
    return f'''<article class="project-card"><div class="card-top"><h3><a href="/project?id={esc(p['id'])}">{esc(p.get('name'))}</a></h3>{badge(p.get('status','Planificado'))}</div><p>{esc(p.get('description','Sin descripción'))}</p><div class="progress"><span style="width:{progress}%"></span></div><div class="card-meta"><span>{progress}%</span><span>{esc(p.get('start_date',''))} → {esc(p.get('end_date',''))}</span></div><div class="card-people">{responsibles_badges(p)}</div></article>'''

def project_list(query=None):
    query=query or {}
    ps=projects()
    responsible=query.get('responsible',[''])[0]
    status=query.get('status',[''])[0]
    if responsible:
        ps=[p for p in ps if responsible in selected_responsibles(p)]
    if status:
        ps=[p for p in ps if p.get('status','Planificado')==status]
    q=''.join(project_card(p) for p in sorted(ps,key=lambda x:x.get('updated',''),reverse=True)) or '<p class="empty">No hay proyectos que coincidan con los filtros.</p>'
    ropts=''.join(f'<option value="{esc(r["id"])}" {"selected" if responsible==r["id"] else ""}>{esc(r["name"])}</option>' for r in sorted(responsibles(),key=lambda x:x.get('name','').lower()))
    project_statuses=['Planificado','En curso','En pausa','Finalizado','Cancelado']
    sopts=''.join(f'<option value="{esc(value)}" {"selected" if status==value else ""}>{esc(value)}</option>' for value in project_statuses)
    filters=f'<form class="filters"><select name="responsible"><option value="">Todos los responsables</option>{ropts}</select><select name="status"><option value="">Todos los estados</option>{sopts}</select><button class="btn">Filtrar</button><a class="btn" href="/projects">Limpiar</a></form>'
    return layout('Proyectos',f'<div class="page-head"><div><h1>Proyectos</h1><p>Consulta el estado, avance, fechas y responsables de cada proyecto.</p></div><a class="btn primary" href="/project/new">Nuevo proyecto</a></div>{filters}<div class="project-grid">{q}</div>','projects')

def project_form(p=None):
    p=p or {}; edit=bool(p)
    statuses=['Planificado','En curso','En pausa','Finalizado','Cancelado']; priorities=['Baja','Media','Alta','Crítica']
    opts=lambda values,current: ''.join(f'<option {"selected" if v==current else ""}>{v}</option>' for v in values)
    body=f'''<div class="page-head"><div><h1>{'Editar' if edit else 'Nuevo'} proyecto</h1><p>Información principal y planificación del proyecto.</p></div></div><form class="form-card project-form" method="post" action="/project/save"><input type="hidden" name="id" value="{esc(p.get('id',''))}"><label class="project-name">Nombre<input required name="name" value="{esc(p.get('name',''))}"></label><div class="project-main"><label class="project-description">Descripción<textarea name="description" rows="16">{esc(p.get('description',''))}</textarea></label><div class="project-options"><label class="project-status">Estado<select name="status">{opts(statuses,p.get('status','Planificado'))}</select></label><label class="project-priority">Prioridad<select name="priority">{opts(priorities,p.get('priority','Media'))}</select></label><label class="project-progress">Avance (%)<input type="number" min="0" max="100" name="progress" value="{esc(p.get('progress',0))}"></label><label class="project-start">Fecha de inicio<input type="date" name="start_date" value="{esc(p.get('start_date',''))}"></label><label class="project-end">Fecha prevista de fin<input type="date" name="end_date" value="{esc(p.get('end_date',''))}"></label><div class="project-responsibles"><div class="field-title">Responsables <span class="field-help">Selecciona o deselecciona uno o varios</span></div><div class="responsible-checklist">{responsible_checkboxes(selected_responsibles(p))}</div><div class="responsible-count" data-responsible-count>0 seleccionados</div></div><label class="project-wiki">Documentación Wiki relacionada <span class="field-help">Puedes seleccionar una o varias páginas</span><select name="wiki_pages" multiple size="7">{wiki_page_options(selected_wiki_pages(p))}</select></label></div></div><div class="form-actions"><button class="btn primary">Guardar proyecto</button><a class="btn" href="/projects">Cancelar</a></div></form>'''
    return layout('Proyecto',body,'projects')

def project_report(pid):
    p=next((x for x in projects() if x.get('id')==pid),None)
    if not p: return layout('No encontrado','<h1>Proyecto no encontrado</h1>','projects')
    pts=sorted([t for t in tasks() if t.get('project_id')==pid],key=lambda x:(x.get('due_date') or '9999',x.get('title','')))
    progress=max(0,min(100,int(p.get('progress',0) or 0)))
    names=', '.join(responsible_names(p)) or 'Sin asignar'
    counts={s:sum(1 for t in pts if t.get('status')==s) for s in ['Pendiente','En curso','Bloqueada','Completada','Cancelada']}

    if pts:
        task_cards=[]
        for index,t in enumerate(pts,1):
            comments=esc(t.get('comments') or 'Sin comentarios registrados.')
            task_history=''.join(f'<li><strong>{esc(h.get("date") or "")}</strong> — {esc(h.get("text") or "")}</li>' for h in t.get('history',[]))
            followups=f'<div class="task-followups"><strong>Seguimientos</strong><ul>{task_history}</ul></div>' if task_history else ''
            task_cards.append(f'''<article class="task-card"><h3>{index}. {esc(t.get('title') or 'Tarea sin título')}</h3><table class="task-facts"><tbody><tr><th>Estado</th><td>{esc(t.get('status') or '—')}</td><th>Prioridad</th><td>{esc(t.get('priority') or '—')}</td><th>Responsables</th><td>{esc(', '.join(responsible_names(t)) or 'Sin asignar')}</td><th>Inicio</th><td>{esc(t.get('start_date') or '—')}</td><th>Fin</th><td>{esc(t.get('due_date') or '—')}</td></tr></tbody></table><div class="task-comments"><strong>Comentarios</strong><p>{comments}</p></div>{followups}</article>''')
        task_html=''.join(task_cards)
    else:
        task_html='<p class="empty-report">No hay tareas asociadas.</p>'

    history_items=[]
    for h in reversed(p.get('history',[])):
        history_items.append(f'''<div class="timeline-item"><div class="timeline-dot"></div><div class="timeline-date">{esc(h.get('date') or 'Sin fecha')}</div><div class="timeline-body"><p>{esc(h.get('text') or '')}</p>{links_html(h.get('links',[]))}{attachments_html(h.get('attachments',[]))}</div></div>''')
    history=''.join(history_items) or '<p class="empty-report">No hay seguimientos registrados.</p>'
    summary=f'''Proyecto al {progress} %. {len(pts)} tareas: {counts['Completada']} completadas, {counts['En curso']} en curso, {counts['Pendiente']} pendientes y {counts['Bloqueada']} bloqueadas.'''
    generated=datetime.now().strftime('%d/%m/%Y %H:%M')

    report_content=f'''<header class="report-head"><div><div class="brandline">Santander Mail Security</div><h1>{esc(p.get('name'))}</h1><p class="summary">{esc(summary)}</p></div><div class="report-meta"><strong>Informe de proyecto</strong><span>Generado el {generated}</span></div></header><section class="metrics" aria-label="Resumen de tareas"><div><strong>{progress}%</strong><span>Progreso</span></div><div><strong>{len(pts)}</strong><span>Total tareas</span></div><div><strong>{counts['Completada']}</strong><span>Completadas</span></div><div><strong>{counts['En curso']}</strong><span>En curso</span></div><div><strong>{counts['Pendiente']}</strong><span>Pendientes</span></div><div><strong>{counts['Bloqueada']}</strong><span>Bloqueadas</span></div></section><section><h2>1. Información general</h2><table class="facts"><tbody><tr><th>Estado</th><td>{esc(p.get('status') or '—')}</td><th>Prioridad</th><td>{esc(p.get('priority') or '—')}</td><th>Progreso</th><td>{progress} %</td></tr><tr><th>Responsables</th><td colspan="5">{esc(names)}</td></tr><tr><th>Inicio</th><td colspan="2">{esc(p.get('start_date') or '—')}</td><th>Fin previsto</th><td colspan="2">{esc(p.get('end_date') or '—')}</td></tr></tbody></table></section><section><h2>2. Descripción</h2><div class="description-box">{esc(p.get('description') or 'Sin descripción')}</div></section><section><h2>3. Tareas</h2>{task_html}</section><section><h2>4. Historial de seguimiento</h2><div class="timeline-report">{history}</div></section><footer class="report-footer">Santander Mail Security · Informe generado el {generated}</footer>'''

    page=f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(p.get('name'))} · Informe</title><style>*{{box-sizing:border-box}}body{{margin:0;background:#f4f5f7;font-family:Arial,Helvetica,sans-serif;color:#20252b;font-size:11px;line-height:1.3}}.toolbar{{position:sticky;top:0;z-index:4;background:#fff;border-bottom:1px solid #d9dde2;padding:10px 16px;display:flex;gap:8px;align-items:center;flex-wrap:wrap}}button,a.btn{{border:1px solid #c8cdd3;background:#fff;padding:8px 12px;border-radius:5px;text-decoration:none;color:#222;font-weight:600;cursor:pointer}}button.primary{{background:#ec0000;color:#fff;border-color:#ec0000}}#status{{font-size:11px;color:#555}}.sheet{{width:794px;max-width:calc(100% - 32px);margin:18px auto;background:#fff;padding:24px 28px;box-shadow:0 2px 12px #0002}}.report-head{{display:flex;justify-content:space-between;gap:20px;border-bottom:2px solid #ec0000;padding-bottom:9px;margin-bottom:12px}}.brandline{{color:#ec0000;font-weight:700;font-size:11px}}h1{{margin:5px 0 3px;font-size:14px;font-weight:700;color:#0050a4}}h2{{font-size:13px;font-weight:700}}h3{{font-size:12px;font-weight:700}}h4{{font-size:11px;font-weight:400;font-style:italic}}.summary{{margin:0;font-weight:700;font-size:11px}}.report-meta{{text-align:right;font-size:11px;color:#4f5963;white-space:nowrap}}.report-meta strong,.report-meta span{{display:block}}section{{margin-top:15px;break-inside:auto}}h2{{font-size:13px;font-weight:700;margin:0 0 7px;border-left:4px solid #ec0000;padding-left:8px}}.metrics{{display:grid;grid-template-columns:repeat(6,1fr);border:1px solid #d6d9dd;border-radius:6px;overflow:hidden;margin-top:0}}.metrics div{{padding:8px 5px;text-align:center;border-right:1px solid #e0e3e6}}.metrics div:last-child{{border-right:0}}.metrics strong{{display:block;font-size:11px;font-weight:700;color:#b30000}}.metrics span{{font-size:11px;color:#59636d}}table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #bfc4c9;padding:5px 7px;vertical-align:top;text-align:left}}th{{background:#f3f4f5;font-weight:700}}.facts{{font-size:11px;table-layout:fixed;margin:0}}.facts th{{width:13%}}.facts td{{width:20%}}.description-box{{border:1px solid #d2d6da;border-radius:5px;padding:9px 11px;white-space:pre-wrap;font-size:11px}}.task-card{{border:1px solid #c9cdd1;border-radius:6px;margin:0 0 10px;overflow:hidden;break-inside:avoid}}.task-card h3{{margin:0;padding:8px 10px;background:#fafafa;font-size:12px;font-weight:700;border-bottom:1px solid #dadddf}}.task-facts{{table-layout:fixed;font-size:11px;margin:0}}.task-facts th{{width:7.5%}}.task-facts td{{width:12.5%;overflow-wrap:anywhere}}.task-comments{{padding:7px 10px;font-size:11px;border-top:0}}.task-comments strong{{display:block;margin-bottom:3px}}.task-comments p{{margin:0;white-space:pre-wrap}}.task-followups{{padding:7px 10px;border-top:1px solid #e1e4e7;font-size:11px}}.task-followups strong{{display:block;margin-bottom:3px}}.task-followups ul{{margin:0;padding-left:17px}}.task-followups li{{margin:2px 0}}.timeline-report{{position:relative;margin-left:5px}}.timeline-report:before{{content:"";position:absolute;left:6px;top:4px;bottom:4px;width:2px;background:#d4d8dc}}.timeline-item{{position:relative;display:grid;grid-template-columns:15px 110px 1fr;gap:8px;padding:0 0 10px;break-inside:avoid}}.timeline-dot{{width:10px;height:10px;border-radius:50%;background:#ec0000;margin-top:3px;z-index:1}}.timeline-date{{font-size:11px;font-weight:700}}.timeline-body{{border-bottom:1px solid #e1e4e7;padding-bottom:8px;font-size:11px}}.timeline-body p{{margin:0;white-space:pre-wrap}}.attachment-list{{margin:4px 0 0;padding-left:17px}}.attachment-list li{{margin:2px 0}}.empty-report{{margin:6px 0;color:#69737d;font-size:11px}}.report-footer{{margin-top:16px;border-top:1px solid #d8dce0;padding-top:7px;color:#6d757d;font-size:11px}}@page{{size:A4 portrait;margin:10mm}}@media print{{body{{background:#fff}}.toolbar{{display:none}}.sheet{{box-shadow:none;margin:0;max-width:none;padding:0;width:auto}}.report-head{{margin-bottom:8px}}section{{margin-top:11px}}h2{{font-size:13px;font-weight:700;margin-bottom:5px}}.metrics div{{padding:6px 4px}}.task-card{{margin-bottom:7px}}}}</style><style>{CORPORATE_THEME_CSS}
/* V26.1: logotipo configurable desde imagenes/logo/logo.png */
.brand::before{{display:none!important;content:none!important;background-image:none!important}}
.brand .brand-logo{{
  display:block!important;width:46px!important;height:46px!important;
  min-width:46px!important;max-width:46px!important;flex:0 0 46px!important;
  object-fit:contain!important;object-position:center!important;
  background:transparent!important;border:0!important;border-radius:0!important;
  box-shadow:none!important
}}
.brand>span{{display:block!important}}
@media(max-width:760px){{
  .brand .brand-logo{{width:38px!important;height:38px!important;min-width:38px!important;max-width:38px!important;flex-basis:38px!important}}
}}
</style></head><body><div class="toolbar"><a class="btn" href="/project?id={esc(pid)}">← Volver al proyecto</a><button onclick="copyText()">Copiar texto</button><button onclick="window.print()">Imprimir / Guardar PDF</button><span id="status"></span></div><div class="sheet"><div id="report-content">{report_content}</div></div><script>const st=document.getElementById('status');function done(m){{st.textContent=m;setTimeout(()=>st.textContent='',2500)}}function mailHtml(n){{const c=n.cloneNode(true);c.style.cssText='width:680px;max-width:680px;box-sizing:border-box;font-family:Arial,Helvetica,sans-serif;color:#20252b;background:#fff;padding:16px;font-size:11px;line-height:1.3';c.querySelectorAll('table').forEach(x=>x.style.cssText+=';border-collapse:collapse;width:100%;max-width:100%;table-layout:fixed');c.querySelectorAll('th,td').forEach(x=>x.style.cssText+=';border:1px solid #bfc4c9;padding:5px 7px;vertical-align:top;text-align:left;overflow-wrap:anywhere;word-break:break-word');c.querySelectorAll('th').forEach(x=>x.style.background='#f3f4f5');c.querySelectorAll('.task-card').forEach(x=>x.style.cssText+=';border:1px solid #c9cdd1;margin:0 0 10px;page-break-inside:avoid');c.querySelectorAll('h1').forEach(x=>x.style.cssText+=';font-size:14px;font-weight:700;color:#0050a4');c.querySelectorAll('h2').forEach(x=>x.style.cssText+=';font-size:13px;font-weight:700');c.querySelectorAll('h3').forEach(x=>x.style.cssText+=';font-size:12px;font-weight:700');c.querySelectorAll('h4').forEach(x=>x.style.cssText+=';font-size:11px;font-weight:400;font-style:italic');c.querySelectorAll('.task-card h3').forEach(x=>x.style.cssText+=';margin:0;padding:8px 10px;background:#fafafa;border-bottom:1px solid #dadddf;font-size:12px;font-weight:700');c.querySelectorAll('.task-comments').forEach(x=>x.style.cssText+=';padding:7px 10px;font-size:11px');c.querySelectorAll('img').forEach(x=>x.style.cssText+=';max-width:100%;height:auto');return c.outerHTML}}async function copyRich(){{const n=document.getElementById('report-content'),h=mailHtml(n),t=n.innerText;try{{if(navigator.clipboard&&window.ClipboardItem)await navigator.clipboard.write([new ClipboardItem({{'text/html':new Blob([h],{{type:'text/html'}}),'text/plain':new Blob([t],{{type:'text/plain'}})}})]);else{{const r=document.createRange();r.selectNode(n);const s=getSelection();s.removeAllRanges();s.addRange(r);document.execCommand('copy');s.removeAllRanges()}}done('Informe copiado.')}}catch(e){{done('No se pudo copiar automáticamente. Usa Ctrl+C.')}}}}async function copyText(){{try{{await navigator.clipboard.writeText(document.getElementById('report-content').innerText);done('Texto copiado.')}}catch(e){{done('No se pudo copiar.')}}}}</script></body></html>'''
    return page

def project_detail(pid):
    ps=projects(); p=next((x for x in ps if x['id']==pid),None)
    if not p: return layout('No encontrado','<h1>Proyecto no encontrado</h1>','projects')
    related=[t for t in tasks() if t.get('project_id')==pid]; progress=int(p.get('progress',0) or 0)
    rows=''.join(task_row(t,ps) for t in related) or '<tr><td colspan="6" class="empty">Este proyecto todavía no tiene tareas.</td></tr>'
    history=p.setdefault('history',[])
    if ensure_note_ids(history):
        all_projects=projects()
        for item in all_projects:
            if item.get('id')==pid: item['history']=history
        write_json(PROJECTS,all_projects)
    linked_docs=[]
    selected=set(selected_wiki_pages(p))
    if WIKI_PAGES.exists():
        for path in WIKI_PAGES.glob('*.json'):
            doc=read_json(path,{})
            slug=str(doc.get('slug') or path.stem)
            if doc.get('project_id')==pid or slug in selected:
                doc['slug']=slug
                linked_docs.append(doc)
    # Evita duplicados si una página está vinculada por ambos mecanismos.
    linked_docs=list({str(d.get('slug')):d for d in linked_docs}.values())
    docs_html=''.join(f'<li class="linked-doc-item"><span class="linked-doc-dot"></span><div class="linked-doc-content"><a href="{esc(WIKI_URL)}/wiki/{esc(d.get("slug",""))}">{esc(d.get("title","Documento"))}</a><div class="linked-doc-meta"><span class="doc-category">{esc(d.get("category","General"))}</span><span>Actualizado: {esc(d.get("updated","").replace("T"," "))}</span></div></div></li>' for d in linked_docs) or '<li class="empty">No hay documentación vinculada.</li>'
    hist=''.join(f'<li><div class="note-head"><strong>{esc(h.get("date"))}</strong>{note_actions("project",pid,h.get("id"))}</div><p>{esc(h.get("text"))}</p>{links_html(h.get("links",[]))}{attachments_html(h.get("attachments",[]))}<small class="note-audit">{("Modificado: "+esc(h.get("modified"))) if h.get("modified") else ""}</small></li>' for h in reversed(history)) or '<li class="empty">Sin anotaciones.</li>'
    body=f'''<div class="page-head"><div><h1>{esc(p.get('name'))}</h1><p>{esc(p.get('description'))}</p></div><div><a class="btn" href="/project/edit?id={esc(pid)}">Editar</a> <a class="btn primary" href="/project/report?id={esc(pid)}">📄 Generar informe</a> <form class="inline" method="post" action="/project/delete" onsubmit="return confirm('¿Eliminar este proyecto y sus tareas?')"><input type="hidden" name="id" value="{esc(pid)}"><button class="btn danger">Eliminar</button></form></div></div><div class="detail-grid"><section class="info-card"><h2>Información</h2><dl><dt>Estado</dt><dd>{badge(p.get('status'))}</dd><dt>Prioridad</dt><dd>{badge(p.get('priority'),'priority')}</dd><dt>Responsables</dt><dd>{responsibles_badges(p)}</dd><dt>Fechas</dt><dd>{esc(p.get('start_date'))} → {esc(p.get('end_date'))}</dd></dl><h3>Avance: {progress}%</h3><div class="progress large"><span style="width:{progress}%"></span></div></section><section class="info-card"><h2>Añadir seguimiento</h2><form method="post" action="/project/note" enctype="multipart/form-data"><input type="hidden" name="id" value="{esc(pid)}"><textarea required name="text" rows="5" placeholder="Avance, incidencia, cambio o decisión..."></textarea><label>Enlaces relacionados <span class="field-help">Uno por línea. Formato opcional: Nombre | URL</span><textarea name="links" rows="3" placeholder="Consola CrowdStrike | https://...
Documento SharePoint | https://..."></textarea></label><label>Adjuntar archivos<input type="file" name="files" multiple></label><button class="btn primary">Guardar anotación</button></form></section></div><section><div class="section-head"><h2>Tareas del proyecto</h2><a class="btn" href="/task/new?project_id={esc(pid)}">Nueva tarea</a></div><div class="table-wrap"><table><thead><tr><th>Tarea</th><th>Proyecto</th><th>Responsables</th><th>Estado</th><th>Prioridad</th><th>Vence</th></tr></thead><tbody>{rows}</tbody></table></div></section><section><div class="section-head"><h2>Documentación Wiki vinculada</h2><a class="btn" href="{esc(WIKI_URL)}/new">Nuevo documento</a></div><ul class="timeline">{docs_html}</ul></section><section><h2>Historial de seguimiento</h2><ul class="timeline">{hist}</ul></section>'''
    return layout(p.get('name'),body,'projects')

def task_row(t, ps):
    p=next((x for x in ps if x['id']==t.get('project_id')),None)
    return f'<tr><td><a href="/task?id={esc(t["id"])}"><strong>{esc(t.get("title"))}</strong></a><small>{esc(t.get("description",""))}</small></td><td>{esc(p.get("name") if p else "Sin proyecto")}</td><td>{responsibles_badges(t)}</td><td>{badge(t.get("status"))}</td><td>{badge(t.get("priority"),"priority")}</td><td>{esc(t.get("due_date") or "—")}</td></tr>'

def task_detail(tid):
    t=next((x for x in tasks() if x.get('id')==tid),None)
    if not t:
        return layout('Tarea no encontrada','<h1>Tarea no encontrada</h1><p><a href="/tasks">Volver a tareas</a></p>','tasks')
    p=next((x for x in projects() if x.get('id')==t.get('project_id')),None)
    history=t.setdefault('history',[])
    if ensure_note_ids(history):
        all_tasks=tasks()
        for item in all_tasks:
            if item.get('id')==tid: item['history']=history
        write_json(TASKS,all_tasks)
    hist=''.join(
        f'<li><div class="note-head"><strong>{esc(h.get("date"))}</strong>{note_actions("task",tid,h.get("id"))}</div><p>{esc(h.get("text"))}</p>{links_html(h.get("links",[]))}{attachments_html(h.get("attachments",[]))}<small class="note-audit">{("Modificado: "+esc(h.get("modified"))) if h.get("modified") else ""}</small></li>'
        for h in reversed(history)
    ) or '<li class="empty">Sin seguimientos registrados.</li>'
    assets=wiki_links_html(t)+links_html(t.get('links',[]))+attachments_html(t.get('attachments',[]))
    project_html=f'<a href="/project?id={esc(p.get("id"))}">{esc(p.get("name"))}</a>' if p else 'Sin proyecto'
    assets_html=f'<div class="current-assets"><strong>Archivos y enlaces</strong>{assets}</div>' if assets else ''
    body=f'''<div class="page-head"><div><h1>{esc(t.get('title'))}</h1><p>{esc(t.get('description') or 'Sin descripción')}</p></div><div><a class="btn" href="/task/edit?id={esc(tid)}">Editar</a> <form class="inline" method="post" action="/task/delete" onsubmit="return confirm('¿Eliminar esta tarea?')"><input type="hidden" name="id" value="{esc(tid)}"><button class="btn danger">Eliminar</button></form></div></div><div class="detail-grid"><section class="info-card"><h2>Información</h2><dl><dt>Proyecto</dt><dd>{project_html}</dd><dt>Estado</dt><dd>{badge(t.get('status'))}</dd><dt>Prioridad</dt><dd>{badge(t.get('priority'),'priority')}</dd><dt>Responsables</dt><dd>{responsibles_badges(t)}</dd><dt>Inicio</dt><dd>{esc(t.get('start_date') or '—')}</dd><dt>Fecha límite</dt><dd>{esc(t.get('due_date') or '—')}</dd></dl>{assets_html}</section><section class="info-card"><h2>Añadir seguimiento</h2><form method="post" action="/task/note" enctype="multipart/form-data"><input type="hidden" name="id" value="{esc(tid)}"><textarea required name="text" rows="5" placeholder="Avance, incidencia, cambio, decisión o resultado..."></textarea><label>Enlaces relacionados <span class="field-help">Uno por línea. Formato opcional: Nombre | URL</span><textarea name="links" rows="3" placeholder="Documento SharePoint | https://..."></textarea></label><label>Adjuntar archivos<input type="file" name="files" multiple></label><button class="btn primary">Guardar seguimiento</button></form></section></div><section><h2>Historial de seguimiento de la tarea</h2><ul class="timeline">{hist}</ul></section>'''
    return layout(t.get('title') or 'Tarea',body,'tasks')

def task_list(query):
    ps=projects(); ts=tasks(); status=query.get('status',[''])[0]; project=query.get('project',[''])[0]; responsible=query.get('responsible',[''])[0]
    if status: ts=[t for t in ts if t.get('status')==status]
    if project: ts=[t for t in ts if t.get('project_id')==project]
    if responsible: ts=[t for t in ts if responsible in selected_responsibles(t)]
    rows=''.join(task_row(t,ps) for t in sorted(ts,key=lambda x:(x.get('due_date') or '9999',x.get('title','')))) or '<tr><td colspan="6" class="empty">No hay tareas que mostrar.</td></tr>'
    popts=''.join(f'<option value="{esc(p["id"])}" {"selected" if project==p["id"] else ""}>{esc(p["name"])}</option>' for p in ps)
    sopts=''.join(f'<option {"selected" if status==s else ""}>{s}</option>' for s in ['Pendiente','En curso','Bloqueada','Completada','Cancelada'])
    ropts=''.join(f'<option value="{esc(r["id"])}" {"selected" if responsible==r["id"] else ""}>{esc(r["name"])}</option>' for r in sorted(responsibles(),key=lambda x:x.get('name','').lower()))
    body=f'''<div class="page-head"><div><h1>Tareas</h1><p>Listado general de tareas y vencimientos.</p></div><a class="btn primary" href="/task/new">Nueva tarea</a></div><form class="filters"><select name="project"><option value="">Todos los proyectos</option>{popts}</select><select name="status"><option value="">Todos los estados</option>{sopts}</select><select name="responsible"><option value="">Todos los responsables</option>{ropts}</select><button class="btn">Filtrar</button><a class="btn" href="/tasks">Limpiar</a></form><div class="table-wrap"><table><thead><tr><th>Tarea</th><th>Proyecto</th><th>Responsables</th><th>Estado</th><th>Prioridad</th><th>Vence</th></tr></thead><tbody>{rows}</tbody></table></div>'''
    return layout('Tareas',body,'tasks')

def task_form(t=None, selected_project=''):
    t=t or {}; edit=bool(t); ps=projects(); statuses=['Pendiente','En curso','Bloqueada','Completada','Cancelada']; priorities=['Baja','Media','Alta','Crítica']
    opts=lambda values,current: ''.join(f'<option {"selected" if v==current else ""}>{v}</option>' for v in values)
    current=t.get('project_id',selected_project); popts=''.join(f'<option value="{esc(p["id"])}" {"selected" if current==p["id"] else ""}>{esc(p["name"])}</option>' for p in ps)
    existing_assets=(links_html(t.get('links',[]))+attachments_html(t.get('attachments',[]))) if edit else ''
    body=f'''<div class="page-head"><div><h1>{'Editar' if edit else 'Nueva'} tarea</h1><p>Define el trabajo, su prioridad y fecha límite.</p></div></div><form class="form-card" method="post" action="/task/save" enctype="multipart/form-data"><input type="hidden" name="id" value="{esc(t.get('id',''))}"><label class="wide">Título<input required name="title" value="{esc(t.get('title',''))}"></label><label class="wide">Descripción<textarea name="description" rows="4">{esc(t.get('description',''))}</textarea></label><label>Proyecto<select name="project_id"><option value="">Sin proyecto</option>{popts}</select></label><label class="wide">Documentación Wiki relacionada <span class="field-help">Puedes seleccionar una o varias páginas</span><select name="wiki_pages" multiple size="6">{wiki_page_options(selected_wiki_pages(t))}</select></label><label class="wide">Responsables <span class="field-help">Puedes seleccionar uno o varios</span><select name="responsible_ids" multiple size="5">{responsible_options(selected_responsibles(t))}</select></label><label>Estado<select name="status">{opts(statuses,t.get('status','Pendiente'))}</select></label><label>Prioridad<select name="priority">{opts(priorities,t.get('priority','Media'))}</select></label><label>Fecha de inicio<input type="date" name="start_date" value="{esc(t.get('start_date',''))}"></label><label>Fecha límite<input type="date" name="due_date" value="{esc(t.get('due_date',''))}"></label><label class="wide">Comentarios de seguimiento<textarea name="comments" rows="5">{esc(t.get('comments',''))}</textarea></label><label class="wide">Enlaces relacionados <span class="field-help">Uno por línea. Formato opcional: Nombre | URL</span><textarea name="links" rows="4" placeholder="Panel SIEM | https://...">{esc(chr(10).join((x.get('title',x.get('url',''))+' | '+x.get('url','')) for x in t.get('links',[])))}</textarea></label><label class="wide">Adjuntar archivos<input type="file" name="files" multiple></label>{f'<div class="wide current-assets"><strong>Archivos y enlaces actuales</strong>{existing_assets}<label class="remove-assets"><input type="checkbox" name="replace_assets" value="1"> Sustituir los adjuntos actuales por los nuevos</label></div>' if edit and existing_assets else ''}<div class="form-actions wide"><button class="btn primary">Guardar tarea</button><a class="btn" href="/tasks">Cancelar</a>{f'<button form="delete-task" type="button" class="btn danger" onclick="document.getElementById(\'delete-task\').submit()">Eliminar</button>' if edit else ''}</div></form>{f'<form id="delete-task" method="post" action="/task/delete" onsubmit="return confirm(\'¿Eliminar esta tarea?\')"><input type="hidden" name="id" value="{esc(t.get("id"))}"></form>' if edit else ''}'''
    return layout('Tarea',body,'tasks')

def responsibles_page():
    people=sorted(responsibles(),key=lambda x:x.get('name','').lower())
    ps=projects(); ts=tasks(); row_parts=[]
    for r in people:
        rid=r.get('id','')
        project_count=sum(rid in selected_responsibles(p) for p in ps)
        task_count=sum(rid in selected_responsibles(t) for t in ts)
        row_parts.append(f'<tr><td><strong>{esc(r.get("name"))}</strong><small>{esc(r.get("email",""))}</small></td><td>{project_count}</td><td>{task_count}</td><td><a class="btn" href="/responsible/edit?id={esc(rid)}">Editar</a> <form class="inline" method="post" action="/responsible/delete" onsubmit="return confirm(&quot;¿Eliminar este responsable? Se quitará de proyectos y tareas.&quot;)"><input type="hidden" name="id" value="{esc(rid)}"><button class="btn danger">Eliminar</button></form></td></tr>')
    rows=''.join(row_parts) or '<tr><td colspan="4" class="empty">No hay responsables creados.</td></tr>'
    body=f'<div class="page-head"><div><h1>Responsables</h1><p>Lista reutilizable para asignar una o varias personas a proyectos y tareas.</p></div><a class="btn primary" href="/responsible/new">Nuevo responsable</a></div><div class="table-wrap"><table><thead><tr><th>Responsable</th><th>Proyectos</th><th>Tareas</th><th>Acciones</th></tr></thead><tbody>{rows}</tbody></table></div>'
    return layout('Responsables',body,'responsibles')

def responsible_form(person=None):
    person=person or {}; edit=bool(person)
    body=f'<div class="page-head"><div><h1>{"Editar" if edit else "Nuevo"} responsable</h1><p>Datos básicos de la persona responsable.</p></div></div><form class="form-card" method="post" action="/responsible/save"><input type="hidden" name="id" value="{esc(person.get("id",""))}"><label class="wide">Nombre<input required name="name" value="{esc(person.get("name",""))}"></label><label class="wide">Correo electrónico<input type="email" name="email" value="{esc(person.get("email",""))}"></label><div class="form-actions wide"><button class="btn primary">Guardar responsable</button><a class="btn" href="/responsibles">Cancelar</a></div></form>'
    return layout('Responsable',body,'responsibles')

def calendar_view():
    ps=projects(); ts=[t for t in tasks() if t.get('due_date')]
    groups={}
    for t in ts: groups.setdefault(t['due_date'],[]).append(t)
    months={}
    for day,items in groups.items(): months.setdefault(day[:7],[]).append((day,items))
    content=''
    for month in sorted(months):
        content+=f'<section><h2>{esc(month)}</h2><div class="calendar-list">'
        for day,items in sorted(months[month]):
            content+=f'<div class="calendar-day"><strong>{esc(day)}</strong><div>' + ''.join(f'<a href="/task?id={esc(t["id"])}">{esc(t["title"])} {badge(t.get("status"))}</a>' for t in items) + '</div></div>'
        content+='</div></section>'
    if not content: content='<p class="empty">No hay tareas con fecha límite.</p>'
    return layout('Calendario',f'<div class="page-head"><div><h1>Calendario</h1><p>Fechas límite agrupadas por mes.</p></div></div>{content}','calendar')



def corporate_logo_path():
    """Locate imagenes/logo/logo.png from the application root."""
    source = Path(__file__).resolve()
    for parent in source.parents:
        candidate = parent / "imagenes" / "logo" / "logo.png"
        if candidate.is_file():
            return candidate
        if (parent / "INICIAR.bat").exists() or (parent / "VERSION.txt").exists():
            (parent / "imagenes" / "logo").mkdir(parents=True, exist_ok=True)
            return None
    return None
def serve_corporate_logo(handler):
    path = corporate_logo_path()
    if path is None:
        handler.send_response(404)
        handler.end_headers()
        return
    data = path.read_bytes()
    handler.send_response(200)
    handler.send_header("Content-Type", "image/png")
    handler.send_header("Content-Length", str(len(data)))
    handler.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
    handler.end_headers()
    handler.wfile.write(data)

class Handler(BaseHTTPRequestHandler):
    def send_html(self, text, code=200):
        data=text.encode('utf-8'); self.send_response(code); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def redirect(self, url): self.send_response(303); self.send_header('Location',url); self.end_headers()
    def form(self):
        n=int(self.headers.get('Content-Length','0') or 0); raw=self.rfile.read(n)
        content_type=self.headers.get('Content-Type','')
        if content_type.startswith('multipart/form-data'):
            message=BytesParser(policy=email_policy).parsebytes((f'Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n').encode()+raw)
            fields={}; uploads=[]
            for part in message.iter_parts():
                name=part.get_param('name',header='content-disposition')
                filename=part.get_filename()
                payload=part.get_payload(decode=True) or b''
                if filename:
                    if payload: uploads.append(save_upload(filename,payload))
                elif name:
                    value=payload.decode(part.get_content_charset() or 'utf-8',errors='replace')
                    if name in fields:
                        fields[name]=fields[name]+[value] if isinstance(fields[name],list) else [fields[name],value]
                    else: fields[name]=value
            fields['_uploads']=uploads
            return fields
        parsed=parse_qs(raw.decode(errors='replace'))
        return {k:(v if len(v)>1 else v[0]) for k,v in parsed.items()}
    def do_GET(self):
        u=urlparse(self.path); q=parse_qs(u.query)
        if u.path in {"/logo.png", "/corporate-logo.png"}: return serve_corporate_logo(self)
        if u.path.startswith('/static/'):
            path=STATIC/u.path.split('/')[-1]
            if path.exists():
                data=path.read_bytes(); self.send_response(200); self.send_header('Content-Type','text/css' if path.suffix=='.css' else 'application/javascript'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        if u.path.startswith('/attachments/'):
            stored=Path(u.path.split('/')[-1]).name; path=ATTACHMENTS/stored
            if path.exists() and path.is_file():
                data=path.read_bytes(); ctype=mimetypes.guess_type(path.name)[0] or 'application/octet-stream'
                self.send_response(200); self.send_header('Content-Type',ctype); self.send_header('Content-Disposition',f'attachment; filename="{safe_filename(path.name.split("_",1)[-1])}"'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        routes={'/':dashboard,'/projects':lambda:project_list(q),'/tasks':lambda:task_list(q),'/responsibles':responsibles_page,'/calendar':calendar_view,'/project/new':project_form,'/task/new':lambda:task_form(selected_project=q.get('project_id',[''])[0]),'/responsible/new':responsible_form}
        if u.path in routes: self.send_html(routes[u.path]()); return
        if u.path=='/project': self.send_html(project_detail(q.get('id',[''])[0])); return
        if u.path=='/project/report': self.send_html(project_report(q.get('id',[''])[0])); return
        if u.path=='/task': self.send_html(task_detail(q.get('id',[''])[0])); return
        if u.path=='/project/note/edit': self.send_html(note_form('project',q.get('id',[''])[0],q.get('note_id',[''])[0])); return
        if u.path=='/task/note/edit': self.send_html(note_form('task',q.get('id',[''])[0],q.get('note_id',[''])[0])); return
        if u.path=='/project/edit':
            p=next((x for x in projects() if x['id']==q.get('id',[''])[0]),None); self.send_html(project_form(p)); return
        if u.path=='/task/edit':
            t=next((x for x in tasks() if x['id']==q.get('id',[''])[0]),None); self.send_html(task_form(t)); return
        if u.path=='/responsible/edit':
            r=next((x for x in responsibles() if x['id']==q.get('id',[''])[0]),None); self.send_html(responsible_form(r)); return
        self.send_html(layout('No encontrado','<h1>Página no encontrada</h1>'),404)
    def do_POST(self):
        f=self.form()
        if self.path=='/responsible/save':
            people=responsibles(); rid=str(f.get('id','') or uid('rsp')); old=next((x for x in people if x.get('id')==rid),{})
            person={**old,'id':rid,'name':str(f.get('name','')).strip(),'email':str(f.get('email','')).strip(),'created':old.get('created',now()),'updated':now()}
            people=[person if x.get('id')==rid else x for x in people] if old else people+[person]; write_json(RESPONSIBLES,people); self.redirect('/responsibles'); return
        if self.path=='/responsible/delete':
            rid=str(f.get('id','')); write_json(RESPONSIBLES,[r for r in responsibles() if r.get('id')!=rid])
            ps=projects(); ts=tasks()
            for item in ps+ts:
                ids=selected_responsibles(item); item['responsible_ids']=[x for x in ids if x!=rid]; item['owner']=''
            write_json(PROJECTS,ps); write_json(TASKS,ts); self.redirect('/responsibles'); return
        if self.path=='/project/save':
            ps=projects(); pid=f.get('id') or uid('prj'); old=next((x for x in ps if x['id']==pid),{})
            p={**old,'id':pid,'name':f.get('name','').strip(),'description':f.get('description','').strip(),'wiki_pages':field_values(f,'wiki_pages'),'responsible_ids':field_values(f,'responsible_ids'),'owner':'','status':f.get('status','Planificado'),'priority':f.get('priority','Media'),'progress':max(0,min(100,int(f.get('progress','0') or 0))),'start_date':f.get('start_date',''),'end_date':f.get('end_date',''),'history':old.get('history',[]),'created':old.get('created',now()),'updated':now()}
            ps=[p if x['id']==pid else x for x in ps] if old else ps+[p]; write_json(PROJECTS,ps); self.redirect('/project?id='+pid); return
        if self.path=='/project/delete':
            pid=f.get('id'); doomed_projects=[p for p in projects() if p['id']==pid]; doomed_tasks=[t for t in tasks() if t.get('project_id')==pid]
            for p in doomed_projects:
                for h in p.get('history',[]): delete_uploads(h.get('attachments',[]))
            for t in doomed_tasks:
                delete_uploads(t.get('attachments',[]))
                for h in t.get('history',[]): delete_uploads(h.get('attachments',[]))
            write_json(PROJECTS,[p for p in projects() if p['id']!=pid]); write_json(TASKS,[t for t in tasks() if t.get('project_id')!=pid]); self.redirect('/projects'); return
        if self.path=='/project/note':
            ps=projects(); pid=f.get('id'); text=f.get('text','').strip()
            for p in ps:
                if p['id']==pid and text: p.setdefault('history',[]).append({'id':uid('note'),'date':datetime.now().strftime('%Y-%m-%d %H:%M'),'text':text,'links':parse_links(f.get('links','')),'attachments':f.get('_uploads',[]),'created':now()}); p['updated']=now()
            write_json(PROJECTS,ps); self.redirect('/project?id='+pid); return
        if self.path=='/task/note':
            ts=tasks(); tid=f.get('id'); text=str(f.get('text','')).strip()
            for t in ts:
                if t.get('id')==tid and text:
                    t.setdefault('history',[]).append({'id':uid('note'),'date':datetime.now().strftime('%Y-%m-%d %H:%M'),'text':text,'links':parse_links(f.get('links','')),'attachments':f.get('_uploads',[]),'created':now()})
                    t['updated']=now()
            write_json(TASKS,ts); self.redirect('/task?id='+str(tid)); return
        if self.path in ('/project/note/save','/task/note/save'):
            kind='project' if self.path.startswith('/project') else 'task'
            path=PROJECTS if kind=='project' else TASKS
            collection=projects() if kind=='project' else tasks()
            parent_id=str(f.get('id','')); note_id=str(f.get('note_id',''))
            for item in collection:
                if item.get('id')!=parent_id: continue
                history=item.setdefault('history',[]); ensure_note_ids(history)
                for note in history:
                    if note.get('id')!=note_id: continue
                    old_attachments=note.get('attachments',[])
                    if f.get('remove_attachments')=='1':
                        delete_uploads(old_attachments); old_attachments=[]
                    value=str(f.get('date','')).strip().replace('T',' ')
                    note['date']=value or note.get('date') or datetime.now().strftime('%Y-%m-%d %H:%M')
                    note['text']=str(f.get('text','')).strip()
                    note['links']=parse_links(f.get('links',''))
                    note['attachments']=old_attachments+f.get('_uploads',[])
                    note['modified']=datetime.now().strftime('%Y-%m-%d %H:%M')
                    note.setdefault('created',now())
                    item['updated']=now()
                    break
            write_json(path,collection); self.redirect(f'/{kind}?id='+parent_id); return
        if self.path in ('/project/note/delete','/task/note/delete'):
            kind='project' if self.path.startswith('/project') else 'task'
            path=PROJECTS if kind=='project' else TASKS
            collection=projects() if kind=='project' else tasks()
            parent_id=str(f.get('id','')); note_id=str(f.get('note_id',''))
            for item in collection:
                if item.get('id')!=parent_id: continue
                history=item.setdefault('history',[]); ensure_note_ids(history)
                doomed=next((n for n in history if n.get('id')==note_id),None)
                if doomed: delete_uploads(doomed.get('attachments',[]))
                item['history']=[n for n in history if n.get('id')!=note_id]
                item['updated']=now()
            write_json(path,collection); self.redirect(f'/{kind}?id='+parent_id); return
        if self.path=='/task/save':
            ts=tasks(); tid=f.get('id') or uid('tsk'); old=next((x for x in ts if x['id']==tid),{})
            new_uploads=f.get('_uploads',[])
            if f.get('replace_assets')=='1':
                delete_uploads(old.get('attachments',[])); attachments=new_uploads
            else:
                attachments=old.get('attachments',[])+new_uploads
            t={**old,'id':tid,'title':f.get('title','').strip(),'description':f.get('description','').strip(),'project_id':f.get('project_id',''),'wiki_pages':field_values(f,'wiki_pages'),'responsible_ids':field_values(f,'responsible_ids'),'owner':'','status':f.get('status','Pendiente'),'priority':f.get('priority','Media'),'start_date':f.get('start_date',''),'due_date':f.get('due_date',''),'comments':f.get('comments','').strip(),'links':parse_links(f.get('links','')),'attachments':attachments,'history':old.get('history',[]),'created':old.get('created',now()),'updated':now()}
            ts=[t if x['id']==tid else x for x in ts] if old else ts+[t]; write_json(TASKS,ts); self.redirect('/task?id='+tid); return
        if self.path=='/task/delete':
            tid=f.get('id'); doomed=next((t for t in tasks() if t['id']==tid),None)
            if doomed:
                delete_uploads(doomed.get('attachments',[]))
                for h in doomed.get('history',[]): delete_uploads(h.get('attachments',[]))
            write_json(TASKS,[t for t in tasks() if t['id']!=tid]); self.redirect('/tasks'); return
        self.redirect('/')
    def log_message(self,*args): pass

if __name__=='__main__':
    port=int(os.environ.get('GESTOR_PORT','8080')); print(f'Gestor disponible en http://127.0.0.1:{port}'); ThreadingHTTPServer(('127.0.0.1',port),Handler).serve_forever()
