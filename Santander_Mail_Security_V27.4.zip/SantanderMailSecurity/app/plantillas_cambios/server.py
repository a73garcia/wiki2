from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path
from datetime import datetime
import os, json, html, uuid, re

BASE=Path(__file__).resolve().parent
ROOT=BASE.parent.parent
DATA=BASE/'data'; TEMPLATES=DATA/'templates.json'; CATEGORIES=DATA/'categories.json'
PORTAL_URL=os.environ.get('PORTAL_URL','http://127.0.0.1:8079')
WIKI_URL=os.environ.get('WIKI_URL','http://127.0.0.1:8080')
GESTOR_URL=os.environ.get('GESTOR_URL','http://127.0.0.1:8081')
BAU_URL=os.environ.get('BAU_URL','http://127.0.0.1:8082')
BITACORA_URL=os.environ.get('BITACORA_URL','http://127.0.0.1:8083')
BIBLIOTECA_URL=os.environ.get('BIBLIOTECA_URL','http://127.0.0.1:8084')
CAMBIOS_URL=os.environ.get('CAMBIOS_URL','http://127.0.0.1:8085')

def read(path,default):
    try:return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default
    except Exception:return default

def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True); tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(path)

def now(): return datetime.now().isoformat(timespec='seconds')
def esc(v): return html.escape(str(v or ''))

def plain_template(value):
    text=re.sub(r'<br\s*/?>', '\n', str(value or ''), flags=re.I)
    text=re.sub(r'</(?:div|p)>', '\n', text, flags=re.I)
    text=re.sub(r'<[^>]+>', '', text)
    return html.unescape(text).strip()

def safe_template_html(value):
    # El editor solo genera formato básico. Se eliminan scripts, eventos y
    # etiquetas ajenas a negrita, cursiva, subrayado, color y saltos.
    source=str(value or '')
    source=re.sub(r'(?is)<script.*?>.*?</script>', '', source)
    source=re.sub(r'(?is)<style.*?>.*?</style>', '', source)
    source=re.sub(r'\son\w+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)', '', source)
    allowed={'b','strong','i','em','u','br','div','p','span','font'}
    def clean_tag(match):
        closing=bool(match.group(1)); name=match.group(2).lower(); attrs=match.group(3) or ''
        if name not in allowed: return ''
        if closing: return f'</{name}>'
        if name=='br': return '<br>'
        if name in {'span','font'}:
            color=''
            m=re.search(r'(?:color\s*=\s*["\']?([^"\'\s>]+)|color\s*:\s*([^;"\']+))',attrs,re.I)
            if m:
                raw=(m.group(1) or m.group(2) or '').strip().lower()
                if raw in {'red','#ff0000','#ec0000','rgb(255, 0, 0)'}: color='#EC0000'
                elif raw in {'blue','#0000ff','#0067b1','rgb(0, 0, 255)'}: color='#0067B1'
            return f'<span style="color:{color}">' if color else '<span>'
        return f'<{name}>'
    return re.sub(r'<\s*(/?)\s*([a-zA-Z0-9]+)([^>]*)>',clean_tag,source)
def categories(): return [str(x).strip() for x in read(CATEGORIES,['CES','ProofPoint']) if str(x).strip()]
def templates(): return read(TEMPLATES,[])
def find_item(i): return next((x for x in templates() if str(x.get('id'))==str(i)),None)
def logo_path():
    p=ROOT/'imagenes'/'logo'/'logo.png'; return p if p.is_file() else None

CSS='''
:root{--red:#EC0000;--dark:#B30000;--soft:#FDECEC;--bg:#F7F7F7;--text:#242424;--muted:#666;--border:#D8D8D8;--font:"Santander Headline","Segoe UI",Arial,sans-serif}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:14px var(--font)}
header{min-height:68px;padding:10px 22px;background:#fff;border-bottom:4px solid var(--red);display:flex;justify-content:space-between;align-items:center;gap:16px}.brand{display:flex;align-items:center;gap:13px;font-size:20px;font-weight:600}.brand-logo{width:46px;height:46px;object-fit:contain}
.shell{display:grid;grid-template-columns:220px minmax(0,1fr);min-height:calc(100vh - 72px)}aside{background:#fff;border-right:1px solid var(--border);padding:18px 13px}nav a{display:block;padding:10px 12px;margin-bottom:5px;color:#3b3b3b;text-decoration:none;border-radius:6px}nav a:hover,nav a.active{background:var(--soft);color:var(--dark);border-left:4px solid var(--red);font-weight:700}
main{padding:24px;max-width:1450px;width:100%;margin:auto}h1,h2{color:var(--dark)}h1{margin-top:0}.card{background:#fff;border:1px solid var(--border);border-radius:10px;padding:18px;margin-bottom:16px}.toolbar,.actions{display:flex;gap:9px;flex-wrap:wrap;align-items:center;justify-content:space-between}.btn,button{display:inline-block;border:1px solid var(--red);border-radius:6px;padding:9px 13px;background:var(--red);color:#fff;text-decoration:none;cursor:pointer;font:inherit}.btn.secondary,button.secondary{background:#fff;color:var(--dark)}button.danger{background:#8A0000;border-color:#8A0000}
input,select,textarea{width:100%;padding:10px;border:1px solid #B8B8B8;border-radius:6px;font:inherit;background:#fff}textarea{min-height:260px;resize:vertical}label{display:block;font-weight:700;margin:12px 0 6px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px}.item h3{margin:0 0 8px}.meta{color:var(--muted);font-size:12px}.template-content{white-space:pre-wrap;background:#FAFAFA;border:1px solid #E2E2E2;border-radius:7px;padding:14px;line-height:1.55}.observation{border-left:4px solid var(--red);background:#FAFAFA;padding:12px;margin:10px 0;border-radius:5px}.observation p{white-space:pre-wrap}.category-row{display:grid;grid-template-columns:minmax(0,1fr) auto auto;gap:8px;margin:8px 0}.search{display:grid;grid-template-columns:minmax(220px,1fr) 220px auto;gap:8px}.empty{padding:28px;text-align:center;color:var(--muted)}form{margin:0}
.rich-toolbar{display:flex;gap:6px;flex-wrap:wrap;align-items:center;padding:8px;background:#F4F4F4;border:1px solid #B8B8B8;border-bottom:0;border-radius:6px 6px 0 0}
.rich-toolbar button{width:auto;min-width:38px;padding:7px 10px;background:#fff;color:#222;border-color:#B8B8B8;font-weight:700}
.rich-toolbar button:hover{background:var(--soft);border-color:var(--red)}
.rich-toolbar .red{color:#EC0000}.rich-toolbar .blue{color:#0067B1}
.rich-editor{min-height:280px;padding:12px;border:1px solid #B8B8B8;border-radius:0 0 6px 6px;background:#fff;line-height:1.55;white-space:pre-wrap;overflow-wrap:anywhere;outline:none}
.rich-editor:focus{border-color:var(--red);box-shadow:0 0 0 3px rgba(236,0,0,.12)}
.template-content{white-space:pre-wrap}
@media(max-width:760px){.shell{grid-template-columns:1fr}aside{display:none}main{padding:14px}.search{grid-template-columns:1fr}.brand-logo{width:38px;height:38px}}
'''

def layout(body):
    links=[('Inicio',PORTAL_URL),('Wiki',WIKI_URL),('Proyectos y tareas',GESTOR_URL),('BAU',BAU_URL),('Bitácora',BITACORA_URL),('Biblioteca',BIBLIOTECA_URL),('Plantillas Cambios',CAMBIOS_URL)]
    nav=''.join(f'<a class="{"active" if n=="Plantillas Cambios" else ""}" href="{esc(u)}">{esc(n)}</a>' for n,u in links)
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Plantillas Cambios</title><style>{CSS}</style>
<style>
/* V27.3 · Logotipo adaptable al espacio disponible */
header{{
  min-height:72px!important;
  height:auto!important;
  overflow:visible!important;
}}
.brand{{
  min-height:56px!important;
  max-width:min(70vw,760px)!important;
  display:flex!important;
  align-items:center!important;
  gap:14px!important;
  overflow:visible!important;
}}
.brand::before{{
  display:none!important;
  content:none!important;
  background-image:none!important;
}}
.brand .brand-logo{{
  display:block!important;
  width:auto!important;
  height:auto!important;
  min-width:0!important;
  min-height:0!important;
  max-width:210px!important;
  max-height:56px!important;
  flex:0 1 auto!important;
  object-fit:contain!important;
  object-position:left center!important;
  background:transparent!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
}}
.brand>span{{
  display:block!important;
  min-width:0!important;
  overflow:hidden!important;
  text-overflow:ellipsis!important;
}}
@media(max-width:760px){{
  header{{min-height:64px!important;padding:8px 14px!important}}
  .brand{{min-height:46px!important;gap:10px!important;max-width:76vw!important}}
  .brand .brand-logo{{
    width:auto!important;
    height:auto!important;
    max-width:145px!important;
    max-height:46px!important;
  }}
}}
@media(max-width:480px){{
  .brand .brand-logo{{max-width:105px!important;max-height:42px!important}}
  .brand>span{{font-size:15px!important}}
}}
</style>

<style>
/* V27.4 · Vista compacta de Plantillas Cambios */
header{{
  min-height:58px!important;
  padding:6px 16px!important;
}}
.brand{{
  min-height:44px!important;
  gap:10px!important;
}}
.brand .brand-logo{{
  max-width:150px!important;
  max-height:44px!important;
}}
main{{
  padding:14px 18px!important;
}}
.compact-page-head{{
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:12px;
  flex-wrap:wrap;
  margin-bottom:10px;
}}
.compact-page-head h1{{
  margin:0!important;
}}
.compact-page-head .actions{{
  justify-content:flex-end;
}}
.search-card{{
  padding:12px!important;
  margin-bottom:12px!important;
}}
.grid{{
  gap:10px!important;
}}
.item{{
  padding:13px 15px!important;
  margin-bottom:0!important;
}}
.item h3{{
  margin:4px 0 10px!important;
  font-size:17px;
}}
.item .meta{{
  margin-bottom:2px;
}}
.item .actions{{
  justify-content:flex-start;
}}
@media(max-width:760px){{
  header{{min-height:54px!important;padding:5px 10px!important}}
  .brand{{min-height:40px!important}}
  .brand .brand-logo{{max-width:105px!important;max-height:40px!important}}
  main{{padding:10px!important}}
}}
</style>
</head><body><header><div class="brand"><img class="brand-logo" src="/logo.png" alt="Logo" onerror="this.style.display='none'"><span>Santander Mail Security · Plantillas Cambios</span></div><div class="actions"><a class="btn secondary" href="/">↑ Nivel superior</a><a class="btn secondary" href="{PORTAL_URL}">Portal</a></div></header><div class="shell"><aside><nav>{nav}</nav></aside><main>{body}</main></div>
<script>
function formatTemplate(command,value){{
  const editor=document.getElementById('templateEditor');
  if(!editor)return;
  editor.focus();
  document.execCommand(command,false,value||null);
  syncTemplate();
}}
function insertTemplateTab(){{
  const editor=document.getElementById('templateEditor');
  if(!editor)return;
  editor.focus();
  document.execCommand('insertText',false,'    ');
  syncTemplate();
}}
function syncTemplate(){{
  const editor=document.getElementById('templateEditor');
  const field=document.getElementById('templateField');
  if(editor&&field)field.value=editor.innerHTML;
}}
document.addEventListener('DOMContentLoaded',function(){{
  const editor=document.getElementById('templateEditor');
  const form=document.getElementById('templateForm');
  if(editor){{
    editor.addEventListener('input',syncTemplate);
    editor.addEventListener('keydown',function(event){{
      if(event.key==='Tab'){{event.preventDefault();insertTemplateTab();}}
    }});
  }}
  if(form)form.addEventListener('submit',function(event){{
    syncTemplate();
    if(!plainText(editor.innerHTML).trim()){{event.preventDefault();alert('El campo Plantilla es obligatorio.');editor.focus();}}
  }});
}});
function plainText(value){{const d=document.createElement('div');d.innerHTML=value||'';return d.textContent||d.innerText||'';}}
</script></body></html>'''

def home(q='',category=''):
    rows=templates()
    term=q.strip().casefold()
    if category:
        rows=[x for x in rows if x.get('category')==category]
    if term:
        rows=[
            x for x in rows
            if term in (' '.join([
                str(x.get('title','')),
                str(x.get('category','')),
                str(x.get('template','')),
                json.dumps(x.get('observations',[]),ensure_ascii=False)
            ])).casefold()
        ]
    opts='<option value="">Todas las categorías</option>'+''.join(
        f'<option {"selected" if c==category else ""}>{esc(c)}</option>'
        for c in categories()
    )
    cards=[]
    for x in sorted(rows,key=lambda y:y.get('updated_at',''),reverse=True):
        fecha=esc(x.get('updated_at','').replace('T',' '))
        categoria=esc(x.get('category'))
        titulo=esc(x.get('title'))
        cards.append(
            f"""<article class="card item">
            <div class="meta">{categoria} · {fecha}</div>
            <h3>{titulo}</h3>
            <div class="actions">
              <a class="btn" href="/view?id={esc(x.get('id'))}">Abrir</a>
              <a class="btn secondary" href="/edit?id={esc(x.get('id'))}">Editar</a>
            </div>
            </article>"""
        )
    return layout(
        f"""<div class="compact-page-head">
        <h1>Plantillas Cambios</h1>
        <div class="actions">
          <a class="btn" href="/new">+ Nueva plantilla</a>
          <a class="btn secondary" href="/categories">Categorías</a>
        </div>
        </div>
        <section class="card search-card">
          <form class="search" method="get">
            <input name="q" value="{esc(q)}" placeholder="Buscar por categoría, fecha o nombre">
            <select name="category">{opts}</select>
            <button>Buscar</button>
          </form>
        </section>
        <section class="grid">
          {''.join(cards) if cards else '<div class="card empty">No hay plantillas que mostrar.</div>'}
        </section>"""
    )

def form_page(item=None,error=''):
    item=item or {}
    opts=''.join(f'<option {"selected" if c==item.get("category") else ""}>{esc(c)}</option>' for c in categories())
    editor_value=safe_template_html(item.get('template',''))
    return layout(f"""<h1>{'Editar plantilla' if item.get('id') else 'Nueva plantilla'}</h1>{f'<div class="card">{esc(error)}</div>' if error else ''}
<section class="card"><form id="templateForm" method="post" action="/save">
<input type="hidden" name="id" value="{esc(item.get('id'))}">
<label>Fecha</label><input value="{esc((item.get('updated_at') or now()).replace('T',' '))}" readonly>
<label>Categoría</label><select name="category" required>{opts}</select>
<label>Título</label><input name="title" value="{esc(item.get('title'))}" required maxlength="240">
<label>Plantilla</label>
<div class="rich-toolbar" role="toolbar" aria-label="Formato de plantilla">
<button type="button" title="Negrita" onclick="formatTemplate('bold')"><strong>N</strong></button>
<button type="button" title="Cursiva" onclick="formatTemplate('italic')"><em>C</em></button>
<button type="button" title="Subrayado" onclick="formatTemplate('underline')"><u>S</u></button>
<button type="button" class="blue" title="Texto azul" onclick="formatTemplate('foreColor','#0067B1')">Azul</button>
<button type="button" class="red" title="Texto rojo" onclick="formatTemplate('foreColor','#EC0000')">Rojo</button>
<button type="button" title="Insertar tabulación" onclick="insertTemplateTab()">Tab ↹</button>
</div>
<div id="templateEditor" class="rich-editor" contenteditable="true">{editor_value}</div>
<textarea id="templateField" name="template" hidden>{esc(item.get('template'))}</textarea>
<div class="actions"><button>Guardar</button><a class="btn secondary" href="/">Cancelar</a></div>
</form></section>""")

def view_page(item):
    obs=[]
    for o in sorted(item.get('observations',[]),key=lambda x:x.get('updated_at',''),reverse=True):
        obs.append(f'''<div class="observation"><div class="meta">Modificada {esc(o.get('updated_at','').replace('T',' '))}</div><p>{esc(o.get('text'))}</p><div class="actions"><a class="btn secondary" href="/observation/edit?template_id={esc(item['id'])}&id={esc(o.get('id'))}">Editar</a><form method="post" action="/observation/delete" onsubmit="return confirm('¿Eliminar observación?')"><input type="hidden" name="template_id" value="{esc(item['id'])}"><input type="hidden" name="id" value="{esc(o.get('id'))}"><button class="danger">Eliminar</button></form></div></div>''')
    return layout(f'''<div class="toolbar"><div><div class="meta">{esc(item.get('category'))} · Creada {esc(item.get('created_at','').replace('T',' '))} · Modificada {esc(item.get('updated_at','').replace('T',' '))}</div><h1>{esc(item.get('title'))}</h1></div><div class="actions"><a class="btn secondary" href="/edit?id={esc(item['id'])}">Editar</a><form method="post" action="/delete" onsubmit="return confirm('¿Eliminar esta plantilla?')"><input type="hidden" name="id" value="{esc(item['id'])}"><button class="danger">Eliminar</button></form></div></div><section class="card"><h2>Plantilla</h2><div class="template-content">{safe_template_html(item.get('template'))}</div></section><section class="card"><h2>Observaciones</h2><form method="post" action="/observation/save"><input type="hidden" name="template_id" value="{esc(item['id'])}"><textarea name="text" style="min-height:100px" placeholder="Añadir observación" required></textarea><button>Añadir observación</button></form>{''.join(obs) if obs else '<p class="empty">Sin observaciones.</p>'}</section>''')

def categories_page():
    rows=''.join(f'''<form class="category-row" method="post" action="/category/save"><input type="hidden" name="old" value="{esc(c)}"><input name="name" value="{esc(c)}" required><button>Guardar</button><button class="danger" formaction="/category/delete" onclick="return confirm('¿Eliminar categoría?')">Eliminar</button></form>''' for c in categories())
    return layout(f'''<h1>Categorías</h1><section class="card"><h2>Añadir categoría</h2><form class="category-row" method="post" action="/category/save"><input type="hidden" name="old"><input name="name" placeholder="Nueva categoría" required><button>Añadir</button><span></span></form></section><section class="card"><h2>Categorías existentes</h2>{rows}</section>''')

def observation_form(item,obs):
    return layout(f'''<h1>Editar observación</h1><section class="card"><form method="post" action="/observation/save"><input type="hidden" name="template_id" value="{esc(item['id'])}"><input type="hidden" name="id" value="{esc(obs.get('id'))}"><textarea name="text" required>{esc(obs.get('text'))}</textarea><div class="actions"><button>Guardar</button><a class="btn secondary" href="/view?id={esc(item['id'])}">Cancelar</a></div></form></section>''')

class Handler(BaseHTTPRequestHandler):
    def send_html(self,text,status=200):
        data=text.encode('utf-8'); self.send_response(status); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def redirect(self,url): self.send_response(303); self.send_header('Location',url); self.end_headers()
    def params(self):
        n=int(self.headers.get('Content-Length','0') or 0); return {k:v[-1] for k,v in parse_qs(self.rfile.read(n).decode('utf-8'),keep_blank_values=True).items()}
    def do_GET(self):
        u=urlparse(self.path); q=parse_qs(u.query)
        if u.path=='/logo.png':
            p=logo_path()
            if not p: self.send_response(404); self.end_headers(); return
            data=p.read_bytes(); self.send_response(200); self.send_header('Content-Type','image/png'); self.send_header('Cache-Control','no-cache, no-store, must-revalidate'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        if u.path=='/': return self.send_html(home(q.get('q',[''])[0],q.get('category',[''])[0]))
        if u.path=='/new': return self.send_html(form_page())
        if u.path=='/edit':
            item=find_item(q.get('id',[''])[0]); return self.send_html(form_page(item) if item else layout('<h1>No encontrada</h1>'),200 if item else 404)
        if u.path=='/view':
            item=find_item(q.get('id',[''])[0]); return self.send_html(view_page(item) if item else layout('<h1>No encontrada</h1>'),200 if item else 404)
        if u.path=='/categories': return self.send_html(categories_page())
        if u.path=='/observation/edit':
            item=find_item(q.get('template_id',[''])[0]); oid=q.get('id',[''])[0]; obs=next((o for o in item.get('observations',[]) if str(o.get('id'))==oid),None) if item else None
            return self.send_html(observation_form(item,obs) if item and obs else layout('<h1>No encontrada</h1>'),200 if item and obs else 404)
        self.send_html(layout('<h1>Página no encontrada</h1>'),404)
    def do_POST(self):
        u=urlparse(self.path); p=self.params()
        if u.path=='/save':
            rows=templates(); item_id=p.get('id','').strip(); current=find_item(item_id) if item_id else None; stamp=now(); record=current or {'id':uuid.uuid4().hex,'created_at':stamp,'observations':[]}
            record.update({'category':p.get('category','').strip(),'title':p.get('title','').strip(),'template':p.get('template',''),'updated_at':stamp})
            if not record['category'] or not record['title']: return self.send_html(form_page(record,'Categoría y título son obligatorios.'),400)
            rows=[record if str(x.get('id'))==str(record['id']) else x for x in rows] if current else rows+[record]; write(TEMPLATES,rows); return self.redirect(f'/view?id={record["id"]}')
        if u.path=='/delete': write(TEMPLATES,[x for x in templates() if str(x.get('id'))!=p.get('id','')]); return self.redirect('/')
        if u.path=='/observation/save':
            rows=templates(); item=find_item(p.get('template_id','')); oid=p.get('id','').strip(); stamp=now()
            if not item:return self.redirect('/')
            observations=item.setdefault('observations',[]); existing=next((o for o in observations if str(o.get('id'))==oid),None) if oid else None
            if existing: existing.update({'text':p.get('text','').strip(),'updated_at':stamp})
            else: observations.append({'id':uuid.uuid4().hex,'text':p.get('text','').strip(),'created_at':stamp,'updated_at':stamp})
            item['updated_at']=stamp; write(TEMPLATES,rows); return self.redirect(f'/view?id={item["id"]}')
        if u.path=='/observation/delete':
            rows=templates(); item=find_item(p.get('template_id',''))
            if item: item['observations']=[o for o in item.get('observations',[]) if str(o.get('id'))!=p.get('id','')]; item['updated_at']=now(); write(TEMPLATES,rows); return self.redirect(f'/view?id={item["id"]}')
            return self.redirect('/')
        if u.path=='/category/save':
            old=p.get('old','').strip(); name=p.get('name','').strip(); cats=categories()
            if name:
                if old:
                    cats=[name if c==old else c for c in cats]; rows=templates()
                    for x in rows:
                        if x.get('category')==old: x['category']=name; x['updated_at']=now()
                    write(TEMPLATES,rows)
                elif name not in cats: cats.append(name)
                write(CATEGORIES,list(dict.fromkeys(cats)))
            return self.redirect('/categories')
        if u.path=='/category/delete':
            old=p.get('old','').strip()
            if not any(x.get('category')==old for x in templates()): write(CATEGORIES,[c for c in categories() if c!=old])
            return self.redirect('/categories')
        self.send_html(layout('<h1>Acción no válida</h1>'),404)
    def log_message(self,*args): pass

if __name__=='__main__':
    DATA.mkdir(parents=True,exist_ok=True)
    if not CATEGORIES.exists(): write(CATEGORIES,['CES','ProofPoint'])
    if not TEMPLATES.exists(): write(TEMPLATES,[])
    ThreadingHTTPServer(('127.0.0.1',int(os.environ.get('CAMBIOS_PORT','8085'))),Handler).serve_forever()
