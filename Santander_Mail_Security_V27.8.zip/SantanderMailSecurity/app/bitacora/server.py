from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, quote
from pathlib import Path
from datetime import datetime
import os, json, html, re, uuid, mimetypes

CORPORATE_THEME_CSS = r""":root {
  --santander-red:#EC0000;
  --santander-red-dark:#C00000;
  --santander-red-deep:#990000;
  --santander-red-soft:#FDECEC;
  --santander-coral:#FF5A5F;
  --santander-orange:#F57C00;
  --santander-black:#111111;
  --santander-text:#2D2D2D;
  --santander-grey-700:#5B5B5B;
  --santander-grey-500:#8A8A8A;
  --santander-grey-300:#C9C9C9;
  --santander-grey-200:#E5E5E5;
  --santander-grey-100:#F2F2F2;
  --santander-bg:#F7F7F7;
  --santander-white:#FFFFFF;
  --brand-font:"Santander Headline","Segoe UI",Arial,sans-serif;
  --body-font:"Santander Headline","Segoe UI",Arial,sans-serif;
}
*{box-sizing:border-box}
html,body{font-family:var(--body-font)!important}
body{background:var(--santander-bg)!important;color:var(--santander-text)!important}
header{
  background:linear-gradient(105deg,var(--santander-red-dark),var(--santander-red))!important;
  color:#fff!important;border-bottom:0!important;box-shadow:0 3px 12px rgba(80,0,0,.18)!important;
}
.brand{font-family:var(--brand-font)!important;font-weight:600!important;letter-spacing:.1px!important;display:flex!important;align-items:center!important;gap:12px!important}
.brand::before{
  content:"";display:inline-block;width:36px;height:34px;flex:0 0 36px;
  background-image:url("/corporate-logo.png");
  background-size:contain;background-position:center;background-repeat:no-repeat;
  filter:brightness(0) invert(1);
}
.shell aside,aside{background:#fff!important;border-right:1px solid var(--santander-grey-200)!important}
aside nav a,nav a{color:#3c3c3c!important;border-radius:6px!important;transition:.15s ease!important}
aside nav a:hover,nav a:hover{background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important}
aside nav a.active,nav a.active{
  background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important;
  border-left:4px solid var(--santander-red)!important;font-weight:700!important;
}
main h1,main h2,.page-title{font-family:var(--brand-font)!important;color:var(--santander-red-dark)!important}
main h3{font-family:var(--brand-font)!important;color:var(--santander-black)!important}
a{color:var(--santander-red-dark)}
a:hover{color:var(--santander-red)}
.btn,.button,button,input[type=submit],input[type=button]{
  font-family:var(--body-font)!important;border-radius:6px!important;box-shadow:none!important;
}
.btn.primary,.btn-primary,.button-primary,button.primary,input[type=submit]{
  background:var(--santander-red)!important;border-color:var(--santander-red)!important;color:#fff!important;
}
.btn.primary:hover,.btn-primary:hover,button.primary:hover,input[type=submit]:hover{
  background:var(--santander-red-dark)!important;border-color:var(--santander-red-dark)!important;
}
.btn:not(.primary),button:not(.primary){
  background:#fff!important;border-color:var(--santander-grey-300)!important;color:var(--santander-text)!important;
}
.card,.panel,.widget,.stat,.tile,.project-card,.task-card,.wiki-card,.bau-card{
  background:#fff!important;border:1px solid var(--santander-grey-200)!important;
  border-radius:10px!important;box-shadow:0 2px 8px rgba(0,0,0,.045)!important;
}
table{background:#fff!important;border-color:var(--santander-grey-200)!important}
thead th,table th{background:var(--santander-red-dark)!important;color:#fff!important;border-color:var(--santander-red-dark)!important}
tbody tr:nth-child(even){background:#FAFAFA!important}
input,select,textarea{
  font-family:var(--body-font)!important;border:1px solid var(--santander-grey-300)!important;border-radius:6px!important;
}
input:focus,select:focus,textarea:focus{
  border-color:var(--santander-red)!important;outline:0!important;box-shadow:0 0 0 3px rgba(236,0,0,.12)!important;
}
.badge,.chip,.tag{border-radius:999px!important}
.badge.en-curso,.badge.alta,.badge.critica,.badge.crítica{background:var(--santander-red-soft)!important;color:var(--santander-red-dark)!important}
.notice,.alert,.callout{border-left:6px solid var(--santander-red)!important;background:#fff!important}
pre,code,.code-block{background:#F2F2F2!important;border-color:#D5D5D5!important}
footer{border-top:1px solid var(--santander-grey-200)!important;color:var(--santander-grey-700)!important}
@media print {
  header,aside,.header-actions,.actions,.toolbar,footer{display:none!important}
  body,main{background:#fff!important;color:#111!important}
  main{width:100%!important;max-width:none!important;margin:0!important;padding:0!important}
  h1,h2{color:var(--santander-red-dark)!important}
  table th{background:var(--santander-red-dark)!important;color:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .notice,.alert,.callout{border-left-color:var(--santander-red)!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
}
/* V25.2 — Cabecera corporativa: símbolo rojo íntegro sobre fondo blanco */
header{
  min-height:68px!important;
  height:auto!important;
  padding:10px 22px!important;
  background:#FFFFFF!important;
  color:#222222!important;
  border-bottom:4px solid #EC0000!important;
  box-shadow:0 2px 10px rgba(0,0,0,.08)!important;
  overflow:visible!important;
}
.brand{
  min-width:0!important;
  color:#222222!important;
  font-family:var(--brand-font,"Santander Headline","Segoe UI",Arial,sans-serif)!important;
  font-size:20px!important;
  line-height:1.15!important;
  font-weight:600!important;
  display:flex!important;
  align-items:center!important;
  gap:13px!important;
  white-space:nowrap!important;
  overflow:visible!important;
}
.brand::before{
  content:""!important;
  display:block!important;
  width:46px!important;
  height:46px!important;
  min-width:46px!important;
  max-width:46px!important;
  flex:0 0 46px!important;
  background-color:#FFFFFF!important;
  background-repeat:no-repeat!important;
  background-position:center!important;
  background-size:contain!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
}
@media(max-width:700px){
  header{min-height:60px!important;padding:8px 14px!important}
  .brand{font-size:17px!important;gap:10px!important}
  .brand::before{width:38px!important;height:38px!important;min-width:38px!important;max-width:38px!important;flex-basis:38px!important}
}

/* V25.3 — Auditoría de legibilidad y contraste */
:root{
  --accessible-text:#202124;
  --accessible-muted:#5F6368;
  --accessible-border:#AEB4BA;
  --accessible-link:#B30000;
  --accessible-focus:#8A0000;
  --code-bg:#1F2328;
  --code-head:#2D333B;
  --code-text:#F0F3F6;
  --code-muted:#B7C0CA;
  --code-keyword:#FF9A91;
  --code-string:#B6D7FF;
  --code-number:#91CBFF;
  --code-comment:#B7C0CA;
  --code-variable:#FFC07A;
  --code-builtin:#DFB6FF;
  --code-pipe:#FFD866;
}
body{color:var(--accessible-text)!important}
a{color:var(--accessible-link)!important}
a:hover,a:focus{text-decoration:underline!important;color:#8A0000!important}
small,.muted,.meta,.aside-note,.page-head p,.stats span,.stat span,.card-meta{
  color:var(--accessible-muted)!important;
  opacity:1!important;
}
button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
  outline:3px solid var(--accessible-focus)!important;
  outline-offset:2px!important;
}
input,select,textarea{
  color:#202124!important;
  background:#FFFFFF!important;
  border-color:#8A9097!important;
  opacity:1!important;
}
input::placeholder,textarea::placeholder{color:#656B72!important;opacity:1!important}
button:disabled,.btn:disabled{opacity:.65!important;color:#3C4043!important}

/* Código: contraste alto y sin transparencias */
.code-wrap,.code-block,.code-container,.editor-code{
  background:var(--code-bg)!important;
  border-color:#59636E!important;
  opacity:1!important;
}
.code-head,.code-header,.code-title{
  background:var(--code-head)!important;
  color:#FFFFFF!important;
  border-color:#59636E!important;
  opacity:1!important;
}
.code-box,.code-box code,pre,pre code,.content pre,.content pre code{
  background:var(--code-bg)!important;
  color:var(--code-text)!important;
  font-family:Consolas,"Courier New",monospace!important;
  font-size:14px!important;
  line-height:1.65!important;
  opacity:1!important;
  text-shadow:none!important;
  filter:none!important;
}
.code-box *,pre *,pre code *{
  opacity:1!important;
  text-shadow:none!important;
  filter:none!important;
}
.tok-keyword{color:var(--code-keyword)!important;font-weight:700!important}
.tok-string{color:var(--code-string)!important}
.tok-comment{color:var(--code-comment)!important;font-style:italic!important}
.tok-number{color:var(--code-number)!important}
.tok-builtin{color:var(--code-builtin)!important}
.tok-variable{color:var(--code-variable)!important}
.tok-operator{color:#FF9A91!important;font-weight:700!important}
.tok-pipe{color:var(--code-pipe)!important;font-weight:800!important}
.tok-key,.tok-tag{color:#9BE9A8!important}
.copy-code,.code-head button,.code-header button{
  background:#FFFFFF!important;
  color:#8A0000!important;
  border:1px solid #FFFFFF!important;
  font-weight:700!important;
}

/* Avisos: texto oscuro y fondos claros */
.admonition,.notice,.alert{
  color:#202124!important;
  opacity:1!important;
}
.admonition *,.notice *,.alert *{opacity:1!important}
.admonition.advertencia,.warning{
  background:#FFF4E5!important;
  border-color:#C54800!important;
  color:#3B2500!important;
}
.admonition.informacion,.admonition.nota,.info{
  background:#F3F6F9!important;
  border-color:#B30000!important;
  color:#202124!important;
}
.admonition.importante{
  background:#FDECEC!important;
  border-color:#B30000!important;
  color:#4A0000!important;
}
.admonition.error,.error{
  background:#FCE8E6!important;
  border-color:#A50E0E!important;
  color:#5F0000!important;
}

/* Tablas, tarjetas, etiquetas y estados */
th{background:#ECEFF1!important;color:#30343B!important}
td{color:#202124!important}
.card,section,.stat,.project-card,.info-card{
  color:#202124!important;
}
.badge,.tag{
  color:#30343B!important;
  opacity:1!important;
}
.status-en-curso,.badge.en-curso{background:#FFE1E1!important;color:#8A0000!important}
.status-finalizado,.status-completada,.badge.resuelta,.badge.cerrada{
  background:#DFF1E5!important;color:#1F5D36!important;
}
.status-bloqueada,.status-cancelado,.priority-critica,.badge.priority.critica{
  background:#F8D7DA!important;color:#721C24!important;
}
.primary,.btn.primary{
  background:#EC0000!important;color:#FFFFFF!important;border-color:#B30000!important;
}
.primary:hover,.btn.primary:hover{background:#B30000!important;color:#FFFFFF!important}

/* V25.4 — Selecciones legibles y zona de información ampliada */
html,body{width:100%;min-width:0}
.shell{
  width:calc(100% - 24px)!important;
  max-width:1920px!important;
  margin:0 auto!important;
  grid-template-columns:230px minmax(0,1fr)!important;
}
main{
  width:100%!important;
  max-width:none!important;
  min-width:0!important;
  margin:0!important;
  padding:20px 24px 36px!important;
}
main > *,article,.content,.page-content,.dashboard-grid{
  max-width:none!important;
}
article{width:100%!important}
.card,section,.hero,.panel{
  max-width:none!important;
}
.form-card,.editor,.github-editor,.info-card{
  max-width:none!important;
  width:100%!important;
}
.table-wrap,.pending-card,.pending-table{
  width:100%!important;
  max-width:none!important;
}
table{width:100%!important}

/* Filtros y pestañas: estados claramente visibles */
.pending-filters,.search-filters,.module-tabs{
  display:flex!important;
  flex-wrap:wrap!important;
  gap:8px!important;
  align-items:center!important;
}
.pending-filter,.search-filters a,.module-tabs a{
  display:inline-flex!important;
  align-items:center!important;
  justify-content:center!important;
  min-height:36px!important;
  padding:8px 14px!important;
  border:1px solid #B8BEC5!important;
  border-radius:999px!important;
  background:#FFFFFF!important;
  color:#9B0000!important;
  font-size:13px!important;
  line-height:1.2!important;
  font-weight:600!important;
  text-decoration:none!important;
  opacity:1!important;
  white-space:nowrap!important;
}
.pending-filter:hover,.search-filters a:hover,.module-tabs a:hover{
  background:#FDECEC!important;
  border-color:#EC0000!important;
  color:#780000!important;
  text-decoration:none!important;
}
.pending-filter.active,.search-filters a.active,.module-tabs a.active{
  background:#EC0000!important;
  border-color:#B30000!important;
  color:#FFFFFF!important;
  font-weight:700!important;
  box-shadow:0 0 0 1px #EC0000!important;
}
.pending-filter.active *,
.search-filters a.active *,
.module-tabs a.active *{
  color:#FFFFFF!important;
}

/* Tarjetas resumen */
.pending-summary{
  grid-template-columns:repeat(4,minmax(180px,1fr))!important;
  gap:12px!important;
}
.pending-chip{
  min-height:72px!important;
  padding:14px 16px!important;
  background:#FFFFFF!important;
  color:#30343B!important;
  border:1px solid #C7CDD3!important;
}
.pending-chip:hover{
  background:#FFF5F5!important;
  border-color:#EC0000!important;
  text-decoration:none!important;
}
.pending-chip strong{font-size:24px!important;color:#202124!important}

/* Ventanas y cuadros de información más amplios */
.import-dialog,.modal-dialog,.dialog,.popup,.detail-dialog{
  width:min(1100px,calc(100vw - 40px))!important;
  max-width:1100px!important;
  max-height:92vh!important;
}
.import-dialog-body,.modal-body,.dialog-body{
  padding:22px 24px!important;
}
.project-grid{
  grid-template-columns:repeat(auto-fit,minmax(280px,1fr))!important;
}
.detail-grid{
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
}
.editor-row{
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
}

@media(min-width:1600px){
  .shell{width:calc(100% - 32px)!important;max-width:2200px!important}
  main{padding:22px 30px 42px!important}
}
@media(max-width:1050px){
  .pending-summary{grid-template-columns:repeat(2,minmax(160px,1fr))!important}
  .detail-grid,.editor-row{grid-template-columns:1fr!important}
}
@media(max-width:850px){
  .shell{display:block!important;width:100%!important}
  main{padding:16px!important}
  .pending-summary{grid-template-columns:1fr!important}
  .pending-filter,.search-filters a,.module-tabs a{font-size:12px!important;padding:8px 12px!important}
}

/* V25.5 — Tipografía exacta para PDF */
@media print {
  html,body,main,article,.content,.page-content{
    font-size:12px!important;
    line-height:1.45!important;
  }

  p,li,dd,dt,td,th,span,div,label{
    font-size:12px!important;
  }

  h1,h2,h3,h4,h5,h6,
  .page-title,.section-title,.card-title{
    font-size:14px!important;
    line-height:1.25!important;
  }

  .email-example,
  .email-example *,
  .communication-email,
  .communication-email *,
  .communication-case,
  .communication-case *,
  .communication-response,
  .communication-response *,
  .case-field,
  .case-field *,
  .admonition,
  .admonition *,
  .notice,
  .notice *,
  .alert,
  .alert *,
  .callout,
  .callout *,
  .code-wrap,
  .code-wrap *,
  .code-box,
  .code-box *,
  .code-head,
  .code-head *,
  pre,
  pre *,
  code,
  code *{
    font-size:9px!important;
    line-height:1.4!important;
  }

  .email-example-title,
  .communication-title,
  .admonition-title,
  .code-head{
    font-size:9px!important;
    font-weight:700!important;
  }

  .email-example,
  .communication-email,
  .communication-case,
  .communication-response,
  .admonition,
  .notice,
  .alert,
  .callout,
  .code-wrap,
  pre{
    break-inside:avoid!important;
    page-break-inside:avoid!important;
  }
}
"""

BASE=Path(__file__).resolve().parent
DATA=BASE/'data'; DB=DATA/'entries.json'; GROUPS_DB=DATA/'groups.json'; LEGACY_UPLOADS=DATA/'uploads'; UPLOADS=BASE.parent.parent/'imagenes'
DATA.mkdir(exist_ok=True); LEGACY_UPLOADS.mkdir(parents=True,exist_ok=True); UPLOADS.mkdir(parents=True,exist_ok=True)
for old_image in LEGACY_UPLOADS.iterdir():
    if old_image.is_file() and not (UPLOADS/old_image.name).exists():
        try:
            import shutil; shutil.copy2(old_image,UPLOADS/old_image.name)
        except OSError: pass
PORTAL_URL=os.environ.get('PORTAL_URL','http://127.0.0.1:8079')
WIKI_URL=os.environ.get('WIKI_URL','http://127.0.0.1:8080')
GESTOR_URL=os.environ.get('GESTOR_URL','http://127.0.0.1:8081')
BAU_URL=os.environ.get('BAU_URL','http://127.0.0.1:8082')
BIBLIOTECA_URL=os.environ.get('BIBLIOTECA_URL','http://127.0.0.1:8084')
CAMBIOS_URL=os.environ.get('CAMBIOS_URL','http://127.0.0.1:8085')
DEFAULT_GROUPS=['Correo','Novedades','FollowTheSun','Acta','CEA','Peticiones','Migracion']


def esc(v): return html.escape(str(v or ''),quote=True)
def load():
    try:return json.loads(DB.read_text(encoding='utf-8')) if DB.exists() else []
    except Exception:return []
def save(rows): DB.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
def load_groups():
    try:
        values=json.loads(GROUPS_DB.read_text(encoding='utf-8')) if GROUPS_DB.exists() else DEFAULT_GROUPS
    except Exception:
        values=DEFAULT_GROUPS
    clean=[]
    for value in values:
        name=str(value or '').strip()
        if name and name.casefold() not in {x.casefold() for x in clean}: clean.append(name)
    if not clean: clean=list(DEFAULT_GROUPS)
    if not GROUPS_DB.exists(): save_groups(clean)
    return clean
def save_groups(values):
    clean=[]
    for value in values:
        name=str(value or '').strip()
        if name and name.casefold() not in {x.casefold() for x in clean}: clean.append(name)
    GROUPS_DB.write_text(json.dumps(clean or list(DEFAULT_GROUPS),ensure_ascii=False,indent=2),encoding='utf-8')
def now(): return datetime.now().isoformat(timespec='seconds')
def getone(rid): return next((x for x in load() if x.get('id')==rid),None)
def options(values,current=''): return ''.join(f'<option value="{esc(x)}" {"selected" if x==current else ""}>{esc(x)}</option>' for x in values)
def tags_list(value): return [x.strip() for x in re.split(r'[,;]',value or '') if x.strip()]
def badge(v): return f'<span class="badge">{esc(v)}</span>'

def preserve_rendered_indent(line):
    expanded=str(line or '').expandtabs(4)
    leading=len(expanded)-len(expanded.lstrip(' '))
    if not leading:
        return line
    return '<span class="text-indent">'+('&#160;'*leading)+'</span>'+expanded.lstrip(' ')

def render(text):
    s=esc(text)
    s=re.sub(r'\[azul\](.*?)\[/azul\]',r'<span class="text-blue">\1</span>',s,flags=re.S|re.I)
    s=re.sub(r'\[rojo\](.*?)\[/rojo\]',r'<span class="text-red">\1</span>',s,flags=re.S|re.I)
    s=re.sub(r'\[amarillo\](.*?)\[/amarillo\]',r'<mark>\1</mark>',s,flags=re.S|re.I)
    s=re.sub(r'\[\[imagen:([^|\]]+)(?:\|([^\]]*))?\]\]',lambda m:f'<img class="embedded-image" src="/uploads/{quote(m.group(1))}" alt="{esc(m.group(2) or m.group(1))}">',s)
    s=re.sub(r'```([^\n]*)\n(.*?)```',lambda m:f'<pre><code class="language-{esc(m.group(1).strip() or "text")}">{m.group(2)}</code></pre>',s,flags=re.S)
    s=re.sub(r'^\s*(={2,6})\s*(.*?)\s*\1\s*$',lambda m:f'<h{min(len(m.group(1)),6)}>{m.group(2)}</h{min(len(m.group(1)),6)}>',s,flags=re.M)
    s=re.sub(r'^!!!\s+nota\s*(.*)$',r'<div class="admonition note"><strong>Nota</strong> \1</div>',s,flags=re.M|re.I)
    s=re.sub(r'^!!!\s+advertencia\s*(.*)$',r'<div class="admonition warning"><strong>Advertencia</strong> \1</div>',s,flags=re.M|re.I)
    s=re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',s,flags=re.S)
    s=re.sub(r"''(.+?)''",r'<em>\1</em>',s,flags=re.S)
    s=re.sub(r'\[([^\]]+)\]\((https?://[^)]+)\)',r'<a href="\2" target="_blank">\1</a>',s)
    lines=s.splitlines(); out=[]; para=[]; in_ul=False
    def flush():
        nonlocal para
        if para: out.append('<p>'+'<br>'.join(para)+'</p>'); para=[]
    for line in lines:
        if line.startswith(('<h','<pre','<div class="admonition','<img')):
            flush()
            if in_ul: out.append('</ul>'); in_ul=False
            out.append(line); continue
        if re.match(r'^\s*[-*]\s+',line):
            flush()
            if not in_ul: out.append('<ul>'); in_ul=True
            out.append('<li>'+re.sub(r'^\s*[-*]\s+','',line)+'</li>'); continue
        if in_ul: out.append('</ul>'); in_ul=False
        if line.strip(): para.append(preserve_rendered_indent(line))
        else: flush()
    flush()
    if in_ul: out.append('</ul>')
    return ''.join(out)

def layout(title,body):
    links=[('Inicio',PORTAL_URL),('Wiki',WIKI_URL),('Proyectos y tareas',GESTOR_URL),('BAU',BAU_URL),('Bitácora','/'),('Biblioteca',BIBLIOTECA_URL),('Plantillas Cambios',CAMBIOS_URL)]
    nav=''.join(f'<a class="{"active" if n=="Bitácora" else ""}" href="{esc(u)}">{esc(n)}</a>' for n,u in links)
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)} · Bitácora</title><style>{CSS}
/* V20.1 · Ajuste visual seguro en cajas de edición */
textarea{{white-space:pre-wrap!important;overflow-wrap:anywhere;word-break:normal;overflow-x:hidden}}
.form textarea.code{{white-space:pre-wrap!important;overflow-wrap:anywhere;word-break:normal;overflow-x:hidden}}
</style><style>{CORPORATE_THEME_CSS}
/* V26.1: logotipo configurable desde imagenes/logo/logo.png */
.brand::before{{display:none!important;content:none!important;background-image:none!important}}
.brand .brand-logo{{
  display:block!important;width:46px!important;height:46px!important;
  min-width:46px!important;max-width:46px!important;flex:0 0 46px!important;
  object-fit:contain!important;object-position:center!important;
  background:transparent!important;border:0!important;border-radius:0!important;
  box-shadow:none!important
}}
.brand>span{{display:block!important}}
@media(max-width:760px){{
  .brand .brand-logo{{width:38px!important;height:38px!important;min-width:38px!important;max-width:38px!important;flex-basis:38px!important}}
}}
</style>
<style>
/* V27.3 · Logotipo adaptable al espacio disponible */
header{{
  min-height:72px!important;
  height:auto!important;
  overflow:visible!important;
}}
.brand{{
  min-height:56px!important;
  max-width:min(70vw,760px)!important;
  display:flex!important;
  align-items:center!important;
  gap:14px!important;
  overflow:visible!important;
}}
.brand::before{{
  display:none!important;
  content:none!important;
  background-image:none!important;
}}
.brand .brand-logo{{
  display:block!important;
  width:auto!important;
  height:auto!important;
  min-width:0!important;
  min-height:0!important;
  max-width:210px!important;
  max-height:56px!important;
  flex:0 1 auto!important;
  object-fit:contain!important;
  object-position:left center!important;
  background:transparent!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
}}
.brand>span{{
  display:block!important;
  min-width:0!important;
  overflow:hidden!important;
  text-overflow:ellipsis!important;
}}
@media(max-width:760px){{
  header{{min-height:64px!important;padding:8px 14px!important}}
  .brand{{min-height:46px!important;gap:10px!important;max-width:76vw!important}}
  .brand .brand-logo{{
    width:auto!important;
    height:auto!important;
    max-width:145px!important;
    max-height:46px!important;
  }}
}}
@media(max-width:480px){{
  .brand .brand-logo{{max-width:105px!important;max-height:42px!important}}
  .brand>span{{font-size:15px!important}}
}}
</style>

<style>
/* V27.7 · Logotipo ajustado al encabezado */
header{{min-height:58px!important;height:auto!important;padding:6px 16px!important;overflow:hidden!important}}
.brand{{min-height:44px!important;display:flex!important;align-items:center!important;gap:10px!important;max-width:min(64vw,700px)!important;overflow:hidden!important}}
.brand::before{{display:none!important;content:none!important}}
.brand .brand-logo{{display:block!important;width:auto!important;height:auto!important;max-width:150px!important;max-height:40px!important;min-width:0!important;min-height:0!important;flex:0 1 auto!important;object-fit:contain!important;object-position:left center!important}}
.brand>span{{min-width:0!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important}}
@media(max-width:760px){{.brand .brand-logo{{max-width:110px!important;max-height:36px!important}}.brand>span{{font-size:15px!important}}
</style>
</head><body><header><div class="brand"><img class="brand-logo" src="/logo.png" alt="Logo Santander" onerror="this.style.display=\'none\'"><span>Santander Mail Security · Bitácora</span></div><div class="header-actions"><a class="btn" href="/">← Atrás</a><a class="btn" href="{esc(PORTAL_URL)}">Inicio común</a><a class="btn primary" href="/new">+ Nueva entrada</a></div></header><div class="shell"><aside><nav>{nav}</nav><div class="aside-note">Aplicación local<br>Sin usuarios<br>Datos en JSON</div></aside><main>{body}</main></div><script src="/editor.js"></script></body></html>'''

def dashboard(qs):
    rows=load(); groups=load_groups(); term=qs.get('q',[''])[0].strip().casefold(); group=qs.get('group',[''])[0]; day=qs.get('date',[''])[0]
    filtered=[]
    for r in rows:
        hay=' '.join([r.get('title',''),r.get('group',''),r.get('content',''),r.get('tags',''),r.get('wiki_link',''),r.get('bau_link','')]).casefold()
        if (not term or term in hay) and (not group or r.get('group')==group) and (not day or r.get('date')==day): filtered.append(r)
    filtered.sort(key=lambda x:(x.get('date',''),x.get('updated','')),reverse=True)
    group_counts=''.join(f'<a class="group-card {"selected" if group==g else ""}" href="/?group={quote(g)}"><strong>{sum(1 for r in rows if r.get("group")==g)}</strong><span>{esc(g)}</span></a>' for g in groups)
    trs=''.join(f'''<tr><td>{esc(r.get('date'))}</td><td>{badge(r.get('group'))}</td><td class="entry-title"><a href="/view?id={esc(r.get('id'))}"><strong>{esc(r.get('title'))}</strong></a><small>{' '.join('#'+esc(t) for t in tags_list(r.get('tags','')))}</small></td><td>{esc(r.get('updated','')[:16].replace('T',' '))}</td></tr>''' for r in filtered) or '<tr><td colspan="4" class="empty">No hay entradas de bitácora.</td></tr>'
    body=f'''<div class="page-head"><div><h1>Cuaderno de Bitácora</h1><p>Novedades, cambios, investigaciones y apuntes técnicos ordenados por fecha y grupo.</p></div><div><a class="btn" href="/groups">Gestionar grupos</a></div></div><div class="groups"><a class="group-card {"selected" if not group else ""}" href="/"><strong>{len(rows)}</strong><span>Todos</span></a>{group_counts}</div><section class="card"><form class="filters" method="get"><input name="q" value="{esc(qs.get('q',[''])[0])}" placeholder="Buscar en título, contenido, etiquetas o enlaces"><select name="group"><option value="">Todos los grupos</option>{options(groups,group)}</select><input type="date" name="date" value="{esc(day)}"><button class="btn primary">Filtrar</button><a class="btn ghost" href="/">Limpiar</a></form></section><section class="card"><div class="section-head"><h2>Entradas</h2><a class="btn primary" href="/new">+ Nueva entrada</a></div><div class="table-wrap"><table><thead><tr><th>Fecha</th><th>Grupo</th><th>Título y etiquetas</th><th>Actualizada</th></tr></thead><tbody>{trs}</tbody></table></div></section>'''
    return layout('Cuaderno de Bitácora',body)

def editor_field(value):
    return f'''<section class="editor-block"><div class="editor-head"><h2>Contenido</h2></div><div class="toolbar" data-target="content"><button type="button" data-heading="2">Título</button><button type="button" data-wrap="**">Negrita</button><button type="button" data-wrap="''">Cursiva</button><button type="button" data-wrap-open="[u]" data-wrap-close="[/u]">Subrayado</button><button type="button" data-insert="::: correo Correo&#10;Para: &#10;CC: &#10;CCO: &#10;Asunto: &#10;&#10;Escriba aquí el cuerpo del correo.&#10;::: endcorreo&#10;">✉ Correo</button><button type="button" data-insert="::: caso Caso&#10;Título: &#10;&#10;Escriba aquí el cuerpo del caso.&#10;::: endcaso&#10;">▣ Caso</button><button type="button" data-insert="::: respuesta Respuesta&#10;Escriba aquí el texto de la respuesta.&#10;::: endrespuesta&#10;">↩ Respuesta</button><button type="button" data-wrap-open="[azul]" data-wrap-close="[/azul]">Azul</button><button type="button" data-wrap-open="[rojo]" data-wrap-close="[/rojo]">Rojo</button><button type="button" data-wrap-open="[amarillo]" data-wrap-close="[/amarillo]">Resaltar</button><button type="button" data-insert="- ">Lista</button><button type="button" data-indent="1">→ Tab +4</button><button type="button" data-outdent="1">← Quitar tab</button><button type="button" data-insert="!!! nota Nota importante&#10;">Nota</button><button type="button" data-insert="!!! advertencia Precaución&#10;">Advertencia</button><button type="button" data-code="spl">Código SPL</button><button type="button" data-code="python">Código Python</button><button type="button" data-image="1">🖼 Imagen</button></div><textarea wrap="soft" id="content" name="content" rows="18" required>{esc(value)}</textarea><input class="bau-image-input" data-editor="content" type="file" accept="image/*" hidden><span class="upload-status" data-status="content"></span></section>'''

def form_page(r=None):
    r=r or {}; editing=bool(r); groups=load_groups()
    body=f'''<div class="page-head"><div><h1>{'Editar' if editing else 'Nueva'} entrada</h1><p>Registra la novedad con fecha, grupo y etiquetas para localizarla fácilmente.</p></div></div><form class="card form" method="post" action="/save"><input type="hidden" name="id" value="{esc(r.get('id'))}"><div class="grid"><label>Fecha<input type="date" name="date" value="{esc(r.get('date') or datetime.now().date())}" required></label><label>Grupo<select name="group" required>{options(groups,r.get('group',groups[0] if groups else 'Correo'))}</select></label><label class="wide">Título<input name="title" value="{esc(r.get('title'))}" maxlength="180" required placeholder="Resumen breve de la novedad"></label><label class="wide">Etiquetas<input name="tags" value="{esc(r.get('tags'))}" placeholder="Ej.: colas, configuración, incidencia"></label></div>{editor_field(r.get('content',''))}<div class="grid links"><label>Wiki relacionada (slug o enlace)<input name="wiki_link" value="{esc(r.get('wiki_link'))}" placeholder="RFC, slug o URL"></label><label>BAU relacionada (ID o enlace)<input name="bau_link" value="{esc(r.get('bau_link'))}" placeholder="INC..., RITM... o URL"></label><label class="wide">Enlace externo adicional<input name="external_link" value="{esc(r.get('external_link'))}" placeholder="https://..."></label></div><div class="actions"><button class="btn primary">Guardar entrada</button><a class="btn ghost" href="/">Cancelar</a></div></form>'''
    return layout('Editor de Bitácora',body)

def groups_page(message=''):
    groups=load_groups(); rows=load()
    notice=f'<div class="notice">{esc(message)}</div>' if message else ''
    items=''
    for index,name in enumerate(groups):
        used=sum(1 for row in rows if row.get('group')==name)
        items+=f'''<tr><td>{index+1}</td><td><form class="group-edit-form" method="post" action="/groups/rename"><input type="hidden" name="old" value="{esc(name)}"><input name="new" value="{esc(name)}" maxlength="80" required><button class="btn">Guardar nombre</button></form></td><td>{used}</td><td><form method="post" action="/groups/delete" onsubmit="return confirm('¿Eliminar este grupo?')"><input type="hidden" name="name" value="{esc(name)}"><button class="btn danger" {'disabled title="No puede eliminarse mientras tenga entradas"' if used else ''}>Eliminar</button></form></td></tr>'''
    body=f'''<div class="page-head"><div><h1>Grupos de Bitácora</h1><p>Crea, modifica y elimina los grupos disponibles en las entradas.</p></div><div><a class="btn" href="/">Volver a la Bitácora</a></div></div>{notice}<section class="card"><h2>Añadir grupo</h2><form class="group-add-form" method="post" action="/groups/add"><input name="name" maxlength="80" required placeholder="Nombre del nuevo grupo"><button class="btn primary">Añadir grupo</button></form></section><section class="card"><h2>Grupos configurados</h2><div class="table-wrap"><table><thead><tr><th>Orden</th><th>Nombre</th><th>Entradas</th><th>Acción</th></tr></thead><tbody>{items}</tbody></table></div><p><small>Un grupo con entradas no puede eliminarse hasta que sus entradas se muevan o se renombre el grupo.</small></p></section>'''
    return layout('Grupos de Bitácora',body)

def smart_link(value,base):
    if not value:return '—'
    href=value if re.match(r'^https?://',value,re.I) else base.rstrip('/')+'/'+quote(value.strip('/'))
    return f'<a href="{esc(href)}" target="_blank">{esc(value)}</a>'
def view_page(r):
    tag_html=''.join(f'<span class="tag">#{esc(t)}</span>' for t in tags_list(r.get('tags','')))
    comments=sorted(r.get('comments',[]) if isinstance(r.get('comments',[]),list) else [],key=lambda x:x.get('created',''))
    comment_items=''
    for comment in comments:
        comment_items+=f'''<article class="comment-item"><div class="comment-meta"><strong>{esc(comment.get('created','').replace('T',' '))}</strong><form method="post" action="/comment/delete" onsubmit="return confirm('¿Eliminar este comentario?')"><input type="hidden" name="entry_id" value="{esc(r['id'])}"><input type="hidden" name="comment_id" value="{esc(comment.get('id'))}"><button class="comment-delete" type="submit">Eliminar</button></form></div><div class="comment-text">{render(comment.get('text',''))}</div></article>'''
    if not comment_items:
        comment_items='<p class="comments-empty">Todavía no hay comentarios.</p>'
    body=f'''<div class="page-head"><div><div class="eyebrow">{esc(r.get('date'))} · {esc(r.get('group'))}</div><h1>{esc(r.get('title'))}</h1><div class="tag-row">{tag_html}</div></div><div><a class="btn" href="/edit?id={esc(r['id'])}">Editar</a> <form class="inline" method="post" action="/delete" onsubmit="return confirm('¿Eliminar esta entrada de bitácora?')"><input type="hidden" name="id" value="{esc(r['id'])}"><button class="btn danger">Eliminar</button></form></div></div><section class="card content">{render(r.get('content',''))}</section><section class="card"><h2>Relaciones y enlaces</h2><div class="meta-grid"><div><strong>Wiki relacionada</strong><span>{smart_link(r.get('wiki_link'),WIKI_URL+'/wiki')}</span></div><div><strong>BAU relacionada</strong><span>{smart_link(r.get('bau_link'),BAU_URL+'/view?id=')}</span></div><div><strong>Enlace externo</strong><span>{smart_link(r.get('external_link'),'')}</span></div><div><strong>Última actualización</strong><span>{esc(r.get('updated','').replace('T',' '))}</span></div></div></section><section class="card comments-card"><div class="section-head"><h2>Comentarios</h2><span class="comment-count">{len(comments)}</span></div><div class="comments-list">{comment_items}</div><form class="comment-form" method="post" action="/comment/add"><input type="hidden" name="entry_id" value="{esc(r['id'])}"><label>Nuevo comentario<textarea wrap="soft" name="text" rows="4" maxlength="4000" required placeholder="Escriba el seguimiento o actualización..."></textarea></label><div class="actions"><button class="btn primary" type="submit">Añadir comentario</button></div></form></section>'''
    return layout(r.get('title','Bitácora'),body)



def corporate_logo_path():
    """Locate imagenes/logo/logo.png from the application root."""
    source = Path(__file__).resolve()
    for parent in source.parents:
        candidate = parent / "imagenes" / "logo" / "logo.png"
        if candidate.is_file():
            return candidate
        if (parent / "INICIAR.bat").exists() or (parent / "VERSION.txt").exists():
            (parent / "imagenes" / "logo").mkdir(parents=True, exist_ok=True)
            return None
    return None
def serve_corporate_logo(handler):
    path = corporate_logo_path()
    if path is None:
        handler.send_response(404)
        handler.end_headers()
        return
    data = path.read_bytes()
    handler.send_response(200)
    handler.send_header("Content-Type", "image/png")
    handler.send_header("Content-Length", str(len(data)))
    handler.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
    handler.end_headers()
    handler.wfile.write(data)

class Handler(BaseHTTPRequestHandler):
    def send_html(self,s,status=200,ctype='text/html; charset=utf-8'):
        b=s.encode(); self.send_response(status); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def redirect(self,u): self.send_response(303); self.send_header('Location',u); self.end_headers()
    def read_form(self):
        n=int(self.headers.get('Content-Length','0') or 0); return {k:v[-1] for k,v in parse_qs(self.rfile.read(n).decode('utf-8','replace'),keep_blank_values=True).items()}
    def multipart(self,max_size=15*1024*1024):
        ct=self.headers.get('Content-Type',''); m=re.search(r'boundary="?([^";]+)',ct); n=int(self.headers.get('Content-Length','0') or 0)
        if not m or n<=0 or n>max_size:return {},[]
        raw=self.rfile.read(n); boundary=('--'+m.group(1)).encode(); fields={}; files=[]
        for part in raw.split(boundary):
            if b'\r\n\r\n' not in part: continue
            head,body=part.split(b'\r\n\r\n',1); body=body.rstrip(b'\r\n-'); nm=re.search(br'name="([^"]+)"',head)
            if not nm: continue
            name=nm.group(1).decode('utf-8','replace'); fm=re.search(br'filename="([^"]*)"',head)
            if fm:
                fn=Path(fm.group(1).decode('utf-8','replace')).name
                if fn: files.append((name,fn,body))
            else: fields[name]=body.decode('utf-8','replace')
        return fields,files
    def do_GET(self):
        u=urlparse(self.path); qs=parse_qs(u.query)
        if u.path in {"/logo.png", "/corporate-logo.png"}: return serve_corporate_logo(self)
        if u.path=='/': return self.send_html(dashboard(qs))
        if u.path=='/new': return self.send_html(form_page())
        if u.path=='/groups': return self.send_html(groups_page(qs.get('message',[''])[0]))
        if u.path in ('/view','/edit'):
            r=getone(qs.get('id',[''])[0])
            if not r:return self.send_error(404)
            return self.send_html(form_page(r) if u.path=='/edit' else view_page(r))
        if u.path=='/editor.js':
            p=BASE/'editor.js'; b=p.read_bytes(); self.send_response(200); self.send_header('Content-Type','text/javascript; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); return self.wfile.write(b)
        if u.path.startswith('/uploads/'):
            p=(UPLOADS/Path(u.path).name).resolve()
            if UPLOADS.resolve() not in p.parents or not p.is_file():return self.send_error(404)
            b=p.read_bytes(); self.send_response(200); self.send_header('Content-Type',mimetypes.guess_type(p)[0] or 'application/octet-stream'); self.send_header('Content-Length',str(len(b))); self.end_headers(); return self.wfile.write(b)
        self.send_error(404)
    def do_POST(self):
        u=urlparse(self.path)
        if u.path=='/groups/add':
            f=self.read_form(); name=f.get('name','').strip(); groups=load_groups()
            if not name: return self.redirect('/groups?message='+quote('El nombre no puede estar vacío.'))
            if name.casefold() in {g.casefold() for g in groups}: return self.redirect('/groups?message='+quote('El grupo ya existe.'))
            groups.append(name); save_groups(groups); return self.redirect('/groups?message='+quote('Grupo añadido correctamente.'))
        if u.path=='/groups/rename':
            f=self.read_form(); old=f.get('old','').strip(); new=f.get('new','').strip(); groups=load_groups()
            if old not in groups or not new: return self.redirect('/groups?message='+quote('No se pudo modificar el grupo.'))
            if new.casefold()!=old.casefold() and new.casefold() in {g.casefold() for g in groups}: return self.redirect('/groups?message='+quote('Ya existe otro grupo con ese nombre.'))
            groups=[new if g==old else g for g in groups]; save_groups(groups)
            rows=load()
            for row in rows:
                if row.get('group')==old: row['group']=new
            save(rows); return self.redirect('/groups?message='+quote('Grupo modificado correctamente.'))
        if u.path=='/groups/delete':
            f=self.read_form(); name=f.get('name','').strip(); groups=load_groups(); rows=load()
            if any(row.get('group')==name for row in rows): return self.redirect('/groups?message='+quote('No puede eliminarse un grupo que contiene entradas.'))
            groups=[g for g in groups if g!=name]
            if not groups: return self.redirect('/groups?message='+quote('Debe existir al menos un grupo.'))
            save_groups(groups); return self.redirect('/groups?message='+quote('Grupo eliminado correctamente.'))
        if u.path=='/comment/add':
            f=self.read_form(); entry_id=f.get('entry_id','').strip(); text=f.get('text','').strip(); rows=load()
            if not text: return self.redirect('/view?id='+quote(entry_id))
            for row in rows:
                if row.get('id')==entry_id:
                    comments=row.get('comments',[])
                    if not isinstance(comments,list): comments=[]
                    comments.append({'id':uuid.uuid4().hex,'text':text,'created':now()})
                    row['comments']=comments; row['updated']=now(); break
            save(rows); return self.redirect('/view?id='+quote(entry_id))
        if u.path=='/comment/delete':
            f=self.read_form(); entry_id=f.get('entry_id','').strip(); comment_id=f.get('comment_id','').strip(); rows=load()
            for row in rows:
                if row.get('id')==entry_id:
                    comments=row.get('comments',[])
                    if isinstance(comments,list): row['comments']=[c for c in comments if c.get('id')!=comment_id]
                    row['updated']=now(); break
            save(rows); return self.redirect('/view?id='+quote(entry_id))
        if u.path=='/upload-image':
            _,files=self.multipart()
            if not files:return self.send_html(json.dumps({'ok':False,'error':'No se recibió ninguna imagen.'}),400,'application/json; charset=utf-8')
            _,fn,data=files[0]; ext=Path(fn).suffix.lower()
            if ext not in ('.png','.jpg','.jpeg','.gif','.webp'):return self.send_html(json.dumps({'ok':False,'error':'Formato no permitido.'}),400,'application/json; charset=utf-8')
            stored=f'{uuid.uuid4().hex}{ext}'; (UPLOADS/stored).write_bytes(data)
            return self.send_html(json.dumps({'ok':True,'filename':stored},ensure_ascii=False),200,'application/json; charset=utf-8')
        f=self.read_form()
        if u.path=='/save':
            rows=load(); rid=f.get('id') or uuid.uuid4().hex; old=next((x for x in rows if x.get('id')==rid),{})
            r={**old,**{k:f.get(k,'').strip() for k in ('date','group','title','tags','content','wiki_link','bau_link','external_link')}}
            r['id']=rid; r['created']=old.get('created') or now(); r['updated']=now()
            rows=[x for x in rows if x.get('id')!=rid]+[r]; save(rows); return self.redirect('/view?id='+rid)
        if u.path=='/delete':
            save([x for x in load() if x.get('id')!=f.get('id','')]); return self.redirect('/')
        self.send_error(404)
    def log_message(self,*args): pass

CSS=r'''*{box-sizing:border-box}body{margin:0;font:14px Arial,sans-serif;color:#26384a;background:#f3f6f9}header{height:62px;background:#25364a;color:#fff;padding:0 24px;display:flex;justify-content:space-between;align-items:center}.brand{font-size:19px;font-weight:bold}.header-actions{display:flex;gap:8px}.shell{display:grid;grid-template-columns:210px minmax(0,1fr);min-height:calc(100vh - 62px)}aside{background:#fff;border-right:1px solid #d9e1e8;padding:20px 14px}nav a{display:block;padding:10px 12px;color:#38516b;text-decoration:none;border-radius:5px;margin-bottom: 5px}nav a.active,nav a:hover{background:#FFF0F0;color:#B30000;font-weight:bold}.aside-note{margin:25px 10px;color:#7b8996;font-size:13px;line-height:1.6}main{padding:24px;max-width:1450px;width:100%;margin:0 auto}.page-head{display:flex;justify-content:space-between;gap:20px;align-items:flex-start;margin-bottom:18px}.page-head h1{margin:0 0 5px;font-size:25px}.page-head p{margin:0;color:#657687}.card{background:#fff;border:1px solid #d7e0e8;border-radius:8px;padding:18px;margin-bottom:16px;box-shadow:0 1px 4px #0000000c}.btn{display:inline-block;border:1px solid #bdcad5;background:#fff;color:#31516e;padding:9px 13px;border-radius:5px;text-decoration:none;cursor:pointer;font:inherit}.btn.primary{background:#EC0000;border-color:#EC0000;color:#fff}.btn.ghost{background:#f5f7f9}.btn.danger{background:#a53b3b;border-color:#a53b3b;color:#fff}.groups{display:flex;gap:10px;overflow:auto;padding-bottom:12px}.group-card{min-width:118px;background:#fff;border:1px solid #d7e0e8;border-radius:7px;padding:12px;text-decoration:none;color:#344c62}.group-card strong{display:block;font-size:22px}.group-card span{font-size:12px;color:#687987}.group-card.selected{border-color:#EC0000;background:#FFF0F0}.filters{display:grid;grid-template-columns:minmax(260px,1fr) 180px 155px auto auto;gap:9px}.filters input,.filters select,.form input,.form select,.form textarea{width:100%;padding:10px;border:1px solid #bdcad5;border-radius:5px;font:inherit;background:#fff}.section-head{display:flex;justify-content:space-between;align-items:center}.section-head h2{margin:0}.table-wrap{overflow:auto}table{width:100%;border-collapse:collapse;margin-top:12px}th,td{text-align:left;padding:11px 9px;border-bottom:1px solid #e2e8ed;vertical-align:top}th{font-size:12px;color:#687989;background:#f7f9fb}.entry-title{width:55%}.entry-title a{color:#B30000;text-decoration:none}.entry-title small{display:block;margin-top:5px;color:#748391}.badge,.tag{display:inline-block;background:#e7eef5;color:#B30000;border-radius:12px;padding:4px 8px;font-size:11px}.empty{text-align:center;color:#71808d;padding:35px}.grid{display:grid;grid-template-columns:180px 220px minmax(280px,1fr);gap:13px}.grid label{font-weight:bold;font-size:12px}.grid label input,.grid label select{margin-top:6px;font-weight:normal}.grid .wide{grid-column:span 1}.links{grid-template-columns:1fr 1fr}.links .wide{grid-column:1/-1}.editor-block{margin:18px 0}.editor-head h2{font-size:17px}.toolbar{display:flex;gap:5px;flex-wrap:wrap;background:#f3f6f8;border:1px solid #cbd6df;border-bottom:0;padding:7px;border-radius:5px 5px 0 0}.toolbar button{border:1px solid #c0ccd6;background:#fff;border-radius:4px;padding:6px 8px;cursor:pointer}.editor-block textarea{border-radius:0 0 5px 5px!important;min-height:330px;line-height:1.5}.actions{display:flex;gap:8px}.inline{display:inline}.eyebrow{text-transform:uppercase;letter-spacing:.08em;color:#607b92;font-size:12px;font-weight:bold}.tag-row{margin-top:8px;display:flex;gap:5px}.content{font-family:Arial,sans-serif;line-height:1.58}.content h2,.content h3{color:#244d70;border-bottom:1px solid #dbe3ea;padding-bottom:5px}.content pre{background:#17222d;color:#eaf2f8;padding:14px;border-radius:5px;overflow:auto}.embedded-image{display:block;max-width:100%;height:auto;margin:12px auto;border-radius:4px}.text-blue{color:#145ca8}.text-red{color:#b52323}mark{background:#fff19b}.admonition{padding:11px 13px;border-left:4px solid #EC0000;background:#FFF4F4;margin:10px 0}.admonition.warning{border-color:#c58418;background:#fff7e5}.meta-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px}.meta-grid div{background:#f7f9fb;padding:12px;border-radius:5px}.meta-grid strong,.meta-grid span{display:block}.meta-grid span{margin-top:5px;color:#5e7080;word-break:break-word}.notice{padding:11px;margin:12px 0;background:#e9f6ec;border:1px solid #aed8b8;border-radius:5px;color:#245c31}.group-add-form{display:flex;gap:9px}.group-add-form input{flex:1;padding:10px;border:1px solid #bdcad5;border-radius:5px}.group-edit-form{display:flex;gap:7px;align-items:center}.group-edit-form input{min-width:220px;padding:8px;border:1px solid #bdcad5;border-radius:5px}.btn:disabled{opacity:.5;cursor:not-allowed}.comments-card{margin-top:18px}.comment-count{display:inline-flex;min-width:26px;height:26px;align-items:center;justify-content:center;border-radius:13px;background:#e7eef5;color:#B30000;font-weight:bold}.comments-list{margin:14px 0}.comment-item{padding:13px 0;border-top:1px solid #e1e7ec}.comment-item:first-child{border-top:0}.comment-meta{display:flex;justify-content:space-between;gap:12px;color:#607080;font-size:12px}.comment-meta form{margin:0}.comment-delete{border:0;background:transparent;color:#a53b3b;cursor:pointer;padding:0}.comment-text{margin-top:8px;line-height:1.5}.comment-text p{margin:0 0 7px}.comments-empty{color:#71808d;font-style:italic}.comment-form{border-top:1px solid #dfe6ec;padding-top:15px}.comment-form label{display:block;font-weight:bold}.comment-form textarea{display:block;width:100%;margin:7px 0 10px;padding:10px;border:1px solid #bdcad5;border-radius:5px;font:inherit;resize:vertical}@media(max-width:900px){.shell{grid-template-columns:1fr}aside{display:none}.filters,.grid,.links{grid-template-columns:1fr}.page-head{display:block}.page-head>div+div{margin-top:12px}}

/* V15.6 · Tipografía del editor unificada con Wiki */
.form label{font-size:12px}
.form input,.form select,.form textarea{font-size:12px;line-height:1.42}
.editor-head h2{font-size:15px}
.editor-block .toolbar{gap:5px;padding:6px 8px}
.editor-block .toolbar button{padding:5px 8px;font-size:12px;line-height:1.2}
.editor-block textarea{
  min-height:430px;
  padding:10px 12px;
  font-family:Consolas,"Courier New",monospace;
  font-size:14px;
  line-height:20px;
  tab-size:4;
}
.comment-form textarea{
  font-family:Arial,sans-serif;
  font-size:13px;
  line-height:1.42;
}

/* V16.0 · Escala documental única (pantalla) */
:root{
  --doc-font-family:Arial,sans-serif;
  --doc-text-size:12px;
  --doc-h4-size:12px;
  --doc-h3-size:13px;
  --doc-h2-size:14px;
  --doc-h1-size:15px;
  --doc-code-size:11px;
  --doc-heading-color:#202124;
  --doc-h1-color:#EC0000;
  --doc-line-height:1.6;
}
.meta,.doc-meta,.page-meta{
  font-size:var(--doc-text-size);
}
article,.document-preview article,.template-preview-panel article,.content,.viewer,.editor-preview{
  font-family:var(--doc-font-family);
  font-size:var(--doc-text-size);
  line-height:var(--doc-line-height);
}
article h1,.document-preview h1,.template-preview-panel h1,.content h1,.viewer h1,.editor-preview h1{
  margin:12px 0 7px;
  color:var(--doc-h1-color);
  font-size:var(--doc-h1-size);
  font-weight:700;
  line-height:1.3;
}
article h2,.document-preview h2,.template-preview-panel h2,.content h2,.viewer h2,.editor-preview h2{
  margin:11px 0 6px;
  color:var(--doc-heading-color);
  font-size:var(--doc-h2-size);
  font-weight:700;
  line-height:1.3;
}
article h3,.document-preview h3,.template-preview-panel h3,.content h3,.viewer h3,.editor-preview h3{
  margin:10px 0 5px;
  color:var(--doc-heading-color);
  font-size:var(--doc-h3-size);
  font-weight:700;
  line-height:1.3;
}
article h4,.document-preview h4,.template-preview-panel h4,.content h4,.viewer h4,.editor-preview h4{
  margin:9px 0 5px;
  color:var(--doc-heading-color);
  font-size:var(--doc-h4-size);
  font-weight:700;
  font-style:italic;
  line-height:1.3;
}
article p,article li,article td,article th,
.document-preview p,.document-preview li,.document-preview td,.document-preview th,
.template-preview-panel p,.template-preview-panel li,.template-preview-panel td,.template-preview-panel th,
.content p,.content li,.content td,.content th,.viewer p,.editor-preview p{
  font-size:var(--doc-text-size);
  line-height:var(--doc-line-height);
}
article p,.document-preview p,.template-preview-panel p,.content p,.viewer p,.editor-preview p{margin:6px 0}
article ul,article ol,.document-preview ul,.document-preview ol,.template-preview-panel ul,.template-preview-panel ol,.content ul,.content ol{margin:6px 0;padding-left:22px}
article pre,article pre code,.code-box,.code-box code,.document-preview pre,.document-preview pre code,.template-preview-panel pre,.template-preview-panel pre code,.content pre,.content pre code{
  font-family:Consolas,"Courier New",monospace;
  font-size:var(--doc-code-size);
  line-height:1.45;
}
article table,.document-preview table,.template-preview-panel table,.content table{width:100%;border-collapse:collapse;font-size:var(--doc-text-size)}
article th,article td,.document-preview th,.document-preview td,.template-preview-panel th,.template-preview-panel td,.content th,.content td{padding:6px 8px;border:1px solid #a2a9b1;text-align:left;vertical-align:top}
article th,.document-preview th,.template-preview-panel th,.content th{background:#eaecf0;font-weight:700}

.text-indent{white-space:pre;display:inline}

/* V19.4 · Espaciado semántico; no se aplica al código */
.content h1{margin:22px 0 8px;color:#145ca8;font-size:14px;font-weight:700}
.content h2{margin:18px 0 6px;font-size:13px;font-weight:700}
.content h3{margin:14px 0 5px;font-size:12px;font-weight:700}
.content h4{margin:10px 0 4px;font-size:11px;font-weight:400;font-style:italic}
.content>p{margin:0 0 8px;padding:0}
.content>p+p{margin-top:2px}
.content ul,.content ol{margin:7px 0 9px;padding-left:24px}
.content blockquote{margin:10px 0 10px 14px;padding:7px 11px}
.content .admonition{margin:10px 0 10px 14px}
.content pre,.content code{font-family:Consolas,"Courier New",monospace;text-indent:0;letter-spacing:normal;word-spacing:normal}
.content pre{margin:12px 0;white-space:pre;line-height:1.45}
.content pre code{white-space:pre}

'''

if __name__=='__main__': ThreadingHTTPServer(('127.0.0.1',int(os.environ.get('BITACORA_PORT','8083'))),Handler).serve_forever()
