from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, quote
from pathlib import Path
from datetime import datetime, timezone
from email.parser import BytesParser
from email.policy import default as email_policy
from xml.etree import ElementTree as ET
import os, json, html, uuid, re, zipfile, shutil
import traceback

BASE=Path(__file__).resolve().parent
ROOT=BASE.parent.parent
DATA=BASE/'data'
TEMPLATES=DATA/'templates.json'
CATEGORIES=DATA/'categories.json'
WORD_FILES=DATA/'word_templates'
GENERATION_WORD_FILES=ROOT/'templates_word'
GENERATION_WORD_CONFIG=GENERATION_WORD_FILES/'config.json'

PORTAL_URL=os.environ.get('PORTAL_URL','http://127.0.0.1:8079')
WIKI_URL=os.environ.get('WIKI_URL','http://127.0.0.1:8080')
GESTOR_URL=os.environ.get('GESTOR_URL','http://127.0.0.1:8081')
BAU_URL=os.environ.get('BAU_URL','http://127.0.0.1:8082')
BITACORA_URL=os.environ.get('BITACORA_URL','http://127.0.0.1:8083')
BIBLIOTECA_URL=os.environ.get('BIBLIOTECA_URL','http://127.0.0.1:8084')
CAMBIOS_URL=os.environ.get('CAMBIOS_URL','http://127.0.0.1:8085')

def read(path,default):
    try:
        return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default
    except Exception:
        return default

def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(path)

def now(): return datetime.now().isoformat(timespec='seconds')
def esc(value): return html.escape(str(value or ''),quote=True)
def xml_escape(value): return html.escape(str(value or ''),quote=False)
def categories(): return [str(x).strip() for x in read(CATEGORIES,['CES','ProofPoint']) if str(x).strip()]
def templates():
    rows=read(TEMPLATES,[])
    return rows if isinstance(rows,list) else []
def find_item(item_id): return next((x for x in templates() if str(x.get('id'))==str(item_id)),None)

def logo_path():
    candidates=[ROOT/'configuracion'/'logo'/'logo.png']
    return next((p for p in candidates if p.is_file()),None)

def safe_filename(value):
    value=re.sub(r'[^\w\- .()]','_',str(value or ''),flags=re.UNICODE).strip(' .')
    return value[:120] or 'plantilla'

def document_path(item):
    filename=str(item.get('document_file') or f"{item.get('id','plantilla')}.docx").strip()
    path=(WORD_FILES/Path(filename).name).resolve()
    if WORD_FILES.resolve() not in path.parents:
        raise ValueError('Ruta no válida')
    return path

def open_local_path(path):
    """Abre un archivo o carpeta con la aplicación predeterminada del sistema."""
    path=Path(path).resolve()
    if not path.exists():
        raise FileNotFoundError(f'No se encuentra: {path}')
    if os.name=='nt':
        os.startfile(str(path))
        return
    if sys.platform=='darwin':
        subprocess.Popen(['open',str(path)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        return
    opener=shutil.which('xdg-open')
    if not opener:
        raise RuntimeError('No se encontró una aplicación para abrir el archivo.')
    subprocess.Popen([opener,str(path)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)


def plain_html(value):
    source=str(value or '')
    source=re.sub(r'(?is)<br\s*/?>','\n',source)
    source=re.sub(r'(?is)</(?:p|div|li|h[1-6])>','\n',source)
    source=re.sub(r'(?is)<[^>]+>','',source)
    return html.unescape(source).strip()

def paragraph_xml(text,bold=False):
    props='<w:rPr><w:b/></w:rPr>' if bold else ''
    return '<w:p><w:r>'+props+f'<w:t xml:space="preserve">{xml_escape(text)}</w:t></w:r></w:p>'

def create_docx(path,title,category,author='A. Garcia',version='1.0',body=''):
    path.parent.mkdir(parents=True,exist_ok=True)
    created=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    body_lines=[x.rstrip() for x in str(body or '').replace('\r\n','\n').split('\n')]
    parts=[
        paragraph_xml(title or 'Nueva plantilla',True),
        paragraph_xml(f'Categoría: {category or "General"}'),
        paragraph_xml(f'Autor: {author or "A. Garcia"}'),
        paragraph_xml(f'Versión: {version or "1.0"}'),
        paragraph_xml(f'Fecha: {datetime.now().strftime("%d/%m/%Y")}'),
        '<w:p/>',
    ]
    if body_lines and any(x.strip() for x in body_lines):
        parts.extend(paragraph_xml(line) if line else '<w:p/>' for line in body_lines)
    else:
        parts.extend([paragraph_xml('Contenido de la plantilla',True),paragraph_xml('Escriba aquí el contenido del documento.')])
    document_xml='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>%s<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>''' % ''.join(parts)
    content_types='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>'''
    rels='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>'''
    doc_rels='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>'''
    styles='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:sz w:val="20"/></w:rPr></w:rPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style></w:styles>'''
    core=f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>{xml_escape(title)}</dc:title><dc:creator>{xml_escape(author)}</dc:creator><cp:lastModifiedBy>{xml_escape(author)}</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">{created}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">{created}</dcterms:modified></cp:coreProperties>'''
    app='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Santander Mail Security</Application></Properties>'''
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('[Content_Types].xml',content_types)
        archive.writestr('_rels/.rels',rels)
        archive.writestr('word/document.xml',document_xml)
        archive.writestr('word/styles.xml',styles)
        archive.writestr('word/_rels/document.xml.rels',doc_rels)
        archive.writestr('docProps/core.xml',core)
        archive.writestr('docProps/app.xml',app)

def docx_text(path,limit=1800):
    try:
        with zipfile.ZipFile(path) as archive:
            data=archive.read('word/document.xml')
        root=ET.fromstring(data)
        ns='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
        paragraphs=[]
        for p in root.iter(ns+'p'):
            chunks=[]
            for node in p.iter():
                if node.tag==ns+'t': chunks.append(node.text or '')
                elif node.tag==ns+'tab': chunks.append('\t')
                elif node.tag==ns+'br': chunks.append('\n')
            text=''.join(chunks).strip()
            if text: paragraphs.append(text)
        return '\n'.join(paragraphs)[:limit]
    except Exception:
        return ''

def valid_docx(data):
    try:
        from io import BytesIO
        with zipfile.ZipFile(BytesIO(data)) as archive:
            names=set(archive.namelist())
            return '[Content_Types].xml' in names and 'word/document.xml' in names
    except Exception:
        return False

def migrate_templates():
    WORD_FILES.mkdir(parents=True,exist_ok=True)
    rows=templates(); changed=False
    for item in rows:
        path=document_path(item)
        if not item.get('document_file'):
            item['document_file']=path.name; changed=True
        if not path.exists():
            create_docx(path,item.get('title','Plantilla'),item.get('category','General'),item.get('author','A. Garcia'),item.get('version','1.0'),plain_html(item.get('template','')))
            changed=True
        item.setdefault('author','A. Garcia'); item.setdefault('version','1.0'); item.setdefault('file_type','docx')
    if changed: write(TEMPLATES,rows)

CSS='''
:root{--red:#EC0000;--dark:#B30000;--soft:#FDECEC;--bg:#F7F7F7;--text:#242424;--muted:#666;--border:#D8D8D8;--font:"Santander Headline","Segoe UI",Arial,sans-serif}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:14px var(--font)}
header{height:58px;padding:6px 16px;background:#fff;border-bottom:4px solid var(--red);display:flex;justify-content:space-between;align-items:center;gap:16px}.brand{display:flex;align-items:center;gap:10px;font-size:20px;font-weight:600;min-width:0}.brand-logo{display:block;width:auto;height:auto;max-width:120px;max-height:38px;object-fit:contain}.brand span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.shell{display:grid;grid-template-columns:215px minmax(0,1fr);min-height:calc(100vh - 58px)}aside{background:#fff;border-right:1px solid var(--border);padding:18px 10px}nav a{display:block;padding:10px 12px;margin-bottom:5px;color:#3b3b3b;text-decoration:none;border-radius:6px}nav a:hover,nav a.active{background:var(--soft);color:var(--dark);border-left:4px solid var(--red);font-weight:700}
main{padding:12px 18px 30px;width:100%;max-width:none;margin:0}h1,h2{color:var(--dark)}h1{margin:0}.card{background:#fff;border:1px solid var(--border);border-radius:10px;padding:14px}.btn,button{display:inline-block;border:1px solid var(--red);border-radius:6px;padding:9px 13px;background:var(--red);color:#fff;text-decoration:none;cursor:pointer;font:inherit}.btn.secondary,button.secondary{background:#fff;color:var(--dark)}button.danger,.btn.danger{background:#8A0000;border-color:#8A0000}
.actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.page-tools{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin:0 0 10px}.search-card{margin-bottom:10px;padding:10px}.search{display:grid;grid-template-columns:minmax(260px,1fr) 220px auto;gap:8px}
input,select,textarea{width:100%;padding:10px;border:1px solid #B8B8B8;border-radius:6px;font:inherit;background:#fff}label{display:block;font-weight:700;margin:10px 0 5px}.form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 14px}.wide{grid-column:1/-1}
.template-list{display:grid;gap:9px}.template-card{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:14px;align-items:center;padding:13px 15px}.template-card h2{font-size:17px;margin:2px 0 6px}.template-card p{margin:0;color:#555}.meta{color:var(--muted);font-size:12px}.word-badge{display:inline-flex;align-items:center;gap:6px;background:#eaf2ff;color:#174a7e;border-radius:999px;padding:5px 9px;font-weight:700;font-size:12px}.empty{padding:24px;text-align:center;color:var(--muted)}
.detail-head{display:flex;justify-content:space-between;align-items:flex-start;gap:14px;flex-wrap:wrap;margin-bottom:10px}.preview{white-space:pre-wrap;line-height:1.5;max-height:520px;overflow:auto;background:#fafafa;border:1px solid #ddd;border-radius:7px;padding:14px}.observation{border-left:4px solid var(--red);background:#fafafa;padding:12px;margin:10px 0;border-radius:5px}.observation p{white-space:pre-wrap}.category-row{display:grid;grid-template-columns:minmax(0,1fr) auto auto;gap:8px;margin:8px 0}.inline{display:inline-block;margin:0}.help{font-size:12px;color:#666;margin-top:5px}.file-current{padding:10px;background:#f4f6f8;border-radius:7px;margin-top:5px}
@media(max-width:800px){.shell{grid-template-columns:1fr}aside{display:none}.search,.form-grid{grid-template-columns:1fr}.template-card{grid-template-columns:1fr}.brand-logo{max-width:90px}}
'''

def layout(body):
    links=[('Inicio',PORTAL_URL),('Wiki',WIKI_URL),('Proyectos y tareas',GESTOR_URL),('BAU',BAU_URL),('Bitácora',BITACORA_URL),('Biblioteca',BIBLIOTECA_URL),('Plantillas',CAMBIOS_URL)]
    nav=''.join(f'<a class="{"active" if name=="Plantillas" else ""}" href="{esc(url)}">{esc(name)}</a>' for name,url in links)
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Plantillas</title><style>{CSS}
.word-local-actions{{margin-top:10px}}
.file-current{{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}}
@media(max-width:700px){{.file-current{{align-items:flex-start;flex-direction:column}}}}
</style></head><body><header><div class="brand"><img class="brand-logo" src="/logo.png?v=27115" alt="Logo Santander"><span>Santander Mail Security · Plantillas <small style="font-size:10px;opacity:.8">V3.1</small></span></div><div class="actions"><a class="btn secondary" href="/">← Atrás</a><a class="btn secondary" href="{PORTAL_URL}">Portal</a></div></header><div class="shell"><aside><nav>{nav}</nav></aside><main>{body}</main></div></body></html>'''

def cambios_home(query='',category=''):
    migrate_templates(); rows=templates(); term=query.strip().casefold()
    if category: rows=[x for x in rows if x.get('category')==category]
    if term:
        rows=[x for x in rows if term in ' '.join([str(x.get('title','')),str(x.get('category','')),str(x.get('author','')),str(x.get('version','')),docx_text(document_path(x),500)]).casefold()]
    options='<option value="">Todas las categorías</option>'+''.join(f'<option value="{esc(c)}" {"selected" if c==category else ""}>{esc(c)}</option>' for c in categories())
    cards=[]
    for item in sorted(rows,key=lambda x:x.get('updated_at',''),reverse=True):
        intro=docx_text(document_path(item),360).replace('\n',' · ')
        cards.append(f'''<article class="card template-card"><div><div class="meta">{esc(item.get('category'))} · {esc(item.get('updated_at','').replace('T',' '))}</div><h2><a href="/view?id={esc(item.get('id'))}">{esc(item.get('title'))}</a></h2><p>{esc(intro or 'Documento Word sin texto detectable.')}</p><div class="meta">Autor: {esc(item.get('author','A. Garcia'))} · Versión: {esc(item.get('version','1.0'))}</div></div><div class="actions"><span class="word-badge">📄 Word</span><a class="btn" href="/download?id={esc(item.get('id'))}">Descargar</a><a class="btn secondary" href="/edit?id={esc(item.get('id'))}">Editar datos</a><form class="inline" method="post" action="/duplicate"><input type="hidden" name="id" value="{esc(item.get('id'))}"><button class="secondary">Duplicar</button></form><form class="inline" method="post" action="/delete" onsubmit="return confirm('¿Eliminar esta plantilla Word?')"><input type="hidden" name="id" value="{esc(item.get('id'))}"><button class="danger">Eliminar</button></form></div></article>''')
    return layout(f'''<div class="page-tools"><div><h1>Plantillas de cambios</h1><p class="help">Plantillas técnicas para documentar cambios.</p></div><div class="actions"><a class="btn" href="/new">+ Nueva plantilla de cambio</a><a class="btn secondary" href="/categories">Categorías</a><a class="btn secondary" href="/">← Plantillas</a></div></div><section class="card search-card"><form class="search"><input name="q" value="{esc(query)}" placeholder="Buscar por nombre, categoría, autor o contenido Word"><select name="category">{options}</select><button>Buscar</button></form></section><section class="template-list">{''.join(cards) if cards else '<div class="card empty">No hay plantillas Word que mostrar.</div>'}</section>''')


def module_home():
    body = """
    <div class="page-tools"><div><h1>Plantillas</h1>
    <p class="help">Seleccione el tipo de plantilla que desea administrar.</p></div></div>
    <section class="template-section-grid">
      <a class="template-section-card" href="/cambios">
        <span class="template-section-icon">🧩</span>
        <span><strong>Plantillas de cambios</strong>
        <small>Plantillas técnicas de cambios con categoría, autor, versión, observaciones y documento Word asociado.</small></span>
      </a>
      <a class="template-section-card" href="/word-templates">
        <span class="template-section-icon">📄</span>
        <span><strong>Plantillas Word para generar documentos</strong>
        <small>Archivos DOCX utilizados desde la Wiki al pulsar «Generar Word».</small></span>
      </a>
    </section>
    <style>
    .template-section-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}
    .template-section-card{display:flex;gap:16px;align-items:flex-start;padding:22px;background:#fff;border:1px solid #d6dbe0;border-radius:10px;text-decoration:none;color:#202124;box-shadow:0 2px 8px rgba(0,0,0,.05)}
    .template-section-card:hover{border-color:#ec0000;background:#fff8f8;text-decoration:none}
    .template-section-card strong{display:block;font-size:18px;color:#b30000;margin-bottom:7px}
    .template-section-card small{display:block;color:#5f6368;line-height:1.45}
    .template-section-icon{font-size:30px;line-height:1}
    @media(max-width:800px){.template-section-grid{grid-template-columns:1fr}}
    </style>
    """
    return layout(body)


def generation_word_config():
    GENERATION_WORD_FILES.mkdir(parents=True,exist_ok=True)
    try:
        data=json.loads(GENERATION_WORD_CONFIG.read_text(encoding='utf-8')) if GENERATION_WORD_CONFIG.exists() else {}
        return data if isinstance(data,dict) else {}
    except Exception:
        return {}


def save_generation_word_config(data):
    GENERATION_WORD_FILES.mkdir(parents=True,exist_ok=True)
    GENERATION_WORD_CONFIG.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')


def generation_word_name(name):
    name=Path(str(name or '')).name.strip()
    return name if name.lower().endswith('.docx') and name not in ('.','..') else None


def generation_word_templates_page(message=''):
    GENERATION_WORD_FILES.mkdir(parents=True,exist_ok=True)
    cfg=generation_word_config()
    default=Path(str(cfg.get('default',''))).name
    files=sorted(GENERATION_WORD_FILES.glob('*.docx'),key=lambda p:p.name.casefold())
    rows=[]
    for file in files:
        is_default=file.name==default
        default_action = (
            '<span class="tag">Predeterminada</span>'
            if is_default else
            '<form class="inline" method="post" action="/word-templates/default?name='+quote(file.name)+'"><button type="submit">Hacer predeterminada</button></form>'
        )
        rows.append(
            '<tr><td><strong>'+esc(file.name)+'</strong>'+(' <span class="tag">Predeterminada</span>' if is_default else '')+'</td>'
            '<td>'+str(max(1,file.stat().st_size//1024))+' KB</td>'
            '<td class="actions">'
            '<a class="btn" href="/word-templates/open?name='+quote(file.name)+'" target="word-template-action">📝 Editar en Word</a>'
            +default_action+
            '<form class="inline" method="post" action="/word-templates/delete" onsubmit="return confirm(\'¿Eliminar esta plantilla Word?\')">'
            '<input type="hidden" name="name" value="'+esc(file.name)+'"><button class="danger">Eliminar</button></form>'
            '</td></tr>'
        )
    notice='<div class="notice">'+esc(message)+'</div>' if message else ''
    table=''.join(rows) if rows else '<tr><td colspan="3">No hay plantillas Word para generar documentos.</td></tr>'
    body=(
        '<div class="page-tools"><div><h1>Plantillas Word para generar documentos</h1>'
        '<p class="help">Estas plantillas aparecen en la Wiki al utilizar «Generar Word».</p></div>'
        '<div class="actions"><a class="btn secondary" href="/">← Plantillas</a></div></div>'
        +notice+
        '<section class="card"><table><thead><tr><th>Plantilla</th><th>Tamaño</th><th>Acciones</th></tr></thead><tbody>'+table+'</tbody></table>'
        '<hr style="border:0;border-top:1px solid #ddd;margin:20px 0">'
        '<h2>Añadir o sustituir plantilla Word</h2>'
        '<p class="help">Al subir un DOCX con el mismo nombre se sustituye el archivo existente.</p>'
        '<form method="post" action="/word-templates/upload" enctype="multipart/form-data">'
        '<div class="actions"><input type="file" name="document" accept=".docx" required><button>Subir plantilla</button></div>'
        '</form><iframe name="word-template-action" hidden></iframe></section>'
    )
    return layout(body)


def form_page(item=None,error=''):
    item=item or {}
    options=''.join(f'<option value="{esc(c)}" {"selected" if c==item.get("category") else ""}>{esc(c)}</option>' for c in categories())
    current=(
        '<div class="file-current"><div>Documento actual: <strong>'
        +esc(item.get("document_name") or item.get("title")+".docx")
        +'</strong></div><div class="actions word-local-actions">'
        +'<a class="btn" href="/open-word?id='+esc(item.get("id"))+'" target="word-action-frame">📝 Editar en Word</a>'
        +'<a class="btn secondary" href="/open-folder" target="word-action-frame">📂 Abrir carpeta</a>'
        +'<a class="btn secondary" href="/download?id='+esc(item.get("id"))+'">Descargar</a>'
        +'</div><iframe name="word-action-frame" hidden></iframe></div>'
    ) if item.get('id') else ''
    return layout(f'''<div class="page-tools"><h1>{'Editar plantilla Word' if item.get('id') else 'Nueva plantilla Word'}</h1></div>{f'<div class="card">{esc(error)}</div>' if error else ''}<section class="card"><form method="post" action="/save" enctype="multipart/form-data"><input type="hidden" name="id" value="{esc(item.get('id'))}"><div class="form-grid"><label>Título<input name="title" value="{esc(item.get('title'))}" required maxlength="240"></label><label>Categoría<select name="category" required>{options}</select></label><label>Autor<input name="author" value="{esc(item.get('author','A. Garcia'))}" required></label><label>Versión<input name="version" value="{esc(item.get('version','1.0'))}" required></label><label class="wide">Archivo Word (.docx)<input type="file" name="document" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document"></label><div class="wide help">{'Seleccione un DOCX para sustituir el actual o déjelo vacío para conservarlo.' if item.get('id') else 'Seleccione un archivo DOCX o cree una plantilla vacía.'}</div><label class="wide"><input style="width:auto" type="checkbox" name="create_blank" value="1"> Crear documento Word vacío automáticamente</label>{current}</div><div class="actions" style="margin-top:14px"><button>Guardar</button><a class="btn secondary" href="/">Cancelar</a></div></form></section>''')

def view_page(item):
    preview=docx_text(document_path(item),12000)
    obs=[]
    for o in sorted(item.get('observations',[]),key=lambda x:x.get('updated_at',''),reverse=True):
        obs.append(f'''<div class="observation"><div class="meta">Modificada {esc(o.get('updated_at','').replace('T',' '))}</div><p>{esc(o.get('text'))}</p><div class="actions"><a class="btn secondary" href="/observation/edit?template_id={esc(item.get('id'))}&id={esc(o.get('id'))}">Editar</a><form method="post" action="/observation/delete"><input type="hidden" name="template_id" value="{esc(item.get('id'))}"><input type="hidden" name="id" value="{esc(o.get('id'))}"><button class="danger">Eliminar</button></form></div></div>''')
    return layout(f'''<div class="detail-head"><div><div class="meta">{esc(item.get('category'))} · Modificada {esc(item.get('updated_at','').replace('T',' '))}</div><h1>{esc(item.get('title'))}</h1><div class="meta">Autor: {esc(item.get('author'))} · Versión: {esc(item.get('version'))}</div></div><div class="actions"><a class="btn" href="/open-word?id={esc(item.get('id'))}" target="word-open-frame">📝 Editar en Word</a><a class="btn secondary" href="/open-folder" target="word-open-frame">📂 Abrir carpeta</a><a class="btn secondary" href="/download?id={esc(item.get('id'))}">Descargar Word</a><a class="btn secondary" href="/edit?id={esc(item.get('id'))}">Editar datos</a><iframe name="word-open-frame" hidden></iframe><form method="post" action="/duplicate"><input type="hidden" name="id" value="{esc(item.get('id'))}"><button class="secondary">Duplicar</button></form><form method="post" action="/delete" onsubmit="return confirm('¿Eliminar esta plantilla Word?')"><input type="hidden" name="id" value="{esc(item.get('id'))}"><button class="danger">Eliminar</button></form></div></div><section class="card"><h2>Vista previa del texto Word</h2><div class="preview">{esc(preview or 'No ha sido posible extraer texto del documento. Puede descargarlo para abrirlo en Word.')}</div></section><section class="card"><h2>Observaciones</h2><form method="post" action="/observation/save"><input type="hidden" name="template_id" value="{esc(item.get('id'))}"><textarea name="text" rows="4" placeholder="Añadir observación" required></textarea><button>Añadir observación</button></form>{''.join(obs) if obs else '<p class="empty">Sin observaciones.</p>'}</section>''')

def categories_page():
    rows=''.join(f'''<form class="category-row" method="post" action="/category/save"><input type="hidden" name="old" value="{esc(c)}"><input name="name" value="{esc(c)}" required><button>Guardar</button><button class="danger" formaction="/category/delete" onclick="return confirm('¿Eliminar categoría?')">Eliminar</button></form>''' for c in categories())
    return layout(f'''<div class="page-tools"><h1>Categorías</h1></div><section class="card"><h2>Añadir categoría</h2><form class="category-row" method="post" action="/category/save"><input type="hidden" name="old"><input name="name" placeholder="Nueva categoría" required><button>Añadir</button><span></span></form></section><section class="card"><h2>Categorías existentes</h2>{rows}</section>''')

def observation_form(item,obs):
    return layout(f'''<div class="page-tools"><h1>Editar observación</h1></div><section class="card"><form method="post" action="/observation/save"><input type="hidden" name="template_id" value="{esc(item.get('id'))}"><input type="hidden" name="id" value="{esc(obs.get('id'))}"><textarea name="text" rows="8" required>{esc(obs.get('text'))}</textarea><div class="actions"><button>Guardar</button><a class="btn secondary" href="/view?id={esc(item.get('id'))}">Cancelar</a></div></form></section>''')

class Handler(BaseHTTPRequestHandler):
    def send_html(self,text,status=200):
        data=text.encode('utf-8'); self.send_response(status); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def redirect(self,url):
        self.send_response(303)
        self.send_header('Location',url)
        self.send_header('Content-Length','0')
        self.send_header('Cache-Control','no-store')
        self.end_headers()
    def read_request(self):
        size=int(self.headers.get('Content-Length','0') or 0); data=self.rfile.read(size); content_type=self.headers.get('Content-Type',''); fields={}; files={}
        if content_type.startswith('multipart/form-data'):
            message=BytesParser(policy=email_policy).parsebytes(b'Content-Type: '+content_type.encode()+b'\r\nMIME-Version: 1.0\r\n\r\n'+data)
            for part in message.iter_parts():
                name=part.get_param('name',header='content-disposition'); filename=part.get_filename(); payload=part.get_payload(decode=True) or b''
                if not name: continue
                if filename: files[name]={'filename':Path(filename).name,'data':payload,'content_type':part.get_content_type()}
                else: fields[name]=payload.decode(part.get_content_charset() or 'utf-8','replace')
        else:
            fields={k:v[-1] for k,v in parse_qs(data.decode('utf-8','replace'),keep_blank_values=True).items()}
        return fields,files
    def serve_document(self,item):
        path=document_path(item)
        if not path.is_file(): return self.send_error(404)
        data=path.read_bytes(); name=safe_filename(item.get('title'))+'.docx'
        self.send_response(200); self.send_header('Content-Type','application/vnd.openxmlformats-officedocument.wordprocessingml.document'); self.send_header('Content-Disposition',f'attachment; filename="{name}"'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        migrate_templates(); u=urlparse(self.path); q=parse_qs(u.query)
        if u.path=='/logo.png':
            path=logo_path()
            if not path: return self.send_error(404)
            data=path.read_bytes(); self.send_response(200); self.send_header('Content-Type','image/png'); self.send_header('Cache-Control','no-cache, no-store, must-revalidate'); self.send_header('Content-Length',str(len(data))); self.end_headers(); return self.wfile.write(data)
        if u.path=='/': return self.send_html(module_home())
        if u.path=='/cambios': return self.send_html(cambios_home(q.get('q',[''])[0],q.get('category',[''])[0]))
        if u.path=='/word-templates':
            return self.send_html(generation_word_templates_page(q.get('message',[''])[0]))
        if u.path=='/word-templates/open':
            name=generation_word_name(q.get('name',[''])[0])
            path=GENERATION_WORD_FILES/name if name else None
            if not path or not path.is_file(): return self.send_error(404)
            try:
                open_local_path(path)
                self.send_response(204); self.send_header('Content-Length','0'); self.send_header('Cache-Control','no-store'); self.end_headers(); return
            except Exception as exc:
                return self.send_html(layout('<div class="card"><h1>No se pudo abrir Word</h1><p>'+esc(exc)+'</p></div>'),500)
        if u.path=='/new': return self.send_html(form_page())
        if u.path=='/edit':
            item=find_item(q.get('id',[''])[0]); return self.send_html(form_page(item) if item else layout('<h1>No encontrada</h1>'),200 if item else 404)
        if u.path=='/view':
            item=find_item(q.get('id',[''])[0]); return self.send_html(view_page(item) if item else layout('<h1>No encontrada</h1>'),200 if item else 404)
        if u.path=='/download':
            item=find_item(q.get('id',[''])[0]); return self.serve_document(item) if item else self.send_error(404)
        if u.path=='/open-word':
            item=find_item(q.get('id',[''])[0])
            if not item:
                return self.send_error(404)
            try:
                open_local_path(document_path(item))
                self.send_response(204)
                self.send_header('Cache-Control','no-store')
                self.end_headers()
                return
            except Exception as exc:
                return self.send_html(layout('<div class="card"><h1>No se pudo abrir Word</h1><p>'+esc(exc)+'</p></div>'),500)
        if u.path=='/open-folder':
            try:
                WORD_FILES.mkdir(parents=True,exist_ok=True)
                open_local_path(WORD_FILES)
                self.send_response(204)
                self.send_header('Cache-Control','no-store')
                self.end_headers()
                return
            except Exception as exc:
                return self.send_html(layout('<div class="card"><h1>No se pudo abrir la carpeta</h1><p>'+esc(exc)+'</p></div>'),500)
        if u.path=='/categories': return self.send_html(categories_page())
        if u.path=='/observation/edit':
            item=find_item(q.get('template_id',[''])[0]); obs=next((o for o in item.get('observations',[]) if str(o.get('id'))==q.get('id',[''])[0]),None) if item else None
            return self.send_html(observation_form(item,obs) if item and obs else layout('<h1>No encontrada</h1>'),200 if item and obs else 404)
        return self.send_html(layout('<h1>Página no encontrada</h1>'),404)
    def do_POST(self):
        try:
            return self._do_POST_impl()
        except (BrokenPipeError,ConnectionAbortedError,ConnectionResetError):
            return
        except Exception as exc:
            traceback.print_exc()
            try:
                message=(
                    '<div class="card"><h1>No se pudo guardar la plantilla Word</h1>'
                    '<p>Se produjo un error al procesar el formulario.</p>'
                    '<p style="white-space:pre-wrap;overflow-wrap:anywhere"><strong>Detalle:</strong> '
                    +esc(exc)+'</p>'
                    '<div class="actions"><a class="btn" href="/">Volver a Plantillas</a></div></div>'
                )
                return self.send_html(layout(message),500)
            except Exception:
                try:
                    data=('Error al guardar: '+str(exc)).encode('utf-8','replace')
                    self.send_response(500)
                    self.send_header('Content-Type','text/plain; charset=utf-8')
                    self.send_header('Content-Length',str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                except Exception:
                    return

    def _do_POST_impl(self):
        migrate_templates(); u=urlparse(self.path); fields,files=self.read_request()
        if u.path=='/word-templates/upload':
            upload=files.get('document')
            if not upload or not upload.get('data'):
                return self.send_html(generation_word_templates_page('Seleccione un archivo DOCX.'),400)
            name=generation_word_name(upload.get('filename',''))
            if not name or not valid_docx(upload['data']):
                return self.send_html(generation_word_templates_page('El archivo seleccionado no es un DOCX válido.'),400)
            GENERATION_WORD_FILES.mkdir(parents=True,exist_ok=True)
            (GENERATION_WORD_FILES/name).write_bytes(upload['data'])
            return self.redirect('/word-templates?message=Plantilla Word guardada correctamente.')
        if u.path=='/word-templates/default':
            name=generation_word_name(parse_qs(u.query).get('name',[''])[0])
            target=GENERATION_WORD_FILES/name if name else None
            if not target or not target.is_file():
                return self.send_html(generation_word_templates_page('La plantilla no existe.'),404)
            cfg=generation_word_config(); cfg['default']=name; save_generation_word_config(cfg)
            return self.redirect('/word-templates?message=Plantilla predeterminada actualizada.')
        if u.path=='/word-templates/delete':
            name=generation_word_name(fields.get('name',''))
            target=GENERATION_WORD_FILES/name if name else None
            if target and target.is_file(): target.unlink()
            cfg=generation_word_config()
            if cfg.get('default')==name:
                cfg.pop('default',None); save_generation_word_config(cfg)
            return self.redirect('/word-templates?message=Plantilla eliminada.')
        if u.path=='/save':
            rows=templates(); item_id=fields.get('id','').strip(); current=find_item(item_id) if item_id else None; stamp=now(); record=current or {'id':uuid.uuid4().hex,'created_at':stamp,'observations':[]}
            record.update({'category':fields.get('category','').strip(),'title':fields.get('title','').strip(),'author':fields.get('author','A. Garcia').strip() or 'A. Garcia','version':fields.get('version','1.0').strip() or '1.0','updated_at':stamp,'file_type':'docx'})
            if not record['category'] or not record['title']: return self.send_html(form_page(record,'Categoría y título son obligatorios.'),400)
            upload=files.get('document'); create_blank=fields.get('create_blank')=='1'; target=WORD_FILES/f"{record['id']}.docx"
            if upload and upload.get('data'):
                if not upload.get('filename','').lower().endswith('.docx') or not valid_docx(upload['data']): return self.send_html(form_page(record,'El archivo seleccionado no es un documento Word DOCX válido.'),400)
                target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(upload['data']); record['document_name']=upload.get('filename')
            elif create_blank:
                create_docx(target,record['title'],record['category'],record['author'],record['version']); record['document_name']=safe_filename(record['title'])+'.docx'
            elif current:
                old_path=document_path(current)
                if old_path.resolve()!=target.resolve():
                    if not old_path.exists():
                        return self.send_html(form_page(record,'No se encuentra el documento Word actual.'),400)
                    target.parent.mkdir(parents=True,exist_ok=True)
                    shutil.copy2(old_path,target)
                elif not target.exists():
                    return self.send_html(form_page(record,'No se encuentra el documento Word actual.'),400)
                record.setdefault('document_name',current.get('document_name') or safe_filename(record['title'])+'.docx')
            else:
                return self.send_html(form_page(record,'Seleccione un archivo DOCX o marque “Crear documento Word vacío”.'),400)
            record['document_file']=target.name; rows=[record if str(x.get('id'))==record['id'] else x for x in rows] if current else rows+[record]; write(TEMPLATES,rows); return self.redirect(f'/view?id={record["id"]}')
        if u.path=='/duplicate':
            item=find_item(fields.get('id',''))
            if item:
                rows=templates(); stamp=now(); copy_item=dict(item); copy_item['id']=uuid.uuid4().hex; copy_item['title']=f"{item.get('title','Plantilla')} - Copia"; copy_item['created_at']=stamp; copy_item['updated_at']=stamp; copy_item['observations']=[]; new_path=WORD_FILES/f"{copy_item['id']}.docx"; shutil.copy2(document_path(item),new_path); copy_item['document_file']=new_path.name; copy_item['document_name']=safe_filename(copy_item['title'])+'.docx'; rows.append(copy_item); write(TEMPLATES,rows); return self.redirect(f'/view?id={copy_item["id"]}')
            return self.redirect('/')
        if u.path=='/delete':
            item=find_item(fields.get('id',''))
            if item:
                try: document_path(item).unlink(missing_ok=True)
                except OSError: pass
            write(TEMPLATES,[x for x in templates() if str(x.get('id'))!=fields.get('id','')]); return self.redirect('/')
        if u.path=='/observation/save':
            rows=templates(); item=find_item(fields.get('template_id','')); oid=fields.get('id','').strip(); stamp=now()
            if not item: return self.redirect('/')
            observations=item.setdefault('observations',[]); existing=next((o for o in observations if str(o.get('id'))==oid),None) if oid else None
            if existing: existing.update({'text':fields.get('text','').strip(),'updated_at':stamp})
            else: observations.append({'id':uuid.uuid4().hex,'text':fields.get('text','').strip(),'created_at':stamp,'updated_at':stamp})
            item['updated_at']=stamp; write(TEMPLATES,rows); return self.redirect(f'/view?id={item["id"]}')
        if u.path=='/observation/delete':
            rows=templates(); item=find_item(fields.get('template_id',''))
            if item:
                item['observations']=[o for o in item.get('observations',[]) if str(o.get('id'))!=fields.get('id','')]; item['updated_at']=now(); write(TEMPLATES,rows); return self.redirect(f'/view?id={item["id"]}')
            return self.redirect('/')
        if u.path=='/category/save':
            old=fields.get('old','').strip(); name=fields.get('name','').strip(); cats=categories()
            if name:
                if old:
                    cats=[name if c==old else c for c in cats]; rows=templates()
                    for item in rows:
                        if item.get('category')==old: item['category']=name; item['updated_at']=now()
                    write(TEMPLATES,rows)
                elif name not in cats: cats.append(name)
                write(CATEGORIES,list(dict.fromkeys(cats)))
            return self.redirect('/categories')
        if u.path=='/category/delete':
            old=fields.get('old','').strip()
            if not any(x.get('category')==old for x in templates()): write(CATEGORIES,[c for c in categories() if c!=old])
            return self.redirect('/categories')
        return self.send_html(layout('<h1>Acción no válida</h1>'),404)
    def log_message(self,*args): pass

if __name__=='__main__':
    DATA.mkdir(parents=True,exist_ok=True); WORD_FILES.mkdir(parents=True,exist_ok=True)
    if not CATEGORIES.exists(): write(CATEGORIES,['CES','ProofPoint'])
    if not TEMPLATES.exists(): write(TEMPLATES,[])
    migrate_templates()
    ThreadingHTTPServer(('127.0.0.1',int(os.environ.get('CAMBIOS_PORT','8085'))),Handler).serve_forever()
