from __future__ import annotations

import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
import webbrowser
from pathlib import Path

BASE = Path(__file__).resolve().parent
APP = BASE / "app"
SERVERS = [
    ("Portal", APP / "portal.py", "PORTAL_PORT", 8079),
    ("Wiki", APP / "wiki/server.py", "WIKI_PORT", 8080),
    ("Gestor", APP / "gestor/server.py", "GESTOR_PORT", 8081),
    ("BAU", APP / "bau/server.py", "BAU_PORT", 8082),
    ("Bitácora", APP / "bitacora/server.py", "BITACORA_PORT", 8083),
    ("Biblioteca", APP / "biblioteca/server.py", "BIBLIOTECA_PORT", 8084),
    ("Plantillas", APP / "plantillas_cambios/server.py", "CAMBIOS_PORT", 8085),
]


def free_port(start: int, used: set[int] | None = None) -> int:
    used = used or set()
    for port in range(start, start + 100):
        if port in used:
            continue
        with socket.socket() as sock:
            try:
                sock.bind(("127.0.0.1", port))
                return port
            except OSError:
                pass
    raise RuntimeError("No hay puertos locales disponibles")


def ready(url: str, process: subprocess.Popen) -> bool:
    for _ in range(60):
        if process.poll() is not None:
            return False
        try:
            if urllib.request.urlopen(url, timeout=0.5).status < 500:
                return True
        except Exception:
            time.sleep(0.2)
    return False


def find_chromium_browser() -> tuple[str | None, str | None]:
    """Localiza primero Chrome en todas sus ubicaciones y solo después Edge/Chromium."""
    chrome_candidates: list[Path] = []
    fallback_candidates: list[tuple[Path, str]] = []

    if os.name == "nt":
        program_files = [
            os.environ.get("PROGRAMFILES"),
            os.environ.get("PROGRAMFILES(X86)"),
        ]
        local_app_data = os.environ.get("LOCALAPPDATA")

        # Chrome tiene prioridad absoluta. Se revisan primero todas sus rutas.
        if local_app_data:
            chrome_candidates.append(
                Path(local_app_data) / "Google/Chrome/Application/chrome.exe"
            )
        for root in filter(None, program_files):
            chrome_candidates.append(
                Path(root) / "Google/Chrome/Application/chrome.exe"
            )

        try:
            import winreg

            chrome_key_names = (
                r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe",
                r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe",
            )
            for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
                for key_name in chrome_key_names:
                    try:
                        with winreg.OpenKey(hive, key_name) as key:
                            value, _ = winreg.QueryValueEx(key, None)
                            if value:
                                chrome_candidates.append(Path(value.strip('"')))
                    except OSError:
                        pass
        except ImportError:
            pass

        for path in chrome_candidates:
            if path.is_file():
                return str(path), "Google Chrome"

        # Solo si Chrome no existe se buscan otros navegadores Chromium.
        if local_app_data:
            fallback_candidates.append(
                (Path(local_app_data) / "Microsoft/Edge/Application/msedge.exe", "Microsoft Edge")
            )
        for root in filter(None, program_files):
            fallback_candidates.append(
                (Path(root) / "Microsoft/Edge/Application/msedge.exe", "Microsoft Edge")
            )

        try:
            import winreg

            edge_key_names = (
                r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe",
                r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe",
            )
            for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
                for key_name in edge_key_names:
                    try:
                        with winreg.OpenKey(hive, key_name) as key:
                            value, _ = winreg.QueryValueEx(key, None)
                            if value:
                                fallback_candidates.append((Path(value.strip('"')), "Microsoft Edge"))
                    except OSError:
                        pass
        except ImportError:
            pass
    else:
        # En otros sistemas también se agotan primero todas las opciones de Chrome.
        for command in ("google-chrome", "google-chrome-stable"):
            found = shutil.which(command)
            if found:
                return found, "Google Chrome"
        for command, display_name in (
            ("chromium", "Chromium"),
            ("chromium-browser", "Chromium"),
            ("microsoft-edge", "Microsoft Edge"),
        ):
            found = shutil.which(command)
            if found:
                fallback_candidates.append((Path(found), display_name))

    for path, display_name in fallback_candidates:
        if path.is_file():
            return str(path), display_name
    return None, None


def open_managed_browser(url: str) -> tuple[subprocess.Popen | None, tempfile.TemporaryDirectory | None]:
    """Abre una instancia aislada. Su proceso termina al cerrar su ventana."""
    browser, display_name = find_chromium_browser()
    if not browser:
        print("Chrome o Edge no están disponibles. Se usará el navegador predeterminado.")
        webbrowser.open_new_tab(url)
        return None, None

    profile_dir = tempfile.TemporaryDirectory(prefix="tech_workspace_browser_")
    args = [
        browser,
        f"--user-data-dir={profile_dir.name}",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-session-crashed-bubble",
        "--new-window",
        url,
    ]
    try:
        creationflags = 0
        if os.name == "nt":
            creationflags = subprocess.CREATE_NEW_PROCESS_GROUP
        process = subprocess.Popen(
            args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creationflags,
        )
        print(f"Navegador administrado: {display_name}")
        print("Al cerrar esta ventana del navegador se cerrará también Santander Mail Security.")
        return process, profile_dir
    except OSError as exc:
        profile_dir.cleanup()
        print(f"No se pudo abrir {display_name}: {exc}")
        webbrowser.open_new_tab(url)
        return None, None


def stop_servers(processes: list[subprocess.Popen]) -> None:
    for process in processes:
        if process.poll() is None:
            process.terminate()

    deadline = time.time() + 4
    for process in processes:
        if process.poll() is None:
            try:
                process.wait(timeout=max(0.1, deadline - time.time()))
            except subprocess.TimeoutExpired:
                process.kill()


def main() -> int:
    if sys.version_info < (3, 10):
        print("Se necesita Python 3.10 o superior")
        return 1

    used: set[int] = set()
    ports: list[int] = []
    for _, _, _, preferred_port in SERVERS:
        port = free_port(preferred_port, used)
        used.add(port)
        ports.append(port)

    urls = [f"http://127.0.0.1:{port}" for port in ports]
    common_env = os.environ.copy()
    common_env.update(
        {
            "PORTAL_URL": urls[0],
            "WIKI_URL": urls[1],
            "GESTOR_URL": urls[2],
            "BAU_URL": urls[3],
            "BITACORA_URL": urls[4],
            "BIBLIOTECA_URL": urls[5],
            "CAMBIOS_URL": urls[6],
        }
    )

    server_processes: list[subprocess.Popen] = []
    browser_process: subprocess.Popen | None = None
    browser_profile: tempfile.TemporaryDirectory | None = None

    try:
        for (_, path, port_key, _), port in zip(SERVERS, ports):
            env = common_env.copy()
            env[port_key] = str(port)
            server_processes.append(
                subprocess.Popen(
                    [sys.executable, str(path)],
                    cwd=str(path.parent),
                    env=env,
                )
            )

        if not all(ready(url, proc) for url, proc in zip(urls, server_processes)):
            print("No se pudo iniciar la suite")
            return 1

        print("SANTANDER MAIL SECURITY iniciado")
        for server, url in zip(SERVERS, urls):
            print(f"{server[0]}: {url}")

        browser_process, browser_profile = open_managed_browser(urls[0])

        if browser_process is not None:
            # La instancia usa un perfil temporal independiente; al cerrar su última
            # ventana termina el proceso y podemos detener la suite con seguridad.
            while browser_process.poll() is None:
                if any(proc.poll() is not None for proc in server_processes):
                    print("Uno de los servidores se ha detenido inesperadamente.")
                    break
                time.sleep(0.5)
            print("Ventana de Santander Mail Security cerrada. Deteniendo servidores...")
        else:
            print("No se puede detectar el cierre del navegador predeterminado.")
            print("Cierre esta ventana o pulse Ctrl+C para detener Santander Mail Security.")
            while all(proc.poll() is None for proc in server_processes):
                time.sleep(0.5)

    except KeyboardInterrupt:
        print("Cerrando Santander Mail Security...")
    finally:
        stop_servers(server_processes)
        if browser_process is not None and browser_process.poll() is None:
            browser_process.terminate()
        if browser_profile is not None:
            try:
                browser_profile.cleanup()
            except OSError:
                pass

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
