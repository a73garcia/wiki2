"""Importador DOCX -> Wiki sin dependencias externas.

V26.2
- Importa exclusivamente el contenido del cuerpo principal (word/document.xml).
- Ignora por completo encabezados, pies de página, numeración y sus imágenes.
- Conserva el texto útil del cuerpo, sus títulos, listas, tablas, enlaces y formato básico.
- No recorre word/header*.xml ni word/footer*.xml bajo ninguna circunstancia.
"""
from __future__ import annotations

from io import BytesIO
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
from xml.etree import ElementTree as ET
import mimetypes
import re
import uuid

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
A = "http://schemas.openxmlformats.org/drawingml/2006/main"
V = "urn:schemas-microsoft-com:vml"
PR = "http://schemas.openxmlformats.org/package/2006/relationships"
NS = {"w": W, "r": R, "a": A, "v": V, "pr": PR}

# Única parte del DOCX permitida como origen del contenido importado.
# Los encabezados y pies (word/header*.xml y word/footer*.xml) se excluyen.
BODY_DOCUMENT_PART = "word/document.xml"
EXCLUDED_PAGE_PARTS = re.compile(r"^word/(?:header|footer)\d*\.xml$", re.I)


def read_body_document(z: ZipFile) -> bytes:
    """Devuelve únicamente el XML del cuerpo principal del Word."""
    if BODY_DOCUMENT_PART not in z.namelist():
        raise ValueError("El archivo no contiene un documento Word válido.")
    return z.read(BODY_DOCUMENT_PART)


def q(ns: str, name: str) -> str:
    return f"{{{ns}}}{name}"


def safe_ext(name: str, content_type: str = "") -> str:
    ext = Path(name).suffix.lower()
    if ext in {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tif", ".tiff", ".emf", ".wmf"}:
        return ext
    guessed = mimetypes.guess_extension(content_type or "")
    return guessed or ".png"


def rels_map(z: ZipFile) -> dict[str, dict[str, object]]:
    result: dict[str, dict[str, object]] = {}
    path = "word/_rels/document.xml.rels"
    if path not in z.namelist():
        return result
    root = ET.fromstring(z.read(path))
    for rel in root:
        rid = rel.attrib.get("Id", "")
        target = rel.attrib.get("Target", "")
        typ = rel.attrib.get("Type", "")
        result[rid] = {
            "target": target,
            "type": typ,
            "external": rel.attrib.get("TargetMode") == "External",
        }
    return result


def style_headings(z: ZipFile) -> dict[str, int]:
    result: dict[str, int] = {}
    if "word/styles.xml" not in z.namelist():
        return result
    root = ET.fromstring(z.read("word/styles.xml"))
    for st in root.findall("w:style", NS):
        sid = st.attrib.get(q(W, "styleId"), "")
        name = st.find("w:name", NS)
        label = name.attrib.get(q(W, "val"), "") if name is not None else ""
        text = (sid + " " + label).lower().replace("í", "i")
        match = re.search(r"(?:heading|titulo|title)\s*([1-3])", text)
        if match:
            result[sid] = int(match.group(1))
    return result


def paragraph_style(p: ET.Element) -> str:
    ppr = p.find("w:pPr", NS)
    if ppr is None:
        return ""
    ps = ppr.find("w:pStyle", NS)
    return ps.attrib.get(q(W, "val"), "") if ps is not None else ""


def paragraph_plain_text(p: ET.Element) -> str:
    return "".join(node.text or "" for node in p.findall(".//w:t", NS)).strip()


def is_toc_paragraph(p: ET.Element) -> bool:
    style = paragraph_style(p).lower().replace(" ", "")
    if style.startswith("toc") or style.startswith("tabladec") or style.startswith("indice"):
        return True
    instruction = " ".join((node.text or "") for node in p.findall(".//w:instrText", NS)).upper()
    return " TOC " in f" {instruction} " or instruction.strip().startswith("TOC ")


def run_properties(run: ET.Element) -> tuple[bool, bool, bool]:
    rp = run.find("w:rPr", NS)
    if rp is None:
        return False, False, False

    def enabled(name: str) -> bool:
        node = rp.find(f"w:{name}", NS)
        if node is None:
            return False
        val = (node.attrib.get(q(W, "val"), "true") or "true").lower()
        return val not in {"false", "0", "none"}

    return enabled("b"), enabled("i"), enabled("u")


def wrap_text(text: str, bold: bool, italic: bool, underline: bool) -> str:
    if not text:
        return ""
    if bold:
        text = f"**{text}**"
    if italic:
        text = f"''{text}''"
    if underline:
        text = f"[u]{text}[/u]"
    return text


def _relationship_member(rel: dict[str, object]) -> str | None:
    if rel.get("external"):
        return None
    target = str(rel.get("target", "")).replace("\\", "/")
    if not target:
        return None
    # Los targets de document.xml.rels son relativos a /word/document.xml.
    member = str(PurePosixPath("word") / PurePosixPath(target))
    parts: list[str] = []
    for part in PurePosixPath(member).parts:
        if part == "..":
            if parts:
                parts.pop()
        elif part not in {".", ""}:
            parts.append(part)
    return "/".join(parts)


def extract_image(z: ZipFile, rel: dict[str, object], uploads: Path, index: int) -> str | None:
    member = _relationship_member(rel)
    if not member or member not in z.namelist():
        return None
    ext = safe_ext(member)
    filename = f"word_import_{uuid.uuid4().hex[:12]}_{index:03d}{ext}"
    uploads.mkdir(parents=True, exist_ok=True)
    (uploads / filename).write_bytes(z.read(member))
    return filename


def image_markup(
    node: ET.Element,
    z: ZipFile,
    rels: dict[str, dict[str, object]],
    uploads: Path,
    image_counter: list[int],
) -> str:
    rid = ""
    if node.tag == q(A, "blip"):
        rid = node.attrib.get(q(R, "embed"), "") or node.attrib.get(q(R, "link"), "")
    elif node.tag == q(V, "imagedata"):
        rid = node.attrib.get(q(R, "id"), "")
    if not rid or rid not in rels:
        return ""
    image_counter[0] += 1
    filename = extract_image(z, rels[rid], uploads, image_counter[0])
    if not filename:
        return ""
    return f"\n[[imagen:{filename}|Imagen importada de Word]]\n"


def render_run(
    run: ET.Element,
    z: ZipFile,
    rels: dict[str, dict[str, object]],
    uploads: Path,
    image_counter: list[int],
) -> str:
    bold, italic, underline = run_properties(run)
    chunks: list[str] = []
    text_buffer: list[str] = []

    def flush_text() -> None:
        if text_buffer:
            chunks.append(wrap_text("".join(text_buffer), bold, italic, underline))
            text_buffer.clear()

    # iter() mantiene el orden XML. Así la imagen queda donde estaba en Word.
    for node in run.iter():
        if node is run:
            continue
        if node.tag == q(W, "t"):
            text_buffer.append(node.text or "")
        elif node.tag == q(W, "tab"):
            text_buffer.append("\t")
        elif node.tag in {q(W, "br"), q(W, "cr")}:
            text_buffer.append("\n")
        elif node.tag in {q(A, "blip"), q(V, "imagedata")}:
            flush_text()
            marker = image_markup(node, z, rels, uploads, image_counter)
            if marker:
                chunks.append(marker)
    flush_text()
    return "".join(chunks)


def render_container(
    container: ET.Element,
    z: ZipFile,
    rels: dict[str, dict[str, object]],
    uploads: Path,
    image_counter: list[int],
) -> str:
    chunks: list[str] = []
    for child in list(container):
        if child.tag == q(W, "r"):
            chunks.append(render_run(child, z, rels, uploads, image_counter))
        elif child.tag == q(W, "hyperlink"):
            label = render_container(child, z, rels, uploads, image_counter).strip()
            rid = child.attrib.get(q(R, "id"), "")
            url = str(rels.get(rid, {}).get("target", "")) if rid else ""
            chunks.append(f"[{url} {label}]" if url and label else label)
        elif child.tag in {q(W, "smartTag"), q(W, "sdt"), q(W, "customXml"), q(W, "ins")}:
            chunks.append(render_container(child, z, rels, uploads, image_counter))
    return "".join(chunks)


def paragraph_to_wiki(
    p: ET.Element,
    z: ZipFile,
    rels: dict[str, dict[str, object]],
    headings: dict[str, int],
    uploads: Path,
    image_counter: list[int],
) -> tuple[str, int | None]:
    heading = headings.get(paragraph_style(p))
    text = render_container(p, z, rels, uploads, image_counter).strip()
    if not text:
        return "", heading
    if heading:
        marks = "=" * (heading + 1)
        return f"{marks} {text} {marks}", heading
    return text, None



INDEX_TITLES = {
    "index", "índice", "indice", "table of contents", "contents",
    "tabla de contenido", "tabla de contenidos", "contenido"
}

COVER_STYLE_WORDS = {
    "title", "titulo", "título", "subtitle", "subtitulo", "subtítulo",
    "cover", "portada"
}


def normalized_text(value: str) -> str:
    value = str(value or "").strip().casefold()
    value = value.replace("í", "i").replace("á", "a").replace("é", "e")
    value = value.replace("ó", "o").replace("ú", "u")
    return re.sub(r"\s+", " ", value)


def is_index_title_paragraph(p: ET.Element) -> bool:
    text = normalized_text(paragraph_plain_text(p))
    if text in {normalized_text(x) for x in INDEX_TITLES}:
        return True
    style = normalized_text(paragraph_style(p)).replace(" ", "")
    return style in {"toctitle", "indextitle", "indicetitle", "tablacontenido"}


def is_cover_paragraph(p: ET.Element) -> bool:
    style = normalized_text(paragraph_style(p))
    return any(word in style for word in COVER_STYLE_WORDS)


def body_start_position(children: list[ET.Element], headings: dict[str, int]) -> int:
    """Calcula dónde empieza el contenido real del documento.

    Prioridad:
    1. Primer Título 1 posterior al último párrafo del índice/TOC.
    2. Primer Título 1 que no sea «Índice».
    3. Primer párrafo significativo que no sea portada.
    """
    toc_positions = [
        index for index, child in enumerate(children)
        if child.tag == q(W, "p") and (is_toc_paragraph(child) or is_index_title_paragraph(child))
    ]
    after_toc = (max(toc_positions) + 1) if toc_positions else 0

    for index in range(after_toc, len(children)):
        child = children[index]
        if child.tag != q(W, "p"):
            continue
        if headings.get(paragraph_style(child)) == 1 and not is_index_title_paragraph(child):
            return index

    for index, child in enumerate(children):
        if child.tag != q(W, "p"):
            continue
        if headings.get(paragraph_style(child)) == 1 and not is_index_title_paragraph(child):
            return index

    for index in range(after_toc, len(children)):
        child = children[index]
        if child.tag != q(W, "p"):
            continue
        if is_toc_paragraph(child) or is_index_title_paragraph(child) or is_cover_paragraph(child):
            continue
        if paragraph_plain_text(child):
            return index

    return len(children)


def import_docx(raw: bytes, uploads: Path) -> dict[str, object]:
    with ZipFile(BytesIO(raw), "r") as z:
        # Solo se analiza word/document.xml. Los encabezados y pies de página
        # (word/header*.xml y word/footer*.xml) nunca se recorren ni se importan.
        document_xml = read_body_document(z)

        rels = rels_map(z)
        headings = style_headings(z)
        root = ET.fromstring(document_xml)
        body = root.find("w:body", NS)
        if body is None:
            raise ValueError("El documento Word no contiene cuerpo.")

        children = list(body)
        start_at = body_start_position(children, headings)
        blocks: list[str] = []
        image_counter = [0]
        first_heading = ""

        for index, child in enumerate(children):
            if index < start_at:
                # Excluye portada, tabla de revisiones, índice y cualquier
                # contenido anterior al cuerpo real.
                continue

            if child.tag == q(W, "p"):
                if is_toc_paragraph(child) or is_index_title_paragraph(child):
                    continue

                text, detected_heading = paragraph_to_wiki(
                    child, z, rels, headings, uploads, image_counter
                )
                if text:
                    if not first_heading and detected_heading == 1:
                        first_heading = re.sub(r"^==\s*|\s*==$", "", text).strip()
                    blocks.append(text)

            elif child.tag == q(W, "tbl"):
                rows: list[list[str]] = []
                for tr in child.findall("w:tr", NS):
                    cells: list[str] = []
                    for tc in tr.findall("w:tc", NS):
                        parts: list[str] = []
                        for p in tc.findall("w:p", NS):
                            if is_toc_paragraph(p) or is_index_title_paragraph(p):
                                continue
                            value, _ = paragraph_to_wiki(
                                p, z, rels, headings, uploads, image_counter
                            )
                            if value:
                                parts.append(value)
                        cells.append(" ".join(parts).replace("|", "\\|"))
                    if cells:
                        rows.append(cells)

                if rows:
                    width = max(len(row) for row in rows)
                    rows = [row + [""] * (width - len(row)) for row in rows]
                    table = (
                        "| " + " | ".join(rows[0]) + " |\n"
                        "| " + " | ".join(["---"] * width) + " |\n" +
                        "\n".join("| " + " | ".join(row) + " |" for row in rows[1:])
                    )
                    blocks.append(table)

        title = first_heading or "Documento importado"
        return {
            "title": title,
            "content": "\n\n".join(blocks).strip(),
            "images": image_counter[0],
        }

