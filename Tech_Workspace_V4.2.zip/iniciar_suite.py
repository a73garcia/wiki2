from __future__ import annotations

import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
import webbrowser
from pathlib import Path

BASE = Path(__file__).resolve().parent
SERVERS = [
    ("Portal", BASE / "portal.py", "PORTAL_PORT", 8079),
    ("Wiki", BASE / "wiki/server.py", "WIKI_PORT", 8080),
    ("Gestor", BASE / "gestor/server.py", "GESTOR_PORT", 8081),
]


def free_port(start: int, used: set[int] | None = None) -> int:
    used = used or set()
    for port in range(start, start + 100):
        if port in used:
            continue
        with socket.socket() as sock:
            try:
                sock.bind(("127.0.0.1", port))
                return port
            except OSError:
                pass
    raise RuntimeError("No hay puertos locales disponibles")


def ready(url: str, process: subprocess.Popen) -> bool:
    for _ in range(60):
        if process.poll() is not None:
            return False
        try:
            if urllib.request.urlopen(url, timeout=0.5).status < 500:
                return True
        except Exception:
            time.sleep(0.2)
    return False


def find_chromium_browser() -> tuple[str | None, str | None]:
    """Devuelve (ruta, nombre) priorizando Chrome y después Edge/Chromium."""
    candidates: list[tuple[Path, str]] = []

    if os.name == "nt":
        roots = [
            os.environ.get("PROGRAMFILES"),
            os.environ.get("PROGRAMFILES(X86)"),
            os.environ.get("LOCALAPPDATA"),
        ]
        for root in filter(None, roots):
            base = Path(root)
            candidates.extend(
                [
                    (base / "Google/Chrome/Application/chrome.exe", "Google Chrome"),
                    (base / "Microsoft/Edge/Application/msedge.exe", "Microsoft Edge"),
                ]
            )

        try:
            import winreg

            app_paths = (
                ("chrome.exe", "Google Chrome"),
                ("msedge.exe", "Microsoft Edge"),
            )
            for executable, display_name in app_paths:
                key_names = (
                    rf"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\{executable}",
                    rf"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\{executable}",
                )
                for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
                    for key_name in key_names:
                        try:
                            with winreg.OpenKey(hive, key_name) as key:
                                value, _ = winreg.QueryValueEx(key, None)
                                if value:
                                    candidates.append((Path(value.strip('"')), display_name))
                        except OSError:
                            pass
        except ImportError:
            pass
    else:
        for command, display_name in (
            ("google-chrome", "Google Chrome"),
            ("google-chrome-stable", "Google Chrome"),
            ("chromium", "Chromium"),
            ("chromium-browser", "Chromium"),
            ("microsoft-edge", "Microsoft Edge"),
        ):
            found = shutil.which(command)
            if found:
                candidates.append((Path(found), display_name))

    for path, display_name in candidates:
        if path.is_file():
            return str(path), display_name
    return None, None


def open_managed_browser(url: str) -> tuple[subprocess.Popen | None, tempfile.TemporaryDirectory | None]:
    """Abre una instancia aislada. Su proceso termina al cerrar su ventana."""
    browser, display_name = find_chromium_browser()
    if not browser:
        print("Chrome o Edge no están disponibles. Se usará el navegador predeterminado.")
        webbrowser.open_new_tab(url)
        return None, None

    profile_dir = tempfile.TemporaryDirectory(prefix="tech_workspace_browser_")
    args = [
        browser,
        f"--user-data-dir={profile_dir.name}",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-session-crashed-bubble",
        "--new-window",
        url,
    ]
    try:
        creationflags = 0
        if os.name == "nt":
            creationflags = subprocess.CREATE_NEW_PROCESS_GROUP
        process = subprocess.Popen(
            args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creationflags,
        )
        print(f"Navegador administrado: {display_name}")
        print("Al cerrar esta ventana del navegador se cerrará también Tech Workspace.")
        return process, profile_dir
    except OSError as exc:
        profile_dir.cleanup()
        print(f"No se pudo abrir {display_name}: {exc}")
        webbrowser.open_new_tab(url)
        return None, None


def stop_servers(processes: list[subprocess.Popen]) -> None:
    for process in processes:
        if process.poll() is None:
            process.terminate()

    deadline = time.time() + 4
    for process in processes:
        if process.poll() is None:
            try:
                process.wait(timeout=max(0.1, deadline - time.time()))
            except subprocess.TimeoutExpired:
                process.kill()


def main() -> int:
    if sys.version_info < (3, 10):
        print("Se necesita Python 3.10 o superior")
        return 1

    used: set[int] = set()
    ports: list[int] = []
    for _, _, _, preferred_port in SERVERS:
        port = free_port(preferred_port, used)
        used.add(port)
        ports.append(port)

    urls = [f"http://127.0.0.1:{port}" for port in ports]
    common_env = os.environ.copy()
    common_env.update(
        {
            "PORTAL_URL": urls[0],
            "WIKI_URL": urls[1],
            "GESTOR_URL": urls[2],
        }
    )

    server_processes: list[subprocess.Popen] = []
    browser_process: subprocess.Popen | None = None
    browser_profile: tempfile.TemporaryDirectory | None = None

    try:
        for (_, path, port_key, _), port in zip(SERVERS, ports):
            env = common_env.copy()
            env[port_key] = str(port)
            server_processes.append(
                subprocess.Popen(
                    [sys.executable, str(path)],
                    cwd=str(path.parent),
                    env=env,
                )
            )

        if not all(ready(url, proc) for url, proc in zip(urls, server_processes)):
            print("No se pudo iniciar la suite")
            return 1

        print("TECH WORKSPACE V4.2 iniciado")
        for server, url in zip(SERVERS, urls):
            print(f"{server[0]}: {url}")

        browser_process, browser_profile = open_managed_browser(urls[0])

        if browser_process is not None:
            # La instancia usa un perfil temporal independiente; al cerrar su última
            # ventana termina el proceso y podemos detener la suite con seguridad.
            while browser_process.poll() is None:
                if any(proc.poll() is not None for proc in server_processes):
                    print("Uno de los servidores se ha detenido inesperadamente.")
                    break
                time.sleep(0.5)
            print("Ventana de Tech Workspace cerrada. Deteniendo servidores...")
        else:
            print("No se puede detectar el cierre del navegador predeterminado.")
            print("Cierre esta ventana o pulse Ctrl+C para detener Tech Workspace.")
            while all(proc.poll() is None for proc in server_processes):
                time.sleep(0.5)

    except KeyboardInterrupt:
        print("Cerrando Tech Workspace...")
    finally:
        stop_servers(server_processes)
        if browser_process is not None and browser_process.poll() is None:
            browser_process.terminate()
        if browser_profile is not None:
            try:
                browser_profile.cleanup()
            except OSError:
                pass

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
