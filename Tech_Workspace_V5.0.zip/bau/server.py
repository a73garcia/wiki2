from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, urlencode, quote
from pathlib import Path
from datetime import datetime
import os, json, html, re, uuid, mimetypes

BASE=Path(__file__).resolve().parent
DATA=BASE/'data'; DB=DATA/'requests.json'; ATT=DATA/'attachments'; STATIC=BASE/'static'
DATA.mkdir(exist_ok=True); ATT.mkdir(parents=True,exist_ok=True)
PORTAL_URL=os.environ.get('PORTAL_URL','http://127.0.0.1:8079')
WIKI_URL=os.environ.get('WIKI_URL','http://127.0.0.1:8080')
GESTOR_URL=os.environ.get('GESTOR_URL','http://127.0.0.1:8081')
STATUSES=['Nueva','En curso','Pendiente','Resuelta','Cerrada']
PRIORITIES=['Baja','Media','Alta','Crítica']
TYPES=['Petición','Incidencia','Consulta','Cambio','Problema']
SYSTEMS=['Cisco ESA','Proofpoint','Splunk','CrowdStrike','Microsoft','Windows','Linux','Redes','Otro']

def esc(v): return html.escape(str(v or ''),quote=True)
def load():
    try:return json.loads(DB.read_text(encoding='utf-8')) if DB.exists() else []
    except Exception:return []
def save(rows): DB.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
def now(): return datetime.now().isoformat(timespec='seconds')
def next_number(rows):
    year=datetime.now().year; nums=[]
    for r in rows:
        m=re.fullmatch(rf'BAU-{year}-(\d+)',r.get('number',''))
        if m: nums.append(int(m.group(1)))
    return f'BAU-{year}-{(max(nums,default=0)+1):06d}'
def getone(rid): return next((x for x in load() if x.get('id')==rid),None)
def render(text):
    s=esc(text)
    s=re.sub(r'```([^\n]*)\n(.*?)```',lambda m:f'<pre><code>{m.group(2)}</code></pre>',s,flags=re.S)
    s=re.sub(r'^### (.+)$',r'<h3>\1</h3>',s,flags=re.M); s=re.sub(r'^## (.+)$',r'<h2>\1</h2>',s,flags=re.M); s=re.sub(r'^# (.+)$',r'<h1>\1</h1>',s,flags=re.M)
    s=re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',s); s=re.sub(r'__(.+?)__',r'<u>\1</u>',s)
    s=re.sub(r'\[([^\]]+)\]\((https?://[^)]+)\)',r'<a href="\2" target="_blank">\1</a>',s)
    parts=[]
    for block in re.split(r'\n\s*\n',s):
        if block.startswith(('<h','<pre','<ul','<ol')): parts.append(block)
        else: parts.append('<p>'+block.replace('\n','<br>')+'</p>')
    return ''.join(parts)
def badge(v,kind=''): return f'<span class="badge {kind} {esc(v).lower().replace("í","i").replace("á","a").replace(" ","-")}">{esc(v)}</span>'
def options(values,current=''): return ''.join(f'<option {"selected" if x==current else ""}>{esc(x)}</option>' for x in values)
def layout(title,body,active='bau'):
    links=[('Inicio',PORTAL_URL),('Wiki',WIKI_URL),('Proyectos y tareas',GESTOR_URL),('BAU','/')]
    nav=''.join(f'<a class="{"active" if n.lower().startswith(active) else ""}" href="{esc(u)}">{esc(n)}</a>' for n,u in links)
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)} · BAU</title><link rel="stylesheet" href="/static/style.css"></head><body><header><div class="brand">Tech Workspace · BAU</div><div class="header-actions"><a class="btn" href="{esc(PORTAL_URL)}">Inicio común</a><a class="btn primary" href="/new">+ Nueva BAU</a></div></header><div class="shell"><aside><nav>{nav}</nav><div class="aside-note">Aplicación local<br>Sin usuarios<br>Datos en JSON</div></aside><main>{body}</main></div><script src="/static/editor.js"></script></body></html>'''

def dashboard(qs):
    rows=load(); status=qs.get('status',[''])[0]; term=qs.get('q',[''])[0].strip().casefold()
    filtered=[r for r in rows if (not status or r.get('status')==status) and (not term or term in ' '.join(str(r.get(k,'')) for k in ('number','title','request','resolution','owner','requester','system')).casefold())]
    filtered.sort(key=lambda x:x.get('opened',''),reverse=True)
    stats=''.join(f'<a class="stat" href="/?status={quote(s)}"><strong>{sum(1 for r in rows if r.get("status")==s)}</strong><span>{esc(s)}</span></a>' for s in STATUSES)
    trs=''.join(f'''<tr><td><a href="/view?id={esc(r['id'])}"><strong>{esc(r.get('number'))}</strong></a></td><td><a href="/view?id={esc(r['id'])}">{esc(r.get('title'))}</a></td><td>{badge(r.get('type'))}</td><td>{badge(r.get('status'))}</td><td>{badge(r.get('priority'),'priority')}</td><td>{esc(r.get('system'))}</td><td>{esc(r.get('opened'))}</td></tr>''' for r in filtered) or '<tr><td colspan="7" class="empty">No hay registros.</td></tr>'
    body=f'''<div class="page-head"><div><h1>Gestión BAU</h1><p>Control de peticiones, incidencias, consultas, cambios y problemas operativos.</p></div></div><div class="stats">{stats}</div><section class="card"><form class="filters" method="get"><input name="q" value="{esc(qs.get('q',[''])[0])}" placeholder="Número, título, sistema, solicitud o resolución"><select name="status"><option value="">Todos los estados</option>{options(STATUSES,status)}</select><button class="btn">Filtrar</button><a class="btn ghost" href="/">Limpiar</a></form></section><section class="card"><div class="section-head"><h2>Registros BAU</h2><a class="btn primary" href="/new">+ Nueva BAU</a></div><div class="table-wrap"><table><thead><tr><th>Número</th><th>Título</th><th>Tipo</th><th>Estado</th><th>Prioridad</th><th>Sistema</th><th>Fecha</th></tr></thead><tbody>{trs}</tbody></table></div></section>'''
    return layout('Gestión BAU',body)

def form_page(r=None):
    r=r or {}; editing=bool(r); action='/save';
    body=f'''<div class="page-head"><div><h1>{'Editar' if editing else 'Nueva'} BAU</h1><p>La solicitud, investigación y resolución utilizan un editor técnico similar al de la Wiki.</p></div></div><form class="card form" method="post" action="{action}" enctype="multipart/form-data"><input type="hidden" name="id" value="{esc(r.get('id'))}"><div class="grid"><label>Número<input name="number" value="{esc(r.get('number'))}" placeholder="Se genera automáticamente"></label><label>Fecha apertura<input type="date" name="opened" value="{esc(r.get('opened') or datetime.now().date())}" required></label><label>Estado<select name="status">{options(STATUSES,r.get('status','Nueva'))}</select></label><label>Prioridad<select name="priority">{options(PRIORITIES,r.get('priority','Media'))}</select></label><label>Tipo<select name="type">{options(TYPES,r.get('type','Petición'))}</select></label><label>Sistema<select name="system">{options(SYSTEMS,r.get('system','Otro'))}</select></label><label>Solicitante<input name="requester" value="{esc(r.get('requester'))}"></label><label>Responsable<input name="owner" value="{esc(r.get('owner'))}"></label></div><label>Título / breve descripción<input name="title" value="{esc(r.get('title'))}" required maxlength="180"></label>{editor_field('Solicitud','request',r.get('request',''))}{editor_field('Investigación','investigation',r.get('investigation',''))}{editor_field('Resolución','resolution',r.get('resolution',''))}<div class="grid"><label>Fecha resolución<input type="date" name="resolved" value="{esc(r.get('resolved'))}"></label><label>Proyecto relacionado (ID o enlace)<input name="project_link" value="{esc(r.get('project_link'))}" placeholder="ID del proyecto o URL"></label><label>Wiki relacionada (slug o enlace)<input name="wiki_link" value="{esc(r.get('wiki_link'))}" placeholder="Slug del documento o URL"></label><label>Enlace externo adicional<input name="external_link" value="{esc(r.get('external_link'))}" placeholder="https://..."></label></div><section class="attachments-editor"><h2>📎 Adjuntos</h2><p>Selecciona uno o varios archivos. Se copiarán dentro del Workspace al guardar.</p><input type="file" name="attachments" multiple><div class="grid"><label>Nombre del vínculo externo<input name="external_name" placeholder="SharePoint, carpeta, documento..."></label><label>Ruta o URL externa<input name="external_target" placeholder="C:\\... | \\\\servidor\\... | https://..."></label></div></section><div class="actions"><button class="btn primary">Guardar BAU</button><a class="btn ghost" href="/">Cancelar</a></div></form>'''
    return layout('Editor BAU',body)
def editor_field(label,name,value):
    return f'''<section class="editor-block"><div class="editor-head"><h2>{label}</h2><div class="toolbar" data-target="{name}"><button type="button" data-wrap="**">B</button><button type="button" data-prefix="# ">H1</button><button type="button" data-prefix="## ">H2</button><button type="button" data-code="1">Código</button><button type="button" data-indent="1">Tab +4</button><button type="button" data-outdent="1">Quitar tab</button></div></div><textarea id="{name}" name="{name}" rows="10">{esc(value)}</textarea></section>'''

def view_page(r):
    attachments=''.join(attachment_row(r,a) for a in r.get('attachments',[])) or '<p class="empty">No hay adjuntos.</p>'
    comments=''.join(f'<li><strong>{esc(c.get("date"))}</strong><div>{render(c.get("text",""))}</div></li>' for c in reversed(r.get('comments',[]))) or '<li class="empty">Sin comentarios.</li>'
    links=[]
    pl=r.get('project_link',''); wl=r.get('wiki_link','')
    if pl: links.append(f'<a class="btn" target="_blank" href="{esc(pl if pl.startswith("http") else GESTOR_URL+"/project?id="+pl)}">Abrir proyecto relacionado</a>')
    if wl: links.append(f'<a class="btn" target="_blank" href="{esc(wl if wl.startswith("http") else WIKI_URL+"/wiki/"+wl)}">Abrir Wiki relacionada</a>')
    if r.get('external_link'): links.append(f'<a class="btn" target="_blank" href="{esc(r["external_link"])}">Abrir enlace externo</a>')
    body=f'''<div class="page-head"><div><div class="eyebrow">{esc(r.get('number'))}</div><h1>{esc(r.get('title'))}</h1><div class="badges">{badge(r.get('type'))}{badge(r.get('status'))}{badge(r.get('priority'),'priority')}{badge(r.get('system'))}</div></div><div><a class="btn" href="/edit?id={esc(r['id'])}">Editar</a> <form class="inline" method="post" action="/delete" onsubmit="return confirm('¿Eliminar esta BAU?')"><input type="hidden" name="id" value="{esc(r['id'])}"><button class="btn danger">Eliminar</button></form></div></div><div class="meta-grid"><div><strong>Apertura</strong><span>{esc(r.get('opened'))}</span></div><div><strong>Resolución</strong><span>{esc(r.get('resolved') or '—')}</span></div><div><strong>Solicitante</strong><span>{esc(r.get('requester') or '—')}</span></div><div><strong>Responsable</strong><span>{esc(r.get('owner') or '—')}</span></div></div><div class="related">{''.join(links)}</div>{section('Solicitud',r.get('request'))}{section('Investigación',r.get('investigation'))}{section('Resolución',r.get('resolution'))}<section class="card"><div class="section-head"><h2>📎 Adjuntos</h2></div><div class="attachments">{attachments}</div></section><section class="card"><h2>Seguimiento</h2><form method="post" action="/comment"><input type="hidden" name="id" value="{esc(r['id'])}"><textarea name="text" rows="4" required placeholder="Añadir avance, respuesta, incidencia o decisión..."></textarea><button class="btn primary">Añadir comentario</button></form><ul class="timeline">{comments}</ul></section>'''
    return layout(r.get('number','BAU'),body)
def section(title,text): return f'<section class="card content"><h2>{title}</h2>{render(text or "Sin información.")}</section>'
def attachment_row(r,a):
    if a.get('type')=='copy': href='/attachments/'+quote(Path(a.get('stored','')).name); detail=f'{a.get("size",0)/1024:.1f} KB'
    else: href=a.get('target','#'); detail='Vínculo externo'
    return f'''<div class="attachment"><div><strong>{esc(a.get('name'))}</strong><small>{esc(detail)}</small></div><div><a class="btn small" target="_blank" href="{esc(href)}">Abrir</a><form class="inline" method="post" action="/attachment/delete" onsubmit="return confirm('¿Eliminar adjunto?')"><input type="hidden" name="id" value="{esc(r['id'])}"><input type="hidden" name="aid" value="{esc(a.get('id'))}"><button class="btn small danger">Eliminar</button></form></div></div>'''

class Handler(BaseHTTPRequestHandler):
    def send_html(self,s,status=200):
        b=s.encode(); self.send_response(status); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def redirect(self,u): self.send_response(303); self.send_header('Location',u); self.end_headers()
    def read_form(self):
        n=int(self.headers.get('Content-Length','0') or 0); return {k:v[-1] for k,v in parse_qs(self.rfile.read(n).decode('utf-8','replace')).items()}
    def multipart(self,max_size=200*1024*1024):
        ct=self.headers.get('Content-Type',''); m=re.search(r'boundary="?([^";]+)',ct); n=int(self.headers.get('Content-Length','0') or 0)
        if not m or n<=0 or n>max_size:return {},[]
        raw=self.rfile.read(n); boundary=('--'+m.group(1)).encode(); fields={}; files=[]
        for part in raw.split(boundary):
            if b'\r\n\r\n' not in part: continue
            head,body=part.split(b'\r\n\r\n',1); body=body.rstrip(b'\r\n-'); nm=re.search(br'name="([^"]+)"',head)
            if not nm: continue
            name=nm.group(1).decode('utf-8','replace'); fm=re.search(br'filename="([^"]*)"',head)
            if fm:
                fn=Path(fm.group(1).decode('utf-8','replace')).name
                if fn: files.append((name,fn,body))
            else: fields[name]=body.decode('utf-8','replace')
        return fields,files
    def do_GET(self):
        u=urlparse(self.path); qs=parse_qs(u.query)
        if u.path=='/': return self.send_html(dashboard(qs))
        if u.path=='/new': return self.send_html(form_page())
        if u.path in ('/view','/edit'):
            r=getone(qs.get('id',[''])[0])
            if not r:return self.send_error(404)
            return self.send_html(form_page(r) if u.path=='/edit' else view_page(r))
        if u.path.startswith('/static/'):
            p=(STATIC/u.path.removeprefix('/static/')).resolve()
            if STATIC.resolve() not in p.parents or not p.is_file(): return self.send_error(404)
            b=p.read_bytes(); self.send_response(200); self.send_header('Content-Type',mimetypes.guess_type(p)[0] or 'application/octet-stream'); self.send_header('Content-Length',str(len(b))); self.end_headers(); return self.wfile.write(b)
        if u.path.startswith('/attachments/'):
            p=(ATT/Path(u.path).name).resolve()
            if ATT.resolve() not in p.parents or not p.is_file():return self.send_error(404)
            b=p.read_bytes(); self.send_response(200); self.send_header('Content-Type',mimetypes.guess_type(p)[0] or 'application/octet-stream'); self.send_header('Content-Disposition',f'inline; filename="{p.name}"'); self.send_header('Content-Length',str(len(b))); self.end_headers(); return self.wfile.write(b)
        self.send_error(404)
    def do_POST(self):
        u=urlparse(self.path)
        if u.path=='/save':
            f,files=self.multipart() if 'multipart/form-data' in self.headers.get('Content-Type','') else (self.read_form(),[]); rows=load(); rid=f.get('id') or uuid.uuid4().hex; old=next((x for x in rows if x.get('id')==rid),{})
            r={**old,**{k:f.get(k,'').strip() for k in ('number','opened','status','priority','type','system','requester','owner','title','request','investigation','resolution','resolved','project_link','wiki_link','external_link')}}
            r['id']=rid; r['number']=r.get('number') or next_number(rows); r['created']=old.get('created') or now(); r['updated']=now(); r.setdefault('comments',[]); r.setdefault('attachments',[])
            for field,fn,data in files:
                if field!='attachments':continue
                safe=re.sub(r'[^A-Za-z0-9._-]+','_',fn).strip('._') or 'archivo'; stored=f'{rid}_{uuid.uuid4().hex[:8]}_{safe}'; (ATT/stored).write_bytes(data); r['attachments'].append({'id':uuid.uuid4().hex[:10],'type':'copy','name':fn,'stored':stored,'size':len(data),'added':now()})
            target=f.get('external_target','').strip()
            if target:r['attachments'].append({'id':uuid.uuid4().hex[:10],'type':'external','name':f.get('external_name','').strip() or Path(target.rstrip('/\\')).name or target,'target':target,'added':now()})
            rows=[x for x in rows if x.get('id')!=rid]+[r]; save(rows); return self.redirect('/view?id='+rid)
        f=self.read_form(); rid=f.get('id',''); rows=load(); r=next((x for x in rows if x.get('id')==rid),None)
        if u.path=='/comment' and r:
            r.setdefault('comments',[]).append({'date':now(),'text':f.get('text','').strip()}); r['updated']=now(); save(rows); return self.redirect('/view?id='+rid)
        if u.path=='/attachment/delete' and r:
            aid=f.get('aid'); kept=[]
            for a in r.get('attachments',[]):
                if a.get('id')==aid:
                    if a.get('type')=='copy':
                        try:(ATT/a.get('stored','')).unlink(missing_ok=True)
                        except OSError:pass
                else:kept.append(a)
            r['attachments']=kept; save(rows); return self.redirect('/view?id='+rid)
        if u.path=='/delete':
            for x in rows:
                if x.get('id')==rid:
                    for a in x.get('attachments',[]):
                        if a.get('type')=='copy':
                            try:(ATT/a.get('stored','')).unlink(missing_ok=True)
                            except OSError:pass
            save([x for x in rows if x.get('id')!=rid]); return self.redirect('/')
        self.send_error(404)
    def log_message(self,*args): pass
if __name__=='__main__': ThreadingHTTPServer(('127.0.0.1',int(os.environ.get('BAU_PORT','8082'))),Handler).serve_forever()
