Modulo Bitácora
Campos:
- Fecha
- Grupo
- Titulo
- Etiquetas
- Impacto
- Contenido
- Relacionado con Wiki/Proyecto/BAU
