# Placeholder Bitacora server
GROUPS=['CES','Proofpoint','Snow','Splunk','Microsoft 365','Exchange','CrowdStrike','Infraestructura','Otros']
print('Bitácora V5.5')
