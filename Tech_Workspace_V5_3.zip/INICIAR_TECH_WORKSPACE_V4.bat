@echo off
cd /d "%~dp0"
py -3 iniciar_suite.py 2>nul || python iniciar_suite.py
exit
