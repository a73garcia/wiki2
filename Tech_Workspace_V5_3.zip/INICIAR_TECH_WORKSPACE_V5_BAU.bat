@echo off
cd /d "%~dp0"
python iniciar_suite.py
if errorlevel 1 pause
