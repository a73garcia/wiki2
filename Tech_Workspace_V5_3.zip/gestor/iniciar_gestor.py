from __future__ import annotations
import os, shutil, socket, subprocess, sys, time, urllib.request, webbrowser
from pathlib import Path
BASE=Path(__file__).resolve().parent

def free_port():
    for p in range(8080,8100):
        with socket.socket() as s:
            try:s.bind(('127.0.0.1',p)); return p
            except OSError: pass
    raise RuntimeError('No hay puertos libres')
def wait(url,proc):
    for _ in range(40):
        if proc.poll() is not None:return False
        try: urllib.request.urlopen(url,timeout=1); return True
        except Exception: time.sleep(.25)
    return False
def open_browser(url):
    candidates=[]
    if os.name=='nt':
        for var in ('PROGRAMFILES','PROGRAMFILES(X86)','LOCALAPPDATA'):
            root=os.environ.get(var)
            if root:candidates.append(Path(root)/'Google/Chrome/Application/chrome.exe')
    for c in candidates:
        if c.is_file(): subprocess.Popen([str(c),url]); return
    webbrowser.open_new_tab(url)
def main():
    os.chdir(BASE); print('='*52); print('       GESTOR LOCAL DE PROYECTOS Y TAREAS'); print('='*52)
    if sys.version_info<(3,10): print('Se necesita Python 3.10 o superior.'); input(); return 1
    port=free_port(); url=f'http://127.0.0.1:{port}'; env=os.environ.copy(); env['GESTOR_PORT']=str(port)
    proc=subprocess.Popen([sys.executable,str(BASE/'server.py')],cwd=BASE,env=env)
    if not wait(url,proc): print('No se pudo iniciar.'); return 1
    open_browser(url); print(f'Aplicación disponible: {url}'); print('Cierre esta ventana o pulse Ctrl+C para detenerla.')
    try:return proc.wait()
    except KeyboardInterrupt: proc.terminate(); return 0
if __name__=='__main__': raise SystemExit(main())
