from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path
from datetime import date, datetime
import json, os, html, uuid

BASE=Path(__file__).resolve().parent
DATA=BASE/'data'; STATIC=BASE/'static'
PROJECTS=DATA/'projects.json'; TASKS=DATA/'tasks.json'
DATA.mkdir(exist_ok=True); STATIC.mkdir(exist_ok=True)
WIKI_URL=os.environ.get('WIKI_URL','http://127.0.0.1:8080')
PORTAL_URL=os.environ.get('PORTAL_URL','http://127.0.0.1:8079')
BAU_URL=os.environ.get('BAU_URL','http://127.0.0.1:8082')
WIKI_PAGES=BASE.parent/'wiki'/'data'/'pages'

def read_json(path, default):
    try: return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default
    except Exception: return default

def write_json(path, value):
    tmp=path.with_suffix('.tmp'); tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(path)

def esc(v): return html.escape(str(v or ''), quote=True)
def now(): return datetime.now().isoformat(timespec='seconds')
def uid(prefix): return prefix+'_'+uuid.uuid4().hex[:10]
def projects(): return read_json(PROJECTS, [])
def tasks(): return read_json(TASKS, [])

def layout(title, body, active='dashboard'):
    nav=[('dashboard','Inicio','/'),('projects','Proyectos','/projects'),('tasks','Tareas','/tasks'),('calendar','Calendario','/calendar')]
    links=f'<a href="{esc(PORTAL_URL)}">Inicio común</a>' + ''.join(f'<a class="{("active" if active==k else "")}" href="{u}">{t}</a>' for k,t,u in nav) + f'<a href="{esc(WIKI_URL)}">Wiki de procedimientos</a><a href="{esc(BAU_URL)}">Gestión BAU</a>'
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)} · Gestor local</title><link rel="stylesheet" href="/static/style.css"></head><body><header><div class="brand">Gestor de Proyectos</div><div class="header-actions"><a class="btn" href="{esc(WIKI_URL)}">← Wiki</a><a class="btn" href="{esc(BAU_URL)}">BAU</a><a class="btn primary" href="/project/new">+ Proyecto</a><a class="btn" href="/task/new">+ Tarea</a></div></header><div class="shell"><aside><nav>{links}</nav><div class="aside-note">Aplicación local<br>Sin usuarios<br>Datos en JSON</div></aside><main>{body}</main></div><footer>Gestor local de proyectos y tareas</footer><script src="/static/app.js"></script></body></html>'''

def badge(value, kind='status'):
    key=str(value or '').lower().replace(' ','-').replace('ó','o').replace('í','i')
    return f'<span class="badge {kind}-{esc(key)}">{esc(value)}</span>'

def dashboard():
    ps=projects(); ts=tasks(); today=date.today().isoformat()
    active=[p for p in ps if p.get('status') not in ('Finalizado','Cancelado')]
    pending=[t for t in ts if t.get('status') not in ('Completada','Cancelada')]
    overdue=[t for t in pending if t.get('due_date') and t['due_date']<today]
    done=len([t for t in ts if t.get('status')=='Completada'])
    cards=f'''<div class="stats"><div><strong>{len(active)}</strong><span>Proyectos activos</span></div><div><strong>{len(pending)}</strong><span>Tareas pendientes</span></div><div><strong>{len(overdue)}</strong><span>Tareas vencidas</span></div><div><strong>{done}</strong><span>Tareas completadas</span></div></div>'''
    recent=sorted(ps,key=lambda x:x.get('updated',''),reverse=True)[:6]
    plist=''.join(project_card(p, compact=True) for p in recent) or '<p class="empty">Todavía no hay proyectos.</p>'
    upcoming=sorted([t for t in pending if t.get('due_date')],key=lambda x:x['due_date'])[:8]
    rows=''.join(task_row(t,ps) for t in upcoming) or '<tr><td colspan="5" class="empty">No hay tareas próximas.</td></tr>'
    body=f'''<div class="page-head"><div><h1>Panel principal</h1><p>Resumen general del trabajo pendiente y los proyectos en curso.</p></div></div>{cards}<section><div class="section-head"><h2>Proyectos recientes</h2><a href="/projects">Ver todos</a></div><div class="project-grid">{plist}</div></section><section><div class="section-head"><h2>Próximas tareas</h2><a href="/tasks">Ver todas</a></div><div class="table-wrap"><table><thead><tr><th>Tarea</th><th>Proyecto</th><th>Estado</th><th>Prioridad</th><th>Vence</th></tr></thead><tbody>{rows}</tbody></table></div></section>'''
    return layout('Inicio',body)

def project_card(p, compact=False):
    progress=int(p.get('progress',0) or 0)
    return f'''<article class="project-card"><div class="card-top"><h3><a href="/project?id={esc(p['id'])}">{esc(p.get('name'))}</a></h3>{badge(p.get('status','Planificado'))}</div><p>{esc(p.get('description','Sin descripción'))}</p><div class="progress"><span style="width:{progress}%"></span></div><div class="card-meta"><span>{progress}%</span><span>{esc(p.get('start_date',''))} → {esc(p.get('end_date',''))}</span></div></article>'''

def project_list():
    ps=projects(); q=''.join(project_card(p) for p in sorted(ps,key=lambda x:x.get('updated',''),reverse=True)) or '<p class="empty">No hay proyectos creados.</p>'
    return layout('Proyectos',f'<div class="page-head"><div><h1>Proyectos</h1><p>Consulta el estado, avance y fechas de cada proyecto.</p></div><a class="btn primary" href="/project/new">Nuevo proyecto</a></div><div class="project-grid">{q}</div>','projects')

def project_form(p=None):
    p=p or {}; edit=bool(p)
    statuses=['Planificado','En curso','En pausa','Finalizado','Cancelado']; priorities=['Baja','Media','Alta','Crítica']
    opts=lambda values,current: ''.join(f'<option {"selected" if v==current else ""}>{v}</option>' for v in values)
    body=f'''<div class="page-head"><div><h1>{'Editar' if edit else 'Nuevo'} proyecto</h1><p>Información principal y planificación del proyecto.</p></div></div><form class="form-card" method="post" action="/project/save"><input type="hidden" name="id" value="{esc(p.get('id',''))}"><label class="wide">Nombre<input required name="name" value="{esc(p.get('name',''))}"></label><label class="wide">Descripción<textarea name="description" rows="4">{esc(p.get('description',''))}</textarea></label><label>Responsable<input name="owner" value="{esc(p.get('owner',''))}"></label><label>Estado<select name="status">{opts(statuses,p.get('status','Planificado'))}</select></label><label>Prioridad<select name="priority">{opts(priorities,p.get('priority','Media'))}</select></label><label>Avance (%)<input type="number" min="0" max="100" name="progress" value="{esc(p.get('progress',0))}"></label><label>Fecha de inicio<input type="date" name="start_date" value="{esc(p.get('start_date',''))}"></label><label>Fecha prevista de fin<input type="date" name="end_date" value="{esc(p.get('end_date',''))}"></label><div class="form-actions wide"><button class="btn primary">Guardar proyecto</button><a class="btn" href="/projects">Cancelar</a></div></form>'''
    return layout('Proyecto',body,'projects')

def project_detail(pid):
    ps=projects(); p=next((x for x in ps if x['id']==pid),None)
    if not p: return layout('No encontrado','<h1>Proyecto no encontrado</h1>','projects')
    related=[t for t in tasks() if t.get('project_id')==pid]; progress=int(p.get('progress',0) or 0)
    rows=''.join(task_row(t,ps) for t in related) or '<tr><td colspan="5" class="empty">Este proyecto todavía no tiene tareas.</td></tr>'
    history=p.get('history',[])
    linked_docs=[]
    if WIKI_PAGES.exists():
        for path in WIKI_PAGES.glob('*.json'):
            doc=read_json(path,{})
            if doc.get('project_id')==pid: linked_docs.append(doc)
    docs_html=''.join(f'<li class="linked-doc-item"><span class="linked-doc-dot"></span><div class="linked-doc-content"><a href="{esc(WIKI_URL)}/wiki/{esc(d.get("slug",""))}">{esc(d.get("title","Documento"))}</a><div class="linked-doc-meta"><span class="doc-category">{esc(d.get("category","General"))}</span><span>Actualizado: {esc(d.get("updated","").replace("T"," "))}</span></div></div></li>' for d in linked_docs) or '<li class="empty">No hay documentación vinculada.</li>'
    hist=''.join(f'<li><strong>{esc(h.get("date"))}</strong><p>{esc(h.get("text"))}</p></li>' for h in reversed(history)) or '<li class="empty">Sin anotaciones.</li>'
    body=f'''<div class="page-head"><div><h1>{esc(p.get('name'))}</h1><p>{esc(p.get('description'))}</p></div><div><a class="btn" href="/project/edit?id={esc(pid)}">Editar</a> <form class="inline" method="post" action="/project/delete" onsubmit="return confirm('¿Eliminar este proyecto y sus tareas?')"><input type="hidden" name="id" value="{esc(pid)}"><button class="btn danger">Eliminar</button></form></div></div><div class="detail-grid"><section class="info-card"><h2>Información</h2><dl><dt>Estado</dt><dd>{badge(p.get('status'))}</dd><dt>Prioridad</dt><dd>{badge(p.get('priority'),'priority')}</dd><dt>Responsable</dt><dd>{esc(p.get('owner') or 'Sin asignar')}</dd><dt>Fechas</dt><dd>{esc(p.get('start_date'))} → {esc(p.get('end_date'))}</dd></dl><h3>Avance: {progress}%</h3><div class="progress large"><span style="width:{progress}%"></span></div></section><section class="info-card"><h2>Añadir seguimiento</h2><form method="post" action="/project/note"><input type="hidden" name="id" value="{esc(pid)}"><textarea required name="text" rows="5" placeholder="Avance, incidencia, cambio o decisión..."></textarea><button class="btn primary">Guardar anotación</button></form></section></div><section><div class="section-head"><h2>Tareas del proyecto</h2><a class="btn" href="/task/new?project_id={esc(pid)}">Nueva tarea</a></div><div class="table-wrap"><table><thead><tr><th>Tarea</th><th>Proyecto</th><th>Estado</th><th>Prioridad</th><th>Vence</th></tr></thead><tbody>{rows}</tbody></table></div></section><section><div class="section-head"><h2>Documentación Wiki vinculada</h2><a class="btn" href="{esc(WIKI_URL)}/new">Nuevo documento</a></div><ul class="timeline">{docs_html}</ul></section><section><h2>Historial de seguimiento</h2><ul class="timeline">{hist}</ul></section>'''
    return layout(p.get('name'),body,'projects')

def task_row(t, ps):
    p=next((x for x in ps if x['id']==t.get('project_id')),None)
    return f'<tr><td><a href="/task/edit?id={esc(t["id"])}"><strong>{esc(t.get("title"))}</strong></a><small>{esc(t.get("description",""))}</small></td><td>{esc(p.get("name") if p else "Sin proyecto")}</td><td>{badge(t.get("status"))}</td><td>{badge(t.get("priority"),"priority")}</td><td>{esc(t.get("due_date") or "—")}</td></tr>'

def task_list(query):
    ps=projects(); ts=tasks(); status=query.get('status',[''])[0]; project=query.get('project',[''])[0]
    if status: ts=[t for t in ts if t.get('status')==status]
    if project: ts=[t for t in ts if t.get('project_id')==project]
    rows=''.join(task_row(t,ps) for t in sorted(ts,key=lambda x:(x.get('due_date') or '9999',x.get('title','')))) or '<tr><td colspan="5" class="empty">No hay tareas que mostrar.</td></tr>'
    popts=''.join(f'<option value="{esc(p["id"])}" {"selected" if project==p["id"] else ""}>{esc(p["name"])}</option>' for p in ps)
    sopts=''.join(f'<option {"selected" if status==s else ""}>{s}</option>' for s in ['Pendiente','En curso','Bloqueada','Completada','Cancelada'])
    body=f'''<div class="page-head"><div><h1>Tareas</h1><p>Listado general de tareas y vencimientos.</p></div><a class="btn primary" href="/task/new">Nueva tarea</a></div><form class="filters"><select name="project"><option value="">Todos los proyectos</option>{popts}</select><select name="status"><option value="">Todos los estados</option>{sopts}</select><button class="btn">Filtrar</button><a class="btn" href="/tasks">Limpiar</a></form><div class="table-wrap"><table><thead><tr><th>Tarea</th><th>Proyecto</th><th>Estado</th><th>Prioridad</th><th>Vence</th></tr></thead><tbody>{rows}</tbody></table></div>'''
    return layout('Tareas',body,'tasks')

def task_form(t=None, selected_project=''):
    t=t or {}; edit=bool(t); ps=projects(); statuses=['Pendiente','En curso','Bloqueada','Completada','Cancelada']; priorities=['Baja','Media','Alta','Crítica']
    opts=lambda values,current: ''.join(f'<option {"selected" if v==current else ""}>{v}</option>' for v in values)
    current=t.get('project_id',selected_project); popts=''.join(f'<option value="{esc(p["id"])}" {"selected" if current==p["id"] else ""}>{esc(p["name"])}</option>' for p in ps)
    body=f'''<div class="page-head"><div><h1>{'Editar' if edit else 'Nueva'} tarea</h1><p>Define el trabajo, su prioridad y fecha límite.</p></div></div><form class="form-card" method="post" action="/task/save"><input type="hidden" name="id" value="{esc(t.get('id',''))}"><label class="wide">Título<input required name="title" value="{esc(t.get('title',''))}"></label><label class="wide">Descripción<textarea name="description" rows="4">{esc(t.get('description',''))}</textarea></label><label>Proyecto<select name="project_id"><option value="">Sin proyecto</option>{popts}</select></label><label>Responsable<input name="owner" value="{esc(t.get('owner',''))}"></label><label>Estado<select name="status">{opts(statuses,t.get('status','Pendiente'))}</select></label><label>Prioridad<select name="priority">{opts(priorities,t.get('priority','Media'))}</select></label><label>Fecha de inicio<input type="date" name="start_date" value="{esc(t.get('start_date',''))}"></label><label>Fecha límite<input type="date" name="due_date" value="{esc(t.get('due_date',''))}"></label><label class="wide">Comentarios de seguimiento<textarea name="comments" rows="5">{esc(t.get('comments',''))}</textarea></label><div class="form-actions wide"><button class="btn primary">Guardar tarea</button><a class="btn" href="/tasks">Cancelar</a>{f'<button form="delete-task" type="button" class="btn danger" onclick="document.getElementById(\'delete-task\').submit()">Eliminar</button>' if edit else ''}</div></form>{f'<form id="delete-task" method="post" action="/task/delete" onsubmit="return confirm(\'¿Eliminar esta tarea?\')"><input type="hidden" name="id" value="{esc(t.get("id"))}"></form>' if edit else ''}'''
    return layout('Tarea',body,'tasks')

def calendar_view():
    ps=projects(); ts=[t for t in tasks() if t.get('due_date')]
    groups={}
    for t in ts: groups.setdefault(t['due_date'],[]).append(t)
    months={}
    for day,items in groups.items(): months.setdefault(day[:7],[]).append((day,items))
    content=''
    for month in sorted(months):
        content+=f'<section><h2>{esc(month)}</h2><div class="calendar-list">'
        for day,items in sorted(months[month]):
            content+=f'<div class="calendar-day"><strong>{esc(day)}</strong><div>' + ''.join(f'<a href="/task/edit?id={esc(t["id"])}">{esc(t["title"])} {badge(t.get("status"))}</a>' for t in items) + '</div></div>'
        content+='</div></section>'
    if not content: content='<p class="empty">No hay tareas con fecha límite.</p>'
    return layout('Calendario',f'<div class="page-head"><div><h1>Calendario</h1><p>Fechas límite agrupadas por mes.</p></div></div>{content}','calendar')

class Handler(BaseHTTPRequestHandler):
    def send_html(self, text, code=200):
        data=text.encode('utf-8'); self.send_response(code); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def redirect(self, url): self.send_response(303); self.send_header('Location',url); self.end_headers()
    def form(self):
        n=int(self.headers.get('Content-Length','0')); raw=self.rfile.read(n).decode(); return {k:v[0] for k,v in parse_qs(raw).items()}
    def do_GET(self):
        u=urlparse(self.path); q=parse_qs(u.query)
        if u.path.startswith('/static/'):
            path=STATIC/u.path.split('/')[-1]
            if path.exists():
                data=path.read_bytes(); self.send_response(200); self.send_header('Content-Type','text/css' if path.suffix=='.css' else 'application/javascript'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        routes={'/':dashboard,'/projects':project_list,'/tasks':lambda:task_list(q),'/calendar':calendar_view,'/project/new':project_form,'/task/new':lambda:task_form(selected_project=q.get('project_id',[''])[0])}
        if u.path in routes: self.send_html(routes[u.path]()); return
        if u.path=='/project': self.send_html(project_detail(q.get('id',[''])[0])); return
        if u.path=='/project/edit':
            p=next((x for x in projects() if x['id']==q.get('id',[''])[0]),None); self.send_html(project_form(p)); return
        if u.path=='/task/edit':
            t=next((x for x in tasks() if x['id']==q.get('id',[''])[0]),None); self.send_html(task_form(t)); return
        self.send_html(layout('No encontrado','<h1>Página no encontrada</h1>'),404)
    def do_POST(self):
        f=self.form()
        if self.path=='/project/save':
            ps=projects(); pid=f.get('id') or uid('prj'); old=next((x for x in ps if x['id']==pid),{})
            p={**old,'id':pid,'name':f.get('name','').strip(),'description':f.get('description','').strip(),'owner':f.get('owner','').strip(),'status':f.get('status','Planificado'),'priority':f.get('priority','Media'),'progress':max(0,min(100,int(f.get('progress','0') or 0))),'start_date':f.get('start_date',''),'end_date':f.get('end_date',''),'history':old.get('history',[]),'created':old.get('created',now()),'updated':now()}
            ps=[p if x['id']==pid else x for x in ps] if old else ps+[p]; write_json(PROJECTS,ps); self.redirect('/project?id='+pid); return
        if self.path=='/project/delete':
            pid=f.get('id'); write_json(PROJECTS,[p for p in projects() if p['id']!=pid]); write_json(TASKS,[t for t in tasks() if t.get('project_id')!=pid]); self.redirect('/projects'); return
        if self.path=='/project/note':
            ps=projects(); pid=f.get('id'); text=f.get('text','').strip()
            for p in ps:
                if p['id']==pid and text: p.setdefault('history',[]).append({'date':datetime.now().strftime('%Y-%m-%d %H:%M'),'text':text}); p['updated']=now()
            write_json(PROJECTS,ps); self.redirect('/project?id='+pid); return
        if self.path=='/task/save':
            ts=tasks(); tid=f.get('id') or uid('tsk'); old=next((x for x in ts if x['id']==tid),{})
            t={**old,'id':tid,'title':f.get('title','').strip(),'description':f.get('description','').strip(),'project_id':f.get('project_id',''),'owner':f.get('owner','').strip(),'status':f.get('status','Pendiente'),'priority':f.get('priority','Media'),'start_date':f.get('start_date',''),'due_date':f.get('due_date',''),'comments':f.get('comments','').strip(),'created':old.get('created',now()),'updated':now()}
            ts=[t if x['id']==tid else x for x in ts] if old else ts+[t]; write_json(TASKS,ts); self.redirect('/tasks'); return
        if self.path=='/task/delete':
            write_json(TASKS,[t for t in tasks() if t['id']!=f.get('id')]); self.redirect('/tasks'); return
        self.redirect('/')
    def log_message(self,*args): pass

if __name__=='__main__':
    port=int(os.environ.get('GESTOR_PORT','8080')); print(f'Gestor disponible en http://127.0.0.1:{port}'); ThreadingHTTPServer(('127.0.0.1',port),Handler).serve_forever()
