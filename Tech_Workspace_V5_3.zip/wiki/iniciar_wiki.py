from __future__ import annotations
import os, shutil, socket, subprocess, sys, time, urllib.request, webbrowser
from pathlib import Path
BASE_DIR=Path(__file__).resolve().parent
SERVER_FILE=BASE_DIR/'server.py'

def pause(message='Pulse INTRO para cerrar...'):
    try: input('\n'+message)
    except (EOFError,KeyboardInterrupt): pass

def find_free_port():
    for port in range(8080,8100):
        with socket.socket() as sock:
            try: sock.bind(('127.0.0.1',port)); return port
            except OSError: pass
    raise RuntimeError('No hay puertos libres entre 8080 y 8099')

def wait_ready(url,process):
    end=time.time()+15
    while time.time()<end:
        if process.poll() is not None: return False
        try:
            with urllib.request.urlopen(url,timeout=1) as response:
                return 200 <= response.status < 500
        except Exception: time.sleep(.35)
    return False

def chrome_candidates():
    values=[]
    if os.name=='nt':
        for var in ('PROGRAMFILES','PROGRAMFILES(X86)','LOCALAPPDATA'):
            base=os.environ.get(var)
            if base: values.append(str(Path(base)/'Google'/'Chrome'/'Application'/'chrome.exe'))
    values += [x for x in (shutil.which('google-chrome'),shutil.which('google-chrome-stable'),shutil.which('chrome'),shutil.which('chromium')) if x]
    return values

def open_browser(url):
    for chrome in chrome_candidates():
        if Path(chrome).is_file():
            try:
                subprocess.Popen([chrome,url],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
                return 'Google Chrome'
            except OSError: pass
    webbrowser.open_new_tab(url)
    return 'navegador predeterminado'

def main():
    os.chdir(BASE_DIR)
    print('='*48); print('          WIKI DE PROCEDIMIENTOS'); print('='*48)
    print(f'Carpeta....... {BASE_DIR}')
    print(f'Python........ {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}')
    if sys.version_info < (3,10): print('ERROR: se necesita Python 3.10 o superior.'); pause(); return 1
    if not SERVER_FILE.exists(): print('ERROR: no se encuentra server.py'); pause(); return 1
    try: port=find_free_port()
    except RuntimeError as exc: print(f'ERROR: {exc}'); pause(); return 1
    url=f'http://127.0.0.1:{port}'
    env=os.environ.copy(); env['WIKI_PORT']=str(port)
    flags=getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0) if os.name=='nt' else 0
    try: process=subprocess.Popen([sys.executable,str(SERVER_FILE)],cwd=str(BASE_DIR),env=env,creationflags=flags)
    except OSError as exc: print(f'ERROR al iniciar el servidor: {exc}'); pause(); return 1
    if not wait_ready(url,process):
        print('No se pudo iniciar la wiki.')
        if process.poll() is None: process.terminate()
        pause(); return 1
    browser=open_browser(url)
    print(f'Wiki disponible: {url}'); print(f'Navegador..... {browser}'); print('Se ha abierto una única pestaña.')
    print('\nPara detener la wiki, cierre esta ventana o pulse Ctrl+C.')
    try: return process.wait()
    except KeyboardInterrupt:
        print('\nCerrando Wiki Procedimientos...'); process.terminate()
        try: process.wait(timeout=5)
        except subprocess.TimeoutExpired: process.kill()
        return 0
if __name__=='__main__': raise SystemExit(main())
