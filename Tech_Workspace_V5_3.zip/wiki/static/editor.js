document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.copy-code').forEach(button => {
    button.addEventListener('click', async () => {
      const code = button.closest('.code-wrap').querySelector('code').innerText;
      await navigator.clipboard.writeText(code);
      const old = button.textContent;
      button.textContent = 'Copiado';
      setTimeout(() => button.textContent = old, 1200);
    });
  });

  const textarea = document.getElementById('content-editor');
  if (!textarea) return;
  const fileInput = document.getElementById('image-file');
  const imageButton = document.getElementById('insert-image-button');
  const status = document.getElementById('image-upload-status');

  const insertAtCursor = (text, wrap = false) => {
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selected = textarea.value.slice(start, end);
    const value = wrap ? text + selected + text : text;
    textarea.setRangeText(value, start, end, 'end');
    textarea.focus();
  };

  document.querySelectorAll('[data-insert]').forEach(btn => btn.addEventListener('click', () => insertAtCursor(btn.dataset.insert)));
  document.querySelectorAll('[data-wrap]').forEach(btn => btn.addEventListener('click', () => insertAtCursor(btn.dataset.wrap, true)));
  document.querySelectorAll('[data-wrap-open]').forEach(btn => btn.addEventListener('click', () => {
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selected = textarea.value.slice(start, end);
    textarea.setRangeText((btn.dataset.wrapOpen || '') + selected + (btn.dataset.wrapClose || ''), start, end, 'end');
    textarea.focus();
  }));
  document.querySelectorAll('[data-code]').forEach(btn => btn.addEventListener('click', () => insertAtCursor(`\n\n\`\`\`${btn.dataset.code}\n\n\`\`\`\n\n`)));

  const changeIndentation = (remove = false) => {
    const value = textarea.value;
    const originalStart = textarea.selectionStart;
    const originalEnd = textarea.selectionEnd;
    const lineStart = value.lastIndexOf('\n', Math.max(0, originalStart - 1)) + 1;
    let lineEnd = value.indexOf('\n', originalEnd);
    if (lineEnd === -1) lineEnd = value.length;

    const block = value.slice(lineStart, lineEnd);
    const lines = block.split('\n');
    let removedFromFirstLine = 0;
    let totalDelta = 0;

    const changed = lines.map((line, index) => {
      if (!remove) {
        totalDelta += 4;
        return '    ' + line;
      }
      let count = 0;
      if (line.startsWith('\t')) count = 1;
      else {
        const match = line.match(/^ {1,4}/);
        count = match ? match[0].length : 0;
      }
      if (index === 0) removedFromFirstLine = count;
      totalDelta -= count;
      return line.slice(count);
    }).join('\n');

    textarea.setRangeText(changed, lineStart, lineEnd, 'select');
    if (!remove) {
      textarea.selectionStart = originalStart + 4;
      textarea.selectionEnd = originalEnd + (4 * lines.length);
    } else {
      textarea.selectionStart = Math.max(lineStart, originalStart - removedFromFirstLine);
      textarea.selectionEnd = Math.max(textarea.selectionStart, originalEnd + totalDelta);
    }
    textarea.focus();
    textarea.dispatchEvent(new Event('input', {bubbles: true}));
  };

  document.getElementById('indent-button')?.addEventListener('click', () => changeIndentation(false));
  document.getElementById('outdent-button')?.addEventListener('click', () => changeIndentation(true));

  textarea.addEventListener('keydown', event => {
    if (event.key !== 'Tab') return;
    event.preventDefault();
    changeIndentation(event.shiftKey);
  });

  async function uploadAndInsert(file) {
    if (!file || !file.type.startsWith('image/')) return;
    const cursor = textarea.selectionStart;
    status.textContent = 'Subiendo imagen…'; status.className = 'upload-status working';
    const form = new FormData(); form.append('image', file);
    try {
      const response = await fetch('/upload-image', {method:'POST', body:form});
      const result = await response.json();
      if (!response.ok || !result.ok) throw new Error(result.error || 'No se pudo subir la imagen.');
      const description = file.name.replace(/\.[^.]+$/, '').replace(/[-_]+/g, ' ');
      const snippet = `\n\n[[imagen:${result.filename}|${description}]]\n\n`;
      textarea.setRangeText(snippet, cursor, cursor, 'end'); textarea.focus();
      status.textContent = 'Imagen insertada.'; status.className = 'upload-status success';
    } catch (error) {
      status.textContent = error.message; status.className = 'upload-status error';
    }
  }

  imageButton?.addEventListener('click', () => { fileInput.value = ''; fileInput.click(); });
  fileInput?.addEventListener('change', () => uploadAndInsert(fileInput.files?.[0]));
  textarea.addEventListener('paste', event => {
    const image = [...(event.clipboardData?.items || [])].find(item => item.type.startsWith('image/'));
    if (image) { event.preventDefault(); uploadAndInsert(image.getAsFile()); }
  });
  textarea.addEventListener('dragover', event => { if ([...(event.dataTransfer?.files || [])].some(f => f.type.startsWith('image/'))) event.preventDefault(); });
  textarea.addEventListener('drop', event => {
    const image = [...(event.dataTransfer?.files || [])].find(f => f.type.startsWith('image/'));
    if (image) { event.preventDefault(); uploadAndInsert(image); }
  });
});

// Adjuntos: selección múltiple y arrastrar/soltar en el editor.
document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('attachment-files');
  const zone = document.getElementById('attachment-dropzone');
  const list = document.getElementById('selected-attachments');
  if (!input || !zone || !list) return;
  const renderFiles = () => {
    const files = Array.from(input.files || []);
    if (!files.length) { list.textContent = 'Ningún archivo seleccionado.'; return; }
    const total = files.reduce((sum, f) => sum + f.size, 0);
    list.innerHTML = '<strong>' + files.length + ' archivo(s), ' + (total / 1024 / 1024).toFixed(2) + ' MB</strong><ul>' +
      files.map(f => '<li>' + f.name.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])) + '</li>').join('') + '</ul>';
  };
  input.addEventListener('change', renderFiles);
  ['dragenter','dragover'].forEach(type => zone.addEventListener(type, e => { e.preventDefault(); zone.classList.add('dragover'); }));
  ['dragleave','drop'].forEach(type => zone.addEventListener(type, e => { e.preventDefault(); zone.classList.remove('dragover'); }));
  zone.addEventListener('drop', e => {
    if (!e.dataTransfer || !e.dataTransfer.files.length) return;
    try { input.files = e.dataTransfer.files; renderFiles(); }
    catch (_) { /* Algunos navegadores no permiten asignar FileList; el selector normal sigue disponible. */ }
  });
});
