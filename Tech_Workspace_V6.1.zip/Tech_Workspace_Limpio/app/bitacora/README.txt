CUADERNO DE BITÁCORA

Módulo integrado en Tech Workspace para registrar novedades y apuntes técnicos.

Funciones:
- Entradas con fecha, grupo, título, etiquetas y contenido.
- Grupos: CES, Proofpoint, Snow, Splunk, Microsoft 365, Exchange,
  CrowdStrike, Infraestructura, Power Automate, Scripts y Otros.
- Búsqueda y filtros por grupo y fecha.
- Editor técnico con títulos, listas, colores, resaltado, notas,
  advertencias, bloques de código e imágenes.
- Enlaces relacionados con Wiki, BAU y recursos externos.
- Creación, edición y eliminación de entradas.
- Datos guardados localmente en data/entries.json.
