from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path
import json, html, os
BASE=Path(__file__).resolve().parent
WIKI_PAGES=BASE/'wiki'/'data'/'pages'; PROJECTS=BASE/'gestor'/'data'/'projects.json'; TASKS=BASE/'gestor'/'data'/'tasks.json'; BAU=BASE/'bau'/'data'/'requests.json'; BITACORA=BASE/'bitacora'/'data'/'entries.json'
WIKI_URL=os.environ.get('WIKI_URL','http://127.0.0.1:8080'); GESTOR_URL=os.environ.get('GESTOR_URL','http://127.0.0.1:8081'); BAU_URL=os.environ.get('BAU_URL','http://127.0.0.1:8082'); BITACORA_URL=os.environ.get('BITACORA_URL','http://127.0.0.1:8083')
def read(path,default):
    try:return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default
    except Exception:return default
def pages():
    out=[]
    for p in (WIKI_PAGES.glob('*.json') if WIKI_PAGES.exists() else []):
        d=read(p,{})
        if d:out.append(d)
    return out
def layout(body):
    return f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Tech Workspace v5</title><style>
*{{box-sizing:border-box}}body{{margin:0;font:14px Arial;color:#26384a;background:#f3f6f9}}header{{background:#25364a;color:white;padding:18px 5%;display:flex;justify-content:space-between;align-items:center}}header h1{{margin:0;font-size:22px}}nav a{{color:white;text-decoration:none;margin-left:18px}}main{{max-width:1180px;margin:28px auto;padding:0 20px}}.hero,.card{{background:white;border:1px solid #d9e1e8;border-radius:9px;padding:22px;box-shadow:0 2px 8px #0001}}.hero{{margin-bottom:20px}}.search{{display:flex;gap:8px}}input{{flex:1;padding:12px;border:1px solid #bfcbd6;border-radius:5px}}button,.btn{{padding:11px 15px;border:0;border-radius:5px;background:#315f8d;color:white;text-decoration:none;cursor:pointer}}.stats,.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px;margin:18px 0}}.stat strong{{font-size:30px;display:block}}.stat span,small,p{{color:#607080}}h2{{margin-top:0}}.result{{border-top:1px solid #e3e8ed;padding:14px 0}}.result:first-child{{border-top:0}}.tag{{font-size:11px;background:#e8eef4;padding:3px 6px;border-radius:10px}}@media(max-width:650px){{header{{display:block}}nav{{margin-top:10px}}nav a{{margin:0 14px 0 0}}}}</style></head><body><header><h1>Tech Workspace v5</h1><nav><a href="/">Inicio</a><a href="{WIKI_URL}">Wiki</a><a href="{GESTOR_URL}">Proyectos y tareas</a><a href="{BAU_URL}">BAU</a><a href="{BITACORA_URL}">Bitácora</a></nav></header><main>{body}</main></body></html>'''
def home():
    ps=read(PROJECTS,[]); ts=read(TASKS,[]); docs=pages(); bau=read(BAU,[]); bitacora=read(BITACORA,[]); pending=[t for t in ts if t.get('status') not in ('Completada','Cancelada')]
    search='<div class="hero"><h2>Buscador global</h2><form class="search" action="/search"><input name="q" placeholder="Buscar en documentos, proyectos, tareas y comentarios"><button>Buscar</button></form></div>'
    stats=f'<div class="stats"><div class="card stat"><strong>{len(docs)}</strong><span>Documentos Wiki</span></div><div class="card stat"><strong>{len(ps)}</strong><span>Proyectos</span></div><div class="card stat"><strong>{len(pending)}</strong><span>Tareas pendientes</span></div><div class="card stat"><strong>{len([t for t in ts if t.get("status")=="Completada"])}</strong><span>Tareas completadas</span></div><div class="card stat"><strong>{len([r for r in bau if r.get("status") not in ("Resuelta","Cerrada")])}</strong><span>BAU pendientes</span></div><div class="card stat"><strong>{len(bitacora)}</strong><span>Entradas de Bitácora</span></div></div>'
    cards=f'<div class="grid"><section class="card"><h2>Wiki técnica</h2><p>Procedimientos, consultas, notas y documentación vinculable a proyectos.</p><a class="btn" href="{WIKI_URL}">Abrir Wiki</a></section><section class="card"><h2>Gestión de proyectos</h2><p>Proyectos, tareas, prioridades, seguimiento, calendario y documentación relacionada.</p><a class="btn" href="{GESTOR_URL}">Abrir gestor</a></section><section class="card"><h2>Gestión BAU</h2><p>Peticiones, incidencias, consultas, cambios, resolución, seguimiento y adjuntos.</p><a class="btn" href="{BAU_URL}">Abrir BAU</a></section><section class="card"><h2>Cuaderno de Bitácora</h2><p>Novedades y apuntes técnicos organizados por fecha y grupo.</p><a class="btn" href="{BITACORA_URL}">Abrir Bitácora</a></section></div>'
    return layout(search+stats+cards)
def search(q):
    term=q.strip().casefold(); results=[]
    if term:
        for d in pages():
            if term in ' '.join([d.get('title',''),d.get('category',''),d.get('content',''),' '.join(d.get('tags',[]))]).casefold(): results.append(('Documento',d.get('title',''),f'{WIKI_URL}/wiki/{d.get("slug","")}',d.get('category','')))
        for p in read(PROJECTS,[]):
            if term in ' '.join([p.get('name',''),p.get('description',''),p.get('owner',''),' '.join(x.get('text','') for x in p.get('history',[]))]).casefold(): results.append(('Proyecto',p.get('name',''),f'{GESTOR_URL}/project?id={p.get("id","")}',p.get('status','')))
        for t in read(TASKS,[]):
            if term in ' '.join([t.get('title',''),t.get('description',''),t.get('comments',''),t.get('owner','')]).casefold(): results.append(('Tarea',t.get('title',''),f'{GESTOR_URL}/task/edit?id={t.get("id","")}',t.get('status','')))
        for r in read(BAU,[]):
            if term in ' '.join(str(r.get(k,'')) for k in ('number','title','request','investigation','resolution','requester','owner','system')).casefold(): results.append(('BAU',f'{r.get("number","")} · {r.get("title","")}',f'{BAU_URL}/view?id={r.get("id","")}',r.get('status','')))
        for r in read(BITACORA,[]):
            if term in ' '.join(str(r.get(k,'')) for k in ('title','group','content','tags','wiki_link','bau_link')).casefold(): results.append(('Bitácora',r.get('title',''),f'{BITACORA_URL}/view?id={r.get("id","")}',f'{r.get("date","")} · {r.get("group","")}'))
    rows=''.join(f'<div class="result"><span class="tag">{html.escape(k)}</span> <a href="{html.escape(u,quote=True)}"><strong>{html.escape(title)}</strong></a><p>{html.escape(meta)}</p></div>' for k,title,u,meta in results) or '<p>No se encontraron coincidencias.</p>'
    return layout(f'<div class="hero"><h2>Resultados para “{html.escape(q)}”</h2><form class="search" action="/search"><input name="q" value="{html.escape(q,quote=True)}"><button>Buscar</button></form></div><section class="card">{rows}</section>')
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        u=urlparse(self.path); q=parse_qs(u.query).get('q',[''])[0]
        body=search(q) if u.path=='/search' else home(); data=body.encode('utf-8')
        self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def log_message(self,*args):pass
if __name__=='__main__':ThreadingHTTPServer(('127.0.0.1',int(os.environ.get('PORTAL_PORT','8079'))),Handler).serve_forever()
